import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_BUILD_COMMIT": "0daf97427d42-dirty", "VITE_BUILD_DATE": "2026-10-13"};// Cut 30 §3 — the town hub (docs/TOWN.md, targets art/ui/targets/town/): the camp as a place. A fixed tile map with named plots and
// a path graph; `townState(lineage, absence)` turns the core's `Lineage.town` into what stands and what walks (buildings with their
// look, the next plot staked, the hero's loop, the absence's parties walking out of the mouth, pets, markers); the view draws it in
// the pixel pipeline's register — one low-res target of town texels (a cached terrain bitmap and instanced sprite quads, `layers.ts`), upscaled k× with nearest
// sampling, lit by a small light pass (the fire, the mouth's torches, the forge, windows at night; day and night from the local
// clock). The Canvas-2D fallback (`view2d.ts` `drawTown2D`) draws the same frame while the GL context is lost or when none exists.
//
// Coordinates: texels, x right, y DOWN the map (a tile is 16 texels); three's world is (x, −y). Every sprite is anchored at its foot
// (bottom centre) and depth-sorted by foot y. Walkers are cosmetic: seeded by the lineage's seed + the local day, never read back.
// Art never blocks the scene: every sprite id has a primitive fallback (a coloured block in the thing's shape) until the atlas has it.
import * as THREE from "/node_modules/.vite/deps/three.js?v=57bd4be0";
import { QuadLayer, BAYER_GLSL } from "/src/render/layers.ts";
import { drawTown2D } from "/src/render/view2d.ts";
import { paintTownTerrain, terrainMaterialVersion, townGrassRoots } from "/src/render/town-terrain.ts";
import { effectsLevel } from "/src/render/fxpref.ts";
import { paintHomeService } from "/src/render/home-service-art.ts";
import { volumeKind, VOLUME_GLSL } from "/src/render/town-volume.ts";
import LIGHTS from "/src/render/town_lights.json?import";
export const TILE = 16;
export const MAP_W = 56, MAP_H = 40;
const CX = 28, OY = 5;
const T = (x, y) => ({
	x: x * TILE,
	y: (y + OY) * TILE
});
// ---- the map: plots, paths -------------------------------------------------------------------------------------------------
export const BUILDINGS = [
	"blacksmith",
	"kennel",
	"bank"
];
export const SERVICE_PLOTS = {
	guild: {
		x: 386,
		y: 402,
		h: 42
	},
	pool: {
		x: 356,
		y: 338,
		h: 22
	},
	device: {
		x: 568,
		y: 318,
		h: 36
	}
};
/** each plot's foot (texels) and its drawn height */
export const PLOTS = {
	...SERVICE_PLOTS,
	mouth: {
		...T(CX, 6.6),
		h: 64
	},
	fire: {
		...T(CX, 14.7),
		h: 16
	},
	tent: {
		...T(CX + 3.3, 14),
		h: 32
	},
	house: {
		...T(CX + 3.3, 14),
		h: 56
	},
	crate: {
		...T(CX + 5, 14.9),
		h: 16
	},
	board: {
		...T(CX - 2.2, 7.6),
		h: 28
	},
	blacksmith: {
		...T(CX - 4.6, 10.7),
		h: 64
	},
	bank: {
		...T(CX + 4.6, 10.7),
		h: 64
	},
	kennel: {
		...T(CX + 4.7, 19.8),
		h: 64
	}
};
const NODES = {
	in: T(CX, 6.3),
	mouth: T(CX, 7.5),
	cross: T(CX, 11.6),
	smith: T(CX - 4.4, 11),
	bank: T(CX + 4.4, 11),
	fireN: T(CX, 13.1),
	fireW: T(CX - 1.5, 14.95),
	fireE: T(CX + 1.5, 14.95),
	tent: T(CX + 2.45, 14.45),
	crate: T(CX + 4.3, 15.55),
	fireS: T(CX, 16.7),
	south: T(CX, 18.6),
	kennel: T(CX + 4.3, 20.1),
	exit: T(CX, 25),
	guild: {
		x: 386,
		y: 410
	},
	pool: {
		x: 356,
		y: 353
	},
	device: {
		x: 568,
		y: 330
	}
};
const EDGES = [
	[
		"in",
		"mouth",
		.9
	],
	[
		"mouth",
		"cross",
		.8
	],
	[
		"cross",
		"smith",
		.5
	],
	[
		"cross",
		"bank",
		.5
	],
	[
		"cross",
		"fireN",
		.8
	],
	[
		"fireN",
		"fireW",
		.55
	],
	[
		"fireN",
		"fireE",
		.55
	],
	[
		"fireE",
		"tent",
		.5
	],
	[
		"tent",
		"crate",
		.45
	],
	[
		"fireW",
		"fireS",
		.55
	],
	[
		"fireE",
		"fireS",
		.55
	],
	[
		"fireS",
		"south",
		.7
	],
	[
		"south",
		"kennel",
		.5
	],
	[
		"south",
		"exit",
		.7
	],
	[
		"south",
		"guild",
		.4
	],
	[
		"fireW",
		"pool",
		.4
	],
	[
		"crate",
		"device",
		.4
	]
];
const ADJ = new Map();
for (const [a, b] of EDGES) {
	ADJ.set(a, [...ADJ.get(a) ?? [], b]);
	ADJ.set(b, [...ADJ.get(b) ?? [], a]);
}
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
/** the shortest route between two nodes (Dijkstra over the path graph), as points */
export function route(from, to) {
	const d = new Map([[from, 0]]), prev = new Map(), open = new Set([from]);
	while (open.size) {
		let u = "";
		let best = Infinity;
		for (const n of open) if ((d.get(n) ?? Infinity) < best) {
			best = d.get(n);
			u = n;
		}
		open.delete(u);
		if (u === to) break;
		for (const v of ADJ.get(u) ?? []) {
			const nd = best + dist(NODES[u], NODES[v]);
			if (nd < (d.get(v) ?? Infinity)) {
				d.set(v, nd);
				prev.set(v, u);
				open.add(v);
			}
		}
	}
	const out = [to];
	while (out[0] !== from) {
		const p = prev.get(out[0]);
		if (!p) return [NODES[from], NODES[to]];
		out.unshift(p);
	}
	return out.map((n) => NODES[n]);
}
const nearestNode = (p) => {
	let b = "fireN", bd = Infinity;
	for (const [k, n] of Object.entries(NODES)) {
		if (k === "in" || k === "exit") continue;
		const e = dist(p, n);
		if (e < bd) {
			bd = e;
			b = k;
		}
	}
	return b;
};
/** the chest's foot, beside the path under the mouth */
export const CHEST_AT = {
	...T(CX + 1.6, 8.3),
	h: 12
};
/** a worker's spot (texels, its foot): by id, else by its post's plot — art/town-ids.md's posts (the sheet's units × ~0.6 onto the map's
*  tiles), the herald and the scout moved to the map's own board (left of the mouth) */
const WORKER_AT = {
	quartermaster: T(CX + 4.9, 15.7),
	porter: T(CX + 1.1, 10.2),
	scout: {
		x: SERVICE_PLOTS.guild.x + 13,
		y: SERVICE_PLOTS.guild.y + 7
	},
	apprentice: T(CX - 1.9, 11.6),
	clerk: T(CX + 2.8, 11.7),
	drillmaster: T(CX + 1.4, 16.3),
	kennel_hand: T(CX + 2.4, 19.7),
	herald: T(CX - 3.6, 7.9),
	guide: T(CX + 1.65, 7.35)
};
const PROPS = [
	{
		id: "town_woodpile",
		...T(CX - 2.75, 13.95),
		h: 13,
		stage: 0
	},
	{
		id: "town_lamppost",
		...T(CX + 1.3, 12.35),
		h: 26,
		stage: 1,
		lamp: true
	},
	{
		id: "town_well",
		...T(CX - 2.9, 17.1),
		h: 26,
		stage: 2
	},
	{
		id: "town_lamppost",
		...T(CX - 1.25, 21.9),
		h: 26,
		stage: 2,
		lamp: true
	},
	{
		id: "town_stall",
		...T(CX + 3.1, 22.6),
		h: 34,
		stage: 3
	},
	{
		id: "town_cart",
		...T(CX - 3.3, 22.9),
		h: 20,
		stage: 3,
		flip: true
	},
	{
		id: "town_lamppost",
		...T(CX + 1.25, 26.4),
		h: 26,
		stage: BUILDINGS.length,
		lamp: true
	}
];
/** Cut 109: townsfolk by stage (docs/TOWN.md §3: "townsfolk multiply with the houses") — cosmetic, seeded, never read back */
const FOLK_AT = {
	smith: T(CX - 6, 11.35),
	merchant: T(CX + 4.75, 22.75)
};
export const workerAt = (w) => WORKER_AT[w.id] ?? PLOTS[w.post] ?? null;
/** a worker's frames (art/town-ids.md: `town_worker_<id>`, `_1` the idle beat) */
export const workerIds = (id, frame = 0) => frame ? [`town_worker_${id}_1`, `town_worker_${id}`] : [`town_worker_${id}`];
/** Stable grounds allocated to actual roster IDs, unaffected by selected/away state. */
export function homeResidentSpots(s) {
	const ids = [...s.roster ?? s.residents?.map((r) => r.id) ?? [s.selectedHero ?? 1]].sort((a, b) => a - b);
	return ids.map((id, index) => ({
		id,
		pool: index === 0 ? {
			x: 306,
			y: 348
		} : {
			x: 306 + (index - 1) * 72,
			y: 420
		},
		device: index === 0 ? {
			x: 580,
			y: 348
		} : {
			x: 580 - (index - 1) * 72,
			y: 420
		}
	}));
}
/** Only state transitions observed by this mounted view produce construction FX. */
export function constructionChanges(prev, next) {
	if (!prev) return [];
	const changes = [];
	if (!prev.home && next.home) changes.push({ id: "house" });
	else if (prev.home && next.home && houseLook(next) > houseLook(prev)) changes.push({
		id: "house",
		fromLook: houseLook(prev)
	});
	for (const building of next.buildings) {
		const old = prev.buildings.find((b) => b.id === building.id);
		if (!old) changes.push({ id: building.id });
		else if (building.look > old.look) changes.push({
			id: building.id,
			fromLook: old.look
		});
	}
	return changes;
}
const BUILD_ASSEMBLY_S = 1.2, BUILD_FX_S = 2.2;
const hashN = (...xs) => {
	let h = 2166136261;
	for (const x of xs) {
		h ^= x | 0;
		h = Math.imul(h, 16777619);
		h ^= h >>> 13;
	}
	return h >>> 0;
};
export const localDay = (now = new Date()) => Math.floor((now.getTime() - now.getTimezoneOffset() * 6e4) / 864e5);
/** Local wall clock, sampled once; lighting stays continuous across minute boundaries. */
export const localHour = (now = new Date()) => now.getHours() + now.getMinutes() / 60 + now.getSeconds() / 3600 + now.getMilliseconds() / 36e5;
const PARTIES_MAX = 6;
/** Cut 109: the hero's house grows with the town (cottage · lean-to · two storeys at2 and all remaining facilities standing) — a look, no rule */
export const houseLook = (s) => s.stage >= BUILDINGS.length ? 3 : s.stage >= 2 ? 2 : 1;
/** The core's town (`Lineage.town`) and the absence's report → the scene. Pure (walkers are seeded, never read back). */
export function townState(L, absence, o = {}) {
	const town = L.town;
	const built = (town?.buildings ?? []).filter((b) => BUILDINGS.includes(b.id));
	const seen = new Set(o.seen ?? built.map((b) => b.id));
	const buildings = built.map((b) => ({
		id: b.id,
		look: Math.max(1, Math.min(3, b.level || 1)),
		fresh: !seen.has(b.id)
	}));
	const has = (id) => buildings.some((b) => b.id === id);
	const next = town?.next && (town.next === "house" || BUILDINGS.includes(town.next)) && !has(town.next) ? {
		id: town.next,
		trigger: town.next_trigger ?? "",
		ready: town.next_ready
	} : undefined;
	const day = localDay(o.now);
	const seed = hashN(L.seed ?? 0, day);
	// the absence's parties: one per run that came home (a death walks nobody out), the biggest first, ≤ PARTIES_MAX
	const parties = [];
	if (absence) {
		const exits = (absence.exits ?? []).filter((x) => !x.cause && (x.keep_pct > 0 || x.kept > 0) && !/^died\b/.test(x.text));
		const home = exits.length ? exits.map((x) => x.kept) : Array.from({ length: Math.min(PARTIES_MAX, Math.max(0, (absence.returned ?? 0) + (absence.banked ?? 0))) }, () => Math.round((absence.gold?.home ?? 0) / Math.max(1, (absence.returned ?? 0) + (absence.banked ?? 0))));
		const order = home.map((g, i) => ({
			g,
			i
		})).sort((a, b) => b.g - a.g || a.i - b.i).slice(0, PARTIES_MAX).sort((a, b) => a.i - b.i);
		const finds = (absence.found?.length ?? 0) > 0 || (absence.new_finds?.length ?? 0) > 0;
		const tame = absence.tamed?.[0];
		const big = Math.max(60, ...home) * .5;
		order.forEach(({ g }, k) => {
			const chest = finds && k === order.length - 1, pet = tame && k === 0 ? tame : undefined;
			parties.push({
				at: 0,
				cls: L.class,
				sack: g <= 0 ? undefined : g >= big ? "large" : "small",
				chest,
				pet,
				to: "tent"
			});
		});
		// ~20 s in all, ≤ 3 on screen (a walk out is ~6 s)
		const span = 20 - 6, gap = parties.length > 1 ? Math.max(2.2, span / (parties.length - 1)) : 0;
		parties.forEach((p, i) => {
			p.at = .6 + i * gap;
		});
	}
	// markers (≤ 3): a sword over the forge when a kit step is affordable, a coin over the bank when a night's interest came in, a `!`
	// over a building not yet opened since it was built
	const markers = [];
	// Cut 30.5: the chest before the porter — closed and empty from day 0 (drawn, not a surface), full with gold (a `!` and the sum), open
	// just after a tap; the porter's hire retires it
	const W = L.tree, porter = W?.nodes.find((n) => n.id === "porter");
	const chest = W && porter && (porter.state !== "done" || porter.paused) ? {
		state: o.chestOpen ? "open" : W.chest > 0 ? "full" : "closed",
		gold: W.chest,
		count: porter.count,
		need: porter.need
	} : undefined;
	if (chest?.state === "full") markers.push({
		at: "chest",
		kind: "chest",
		label: `$${chest.gold}`
	});
	const workers = (town?.workers ?? []).map((w) => ({
		id: w.id,
		post: w.post,
		lit: !!w.lit,
		price: w.price,
		paused: !!w.paused,
		rank: w.rank ?? 1
	}));
	if (has("blacksmith") && (o.kit?.n ?? 0) > 0) markers.push({
		at: "blacksmith",
		kind: "sword",
		label: o.kit?.price ? `Upgrade $${o.kit.price}` : undefined
	});
	if (has("bank") && (town?.bank ?? 0) > 0 && o.absenceNew) markers.push({
		at: "bank",
		kind: "coin"
	});
	const opened = new Set(o.opened ?? []);
	for (const b of buildings) if (markers.length < 3 && !opened.has(b.id) && !markers.some((m) => m.at === b.id)) markers.push({
		at: b.id,
		kind: "rune"
	});
	return {
		home: town?.home !== false,
		seed,
		day,
		stage: buildings.length,
		buildings,
		staked: next,
		hero: {
			cls: L.class || "fighter",
			look: L.look
		},
		services: town?.home === false ? [] : [
			"guild",
			"pool",
			"device"
		].filter((id) => L.persistent_hero?.[id].available),
		residents: L.hero_slots?.filter((h) => h.life_state !== undefined ? h.life_state !== "away" : h.state !== "live").map((h) => ({
			id: h.id,
			cls: h.class,
			look: h.look,
			resting: h.state === "rests" || h.rest_s > 0 || h.life_state === "recovering",
			phase: h.life_state ?? (h.id === L.selected_bloodline ? L.persistent_hero?.state : undefined)
		})) ?? (L.live ? [] : [{
			id: L.selected_bloodline ?? 1,
			cls: L.class || "fighter",
			look: L.look
		}]),
		selectedHero: L.selected_bloodline ?? 1,
		roster: (L.hero_slots?.map((h) => h.id) ?? [L.selected_bloodline ?? 1]).sort((a, b) => a - b),
		pets: (L.party ?? []).slice(0, 2).map((c) => c.kind),
		penned: has("kennel") ? (L.kennel ?? []).slice(0, 2).map((c) => c.kind) : [],
		parties,
		markers: markers.slice(0, 3),
		depth: L.best_depth ?? 0,
		board: !!o.board,
		chest: town?.home === false || town?.auto_collect ? undefined : chest,
		workers: town?.home === false ? [] : workers
	};
}
let packed = null;
function loadPacked() {
	packed ??= fetch(`${import.meta.env.BASE_URL}art/atlas.json`).then((r) => r.json()).then((j) => new Promise((res) => {
		const img = new Image();
		img.onload = () => res({
			img,
			frames: j.frames ?? {}
		});
		img.onerror = () => res(null);
		img.src = `${import.meta.env.BASE_URL}art/${j.image ?? "atlas.png"}`;
	})).catch(() => null);
	return packed;
}
const ATLAS = 1024;
/** a walker's coat hue by class (rgb 0..255, applied to the mid-tones at a pixel's own value) */
const WALKER_TINT = {
	rogue: [
		120,
		70,
		140
	],
	ranger: [
		80,
		140,
		72
	],
	caster: [
		70,
		96,
		200
	],
	fighter: [
		150,
		160,
		176
	]
};
/** fallback aspect (w / h) per id family */
const ASPECT = [
	[/^town_service_guild/, 1.5],
	[/^town_service_pool/, 2.636],
	[/^town_service_device/, 1.222],
	[/^town_service_station/, 3.333],
	[/^town_mouth/, 1.55],
	[/^town_(blacksmith|bank|kennel)_/, 1.25],
	[/^town_tent/, 1.05],
	[/^town_board/, .85],
	[/^town_campfire/, 1.1],
	[/^town_plot/, 1.1],
	[/^town_scaffold/, .9],
	[/^(hero_|walk_|town_(smith|merchant|carter|child))/, .7],
	[/^town_(sack|chest)/, .95],
	[/^town_worker_(porter|apprentice|drillmaster|kennel_hand)/, 1.2],
	[/^town_worker_/, .75],
	[/^town_haul_chest/, 1.5],
	[/^town_flag/, .6],
	[/^env_torch/, .66],
	[/^town_env_tree/, .5],
	[/^town_env_/, 1],
	[/^fx_/, 1]
];
export class TownAtlas {
	canvas;
	ctx;
	version = 0;
	slots = new Map();
	sx = 1;
	sy = 1;
	sh = 0;
	src = null;
	ready = false;
	lastId = "";
	constructor() {
		this.canvas = document.createElement("canvas");
		this.canvas.width = ATLAS;
		this.canvas.height = ATLAS;
		this.ctx = this.canvas.getContext("2d", { willReadFrequently: true });
		void loadPacked().then((p) => {
			this.src = p;
			this.ready = true;
			this.reset();
		});
	}
	has(id) {
		return !!this.src?.frames[id];
	}
	/** Cached stepped pigment ellipse; geometry stays in integer town texels. */
	shadow(width, depth) {
		return this.get(`town_ground_shadow_${Math.max(6, Math.round(width))}`, Math.max(3, Math.round(depth)));
	}
	/** Cut 30.5: the slot of `ids` greyed — a lit node's worker not yet hired (art/town_sheet.py `grey()`: the values only, lifted toward a
	*  pale MIST grey, alpha × 0.8), cut once into its own slot */
	grey(ids, h) {
		const base = this.get(ids, h);
		const key = `grey:${Array.isArray(ids) ? ids.join("|") : ids}@${h}`;
		const hit = this.slots.get(key);
		if (hit) return hit;
		const w = base.w;
		if (this.sx + w + 1 > ATLAS) {
			this.sy += this.sh + 1;
			this.sx = 1;
			this.sh = 0;
		}
		if (this.sy + h + 1 > ATLAS) {
			this.reset();
			return this.get(ids, h);
		}
		const x = this.sx, y = this.sy;
		this.sx += w + 1;
		this.sh = Math.max(this.sh, h);
		const d = this.ctx.getImageData(base.x, base.y, base.w, base.h), p = d.data;
		for (let i = 0; i < p.length; i += 4) {
			const l = .2126 * p[i] + .7152 * p[i + 1] + .0722 * p[i + 2];
			p[i] = l * .4 + 164 * .42;
			p[i + 1] = l * .4 + 188 * .42;
			p[i + 2] = l * .4 + 214 * .42;
			p[i + 3] = p[i + 3] * .8;
		}
		this.ctx.putImageData(d, x, y);
		const slot = {
			x,
			y,
			w,
			h,
			u0: x / ATLAS,
			v0: 1 - (y + h) / ATLAS,
			u1: (x + w) / ATLAS,
			v1: 1 - y / ATLAS
		};
		this.slots.set(key, slot);
		this.version++;
		return slot;
	}
	seated(ids, h) {
		const base = this.get(ids, h), key = `seated:${ids.join("|")}@${h}`;
		const cached = this.slots.get(key);
		if (cached) return cached;
		const w = base.w + 3, sh = Math.max(8, Math.round(h * .8));
		if (this.sx + w + 1 > ATLAS) {
			this.sy += this.sh + 1;
			this.sx = 1;
			this.sh = 0;
		}
		if (this.sy + sh + 1 > ATLAS) {
			this.reset();
			return this.seated(ids, h);
		}
		const x = this.sx, y = this.sy;
		this.sx += w + 1;
		this.sh = Math.max(this.sh, sh);
		const torso = Math.round(base.h * .68);
		this.ctx.imageSmoothingEnabled = false;
		this.ctx.drawImage(this.canvas, base.x, base.y, base.w, torso, x, y, base.w, torso);
		this.ctx.drawImage(this.canvas, base.x, base.y + torso, base.w, base.h - torso, x + 2, y + torso, base.w + 1, sh - torso);
		const slot = {
			x,
			y,
			w,
			h: sh,
			u0: x / ATLAS,
			v0: 1 - (y + sh) / ATLAS,
			u1: (x + w) / ATLAS,
			v1: 1 - y / ATLAS
		};
		this.slots.set(key, slot);
		this.version++;
		return slot;
	}
	reset() {
		this.slots.clear();
		this.sx = 1;
		this.sy = 1;
		this.sh = 0;
		this.ctx.clearRect(0, 0, ATLAS, ATLAS);
		this.version++;
	}
	/** the slot of `id` drawn `h` texels tall (the first id of `ids` the atlas has, else a primitive of the first) */
	get(ids, h) {
		const requested = Array.isArray(ids) ? ids : [ids];
		if (requested[0]?.startsWith("town_seated:")) return this.seated(requested.map((id) => id.replace(/^town_seated:/, "")), h);
		const list = Array.isArray(ids) ? ids : [ids];
		const id = list.find((x) => this.src?.frames[x]) ?? list[0];
		const key = `${id}@${h}`;
		const s = this.slots.get(key);
		if (s) return s;
		const f = this.src?.frames[id];
		const shadowWidth = /^town_ground_shadow_(\d+)$/.exec(id);
		const w = shadowWidth ? Number(shadowWidth[1]) : f ? Math.max(1, Math.round(h * f.w / f.h)) : Math.max(1, Math.round(h * (ASPECT.find(([re]) => re.test(id))?.[1] ?? 1)));
		if (this.sx + w + 1 > ATLAS) {
			this.sy += this.sh + 1;
			this.sx = 1;
			this.sh = 0;
		}
		if (this.sy + h + 1 > ATLAS) this.reset();
		const x = this.sx, y = this.sy;
		this.sx += w + 1;
		this.sh = Math.max(this.sh, h);
		const slot = {
			x,
			y,
			w,
			h,
			u0: x / ATLAS,
			v0: 1 - (y + h) / ATLAS,
			u1: (x + w) / ATLAS,
			v1: 1 - y / ATLAS
		};
		this.slots.set(key, slot);
		this.lastId = id;
		if (f && this.src) this.cut(this.src.img, f, slot);
		else if (!paintHomeService(this.ctx, id, x, y, w, h)) drawPrimitive(this.ctx, id, x, y, w, h);
		this.version++;
		return slot;
	}
	/** a packed master cut to its drawn size by area (smoothed, then the alpha thresholded: a crisp silhouette) */
	cut(img, f, s) {
		if (f.w === s.w && f.h === s.h) {
			this.ctx.imageSmoothingEnabled = false;
			this.ctx.drawImage(img, f.x, f.y, f.w, f.h, s.x, s.y, s.w, s.h);
			return;
		}
		const c = document.createElement("canvas");
		c.width = s.w;
		c.height = s.h;
		const g = c.getContext("2d", { willReadFrequently: true });
		g.imageSmoothingEnabled = true;
		g.imageSmoothingQuality = "high";
		g.drawImage(img, f.x, f.y, f.w, f.h, 0, 0, s.w, s.h);
		const d = g.getImageData(0, 0, s.w, s.h), p = d.data;
		for (let i = 3; i < p.length; i += 4) p[i] = p[i] < 110 ? 0 : 255;
		// the art note ("the four walkers look alike"): a walker's coat takes its class's hue — mid-tones, never the BLOOD cloak or the ink
		const tint = WALKER_TINT[/^(?:walk|hero)_(\w+?)(?:_|$)/.exec(f === undefined ? "" : this.lastId)?.[1] ?? ""];
		if (tint) for (let i = 0; i < p.length; i += 4) {
			if (!p[i + 3]) continue;
			const r = p[i], gg = p[i + 1], b = p[i + 2], l = (.2126 * r + .7152 * gg + .0722 * b) / 255;
			if (l < .12 || l > .8 || r > gg * 1.5 && r > b * 1.4) continue;
			const m = .42 * (1 - Math.abs(l - .42) * 1.6);
			p[i] = r + (tint[0] * l * 2 - r) * m;
			p[i + 1] = gg + (tint[1] * l * 2 - gg) * m;
			p[i + 2] = b + (tint[2] * l * 2 - b) * m;
		}
		this.ctx.putImageData(d, s.x, s.y);
	}
}
/** the primitive for an id the atlas lacks: a coloured block in the thing's shape (docs/TOWN.md §7: "a coloured block + its icon") */
function drawPrimitive(g, id, x, y, w, h) {
	const R = (c, a, b, cw, ch) => {
		g.fillStyle = c;
		g.fillRect(x + Math.round(a), y + Math.round(b), Math.max(1, Math.round(cw)), Math.max(1, Math.round(ch)));
	};
	const tri = (c, x0, y0, x1, x2, yb) => {
		g.fillStyle = c;
		g.beginPath();
		g.moveTo(x + x0, y + y0);
		g.lineTo(x + x1, y + yb);
		g.lineTo(x + x2, y + yb);
		g.closePath();
		g.fill();
	};
	const speck = (base, dark, n) => {
		R(base, 0, 0, w, h);
		for (let i = 0; i < n; i++) R(dark, hashN(i, x, y) % w, hashN(y, i, 7) % h, 1, 1);
	};
	if (id.startsWith("town_ground_shadow_")) {
		// Three quiet ink washes, a crisp outer edge and a dense foot contact.
		// No blur or gradient: both renderer paths sample the same small bitmap.
		for (let yy = 0; yy < h; yy++) for (let xx = 0; xx < w; xx++) {
			const d = Math.pow((xx + .5 - w / 2) / (w / 2), 2) + Math.pow((yy + .5 - h / 2) / (h / 2), 2);
			if (d <= 1) R(d < .24 ? "rgba(13,17,24,.32)" : d < .63 ? "rgba(13,17,24,.21)" : "rgba(13,17,24,.09)", xx, yy, 1, 1);
		}
	} else if (id.startsWith("town_wind_grass_")) {
		const lean = Number(id.split("_").at(-1)) - 2;
		// Stepped ink/wash blade clusters, five bends with the same rooted bases.
		for (const [root, tall, bias] of [
			[
				w * .25,
				h * .72,
				-1
			],
			[
				w * .5,
				h,
				0
			],
			[
				w * .75,
				h * .6,
				1
			]
		]) {
			for (let j = 0; j < tall; j++) {
				const bend = Math.round((lean + bias) * Math.pow(j / tall, 1.35));
				R(j === Math.ceil(tall) - 1 ? "#60715e" : "#394b40", Math.max(0, Math.min(w - 1, root + bend)), h - 1 - j, 1, 1);
			}
		}
	} else if (id.startsWith("town_env_grass")) speck("#3d5a2a", "#2f4720", 22);
	else if (id.startsWith("town_env_dirt")) speck("#7a5a3a", "#5e442a", 18);
	else if (id.startsWith("town_env_plaza")) {
		speck("#8a8478", "#6b665c", 10);
		R("#5c574e", 0, 7, w, 1);
		R("#5c574e", 7, 0, 1, 8);
	} else if (id.startsWith("town_env_cliff")) speck("#3b3a3f", "#2a292e", 26);
	else if (id.startsWith("town_env_water")) speck("#2a4a62", "#3f6a86", 12);
	else if (id.startsWith("town_env_tree")) {
		R("#4a321f", w * .4, h * .65, w * .2, h * .35);
		g.fillStyle = "#24401f";
		g.beginPath();
		g.ellipse(x + w / 2, y + h * .4, w * .5, h * .38, 0, 0, Math.PI * 2);
		g.fill();
	} else if (id.startsWith("town_mouth")) {
		R("#4a474e", 0, h * .15, w, h * .85);
		g.fillStyle = "#0c0b10";
		g.beginPath();
		g.ellipse(x + w / 2, y + h * .62, w * .2, h * .36, 0, Math.PI, 0);
		g.fill();
		R("#0c0b10", w * .3, h * .62, w * .4, h * .38);
	} else if (/^town_(blacksmith|bank|kennel)_/.test(id)) {
		const col = /blacksmith/.test(id) ? ["#4b4650", "#7a2a1c"] : /bank/.test(id) ? ["#b8b0a0", "#5a6f86"] : ["#8c6a44", "#6a4a2a"];
		R(col[0], w * .08, h * .42, w * .84, h * .58);
		tri(col[1], w / 2, 0, -w * .02 + w * .02, w, h * .46);
		R("#1e1914", w * .42, h * .68, w * .16, h * .32);
		if (/blacksmith/.test(id)) R("#e07a2a", w * .16, h * .7, w * .14, h * .1);
		if (/bank/.test(id)) {
			g.fillStyle = "#e3c24a";
			g.beginPath();
			g.arc(x + w * .5, y + h * .3, Math.max(2, h * .08), 0, Math.PI * 2);
			g.fill();
		}
	} else if (id.startsWith("town_tent")) {
		tri("#c9b48a", w / 2, 0, 0, w, h);
		tri("#2a2218", w / 2, h * .45, w * .36, w * .64, h);
	} else if (id.startsWith("town_board")) {
		R("#4a321f", w * .15, h * .3, 2, h * .7);
		R("#4a321f", w * .8, h * .3, 2, h * .7);
		R("#6a5034", 0, 0, w, h * .6);
		R("#d8c8a0", w * .2, h * .12, w * .3, h * .25);
	} else if (id.startsWith("town_crate")) {
		R("#8a6034", 0, 0, w, h);
		R("#5a3c1e", 0, h / 2, w, 1);
		R("#5a3c1e", w / 2, 0, 1, h);
	} else if (id.startsWith("town_campfire")) {
		R("#4a321f", 0, h * .75, w, h * .25);
		tri(id.endsWith("_1") ? "#ffcf5a" : "#f08a2a", w / 2, 0, w * .15, w * .85, h * .8);
	} else if (id.startsWith("town_plot")) {
		for (const a of [.1, .9]) R("#6a4a2a", w * a - 1, h * .2, 2, h * .8);
		R("#d8c8a0", w * .1, h * .35, w * .8, 1);
	} else if (id.startsWith("town_scaffold")) {
		for (let i = 0; i <= 3; i++) {
			R("#7a5534", (w - 2) * i / 3, 0, 2, h);
			R("#7a5534", 0, (h - 2) * i / 3, w, 2);
		}
	} else if (id.startsWith("town_sack")) {
		g.fillStyle = "#b89a62";
		g.beginPath();
		g.ellipse(x + w / 2, y + h * .6, w * .45, h * .4, 0, 0, Math.PI * 2);
		g.fill();
		R("#e3c24a", w * .4, h * .1, w * .2, h * .25);
	} else if (id.startsWith("town_haul_chest")) {
		// the haul chest: closed · full (a coin heap and a glint) · open (the lid up behind, dark inside)
		const open = id.endsWith("_open"), full = id.endsWith("_full");
		if (open) {
			R("#4a3220", w * .08, 0, w * .84, h * .4);
			R("#0d0c14", w * .12, h * .4, w * .76, h * .14);
		}
		R("#5a3c22", w * .06, h * .45, w * .88, h * .47);
		R("#2b3350", w * .06, h * .6, w * .88, 1);
		R("#2b3350", w * .3, h * .45, 1, h * .47);
		R("#2b3350", w * .7, h * .45, 1, h * .47);
		if (!open) R("#6a4a2c", w * .04, h * .32, w * .92, h * .15);
		R("#b89448", w * .45, h * .52, w * .1, h * .14);
		if (full) {
			R("#b89448", w * .12, h * .22, w * .76, h * .1);
			R("#eadfc5", w * .62, h * .08, 1, h * .16);
			R("#eadfc5", w * .56, h * .15, w * .14, 1);
		}
	} else if (id.startsWith("town_worker_")) {
		// a worker: a townsperson (no BLOOD) and the role's tag in its own colour (art/town-ids.md, workers)
		const role = id.replace(/^town_worker_|_1$/g, "");
		const coat = {
			porter: "#3a3448",
			apprentice: "#5a3c22",
			clerk: "#1c1b2b",
			drillmaster: "#6a5a40",
			kennel_hand: "#4a3a2a",
			herald: "#2b3350",
			guide: "#7d8ea4",
			scout: "#4a3a2a",
			quartermaster: "#6a5a40"
		};
		const fw = /porter|apprentice|drillmaster|kennel_hand/.test(role) ? w * .55 : w;
		R(coat[role] ?? "#3a3448", fw * .22, h * .28, fw * .56, h * .5);
		R("#eadfc5", fw * .32, h * .06, fw * .36, h * .2);
		R("#1c1b2b", fw * .26, h * .78, fw * .18, h * .22);
		R("#1c1b2b", fw * .56, h * .78, fw * .18, h * .22);
		const T = (c, a, b, cw, ch) => R(c, fw + (w - fw) * a, h * b, (w - fw) * cw, h * ch);
		if (role === "porter") {
			T("#6a4a2c", .05, .45, .9, .3);
			T("#eadfc5", .15, .25, .7, .22);
			T("#1c1b2b", .3, .72, .35, .28);
		} else if (role === "apprentice") {
			T("#0d0c14", .1, .55, .8, .2);
			T("#0d0c14", .35, .75, .3, .25);
			T("#e8923a", .25, .48, .5, .07);
		} else if (role === "drillmaster") {
			T("#b89448", .4, .15, .2, .3);
			T("#6a4a2c", .47, .45, .06, .55);
			T("#6a4a2c", .1, .32, .8, .06);
		} else if (role === "kennel_hand") {
			T("#4d6c99", .1, .55, .7, .25);
			T("#4d6c99", .55, .4, .3, .2);
			T("#1c1b2b", .15, .8, .1, .2);
		} else if (role === "clerk") R("#eadfc5", fw * .5, h * .4, fw * .45, h * .16);
		else if (role === "herald") {
			R("#eadfc5", fw * .6, h * .42, fw * .25, h * .4);
			R("#b89448", fw * .78, h * .25, fw * .16, h * .1);
		} else if (role === "guide") {
			R("#e8923a", fw * .76, h * .4, fw * .18, h * .12);
			R("#6a4a2c", fw * .12, h * .05, 1, h * .95);
		} else if (role === "scout") {
			R("#1c1b2b", fw * .15, h * .02, fw * .7, h * .08);
			R("#b89448", fw * .62, h * .12, fw * .32, h * .06);
			R("#eadfc5", fw * .78, h * .35, fw * .2, h * .06);
		} else if (role === "quartermaster") {
			R("#5a3c22", fw * .5, h * .3, fw * .45, h * .35);
			R("#eadfc5", fw * .5, h * .26, fw * .45, h * .06);
		}
	} else if (id.startsWith("town_chest")) {
		R("#7a4a1e", 0, h * .3, w, h * .7);
		R("#ffd76a", 0, h * .3, w, 2);
		R("#ffd76a", w * .42, h * .45, w * .16, h * .2);
	} else if (id.startsWith("town_flag")) {
		R("#4a321f", 0, 0, 1, h);
		R(id.endsWith("_1") ? "#a01a28" : "#c01530", 1, 1, w - 1, h * .4);
	} else if (id.startsWith("env_torch")) {
		R("#4a321f", w * .4, h * .4, w * .2, h * .6);
		R(id.endsWith("_1") ? "#ffcf5a" : "#f08a2a", w * .25, 0, w * .5, h * .45);
	} else if (id.startsWith("fx_glint")) {
		const c = Math.floor(w / 2);
		R("#fffbe8", c, 0, 1, h);
		R("#fffbe8", 0, c, w, 1);
		R("#ffffff", c - 1, c - 1, 3, 3);
	} else if (id === "town_lantern") {
		// Ink cage and orange ember wick, shared by GL and Canvas.
		R("#4d6c99", 1, 0, 3, 1);
		R("#0d0c14", 1, 1, 1, 3);
		R("#0d0c14", 3, 1, 1, 3);
		R("#e8923a", 2, 1, 1, 3);
		R("#b89448", 1, 4, 3, 1);
	} else if (id.startsWith("fx_dot_")) R(`#${id.slice(7)}`, 0, 0, w, h);
	else if (/^(hero_|walk_)/.test(id)) {
		const body = /rogue/.test(id) ? "#4a3a5a" : /ranger/.test(id) ? "#3f5a32" : /caster/.test(id) ? "#3a4a7a" : "#8a8f98";
		R("#c01530", w * .15, h * .32, w * .3, h * .5);
		R(body, w * .25, h * .3, w * .5, h * .45);
		R("#e8dcc8", w * .32, h * .08, w * .36, h * .22);
		R("#2a2420", w * .3, h * .75, w * .15, h * .25);
		R("#2a2420", w * .55, h * .75, w * .15, h * .25);
	} else {
		R("#7a6a4a", w * .1, h * .35, w * .8, h * .45);
		R("#5a4a32", w * .15, h * .75, w * .12, h * .25);
		R("#5a4a32", w * .7, h * .75, w * .12, h * .25);
		R("#7a6a4a", w * .65, h * .15, w * .3, h * .3);
	}
}
/** hour (0..24) → night 0..1: day 7–17, dusk 17–21, night 21–5, dawn 5–7 */
export function nightOf(hour) {
	const h = (hour % 24 + 24) % 24;
	if (h >= 21 || h < 5) return 1;
	if (h >= 7 && h < 17) return 0;
	return h < 7 ? 1 - (h - 5) / 2 : (h - 17) / 4;
}
const mix3 = (a, b, t) => [
	a[0] + (b[0] - a[0]) * t,
	a[1] + (b[1] - a[1]) * t,
	a[2] + (b[2] - a[2]) * t
];
const AMB_DAY = [
	1.1,
	1.08,
	1.06
], AMB_DUSK = [
	.86,
	.68,
	.62
], AMB_NIGHT = [
	.27,
	.34,
	.58
];
export function ambientOf(night) {
	return night < .5 ? mix3(AMB_DAY, AMB_DUSK, night * 2) : mix3(AMB_DUSK, AMB_NIGHT, (night - .5) * 2);
}
const SPEED = 40;
function legsAlong(pts, t0, speed = SPEED, out = []) {
	let t = t0;
	for (let i = 1; i < pts.length; i++) {
		const d = dist(pts[i - 1], pts[i]);
		if (d < .01) continue;
		out.push({
			t0: t,
			t1: t + d / speed,
			a: pts[i - 1],
			b: pts[i]
		});
		t += d / speed;
	}
	return t;
}
function walkerAt(w, t) {
	if (t < w.from || t > w.to) return null;
	const legs = w.legs;
	if (w.extend && legs.length && legs[legs.length - 1].t1 < t + 30) w.extend(w);
	if (!legs.length) return null;
	if (t <= legs[0].t0) return {
		x: legs[0].a.x,
		y: legs[0].a.y,
		moving: false,
		dx: 0
	};
	let lo = 0, hi = legs.length - 1;
	while (lo < hi) {
		const m = lo + hi + 1 >> 1;
		if (legs[m].t0 <= t) lo = m;
		else hi = m - 1;
	}
	const L = legs[lo];
	if (t >= L.t1) return {
		x: L.b.x,
		y: L.b.y,
		moving: false,
		dx: 0
	};
	const f = (t - L.t0) / (L.t1 - L.t0);
	return {
		x: L.a.x + (L.b.x - L.a.x) * f,
		y: L.a.y + (L.b.y - L.a.y) * f,
		moving: true,
		dx: L.b.x - L.a.x
	};
}
const SMOKE = [
	"9a958c",
	"7d7a74",
	"b4afa4"
], EMBER = [
	"ffb04a",
	"ff7a2a",
	"ffd76a"
], DUST = [
	"b89a6a",
	"9a7e56",
	"cdb48a"
];
const IDLE_MS = 1e4, IDLE_FPS = 20, SOFT_FPS = 2;
let sharedAtlas = null;
let sharedGl = null;
let lightingInspector = null;
/** Dev-only identical-frame readback; never runs in the animation loop. */
export function inspectTownLighting() {
	return import.meta.env.DEV ? lightingInspector?.() : null;
}
export function createTownView(host) {
	const el = host;
	// one GL canvas and context for every mount (a camp re-mounts on every return): taken here, given back on dispose
	const kept = sharedGl && !sharedGl.gl.isLost() ? sharedGl : null;
	if (sharedGl && !kept) sharedGl.gl.dispose();
	sharedGl = null;
	const glCanvas = kept?.canvas ?? document.createElement("canvas");
	glCanvas.className = "town-gl";
	glCanvas.setAttribute("aria-hidden", "true");
	el.appendChild(glCanvas);
	const atlas = sharedAtlas ??= new TownAtlas();
	let gl = null;
	if (kept) {
		gl = kept.gl;
		gl.restored();
	} else try {
		gl = new GLTown(glCanvas, atlas);
	} catch (e) {
		console.warn("town: no WebGL, the 2D view stands in", e);
		gl = null;
	}
	let c2d = null;
	const view2d = () => {
		if (c2d) return c2d;
		c2d = document.createElement("canvas");
		c2d.className = "town-2d";
		c2d.setAttribute("aria-hidden", "true");
		el.appendChild(c2d);
		return c2d;
	};
	let glLost = false;
	const onLost = (e) => {
		e.preventDefault();
		glLost = true;
		layoutDirty = true;
	};
	const onRestored = () => {
		glLost = false;
		gl?.restored();
		layoutDirty = true;
	};
	glCanvas.addEventListener("webglcontextlost", onLost);
	glCanvas.addEventListener("webglcontextrestored", onRestored);
	let state = null;
	let walkers = [];
	let homeSpots = [];
	const parts = [];
	let t = 0, last = performance.now(), raf = 0, frames = 0, disposed = false;
	const fpsWin = [], cpu = [];
	let lastInput = performance.now(), lastDraw = 0;
	let hourOverride = null;
	let layoutDirty = true;
	const layoutFns = [];
	const upgradeFrom = new Map();
	let buildEvents = 0;
	const buildFxEnabled = () => !motionPreference.matches && !document.hidden && effectsLevel() !== "off" && document.documentElement.dataset.juice !== "off";
	let builtAt = new Map();
	let hero = null;
	const actorLayout = [];
	let walkingIn = null;
	let stressN = 0;
	const arrive = new Map();
	const F = {
		x0: 0,
		y0: 0,
		w: 1,
		h: 1,
		k: 1,
		W: 1,
		H: 1,
		quads: [],
		n: 0,
		terrain: null,
		groundKey: "",
		lights: [],
		amb: [
			1,
			1,
			1
		],
		night: 0,
		live: 0
	};
	if (import.meta.env.DEV) lightingInspector = () => gl && !glLost ? gl.compareLighting(F) : null;
	let terrainPaints = 0, terrainPaintMs = 0;
	let windTufts = 0, windSignature = 0;
	const motionPreference = matchMedia("(prefers-reduced-motion: reduce)");
	const rng = (n) => hashN(state?.seed ?? 1, n) % 1e5 / 1e5;
	// -- the walkers of a state --
	function build(homeArrival = false) {
		const s = state;
		walkers = [];
		const cls = s.hero.cls, heroIds = [
			...s.hero.look ? [`hero_${cls}_${s.hero.look}`] : [],
			`hero_${cls}`,
			"hero_fighter"
		], walkIds = [`walk_${cls}`, ...heroIds];
		let k = 0;
		const partyEnd = s.parties.length ? s.parties[s.parties.length - 1].at + 7 : 0;
		for (const p of s.parties) {
			const legs = [];
			const end = legsAlong(route("in", p.to), p.at, SPEED, legs);
			const w = {
				id: `party${k++}`,
				sprite: heroIds,
				walk: walkIds,
				h: 24,
				legs,
				from: p.at,
				to: end + .4,
				lag: 0,
				emerge: true,
				vanish: true,
				carry: p.chest ? "town_chest_glow" : p.sack ? `town_sack_${p.sack}` : undefined,
				carryH: p.chest ? 8 : p.sack === "large" ? 8 : 6
			};
			walkers.push(w);
			if (p.pet) walkers.push({
				id: `${w.id}pet`,
				sprite: [p.pet, "town_dog"],
				walk: [p.pet, "town_dog"],
				h: 14,
				legs,
				from: p.at + .7,
				to: end + 1.1,
				lag: .7,
				follow: w,
				emerge: true,
				vanish: true,
				pet: true
			});
		}
		buildFolk();
		if (!s.home) {
			hero = null;
			addStress();
			return;
		}
		// the hero at home: tent → forge → fire (→ the crate while no forge stands), a pause of 2–6 s at each
		const stops = [
			"tent",
			s.buildings.some((b) => b.id === "blacksmith") ? "smith" : "crate",
			"fireW"
		];
		hero = null;
		const residents = s.residents ?? [{
			id: s.selectedHero ?? 1,
			cls: s.hero.cls,
			look: s.hero.look
		}];
		for (const resident of residents) {
			let i = homeArrival ? 0 : (Math.floor(rng(resident.id * 31) * 3) + resident.id) % 3, n = 0;
			const ids = [
				...resident.look ? [`hero_${resident.cls}_${resident.look}`] : [],
				`hero_${resident.cls}`,
				"hero_fighter"
			];
			const actor = {
				id: `resident:${resident.id}`,
				homeOffset: {
					x: ((resident.id - 1) % 3 - 1) * 12,
					y: 0
				},
				sprite: ids,
				walk: [`walk_${resident.cls}`, ...ids],
				h: 24,
				legs: [],
				from: partyEnd,
				to: Infinity,
				lag: resident.id * .1,
				extend: (w) => {
					let tt = w.legs.length ? w.legs[w.legs.length - 1].t1 : partyEnd;
					for (let j = 0; j < 6; j++) {
						const a = stops[i % 3], b = stops[(i + 1) % 3];
						i++;
						const pause = 2 + rng(100 + resident.id * 101 + n++) * 4;
						const at = NODES[a];
						w.legs.push({
							t0: tt,
							t1: tt + pause,
							a: at,
							b: at
						});
						tt += pause;
						tt = legsAlong(route(a, b), tt, SPEED * .8, w.legs);
					}
				}
			};
			if (resident.phase === "reincarnating" && s.services?.includes("device")) {
				actor.homeOffset = {
					x: 0,
					y: 0
				};
				actor.reincarnating = true;
				const p = homeSpots.find((p) => p.id === resident.id).device;
				actor.legs = [{
					t0: partyEnd,
					t1: Infinity,
					a: p,
					b: p
				}];
				actor.extend = undefined;
			} else if (resident.resting && s.services?.includes("pool")) {
				actor.homeOffset = {
					x: 0,
					y: 0
				};
				actor.sprite = ids.map((id) => `town_seated:${id}`);
				actor.walk = actor.sprite;
				const p = homeSpots.find((p) => p.id === resident.id).pool;
				actor.legs = [{
					t0: partyEnd,
					t1: Infinity,
					a: p,
					b: p
				}];
				actor.extend = undefined;
			} else actor.extend(actor);
			walkers.push(actor);
			if (resident.id === (s.selectedHero ?? 1)) hero = actor;
		}
		if (hero) s.pets.forEach((p, j) => walkers.push({
			id: `pet${j}`,
			sprite: [p, "town_dog"],
			walk: [p, "town_dog"],
			h: 14,
			legs: hero.legs,
			from: partyEnd,
			to: Infinity,
			lag: .9 + j * .6,
			follow: hero,
			pet: true
		}));
		addStress();
	}
	/** Cut 109: the walking townsfolk (`folk` draws them by stage): the child's loop and the carter's round, seeded by the day */
	let townsfolk = [];
	function buildFolk() {
		townsfolk = [];
		const loop = (id, sprite, h, stops, speed, pauseLo, pauseHi, minStage, carry) => {
			let i = 0, n = 0;
			const w = {
				id,
				sprite: [sprite],
				walk: [sprite],
				h,
				legs: [],
				from: 0,
				to: Infinity,
				lag: rng(400 + id.length) * 3,
				minStage,
				carry,
				carryH: 16,
				extend: (ww) => {
					let tt = ww.legs.length ? ww.legs[ww.legs.length - 1].t1 : rng(500 + id.length) * 4;
					for (let j = 0; j < 6; j++) {
						const a = stops[i % stops.length], b = stops[(i + 1) % stops.length];
						i++;
						const pause = pauseLo + rng(600 + n++ + id.length * 50) * (pauseHi - pauseLo);
						const at = NODES[a];
						ww.legs.push({
							t0: tt,
							t1: tt + pause,
							a: at,
							b: at
						});
						tt += pause;
						tt = legsAlong(route(a, b), tt, speed, ww.legs);
					}
				}
			};
			w.extend(w);
			townsfolk.push(w);
		};
		loop("child", "town_child", 17, [
			"fireS",
			"fireW",
			"fireN",
			"fireE"
		], SPEED * 1.15, .6, 2.5, 2);
		loop("carter", "town_carter", 23, [
			"exit",
			"south",
			"kennel",
			"south"
		], SPEED * .6, 2, 6, BUILDINGS.length, "town_cart");
	}
	function addStress() {
		walkers = walkers.filter((w) => !w.id.startsWith("stress"));
		const names = Object.keys(NODES).filter((x) => x !== "in" && x !== "exit"), classes = [
			"fighter",
			"rogue",
			"ranger",
			"caster"
		];
		for (let j = 0; j < stressN; j++) {
			const cls = classes[j % 4];
			let at = names[j % names.length];
			let m = 0;
			const w = {
				id: `stress${j}`,
				sprite: [`hero_${cls}`],
				walk: [`walk_${cls}`, `hero_${cls}`],
				h: 24,
				legs: [],
				from: t,
				to: Infinity,
				lag: 0,
				extend: (ww) => {
					let tt = ww.legs.length ? ww.legs[ww.legs.length - 1].t1 : t;
					for (let q = 0; q < 6; q++) {
						const nx = names[hashN(j, m++, 77) % names.length];
						if (nx === at) continue;
						ww.legs.push({
							t0: tt,
							t1: tt + .6,
							a: NODES[at],
							b: NODES[at]
						});
						tt = legsAlong(route(at, nx), tt + .6, SPEED, ww.legs);
						at = nx;
					}
				}
			};
			w.extend(w);
			walkers.push(w);
		}
	}
	// -- the frame --
	const push = (s, x, y, z, flip = false, dim = 1, fade = 0, w = s.w, h = s.h) => {
		let q = F.quads[F.n];
		if (!q) {
			q = {
				s,
				x,
				y,
				z,
				w,
				h,
				flip,
				dim,
				fade
			};
			F.quads[F.n] = q;
		} else {
			q.s = s;
			q.x = x;
			q.y = y;
			q.z = z;
			q.w = w;
			q.h = h;
			q.flip = flip;
			q.dim = dim;
			q.fade = fade;
			q.relief = 0;
		}
		F.n++;
	};
	const zOf = (footY) => 1 + footY / 2e3;
	const inView = (x, y, w, h) => x + w / 2 >= F.x0 - 4 && x - w / 2 <= F.x0 + F.w + 4 && y >= F.y0 - 4 && y - h <= F.y0 + F.h + 4;
	function grounding(x, y, width, height, fade = 0) {
		const broad = height >= 36, w = Math.max(6, Math.round(width * (broad ? .78 : .6)));
		const depth = broad ? Math.min(10, Math.max(5, Math.round(width * .13))) : 4;
		const contact = atlas.shadow(w, depth);
		push(contact, Math.round(x), Math.round(y + depth / 2 - 1), .22, false, 1, Math.max(fade, F.night * .12));
		// A short cast mark is visible in daylight; overhead moonlight leaves the
		// contact alone. Ground-plane z keeps it behind every tree, prop and person.
		if (F.night < .85) {
			const cast = atlas.shadow(Math.round(w * 1.15), depth + (broad ? 4 : 2));
			push(cast, Math.round(x + height * .08), Math.round(y + cast.h - 1), .21, false, 1, Math.max(fade, .55 + F.night * .45));
		}
	}
	function sprite(ids, h, x, y, o = {}) {
		const s = atlas.get(ids, h);
		if (!inView(x, y, s.w, s.h)) return;
		const id = Array.isArray(ids) ? ids[0] : ids;
		if (o.ground ?? /^(hero_|walk_|town_(house_|blacksmith_|bank_|kennel_|worker_|smith$|merchant$|carter$|child$|crate$|board$|campfire_|haul_chest|stall$|barrel$|brazier$|bench$|well$))/.test(id)) {
			grounding(x, o.groundY ?? y, s.w, s.h, o.fade ?? 0);
		}
		push(s, Math.round(x), Math.round(y), o.z ?? zOf(y), !!o.flip, o.dim ?? 1, o.fade ?? 0);
		// Only exact, decoded painted poses are mapped. Fallbacks and other looks
		// retain their art, including look-specific heroes that lack a walk pose.
		const resolved = (Array.isArray(ids) ? ids : [ids]).find((key) => atlas.has(key));
		F.quads[F.n - 1].relief = (townVolumePrototype() ? volumeKind(resolved) : 0) || (resolved === "town_blacksmith_1" ? 1 : resolved === "hero_fighter" || resolved === "hero_fighter_male" || resolved === "walk_fighter" ? 2 : 0);
	}
	/** Terrain is independent of the sprite atlas and camera. One bitmap per construction state. */
	function ground() {
		const s = state, key = `${s.home}|${s.stage}|${homeSpots.length}|${(s.services ?? []).join(",")}|${s.buildings.map((b) => b.id).sort().join(",")}|${terrainMaterialVersion()}`;
		if (key === F.groundKey) return;
		F.groundKey = key;
		const standing = new Set([...s.buildings.map((b) => DOOR[b.id]), ...s.services ?? []]);
		const started = performance.now();
		F.terrain = paintTownTerrain({
			width: MAP_W * TILE,
			height: MAP_H * TILE,
			trails: [...EDGES.filter(([, b]) => !SPURS.has(b) || standing.has(b)).map(([a, b, r]) => ({
				a: NODES[a],
				b: NODES[b],
				r: r * TILE
			})), ...(s.services ?? []).filter((id) => id === "pool" || id === "device").flatMap((id) => {
				const points = homeSpots.map((spot) => spot[id]);
				return points.length ? [{
					a: NODES[id],
					b: points[0],
					r: 4
				}, ...points.slice(1).map((p, i) => ({
					a: points[i],
					b: p,
					r: 4
				}))] : [];
			})],
			fire: PLOTS.fire,
			plaza: s.stage >= BUILDINGS.length,
			aprons: [
				...s.home ? [PLOTS.house] : [],
				...s.buildings.map((b) => PLOTS[b.id]),
				...(s.services ?? []).map((id) => PLOTS[id])
			],
			hillFoot,
			shadows: trees
		});
		terrainPaintMs = performance.now() - started;
		terrainPaints++;
	}
	function grassWind() {
		windTufts = 0;
		windSignature = 0;
		const level = effectsLevel();
		if (!F.terrain || level === "off" || motionPreference.matches) return;
		const roots = townGrassRoots(F.terrain), stride = level === "low" ? 3 : 1;
		for (let i = 0; i < roots.length; i += stride) {
			const p = roots[i];
			if (!inView(p.x, p.y, 8, p.h)) continue;
			// A shared travelling gust plus a quieter local flutter. Bases never move.
			const gust = Math.sin(t * .85 - p.x * .025 - p.y * .013);
			const pose = Math.max(0, Math.min(4, 2 + Math.round((gust * .8 + Math.sin(t * 1.4 + p.phase) * .2) * 2)));
			const slot = atlas.get(`town_wind_grass_${pose}`, p.h);
			push(slot, p.x, p.y, .1, false, .9, .28);
			windTufts++;
			windSignature = Math.imul(windSignature, 31) + pose + i >>> 0;
		}
	}
	/** the hill's foot: a ragged line (runs of two columns, one in three, a tile further down, never by the mouth), not a ruled edge */
	const hillFoot = (x) => 5 + OY + (Math.abs(x - CX) > 4 && hashN(x >> 1, 0, 7) % 3 === 0 ? 1 : 0);
	const hillDim = (y) => .3 + .7 * Math.pow(Math.min(1, (y + 1) / (5 + OY)), 1.6);
	const DOOR = {
		blacksmith: "smith",
		bank: "bank",
		kennel: "kennel"
	};
	const SPURS = new Set([
		...Object.values(DOOR),
		"guild",
		"pool",
		"device"
	]);
	/** the forest: trees on a jittered grid, cleared from the paths, the plots and the cliff */
	let trees = [];
	function forest() {
		trees = [];
		const keep = (p) => {
			if (p.y < (5.6 + OY) * TILE || p.x > (CX - 19.8) * TILE && p.x < (CX - 16.2) * TILE) return false;
			if (EDGES.some(([a, b, r]) => (![
				"guild",
				"pool",
				"device"
			].includes(b) || state?.services?.includes(b)) && segDist(p, NODES[a], NODES[b]) <= (r + .9) * TILE)) return false;
			if (dist(p, PLOTS.fire) < 3 * TILE) return false;
			if (PROPS.some((q) => Math.abs(p.x - q.x) < 2.2 * TILE && p.y > q.y - q.h * .6 && p.y < q.y + 1.4 * TILE)) return false;
			for (const id of ["pool", "device"]) {
				if (!state?.services?.includes(id)) continue;
				const points = homeSpots.map((spot) => spot[id]);
				if (points.some((spot) => Math.abs(p.x - spot.x) < 40 && p.y > spot.y - 32 && p.y < spot.y + 64)) return false;
				if (points.some((spot, i) => segDist(p, i ? points[i - 1] : NODES[id], spot) < 22)) return false;
			}
			if (Object.values(FOLK_AT).some((q) => dist(p, q) < 1.6 * TILE)) return false;
			for (const [id, pl] of Object.entries(PLOTS)) {
				if ((id === "guild" || id === "pool" || id === "device") && !state?.services?.includes(id)) continue;
				const hw = id === "mouth" ? 4.2 * TILE : id === "fire" || id === "crate" ? 1.4 * TILE : 3.3 * TILE;
				if (Math.abs(p.x - pl.x) < hw && p.y > pl.y - pl.h * .55 && p.y < pl.y + 1.6 * TILE) return false;
			}
			return true;
		};
		for (let gy = 5.8 + OY; gy < MAP_H; gy += 1.35) for (let gx = .5; gx < MAP_W; gx += 1.25) {
			const j = hashN(Math.round(gx * 10), Math.round(gy * 10), 9);
			const p = {
				x: (gx + (j % 100 / 100 - .5) * .9) * TILE,
				y: (gy + ((j >> 8) % 100 / 100 - .5) * .8) * TILE
			};
			if ((j >> 16) % 100 < 18) continue;
			if (keep(p)) trees.push({
				...p,
				k: (j >> 4) % 3 === 0,
				h: 24 + j % 4 * 4,
				d: .88 + (j >> 8) % 4 * .04
			});
		}
		// a thin wood up the hillside (dimmed with the slope), clear of the mouth: the band reads as a hill, not a wall
		for (let gy = 2.2; gy < 5.4 + OY; gy += 1.5) for (let gx = .5; gx < MAP_W; gx += 1.6) {
			const j = hashN(Math.round(gx * 10), Math.round(gy * 10), 13);
			const p = {
				x: (gx + (j % 100 / 100 - .5) * 1.2) * TILE,
				y: (gy + ((j >> 8) % 100 / 100 - .5) * .9) * TILE
			};
			if ((j >> 16) % 100 < 55 || Math.abs(p.x - PLOTS.mouth.x) < 4.6 * TILE) continue;
			trees.push({
				...p,
				k: (j >> 4) % 2 === 0,
				h: 24 + j % 4 * 4,
				d: hillDim(p.y / TILE - .5) * .85
			});
		}
		trees.sort((a, b) => a.y - b.y);
	}
	forest();
	let flickNow = 1;
	/** the warm emitters painted into a sprite (art/town_lights.json: [dx, dy, strength] from its foot), at `base` strength by day */
	function emitters(id, p, night, r, base, gain = 1.5, scale = 1) {
		const L = LIGHTS;
		const list = L[id] ?? L[id.replace(/_\d$/, "_1")] ?? [];
		for (const [dx, dy, k] of list) {
			const a = (base + night * gain) * (k ?? 1) * flickNow;
			if (a < .04 || F.lights.length >= MAX_LIGHTS) continue;
			F.lights.push({
				x: p.x + dx * scale,
				y: p.y + dy * scale,
				r: r * (.7 + .3 * (k ?? 1)) + night * 12,
				c: [
					1 * a,
					.64 * a,
					.3 * a
				]
			});
		}
	}
	const characterLights = [];
	function lantern(x, y, flip, night, fade = 0) {
		const strength = Math.max(0, Math.min(1, (night - .15) / .65)) * (1 - fade);
		if (strength <= 0 || !inView(x, y, 24, 30)) return;
		const lx = x + (flip ? -6 : 6), ly = y - 8;
		sprite("town_lantern", 5, lx, ly + 2, {
			z: zOf(y) + 4e-4,
			fade: 1 - strength
		});
		const a = strength * .85;
		characterLights.push({
			x: lx,
			y: ly,
			r: 23,
			c: [
				a,
				a * .64,
				a * .3
			]
		});
	}
	/** Cut 109: the townsfolk — the smith at the forge's door from the first building, a child about the fire and the well from the
	*  second, the merchant at the stall from the third, the carter up and down the south road when all facilities stand; a step bob, no walk frames */
	function folk(s, night) {
		if (!s.home) return;
		const bob = (ph, rate = 1.3) => Math.floor(t * rate + ph) & 1;
		if (s.buildings.some((b) => b.id === "blacksmith")) {
			const p = FOLK_AT.smith;
			sprite("town_smith", 23, p.x, p.y - bob(.3, 2.2), { flip: false });
			lantern(p.x, p.y - bob(.3, 2.2), false, night);
		}
		if (s.stage >= 3) {
			const p = FOLK_AT.merchant;
			sprite("town_merchant", 22, p.x, p.y - bob(.7, .9), { flip: true });
			lantern(p.x, p.y - bob(.7, .9), true, night);
		}
		for (const w of townsfolk) {
			if (w.minStage > s.stage) continue;
			const at = walkerAt(w, t);
			if (!at) continue;
			const step = at.moving && (Math.floor(t * 6 + w.lag) & 1) === 1;
			sprite(w.sprite, w.h, at.x, at.y - (step ? 1 : 0), { flip: at.dx < -.01 });
			lantern(at.x, at.y - (step ? 1 : 0), at.dx < -.01, night);
			if (w.carry) sprite(w.carry, w.carryH ?? 14, at.x + (at.dx < -.01 ? 13 : -13), at.y, {
				flip: at.dx < -.01,
				z: zOf(at.y) - 2e-4
			});
		}
		// fireflies from dusk: a dozen motes drifting over the grass, each blinking on its own beat
		if (night > .35) for (let i = 0; i < 14; i++) {
			const hx = hashN(i, 31), hy = hashN(i, 57);
			const bx = PLOTS.fire.x + (hx % 2e3 / 1e3 - 1) * 9 * TILE, by = PLOTS.fire.y + (hy % 2e3 / 1e3 - 1) * 7 * TILE;
			const x = bx + Math.sin(t * .37 + i) * 10 + Math.sin(t * 1.1 + i * 2.3) * 3, y = by + Math.cos(t * .29 + i * 1.7) * 7;
			const blink = Math.max(0, Math.sin(t * (.8 + hx % 7 / 10) + i * 1.9));
			if (blink < .25) continue;
			sprite("fx_dot_e8f08a", 1, x, y, {
				z: 2.55,
				fade: 1 - blink
			});
			if (blink > .8 && F.lights.length < MAX_LIGHTS - 4) F.lights.push({
				x,
				y,
				r: 7,
				c: [
					.5 * night,
					.6 * night,
					.25 * night
				]
			});
		}
	}
	function completionGlint(p, at) {
		if (at === undefined || t - at < BUILD_ASSEMBLY_S || t - at >= BUILD_FX_S) return;
		const g = (t - at - BUILD_ASSEMBLY_S) / (BUILD_FX_S - BUILD_ASSEMBLY_S);
		sprite("fx_glint", effectsLevel() === "low" ? 6 : 9, p.x + 18, p.y - p.h + 8 + g * 4, {
			z: 3,
			fade: Math.max(0, g * 1.2 - .2)
		});
	}
	function buildingSprite(id, look) {
		const p = PLOTS[id], at = builtAt.get(id);
		const age = at === undefined ? BUILD_FX_S : t - at;
		const art = (n) => [`town_${id}_${n}`, `town_${id}_1`];
		if (at === undefined || age >= BUILD_ASSEMBLY_S) sprite(art(look), p.h, p.x, p.y);
		else {
			const oldLook = upgradeFrom.get(id);
			if (oldLook !== undefined) sprite(art(oldLook), p.h, p.x, p.y);
			else sprite("town_plot", 16, p.x, p.y);
			const reveal = Math.max(0, Math.min(1, (age - .6) / .6));
			sprite("town_scaffold", oldLook !== undefined ? 28 : p.h, p.x, p.y, {
				fade: reveal,
				ground: true
			});
			if (reveal > 0) sprite(art(look), p.h, p.x, p.y, { fade: 1 - reveal });
		}
		completionGlint(p, at);
	}
	function frame() {
		const s = state;
		if (!buildFxEnabled()) {
			builtAt.clear();
			upgradeFrom.clear();
			dusted.clear();
			for (let i = parts.length - 1; i >= 0; i--) if (parts[i].kind === "dust") parts.splice(i, 1);
		} else for (const [id, at] of builtAt) if (t - at >= BUILD_FX_S) {
			builtAt.delete(id);
			upgradeFrom.delete(id);
			dusted.delete(id);
		}
		F.n = 0;
		F.lights.length = 0;
		characterLights.length = 0;
		const hour = hourOverride ?? localHour();
		F.night = nightOf(hour);
		F.amb = ambientOf(F.night);
		const night = F.night;
		ground();
		grassWind();
		// trees (two kinds), the cliff's rim of trees
		for (let i = 0; i < trees.length; i++) {
			const p = trees[i], sl = atlas.get(p.k ? "town_env_tree_1" : "town_env_tree_0", p.h);
			if (inView(p.x, p.y, sl.w, sl.h)) push(sl, Math.round(p.x), Math.round(p.y), zOf(p.y), false, p.d ?? 1);
		}
		// the mouth, its torches, the depth plaque's light
		const m = PLOTS.mouth;
		sprite(["town_mouth_cave"], m.h, m.x, m.y);
		const fl = Math.floor(t * 6) & 1;
		void fl;
		emitters("town_mouth_cave", m, night, 30, .5, .7);
		// the camp: the fire, the tent, the crate
		const f = PLOTS.fire;
		if (s.home) sprite([`town_campfire_${Math.floor(t * 5) & 1}`, "town_campfire_0"], f.h, f.x, f.y);
		const flick = .9 + .1 * Math.sin(t * 11) * Math.sin(t * 3.7);
		if (s.home) F.lights.push({
			x: f.x,
			y: f.y - 8,
			r: (46 + night * 44) * flick,
			c: [
				1,
				.6,
				.26
			].map((v) => v * (.45 + night * 1.5) * flick)
		});
		flickNow = flick;
		if (s.home) {
			const p = PLOTS.house, look = houseLook(s);
			buildingSprite("house", look);
			emitters(`town_house_${look}`, p, night, 16, 0, 1.3, p.h / 64);
		}
		if (s.home && night > .3) F.lights.push({
			x: PLOTS.tent.x,
			y: PLOTS.tent.y - 6,
			r: 14,
			c: [
				.9,
				.55,
				.25
			]
		});
		if (s.home) sprite("town_crate", PLOTS.crate.h, PLOTS.crate.x, PLOTS.crate.y);
		// Cut 109: the dressing the stage has earned, the lamps lit at dusk
		for (const q of PROPS) {
			if (q.stage > s.stage || !s.home && q.stage === 0) continue;
			sprite(q.id, q.h, q.x, q.y, { flip: q.flip });
			if (q.lamp && night > .15 && F.lights.length < MAX_LIGHTS) {
				const a = (.2 + night * 1.05) * flickNow;
				F.lights.push({
					x: q.x - 2,
					y: q.y - q.h * .78,
					r: 20 + night * 10,
					c: [
						1 * a,
						.66 * a,
						.32 * a
					]
				});
			}
			if (q.id === "town_stall") emitters("town_stall", q, night, 12, 0, .6, q.h / 40);
		}
		for (const id of s.services ?? []) {
			const p = SERVICE_PLOTS[id];
			const reincarnating = id === "device" && s.residents?.some((r) => r.phase === "reincarnating");
			const animate = !motionPreference.matches && effectsLevel() !== "off";
			const spriteId = id === "device" && reincarnating ? `town_service_device_active_${animate ? Math.floor(t * 2) & 1 : 0}` : `town_service_${id}`;
			sprite(spriteId, p.h, p.x, p.y, { ground: true });
			if (id === "pool") {
				for (const spot of homeSpots) sprite("town_bench", 8, spot.pool.x, spot.pool.y + 2, { ground: true });
				if (animate) {
					const waves = effectsLevel() === "low" ? 1 : 2;
					for (let i = 0; i < waves; i++) sprite("fx_dot_a4bcd6", 1, p.x - 10 + i * 18 + Math.round(Math.sin(t * .7 + i) * 2), p.y - 10 + i * 3, {
						z: zOf(p.y) + 1e-4,
						fade: .5
					});
				}
			}
			if (id === "device") for (const spot of homeSpots) sprite("town_service_station", 6, spot.device.x, spot.device.y + 2, { ground: true });
			if (night > .15 && F.lights.length < MAX_LIGHTS) {
				const lx = id === "guild" ? p.x + 17 : id === "device" ? p.x + 16 : p.x - 25;
				const ly = id === "guild" ? p.y - 20 : id === "device" ? p.y - 9 : p.y - 6;
				if (id === "pool") sprite("town_lantern", 8, lx, ly, { ground: true });
				const a = night * .42;
				F.lights.push({
					x: lx,
					y: ly,
					r: id === "pool" ? 12 : 17,
					c: [
						a,
						.64 * a,
						.3 * a
					]
				});
			}
		}
		folk(s, night);
		if (s.board) sprite("town_board", PLOTS.board.h, PLOTS.board.x, PLOTS.board.y);
		// the buildings: scaffold → built (dust, a glint)
		for (const b of s.buildings) {
			const p = PLOTS[b.id];
			buildingSprite(b.id, b.look);
			// the painted emitters (art/town_lights.json: the forge's mouth, lit windows): the forge always, the windows at night
			emitters(`town_${b.id}_${b.look}`, p, night, b.id === "blacksmith" ? 26 : 18, b.id === "blacksmith" ? .35 : 0);
		}
		if (s.staked) {
			const p = PLOTS[s.staked.id];
			// Ready plots use the larger painted foundation in the UI overlay.
			if (!s.staked.ready && s.staked.id !== "house") sprite("town_plot", 16, p.x, p.y);
		}
		// Cut 30.5: the haul chest by the mouth — full, it hops and glints; open, the lid up a moment after the tap
		if (s.chest) {
			const c = CHEST_AT, st = s.chest.state, full = st === "full";
			const hop = full ? -Math.round(Math.max(0, Math.sin(t * 4)) * 2) : 0;
			sprite([`town_haul_chest${st === "closed" ? "" : `_${st}`}`, "town_haul_chest"], c.h, c.x, c.y + hop);
			if (full) {
				const g = t * .7 % 1;
				sprite("fx_glint", 7, c.x + 5, c.y - c.h + 1 + hop, {
					z: 3,
					fade: Math.min(1, Math.abs(g - .5) * 2.4)
				});
				if (F.lights.length < MAX_LIGHTS) F.lights.push({
					x: c.x,
					y: c.y - 6,
					r: 14 + night * 8,
					c: [
						.9,
						.72,
						.3
					]
				});
			}
		}
		// Cut 30.5: the workers at their posts — an idle beat (two frames, desynchronised); the lit node's worker greyed, still; a new hire
		// walks out of the tent to his post
		for (const w of s.workers) {
			const p = workerAt(w);
			if (!p) continue;
			let x = p.x, y = p.y, moving = false, flip = false;
			const legs = arrive.get(w.id);
			if (legs?.length) {
				const at = walkerAt({
					legs,
					from: legs[0].t0,
					to: Infinity
				}, t);
				if (at && t < legs[legs.length - 1].t1) {
					x = at.x;
					y = at.y;
					moving = at.moving;
					flip = at.dx < -.01;
				} else arrive.delete(w.id);
			}
			const k = hashN(w.id.length, w.id.charCodeAt(0), w.id.charCodeAt(w.id.length - 1));
			const beat = .9 + k % 50 / 100, phase = k % 97 / 31;
			const step = moving && (Math.floor(t * 6.5) & 1) === 1;
			const frameN = w.lit || moving ? 0 : Math.floor((t + phase) / beat) & 1;
			if (w.lit) {
				const g = atlas.grey(workerIds(w.id), 24);
				if (inView(x, y, g.w, g.h)) {
					grounding(x, y, g.w, g.h);
					push(g, Math.round(x), Math.round(y), zOf(y), flip, 1, 0);
				}
			} else sprite(workerIds(w.id, frameN), 24, x, y - (step ? 1 : 0), {
				flip,
				dim: w.paused ? .7 : 1
			});
			// week 2: his rank, quiet — a gilt pip over his head per rank past the first (II ·, III ··)
			if (!w.lit && w.rank > 1) for (let r = 0; r < w.rank - 1; r++) sprite("fx_dot_d8b45a", 2, x - (w.rank - 2) * 1.5 + r * 3, y - 26 - (step ? 1 : 0), { z: zOf(y) + 3e-4 });
			if (!w.lit) lantern(x, y - (step ? 1 : 0), flip, night);
		}
		// the pen: penned pets lie by the kennel
		s.penned.forEach((k, j) => {
			const p = PLOTS.kennel;
			sprite([k, "town_dog"], 10, p.x - 20 + j * 12, p.y + 8, {
				flip: j % 2 === 1,
				ground: true
			});
		});
		// walkers
		let live = 0;
		for (const w of walkers) {
			const at = w.follow ? walkerAt(w.follow, t - w.lag) : walkerAt(w, t);
			if (!at || w.follow && t < w.from || t > w.to) continue;
			const offset = (w.follow ?? w).homeOffset;
			let x = at.x + (offset?.x ?? 0), y = at.y + (offset?.y ?? 0);
			if (w.follow && at.moving) {
				x -= Math.sign(at.dx) * 4;
				y += 2;
			}
			const flip = at.dx < -.01;
			let fade = 0;
			if (w.emerge) {
				const age = t - w.from;
				if (age < .5) fade = 1 - age / .5;
			}
			if (w.vanish && w.to - t < .5) fade = Math.max(fade, 1 - (w.to - t) / .5);
			if (w === hero && walkingIn) {
				const g = (t - walkingIn.t0) / (walkingIn.t1 - walkingIn.t0);
				if (g > .75) fade = Math.min(1, (g - .75) * 4);
			}
			if (w.reincarnating) fade = Math.max(fade, motionPreference.matches || effectsLevel() === "off" ? .35 : .3 + Math.sin(t * 2) * .12);
			const step = at.moving && (Math.floor(t * 6.5 + w.lag * 3) & 1) === 1;
			const ids = step ? w.walk : w.sprite;
			const previousQuads = F.n;
			const mappedHero = w.sprite[0] === "hero_fighter" || w.sprite[0] === "hero_fighter_male" || townVolumePrototype() && volumeKind(w.sprite[0]) === 5;
			sprite(ids, w.h, x, y - (step ? 1 : 0), {
				flip,
				fade,
				ground: true,
				groundY: townLightPrototype() && mappedHero ? y : undefined
			});
			if (F.n > previousQuads && !mappedHero) F.quads[F.n - 1].relief = 0;
			if (!w.pet) lantern(x, y - (step ? 1 : 0), flip, night, fade);
			if (w.carry) {
				const back = (flip ? -1 : 1) * (w.carry === "town_chest_glow" ? 6 : 7);
				sprite(w.carry, w.carryH ?? 6, x + back, y - 8 + (w.carryH ?? 6) - (step ? 1 : 0), {
					z: zOf(y) + 2e-4,
					flip,
					fade
				});
				if (w.carry === "town_chest_glow") F.lights.push({
					x: x + back,
					y: y - 8,
					r: 18,
					c: [
						1,
						.85,
						.4
					]
				});
			}
			live++;
		}
		F.live = live;
		// particles: smoke over the fire and the forge's chimney, embers, forge sparks, the build's dust
		tickParts(night);
		for (const p of parts) {
			const life = p.age / p.life;
			sprite(`fx_dot_${p.c}`, p.s, p.x, p.y, {
				z: p.kind === "smoke" ? 2.5 : 2.6,
				fade: p.kind === "smoke" ? Math.max(0, life * 1.3 - .3) : Math.max(0, life * 1.6 - .6)
			});
			if (p.kind === "spark" && night > .5 && F.lights.length < MAX_LIGHTS) F.lights.push({
				x: p.x,
				y: p.y,
				r: 6,
				c: [
					1,
					.6,
					.2
				]
			});
		}
		// Prioritize people over decorative motes within the existing shader budget.
		F.lights.unshift(...characterLights);
		F.lights.length = Math.min(F.lights.length, MAX_LIGHTS);
	}
	let emitT = 0, sparkT = 0, chimT = 0;
	function tickParts(night) {
		void night;
		const dt = Math.min(.1, t - emitT);
		emitT = t;
		const f = PLOTS.fire;
		const rand = Math.random;
		if (state.home && rand() < dt * 5) parts.push({
			x: f.x + (rand() - .5) * 4,
			y: f.y - 10,
			vx: (rand() - .5) * 2,
			vy: -10 - rand() * 4,
			age: 0,
			life: 2.4 + rand(),
			kind: "smoke",
			c: SMOKE[Math.floor(rand() * 3)],
			s: rand() < .5 ? 2 : 3
		});
		if (state.home && rand() < dt * 4) parts.push({
			x: f.x + (rand() - .5) * 6,
			y: f.y - 6,
			vx: (rand() - .5) * 6,
			vy: -22 - rand() * 10,
			age: 0,
			life: .6 + rand() * .4,
			kind: "ember",
			c: EMBER[Math.floor(rand() * 3)],
			s: 1
		});
		const smith = state.buildings.find((b) => b.id === "blacksmith" && !(builtAt.has(b.id) && t - builtAt.get(b.id) < BUILD_ASSEMBLY_S));
		if (smith) {
			const p = PLOTS.blacksmith;
			if (t - sparkT > 1.5 + hashN(Math.floor(t)) % 10 / 10) {
				sparkT = t;
				for (let i = 0; i < 7; i++) parts.push({
					x: p.x - 14,
					y: p.y - 8,
					vx: (rand() - .5) * 40,
					vy: -20 - rand() * 25,
					age: 0,
					life: .4 + rand() * .3,
					kind: "spark",
					c: EMBER[Math.floor(rand() * 3)],
					s: 1
				});
			}
			if (t - chimT > .45) {
				chimT = t;
				parts.push({
					x: p.x + 14 + (rand() - .5) * 2,
					y: p.y - p.h + 2,
					vx: 3 + rand() * 2,
					vy: -8 - rand() * 3,
					age: 0,
					life: 2.6 + rand(),
					kind: "smoke",
					c: SMOKE[Math.floor(rand() * 3)],
					s: 2
				});
			}
		}
		for (const [id, at] of builtAt) if (buildFxEnabled() && t - at >= BUILD_ASSEMBLY_S && !dusted.has(id)) {
			dusted.add(id);
			const p = PLOTS[id];
			for (let i = 0; i < (effectsLevel() === "low" ? 8 : 22); i++) {
				const a = rand() * Math.PI * 2, v = 14 + rand() * 22;
				parts.push({
					x: p.x + Math.cos(a) * 14,
					y: p.y - 4,
					vx: Math.cos(a) * v,
					vy: Math.sin(a) * v * .4 - 6,
					age: 0,
					life: .5 + rand() * .3,
					kind: "dust",
					c: (id === "blacksmith" ? SMOKE : DUST)[Math.floor(rand() * 3)],
					s: 2
				});
			}
		}
		for (let i = parts.length - 1; i >= 0; i--) {
			const p = parts[i];
			p.age += dt;
			if (p.age >= p.life) {
				parts.splice(i, 1);
				continue;
			}
			if (p.kind === "smoke") {
				p.vx += Math.sin(t * 1.3 + i) * dt * 2;
				p.s = p.age / p.life > .5 ? 3 : p.s;
			}
			if (p.kind === "spark") p.vy += 70 * dt;
			if (p.kind === "dust") {
				p.vx *= 1 - dt * 3;
				p.vy *= 1 - dt * 3;
			}
			p.x += p.vx * dt;
			p.y += p.vy * dt;
		}
		if (parts.length > 220) parts.splice(0, parts.length - 220);
	}
	const dusted = new Set();
	// -- the camera: the stage's box fits the view, k = whole device px per texel --
	function fit() {
		const s = state;
		if (!s) return;
		const r = el.getBoundingClientRect();
		const dpr = window.devicePixelRatio || 1;
		const W = Math.max(1, Math.round(r.width * dpr)), H = Math.max(1, Math.round(r.height * dpr));
		// the box: what stands (the mouth, the camp, the buildings, the staked plot) with a margin
		let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
		const add = (p, hw) => {
			x0 = Math.min(x0, p.x - hw);
			x1 = Math.max(x1, p.x + hw);
			y0 = Math.min(y0, p.y - p.h);
			y1 = Math.max(y1, p.y + 6);
		};
		add(PLOTS.mouth, 52);
		add(PLOTS.fire, 30);
		add(PLOTS.tent, 18);
		add(PLOTS.crate, 10);
		for (const b of s.buildings) add(PLOTS[b.id], 44);
		for (const id of s.services ?? []) add(PLOTS[id], id === "guild" ? 32 : id === "pool" ? 30 : 23);
		for (const id of ["pool", "device"]) if (s.services?.includes(id)) for (const spot of homeSpots) add({
			...spot[id],
			h: 44
		}, 34);
		for (const w of s.workers) {
			const p = workerAt(w);
			if (p) add({
				...p,
				h: 24
			}, 10);
		}
		if (s.staked) add({
			...PLOTS[s.staked.id],
			h: 22
		}, 24);
		for (const q of PROPS) if (q.stage <= s.stage && q.stage > 0 && q.y < PLOTS.kennel.y + 4.5 * TILE) add(q, 12);
		const M = 10;
		x0 -= M;
		x1 += M;
		y0 -= M;
		y1 += M + 4;
		// k: whole device px per texel — the largest that fits the box, or one more when that crops ≤ a margin's worth on each side
		const kf = Math.min(W / (x1 - x0), H / (y1 - y0));
		const up = Math.ceil(kf), fitsUp = W / up >= x1 - x0 - 2 * M - 4 && H / up >= y1 - y0 - 2 * M - 8;
		// (a low-density screen — fewer than 2 device px a texel — scales by a fraction instead: the town at k = 1 was a postage stamp)
		const k = up > kf && fitsUp ? up : kf < 2 ? Math.max(1, Math.floor(kf * 8) / 8) : Math.floor(kf);
		const w = Math.ceil(W / k), h = Math.ceil(H / k);
		let cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
		cx = Math.max(w / 2, Math.min(MAP_W * TILE - w / 2, cx));
		cy = Math.max(h / 2, Math.min(MAP_H * TILE - h / 2, cy));
		const nx0 = Math.round(cx - w / 2), ny0 = Math.round(cy - h / 2);
		if (nx0 !== F.x0 || ny0 !== F.y0 || w !== F.w || h !== F.h || k !== F.k || W !== F.W || H !== F.H) {
			F.x0 = nx0;
			F.y0 = ny0;
			F.w = w;
			F.h = h;
			F.k = k;
			F.W = W;
			F.H = H;
			layoutDirty = true;
			for (const fn of actorLayout) fn();
		}
	}
	function loop(now) {
		raf = 0;
		if (disposed) return;
		if (document.hidden) {
			last = now;
			return;
		}
		if (!el.isConnected) {
			last = now;
			raf = requestAnimationFrame(loop);
			return;
		}
		const idle = now - lastInput > IDLE_MS;
		// the frame cap: none while input arrives, IDLE_FPS after 10 s without; a software GL under automation (juice off: the headless
		// suites, seven browsers on the CPU) draws at SOFT_FPS — the scene is cosmetic and its frames were the suite's load
		const cap = document.documentElement.dataset.juice === "off" ? SOFT_FPS : idle ? IDLE_FPS : 0;
		if (cap && now - lastDraw < 1e3 / cap - 2) {
			raf = requestAnimationFrame(loop);
			return;
		}
		const dt = Math.min(.1, (now - last) / 1e3);
		last = now;
		lastDraw = now;
		t += dt;
		if (state) {
			const c0 = performance.now();
			fit();
			frame();
			if (gl && !glLost) {
				gl.render(F);
				if (c2d) c2d.style.display = "none";
			} else {
				const c = view2d();
				c.style.display = "block";
				drawTown2D(c, F, atlas.canvas);
			}
			cpu.push(performance.now() - c0);
			if (cpu.length > 120) cpu.shift();
			for (const fn of actorLayout) fn();
			frames++;
			fpsWin.push(now);
			while (fpsWin.length && fpsWin[0] < now - 1e3) fpsWin.shift();
			if (walkingIn && t >= walkingIn.t1) {
				const d = walkingIn.done;
				walkingIn = null;
				d();
			}
			if (layoutDirty) {
				layoutDirty = false;
				for (const fn of layoutFns) fn();
			}
		}
		raf = requestAnimationFrame(loop);
	}
	const start = () => {
		if (!raf && !disposed) {
			last = performance.now();
			raf = requestAnimationFrame(loop);
		}
	};
	const onVis = () => {
		if (!document.hidden) start();
	};
	document.addEventListener("visibilitychange", onVis);
	const poke = () => {
		lastInput = performance.now();
	};
	const inputs = [
		"pointerdown",
		"pointermove",
		"keydown",
		"wheel",
		"touchstart"
	];
	for (const ev of inputs) window.addEventListener(ev, poke, { passive: true });
	const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(() => {
		fit();
		layoutDirty = true;
	}) : null;
	ro?.observe(el);
	const css = (x, y) => {
		const dpr = window.devicePixelRatio || 1;
		return {
			x: (x - F.x0) * F.k / dpr,
			y: (y - F.y0) * F.k / dpr
		};
	};
	const actorRect = (id) => {
		const actor = walkers.find((w) => w.id === `resident:${id}`);
		if (!actor) return null;
		const at = walkerAt(actor, t);
		if (!at) return null;
		const slot = atlas.get(actor.sprite, actor.h);
		const x = at.x + (actor.homeOffset?.x ?? 0), y = at.y + (actor.homeOffset?.y ?? 0);
		const a = css(x - slot.w / 2, y - slot.h), b = css(x + slot.w / 2, y);
		return {
			x: a.x,
			y: a.y,
			w: b.x - a.x,
			h: b.y - a.y
		};
	};
	return {
		el,
		setState(s) {
			const prev = state;
			state = s;
			homeSpots = homeResidentSpots(s);
			if (prev) for (const id of builtAt.keys()) {
				const oldLook = id === "house" ? houseLook(prev) : prev.buildings.find((b) => b.id === id)?.look;
				const nextLook = id === "house" ? s.home ? houseLook(s) : undefined : s.buildings.find((b) => b.id === id)?.look;
				if (nextLook === undefined || oldLook !== undefined && nextLook < oldLook) {
					builtAt.delete(id);
					upgradeFrom.delete(id);
					dusted.delete(id);
				}
			}
			const changes = constructionChanges(prev, s);
			buildEvents += changes.length;
			if (changes.length && buildFxEnabled()) poke();
			if (buildFxEnabled()) for (const change of changes) {
				builtAt.set(change.id, t);
				dusted.delete(change.id);
				if (change.fromLook !== undefined) upgradeFrom.set(change.id, change.fromLook);
				else upgradeFrom.delete(change.id);
			}
			// a worker hired since the last state (he stood greyed, or nowhere): out of the tent, along the paths, to his post
			if (prev) for (const w of s.workers) {
				if (w.lit || prev.workers.some((x) => x.id === w.id && !x.lit)) continue;
				const p = workerAt(w);
				if (!p) continue;
				const legs = [];
				legsAlong([
					NODES.tent,
					...route("tent", nearestNode(p)),
					p
				], t + .2, SPEED * 1.3, legs);
				arrive.set(w.id, legs);
			}
			if (!prev || JSON.stringify([prev.services, prev.roster?.length]) !== JSON.stringify([s.services, s.roster?.length])) forest();
			const key = (x) => x ? JSON.stringify([
				x.home,
				x.hero,
				x.residents,
				x.roster,
				x.services,
				x.selectedHero,
				x.pets,
				x.parties.length,
				x.buildings.map((b) => b.id),
				x.seed
			]) : "";
			if (!prev || key(prev) !== key(s)) build(prev?.home === false && s.home);
			if (prev?.home === false && s.home && hero && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
				const destination = NODES.tent;
				hero.from = t + .5;
				hero.legs = [];
				legsAlong([{
					x: destination.x + 100,
					y: destination.y + 70
				}, destination], t + .5, 100, hero.legs);
			}
			fit();
			layoutDirty = true;
			start();
		},
		focusHero() {
			if (!hero) return;
			const at = walkerAt(hero, t);
			if (!at) return;
			const p = css(at.x, at.y);
			const ring = document.createElement("i");
			ring.className = "town-hero-focus";
			ring.setAttribute("aria-hidden", "true");
			ring.style.left = `${p.x}px`;
			ring.style.top = `${p.y}px`;
			el.appendChild(ring);
			window.setTimeout(() => ring.remove(), 1800);
			poke();
			start();
		},
		walkIn(ms = 700) {
			if (!hero || !state) return Promise.resolve();
			if (walkingIn) return new Promise((res) => {
				const d = walkingIn.done;
				walkingIn.done = () => {
					d();
					res();
				};
			});
			const at = walkerAt(hero, t) ?? {
				x: NODES.tent.x,
				y: NODES.tent.y
			};
			const pts = [{
				x: at.x,
				y: at.y
			}, ...route(nearestNode(at), "in")];
			let len = 0;
			for (let i = 1; i < pts.length; i++) len += dist(pts[i - 1], pts[i]);
			const dur = ms / 1e3;
			hero.from = Math.min(hero.from, t);
			hero.legs = [];
			hero.extend = undefined;
			hero.to = t + dur + .05;
			hero.vanish = false;
			legsAlong(pts, t, Math.max(SPEED, len / dur), hero.legs);
			poke();
			return new Promise((res) => {
				walkingIn = {
					t0: t,
					t1: t + dur,
					done: res
				};
				start();
			});
		},
		resize() {
			fit();
			layoutDirty = true;
		},
		rectOf(id) {
			if (!state) return null;
			if (id === "chest" || id.startsWith("worker:")) {
				// (the chest and the workers stand off the plots)
				const wk = id === "chest" ? null : state.workers.find((w) => `worker:${w.id}` === id);
				const p = id === "chest" ? state.chest ? CHEST_AT : null : wk ? workerAt(wk) : null;
				if (!p) return null;
				const s = id === "chest" ? atlas.get(["town_haul_chest"], CHEST_AT.h) : atlas.get(workerIds(wk.id), 24);
				const a = css(p.x - s.w / 2, p.y - s.h), b = css(p.x + s.w / 2, p.y);
				return {
					x: a.x,
					y: a.y,
					w: b.x - a.x,
					h: b.y - a.y
				};
			}
			if ((id === "guild" || id === "pool" || id === "device") && !state.services?.includes(id)) return null;
			const plot = id === "staked" ? state.staked ? PLOTS[state.staked.id] : null : PLOTS[id];
			if (!plot) return null;
			const ids = {
				mouth: ["town_mouth_cave"],
				fire: ["town_campfire_0"],
				tent: ["town_tent"],
				crate: ["town_crate"],
				board: ["town_board"],
				guild: ["town_service_guild"],
				pool: ["town_service_pool"],
				device: ["town_service_device"]
			};
			let s;
			if (id === "tent" && state.home) s = atlas.get([`town_house_${houseLook(state)}`, "town_house_1"], PLOTS.house.h);
			else if (id === "staked") s = atlas.get("town_plot", 16);
			else if (BUILDINGS.includes(id)) {
				const b = state.buildings.find((x) => x.id === id);
				if (!b) return null;
				s = atlas.get([`town_${id}_${b.look}`, `town_${id}_1`], plot.h);
			} else s = atlas.get(ids[id] ?? [id], plot.h);
			const a = css(plot.x - s.w / 2, plot.y - s.h), b = css(plot.x + s.w / 2, plot.y);
			return {
				x: a.x,
				y: a.y,
				w: b.x - a.x,
				h: b.y - a.y
			};
		},
		onLayout(fn) {
			layoutFns.push(fn);
		},
		onActors(fn) {
			actorLayout.push(fn);
		},
		actorRect,
		actorTargets() {
			return (state?.residents ?? []).flatMap((resident) => {
				const r = actorRect(resident.id);
				if (!r) return [];
				const w = Math.max(44, r.w), h = Math.max(44, r.h);
				return [{
					id: resident.id,
					x: Math.round(r.x + r.w / 2 - w / 2),
					y: Math.round(r.y + r.h / 2 - h / 2),
					w: Math.round(w),
					h: Math.round(h)
				}];
			});
		},
		stats() {
			const s = state;
			const sorted = [...cpu].sort((a, b) => a - b);
			return {
				fps: fpsWin.length,
				frames,
				cpuMs: cpu[cpu.length - 1] ?? 0,
				cpuP50: sorted[Math.floor(sorted.length * .5)] ?? 0,
				cpuP95: sorted[Math.floor(sorted.length * .95)] ?? 0,
				walkers: F.live,
				mode: gl && !glLost ? "gl" : "2d",
				glLost,
				k: F.k,
				night: F.night,
				characterLights: characterLights.length,
				dimensionalLight: gl && !glLost && townLightPrototype(),
				mappedSprites: F.quads.slice(0, F.n).filter((q) => q.relief).map((q) => ({
					kind: q.relief,
					flip: q.flip,
					x: q.x,
					y: q.y
				})),
				lights: F.lights.length,
				idle: performance.now() - lastInput > IDLE_MS,
				running: !!raf,
				terrainPaints,
				terrainPaintMs,
				windTufts,
				windSignature,
				buildings: s?.buildings.map((b) => b.id) ?? [],
				services: s?.services ?? [],
				residentStates: s?.residents?.map((r) => ({
					id: r.id,
					resting: !!r.resting,
					phase: r.phase
				})) ?? [],
				activeBuilds: [...builtAt.keys()],
				buildEvents,
				buildDust: parts.filter((p) => p.kind === "dust").length,
				staked: s?.staked?.id,
				markers: s?.markers.map((m) => `${m.kind}@${m.at}`) ?? [],
				view: [
					F.x0,
					F.y0,
					F.w,
					F.h
				],
				chest: s?.chest?.state,
				workers: s?.workers.map((w) => `${w.id}${w.lit ? "(lit)" : w.paused ? "(off)" : ""}`) ?? [],
				ranks: Object.fromEntries((s?.workers ?? []).filter((w) => !w.lit && w.rank > 1).map((w) => [w.id, w.rank]))
			};
		},
		stress(n) {
			stressN = n;
			if (state) addStress();
		},
		setHour(h) {
			hourOverride = h;
		},
		poke,
		dispose() {
			disposed = true;
			if (raf) cancelAnimationFrame(raf);
			raf = 0;
			document.removeEventListener("visibilitychange", onVis);
			for (const ev of inputs) window.removeEventListener(ev, poke);
			ro?.disconnect();
			glCanvas.removeEventListener("webglcontextlost", onLost);
			glCanvas.removeEventListener("webglcontextrestored", onRestored);
			glCanvas.remove();
			c2d?.remove();
			// the context is kept for the next mount (never left for the browser to reap: a dozen camps held a dozen contexts, and Chrome's
			// cap then forced the oldest live one — the watch's — lost); a lost one is let go
			if (gl && !glLost) {
				sharedGl?.gl.dispose();
				sharedGl = {
					canvas: glCanvas,
					gl,
					lost: false
				};
			} else gl?.dispose();
		}
	};
}
function segDist(p, a, b) {
	const dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy;
	const u = l2 ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2)) : 0;
	return Math.hypot(p.x - (a.x + u * dx), p.y - (a.y + u * dy));
}
// ---- the GL view: one target of town texels, the light pass upscaling it ---------------------------------------------------------
const MAX_LIGHTS = 32;
function townLightPrototype() {
	return import.meta.env.DEV && ["planes", "volume"].includes(new URLSearchParams(location.search).get("townLight") ?? "") && effectsLevel() !== "off";
}
function townVolumePrototype() {
	return import.meta.env.DEV && new URLSearchParams(location.search).get("townLight") === "volume" && effectsLevel() !== "off";
}
// Analytic surface masks in sprite-local coordinates: no repeated atlas reads,
// luma-derived geometry, extra buffer, or authored-art replacement. Local X is
// mirrored with the colour UV; normal X is then returned to world orientation.
const TOWN_RELIEF = `
${VOLUME_GLSL}
uniform float uReliefOn;
uniform float uReliefNight;
uniform vec4 uReliefL[${MAX_LIGHTS}];
uniform vec3 uReliefC[${MAX_LIGHTS}];
uniform int uReliefN;
varying vec2 vLocal;
varying vec2 vWorld;
vec3 townNormal(vec2 p, float kind) {
  if (uVolumeOn > 0.5 && kind > 1.5) return volumeNormal(p,kind);
  if (kind < 1.5) {
    // Main slate roof, lower timber side, open gable/front; chimney is masonry.
    if (p.x < 0.22 && p.y > 0.53) return normalize(vec3(-0.65, 0.0, 0.8));
    if (p.y > 0.40 + 0.27 * (1.0 - p.x)) return normalize(vec3(-0.22, 0.78, 0.65));
    if (p.x < 0.56) return normalize(vec3(-0.7, 0.05, 0.72));
    return normalize(vec3(0.48, 0.05, 0.88));
  }
  // Tiny head/cloth volumes: silhouette art remains authoritative. No gloss,
  // no treating ink/wash brightness as bumps. Both existing poses share axes.
  float head = step(0.76, p.y);
  float centre = mix(0.49, 0.46, head);
  float nx = clamp((p.x - centre) * 1.5, -0.65, 0.65);
  float ny = mix(0.12, clamp((p.y - 0.85) * 4.0, -0.3, 0.45), head);
  return normalize(vec3(nx, ny, 1.0));
}
vec3 townRelief(vec3 colour) {
  if (uReliefOn < 0.5 || vParam.y < 0.5) return colour;
  vec3 N = townNormal(vLocal, vParam.y);
  if (vParam.w > 0.5) N.x = -N.x;
  vec3 sky = normalize(vec3(mix(-0.55, -0.12, uReliefNight), 0.82, 0.85));
  float key = clamp((dot(N, sky) - 0.65) * 0.4, -0.18, 0.18);
  vec3 response = vec3(0.0);
  for (int i = 0; i < ${MAX_LIGHTS}; i++) {
    if (i >= uReliefN) break;
    vec2 d = uReliefL[i].xy - vWorld;
    float fall = max(0.0, 1.0 - length(d) / uReliefL[i].z);
    vec3 L = normalize(vec3(d.x, -d.y, 14.0));
    response += uReliefC[i] * fall * fall * (dot(N, L) - 0.65) * 0.3 * volumeVisibility(vWorld,uReliefL[i].xy);
  }
  float ink = smoothstep(0.035, 0.12, dot(colour, vec3(0.2126, 0.7152, 0.0722)));
  return colour * (vec3(1.0) + ink * (vec3(key) + clamp(response, vec3(-0.12), vec3(0.12))));
}
`;
const BLIT_VERT = `varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;
const BLIT_FRAG = `
${VOLUME_GLSL}
uniform sampler2D tex;
uniform vec2 uSize;      // the target, texels
uniform float uK;        // device px per texel
uniform float uDevH;
uniform vec3 uAmb;
uniform float uNight;
uniform vec4 uL[${MAX_LIGHTS}];   // x, y (texels from the view's top-left), radius, unused
uniform vec3 uC[${MAX_LIGHTS}];
uniform int uN;
uniform vec2 uOrigin;    // the view's top-left in world texels (the moonlight's patches stay on the ground)
uniform float uTime;
${BAYER_GLSL}
void main() {
  vec2 px = floor(vec2(gl_FragCoord.x, uDevH - gl_FragCoord.y) / uK);
  vec2 uv = vec2((px.x + 0.5) / uSize.x, 1.0 - (px.y + 0.5) / uSize.y);
  vec3 c = texture2D(tex, uv).rgb;
  vec3 light = vec3(0.0);
  float d4 = bayer4(px);
  for (int i = 0; i < ${MAX_LIGHTS}; i++) {
    if (i >= uN) break;
    vec2 d = px - uL[i].xy;
    float f = max(0.0, 1.0 - length(d * vec2(1.0, 1.25)) / uL[i].z);
    f = floor(f * f * 6.0 + d4) / 6.0;   // banded, dithered falloff: a pixel-art pool
    light += uC[i] * f * volumeVisibility(px + uOrigin, uL[i].xy + uOrigin);
  }
  // moonlight in drifting patches (the art note: the grass read flat): a slow, broad value swell over the ground, banded
  vec2 w = px + uOrigin;
  float m = sin(w.x * 0.021 + uTime * 0.04) * sin(w.y * 0.027 - uTime * 0.03) + 0.5 * sin((w.x + w.y) * 0.013 + 1.7);
  m = floor((0.5 + 0.33 * m) * 5.0 + d4) / 5.0;
  // night: what the warm light does not reach is graded toward the moon (cool, desaturated), so a lit window or the fire reads
  // against a blue world rather than a darker copy of the day
  float lit = clamp(dot(light, vec3(0.45, 0.35, 0.2)) * 2.0, 0.0, 1.0);
  float lum = dot(c, vec3(0.299, 0.587, 0.114));
  c = mix(c, vec3(0.62, 0.8, 1.2) * lum, 0.65 * uNight * (1.0 - lit));
  vec3 col = c * (uAmb * (0.84 + 0.36 * m) + light) + light * light * (0.05 + 0.12 * uNight) * (0.4 + uNight);
  // a soft vignette: the corners a step down (the night's more)
  vec2 q = px / uSize - 0.5;
  col *= 1.0 - (0.18 + 0.22 * uNight) * smoothstep(0.32, 0.75, length(q * vec2(1.0, 0.8)));
  gl_FragColor = vec4(col, 1.0);
}`;
class GLTown {
	renderer;
	rt;
	scene = new THREE.Scene();
	camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 1, 200);
	tex;
	terrainTex;
	groundL;
	objL;
	shadowL;
	blitScene = new THREE.Scene();
	blitCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
	mat;
	groundKey = "";
	atlasV = -1;
	lv = Array.from({ length: MAX_LIGHTS }, () => new THREE.Vector4());
	lc = Array.from({ length: MAX_LIGHTS }, () => new THREE.Vector3());
	volumeBlocks = [new THREE.Vector4(), new THREE.Vector4()];
	canvas;
	atlas;
	constructor(canvas, atlas) {
		this.canvas = canvas;
		this.atlas = atlas;
		this.renderer = new THREE.WebGLRenderer({
			canvas,
			antialias: false,
			alpha: false,
			stencil: false,
			depth: false,
			powerPreference: "high-performance",
			premultipliedAlpha: false
		});
		this.renderer.setPixelRatio(1);
		this.rt = new THREE.WebGLRenderTarget(4, 4, {
			minFilter: THREE.NearestFilter,
			magFilter: THREE.NearestFilter,
			generateMipmaps: false,
			depthBuffer: true,
			stencilBuffer: false,
			colorSpace: THREE.NoColorSpace
		});
		this.tex = new THREE.CanvasTexture(atlas.canvas);
		Object.assign(this.tex, {
			minFilter: THREE.NearestFilter,
			magFilter: THREE.NearestFilter,
			generateMipmaps: false,
			colorSpace: THREE.NoColorSpace,
			flipY: true,
			premultiplyAlpha: false
		});
		this.terrainTex = new THREE.CanvasTexture(document.createElement("canvas"));
		Object.assign(this.terrainTex, {
			minFilter: THREE.NearestFilter,
			magFilter: THREE.NearestFilter,
			generateMipmaps: false,
			colorSpace: THREE.NoColorSpace,
			flipY: true
		});
		this.groundL = new QuadLayer(this.terrainTex, 1, 1, 0);
		this.objL = new QuadLayer(this.tex, 1600, 1, 1);
		this.shadowL = new QuadLayer(this.tex, 800, 1, 1);
		const objectMat = this.objL.mesh.material;
		objectMat.vertexShader = objectMat.vertexShader.replace("varying vec2 vUv;", "varying vec2 vUv; varying vec2 vLocal; varying vec2 vWorld;").replace("vParam = iParam;", "vParam = iParam; vLocal = vec2(u, uv.y);").replace("gl_Position =", "vWorld = vec2(p.x, -p.y); gl_Position =");
		objectMat.fragmentShader = objectMat.fragmentShader.replace("void main() {", `${TOWN_RELIEF}\nvoid main() {`).replace("col = mix(col, uFlash, vParam.y * smoothstep(0.06, 0.3, l));", "col = townRelief(col);");
		Object.assign(objectMat.uniforms, {
			uVolumeOn: { value: 0 },
			uVolumeBlock: { value: this.volumeBlocks },
			uReliefOn: { value: 0 },
			uReliefNight: { value: 0 },
			uReliefL: { value: this.lv },
			uReliefC: { value: this.lc },
			uReliefN: { value: 0 }
		});
		// Town-only translucent ground pigment. Ordinary sprites retain their
		// existing hard alpha threshold; this layer writes no depth or light tags.
		const shadowMat = this.shadowL.mesh.material;
		shadowMat.fragmentShader = shadowMat.fragmentShader.replace("if (c.a < 0.5) discard;", "if (c.a < 0.01) discard;").replace("if (vParam.z > 0.0 && vParam.z > bayer4(gl_FragCoord.xy)) discard;", "").replace("gl_FragColor = vec4(col, uTag);", "gl_FragColor = vec4(col, c.a * (1.0 - vParam.z));");
		shadowMat.transparent = true;
		shadowMat.depthWrite = false;
		this.scene.add(this.groundL.mesh, this.objL.mesh, this.shadowL.mesh);
		this.camera.position.set(0, 0, 100);
		this.mat = new THREE.ShaderMaterial({
			vertexShader: BLIT_VERT,
			fragmentShader: BLIT_FRAG,
			depthTest: false,
			depthWrite: false,
			uniforms: {
				tex: { value: this.rt.texture },
				uSize: { value: new THREE.Vector2(4, 4) },
				uK: { value: 1 },
				uDevH: { value: 4 },
				uAmb: { value: new THREE.Vector3(1, 1, 1) },
				uNight: { value: 0 },
				uL: { value: this.lv },
				uC: { value: this.lc },
				uN: { value: 0 },
				uOrigin: { value: new THREE.Vector2() },
				uTime: { value: 0 },
				uVolumeOn: { value: 0 },
				uVolumeBlock: { value: this.volumeBlocks }
			}
		});
		this.blitScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.mat));
	}
	restored() {
		this.groundKey = "";
		this.atlasV = -1;
		this.tex.needsUpdate = true;
		this.terrainTex.needsUpdate = true;
	}
	/** the GL context is gone (forced lost on dispose, or by the browser) */
	isLost() {
		return this.renderer.getContext().isContextLost();
	}
	compareLighting(F) {
		const captures = [];
		for (const enabled of [false, true]) {
			this.render(F, enabled, 0);
			const pixels = new Uint8Array(F.w * F.h * 4);
			this.renderer.readRenderTargetPixels(this.rt, 0, 0, F.w, F.h, pixels);
			captures.push(pixels);
		}
		let changed = 0, unmapped = 0, alphaChanges = 0, max = 0, sum = 0;
		const maps = F.quads.slice(0, F.n).filter((q) => q.relief);
		const changedByKind = {};
		for (let y = 0; y < F.h; y++) for (let x = 0; x < F.w; x++) {
			const i = (y * F.w + x) * 4;
			const delta = Math.max(...[
				0,
				1,
				2
			].map((c) => Math.abs(captures[0][i + c] - captures[1][i + c])));
			if (captures[0][i + 3] !== captures[1][i + 3]) alphaChanges++;
			if (!delta) continue;
			changed++;
			sum += delta;
			max = Math.max(max, delta);
			const wx = F.x0 + x + .5, wy = F.y0 + F.h - y - .5;
			for (const q of maps) {
				if (wx >= q.x - q.w / 2 && wx <= q.x + q.w / 2 && wy <= q.y && wy >= q.y - q.h) changedByKind[q.relief] = (changedByKind[q.relief] ?? 0) + 1;
			}
			if (!maps.some((q) => wx >= q.x - q.w / 2 && wx <= q.x + q.w / 2 && wy <= q.y && wy >= q.y - q.h)) unmapped++;
		}
		const images = captures.map((pixels) => {
			const canvas = document.createElement("canvas");
			canvas.width = F.w;
			canvas.height = F.h;
			const ctx = canvas.getContext("2d"), image = ctx.createImageData(F.w, F.h);
			for (let y = 0; y < F.h; y++) image.data.set(pixels.subarray(y * F.w * 4, (y + 1) * F.w * 4), (F.h - 1 - y) * F.w * 4);
			ctx.putImageData(image, 0, 0);
			return canvas.toDataURL();
		});
		this.render(F);
		const material = this.objL.mesh.material;
		return {
			width: F.w,
			height: F.h,
			night: F.night,
			changed,
			unmapped,
			alphaChanges,
			maxDelta: max,
			meanChangedDelta: changed ? sum / changed : 0,
			changedByKind,
			mappedPoses: maps.map((q) => ({
				kind: q.relief,
				w: q.w,
				h: q.h,
				flip: q.flip
			})),
			shaderPatched: material.fragmentShader.includes("col = townRelief(col);") && material.vertexShader.includes("vLocal = vec2(u, uv.y)"),
			images
		};
	}
	render(F, reliefOverride, timeOverride) {
		const r = this.renderer;
		if (this.canvas.width !== F.W || this.canvas.height !== F.H) r.setSize(F.W, F.H, false);
		if (this.rt.width !== F.w || this.rt.height !== F.h) this.rt.setSize(F.w, F.h);
		if (this.atlas.version !== this.atlasV) {
			this.atlasV = this.atlas.version;
			this.tex.needsUpdate = true;
		}
		if (F.groundKey !== this.groundKey) {
			this.groundKey = F.groundKey;
			const L = this.groundL;
			L.begin();
			if (F.terrain) {
				this.terrainTex.image = F.terrain;
				this.terrainTex.needsUpdate = true;
				L.push(MAP_W * TILE / 2, -MAP_H * TILE, 0, MAP_W * TILE, MAP_H * TILE, 0, 0, 1, 1);
			}
			L.end();
		}
		const O = this.objL, S = this.shadowL;
		O.begin();
		S.begin();
		for (let i = 0; i < F.n; i++) {
			const q = F.quads[i];
			// .21/.22 are reserved for ground pigment; wind stays at .1.
			const layer = q.z === .21 || q.z === .22 ? S : O;
			layer.push(q.x, -q.y, q.z, q.w, q.h, q.s.u0, q.s.v0, q.s.u1, q.s.v1, q.dim, q.relief ?? 0, q.fade, q.flip ? 1 : 0);
		}
		O.end();
		S.end();
		const c = this.camera;
		c.left = F.x0;
		c.right = F.x0 + F.w;
		c.top = -F.y0;
		c.bottom = -(F.y0 + F.h);
		c.updateProjectionMatrix();
		const relief = this.objL.mesh.material.uniforms;
		relief.uReliefOn.value = reliefOverride ?? townLightPrototype() ? 1 : 0;
		const volume = townVolumePrototype() && (reliefOverride ?? true);
		relief.uVolumeOn.value = volume ? 1 : 0;
		for (const b of this.volumeBlocks) b.set(0, 0, 0, 0);
		let block = 0;
		if (volume) for (let i = 0; i < F.n && block < 2; i++) {
			const q = F.quads[i];
			if (q.relief === 3 || q.relief === 4) this.volumeBlocks[block++].set(q.x, q.y - 5, q.w * .27, Math.max(3, q.h * .07));
		}
		relief.uReliefNight.value = F.night;
		relief.uReliefN.value = Math.min(MAX_LIGHTS, F.lights.length);
		for (let i = 0; i < relief.uReliefN.value; i++) {
			const light = F.lights[i];
			this.lv[i].set(light.x, light.y, light.r, 0);
			this.lc[i].set(...light.c);
		}
		r.setRenderTarget(this.rt);
		r.setClearColor(1778706, 1);
		r.clear();
		r.render(this.scene, c);
		const u = this.mat.uniforms;
		u.uVolumeOn.value = volume ? 1 : 0;
		u.uSize.value.set(F.w, F.h);
		u.uK.value = F.k;
		u.uDevH.value = F.H;
		u.uAmb.value.set(...F.amb);
		u.uNight.value = F.night;
		const n = Math.min(MAX_LIGHTS, F.lights.length);
		for (let i = 0; i < n; i++) {
			const l = F.lights[i];
			this.lv[i].set(l.x - F.x0, l.y - F.y0, l.r, 0);
			this.lc[i].set(...l.c);
		}
		u.uN.value = n;
		u.uOrigin.value.set(F.x0, F.y0);
		u.uTime.value = timeOverride ?? performance.now() / 1e3;
		r.setRenderTarget(null);
		r.render(this.blitScene, this.blitCam);
	}
	// (the context is let go, not left for the browser to reap: a camp mounted a dozen times held a dozen contexts, and Chrome's cap
	// then forced the oldest live one — the watch's — lost)
	dispose() {
		this.groundL.dispose();
		this.objL.dispose();
		this.shadowL.dispose();
		this.mat.dispose();
		this.rt.dispose();
		this.tex.dispose();
		this.terrainTex.dispose();
		this.renderer.dispose();
		this.renderer.forceContextLoss();
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQVVBLFlBQVksV0FBVztBQUN2QixTQUFTLFdBQVcsa0JBQWtCO0FBQ3RDLFNBQVMsa0JBQWtCO0FBRTNCLFNBQVMsa0JBQWtCLHdCQUF3QixzQkFBc0I7QUFDekUsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxZQUFZLG1CQUFtQjtBQUN4QyxPQUFPLFlBQVk7QUFFbkIsT0FBTyxNQUFNLE9BQU87QUFDcEIsT0FBTyxNQUFNLFFBQVEsSUFDbkIsUUFBUTtBQUNWLE1BQU0sS0FBSyxJQUNULEtBQUs7QUFDUCxNQUFNLEtBQUssR0FBVyxPQUFtQjtDQUFFLEdBQUcsSUFBSTtDQUFNLElBQUksSUFBSSxNQUFNO0FBQUs7O0FBSzNFLE9BQU8sTUFBTSxZQUFZO0NBQUM7Q0FBYztDQUFVO0FBQU07QUFHeEQsT0FBTyxNQUFNLGdCQUFnQjtDQUMzQixPQUFPO0VBQUUsR0FBRztFQUFLLEdBQUc7RUFBSyxHQUFHO0NBQUc7Q0FDL0IsTUFBTTtFQUFFLEdBQUc7RUFBSyxHQUFHO0VBQUssR0FBRztDQUFHO0NBQzlCLFFBQVE7RUFBRSxHQUFHO0VBQUssR0FBRztFQUFLLEdBQUc7Q0FBRztBQUNsQzs7QUFXQSxPQUFPLE1BQU0sUUFBNEM7Q0FDdkQsR0FBRztDQUNILE9BQU87RUFBRSxHQUFHLEVBQUUsSUFBSSxHQUFHO0VBQUcsR0FBRztDQUFHO0NBQzlCLE1BQU07RUFBRSxHQUFHLEVBQUUsSUFBSSxJQUFJO0VBQUcsR0FBRztDQUFHO0NBQzlCLE1BQU07RUFBRSxHQUFHLEVBQUUsS0FBSyxLQUFLLEVBQUk7RUFBRyxHQUFHO0NBQUc7Q0FDcEMsT0FBTztFQUFFLEdBQUcsRUFBRSxLQUFLLEtBQUssRUFBSTtFQUFHLEdBQUc7Q0FBRztDQUNyQyxPQUFPO0VBQUUsR0FBRyxFQUFFLEtBQUssR0FBSyxJQUFJO0VBQUcsR0FBRztDQUFHO0NBQ3JDLE9BQU87RUFBRSxHQUFHLEVBQUUsS0FBSyxLQUFLLEdBQUc7RUFBRyxHQUFHO0NBQUc7Q0FDcEMsWUFBWTtFQUFFLEdBQUcsRUFBRSxLQUFLLEtBQUssSUFBSTtFQUFHLEdBQUc7Q0FBRztDQUMxQyxNQUFNO0VBQUUsR0FBRyxFQUFFLEtBQUssS0FBSyxJQUFJO0VBQUcsR0FBRztDQUFHO0NBQ3BDLFFBQVE7RUFBRSxHQUFHLEVBQUUsS0FBSyxLQUFLLElBQUk7RUFBRyxHQUFHO0NBQUc7QUFDeEM7QUFDQSxNQUFNLFFBQTRCO0NBQ2hDLElBQUksRUFBRSxJQUFJLEdBQUc7Q0FDYixPQUFPLEVBQUUsSUFBSSxHQUFHO0NBQ2hCLE9BQU8sRUFBRSxJQUFJLElBQUk7Q0FDakIsT0FBTyxFQUFFLEtBQUssS0FBSyxFQUFJO0NBQ3ZCLE1BQU0sRUFBRSxLQUFLLEtBQUssRUFBSTtDQUN0QixPQUFPLEVBQUUsSUFBSSxJQUFJO0NBQ2pCLE9BQU8sRUFBRSxLQUFLLEtBQUssS0FBSztDQUN4QixPQUFPLEVBQUUsS0FBSyxLQUFLLEtBQUs7Q0FDeEIsTUFBTSxFQUFFLEtBQUssTUFBTSxLQUFLO0NBQ3hCLE9BQU8sRUFBRSxLQUFLLEtBQUssS0FBSztDQUN4QixPQUFPLEVBQUUsSUFBSSxJQUFJO0NBQ2pCLE9BQU8sRUFBRSxJQUFJLElBQUk7Q0FDakIsUUFBUSxFQUFFLEtBQUssS0FBSyxJQUFJO0NBQ3hCLE1BQU0sRUFBRSxJQUFJLEVBQUU7Q0FDZCxPQUFPO0VBQUUsR0FBRztFQUFLLEdBQUc7Q0FBSTtDQUN4QixNQUFNO0VBQUUsR0FBRztFQUFLLEdBQUc7Q0FBSTtDQUN2QixRQUFRO0VBQUUsR0FBRztFQUFLLEdBQUc7Q0FBSTtBQUMzQjtBQUNBLE1BQU0sUUFBb0M7Q0FFeEM7RUFBQztFQUFNO0VBQVM7Q0FBRztDQUNuQjtFQUFDO0VBQVM7RUFBUztDQUFHO0NBQ3RCO0VBQUM7RUFBUztFQUFTO0NBQUc7Q0FDdEI7RUFBQztFQUFTO0VBQVE7Q0FBRztDQUNyQjtFQUFDO0VBQVM7RUFBUztDQUFHO0NBQ3RCO0VBQUM7RUFBUztFQUFTO0NBQUk7Q0FDdkI7RUFBQztFQUFTO0VBQVM7Q0FBSTtDQUN2QjtFQUFDO0VBQVM7RUFBUTtDQUFHO0NBQ3JCO0VBQUM7RUFBUTtFQUFTO0NBQUk7Q0FDdEI7RUFBQztFQUFTO0VBQVM7Q0FBSTtDQUN2QjtFQUFDO0VBQVM7RUFBUztDQUFJO0NBQ3ZCO0VBQUM7RUFBUztFQUFTO0NBQUc7Q0FDdEI7RUFBQztFQUFTO0VBQVU7Q0FBRztDQUN2QjtFQUFDO0VBQVM7RUFBUTtDQUFHO0NBQ3JCO0VBQUM7RUFBUztFQUFTO0NBQUc7Q0FDdEI7RUFBQztFQUFTO0VBQVE7Q0FBRztDQUNyQjtFQUFDO0VBQVM7RUFBVTtDQUFHO0FBQ3pCO0FBQ0EsTUFBTSxNQUFNLElBQUksSUFBc0I7QUFDdEMsS0FBSyxNQUFNLENBQUMsR0FBRyxNQUFNLE9BQU87Q0FDMUIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxHQUFJLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFJLENBQUMsQ0FBQztDQUNyQyxJQUFJLElBQUksR0FBRyxDQUFDLEdBQUksSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUksQ0FBQyxDQUFDO0FBQ3ZDO0FBQ0EsTUFBTSxRQUFRLEdBQU8sTUFBa0IsS0FBSyxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQzs7QUFFdEUsT0FBTyxTQUFTLE1BQU0sTUFBYyxJQUFrQjtDQUNwRCxNQUFNLElBQUksSUFBSSxJQUFvQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUMzQyxPQUFPLElBQUksSUFBb0IsR0FDL0IsT0FBTyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUM7Q0FDdkIsT0FBTyxLQUFLLE1BQU07RUFDaEIsSUFBSSxJQUFJO0VBQ1IsSUFBSSxPQUFPO0VBQ1gsS0FBSyxNQUFNLEtBQUssTUFDZCxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssWUFBWSxNQUFNO0dBQ2pDLE9BQU8sRUFBRSxJQUFJLENBQUM7R0FDZCxJQUFJO0VBQ047RUFDRixLQUFLLE9BQU8sQ0FBQztFQUNiLElBQUksTUFBTSxJQUFJO0VBQ2QsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUc7R0FDaEMsTUFBTSxLQUFLLE9BQU8sS0FBSyxNQUFNLElBQUssTUFBTSxFQUFHO0dBQzNDLElBQUksTUFBTSxFQUFFLElBQUksQ0FBQyxLQUFLLFdBQVc7SUFDL0IsRUFBRSxJQUFJLEdBQUcsRUFBRTtJQUNYLEtBQUssSUFBSSxHQUFHLENBQUM7SUFDYixLQUFLLElBQUksQ0FBQztHQUNaO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sTUFBZ0IsQ0FBQyxFQUFFO0NBQ3pCLE9BQU8sSUFBSSxPQUFPLE1BQU07RUFDdEIsTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUc7RUFDMUIsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sT0FBUSxNQUFNLEdBQUk7RUFDeEMsSUFBSSxRQUFRLENBQUM7Q0FDZjtDQUNBLE9BQU8sSUFBSSxLQUFLLE1BQU0sTUFBTSxFQUFHO0FBQ2pDO0FBQ0EsTUFBTSxlQUFlLE1BQWtCO0NBQ3JDLElBQUksSUFBSSxTQUNOLEtBQUs7Q0FDUCxLQUFLLE1BQU0sQ0FBQyxHQUFHLE1BQU0sT0FBTyxRQUFRLEtBQUssR0FBRztFQUMxQyxJQUFJLE1BQU0sUUFBUSxNQUFNLFFBQVE7RUFDaEMsTUFBTSxJQUFJLEtBQUssR0FBRyxDQUFDO0VBQ25CLElBQUksSUFBSSxJQUFJO0dBQ1YsS0FBSztHQUNMLElBQUk7RUFDTjtDQUNGO0NBQ0EsT0FBTztBQUNUOztBQXlCQSxPQUFPLE1BQU0sV0FBK0I7Q0FBRSxHQUFHLEVBQUUsS0FBSyxLQUFLLEdBQUc7Q0FBRyxHQUFHO0FBQUc7OztBQUd6RSxNQUFNLFlBQWdDO0NBQ3BDLGVBQWUsRUFBRSxLQUFLLEtBQUssSUFBSTtDQUMvQixRQUFRLEVBQUUsS0FBSyxLQUFLLElBQUk7Q0FDeEIsT0FBTztFQUFFLEdBQUcsY0FBYyxNQUFNLElBQUk7RUFBSSxHQUFHLGNBQWMsTUFBTSxJQUFJO0NBQUU7Q0FDckUsWUFBWSxFQUFFLEtBQUssS0FBSyxJQUFJO0NBQzVCLE9BQU8sRUFBRSxLQUFLLEtBQUssSUFBSTtDQUN2QixhQUFhLEVBQUUsS0FBSyxLQUFLLElBQUk7Q0FDN0IsYUFBYSxFQUFFLEtBQUssS0FBSyxJQUFJO0NBQzdCLFFBQVEsRUFBRSxLQUFLLEtBQUssR0FBRztDQUN2QixPQUFPLEVBQUUsS0FBSyxNQUFNLElBQUk7QUFDMUI7QUFJQSxNQUFNLFFBQWdCO0NBQ3BCO0VBQUUsSUFBSTtFQUFpQixHQUFHLEVBQUUsS0FBSyxNQUFNLEtBQUs7RUFBRyxHQUFHO0VBQUksT0FBTztDQUFFO0NBQy9EO0VBQUUsSUFBSTtFQUFpQixHQUFHLEVBQUUsS0FBSyxLQUFLLEtBQUs7RUFBRyxHQUFHO0VBQUksT0FBTztFQUFHLE1BQU07Q0FBSztDQUMxRTtFQUFFLElBQUk7RUFBYSxHQUFHLEVBQUUsS0FBSyxLQUFLLElBQUk7RUFBRyxHQUFHO0VBQUksT0FBTztDQUFFO0NBQ3pEO0VBQUUsSUFBSTtFQUFpQixHQUFHLEVBQUUsS0FBSyxNQUFNLElBQUk7RUFBRyxHQUFHO0VBQUksT0FBTztFQUFHLE1BQU07Q0FBSztDQUMxRTtFQUFFLElBQUk7RUFBYyxHQUFHLEVBQUUsS0FBSyxLQUFLLElBQUk7RUFBRyxHQUFHO0VBQUksT0FBTztDQUFFO0NBQzFEO0VBQUUsSUFBSTtFQUFhLEdBQUcsRUFBRSxLQUFLLEtBQUssSUFBSTtFQUFHLEdBQUc7RUFBSSxPQUFPO0VBQUcsTUFBTTtDQUFLO0NBQ3JFO0VBQUUsSUFBSTtFQUFpQixHQUFHLEVBQUUsS0FBSyxNQUFNLElBQUk7RUFBRyxHQUFHO0VBQUksT0FBTyxVQUFVO0VBQVEsTUFBTTtDQUFLO0FBQzNGOztBQUVBLE1BQU0sVUFBVTtDQUFFLE9BQU8sRUFBRSxLQUFLLEdBQUssS0FBSztDQUFHLFVBQVUsRUFBRSxLQUFLLE1BQU0sS0FBSztBQUFFO0FBQzNFLE9BQU8sTUFBTSxZQUFZLE1BQ3ZCLFVBQVUsRUFBRSxPQUFRLE1BQXlDLEVBQUUsU0FBUzs7QUFFMUUsT0FBTyxNQUFNLGFBQWEsSUFBWSxRQUFRLE1BQzVDLFFBQVEsQ0FBQyxlQUFlLEdBQUcsS0FBSyxlQUFlLElBQUksSUFBSSxDQUFDLGVBQWUsSUFBSTs7QUFzQzdFLE9BQU8sU0FBUyxrQkFDZCxHQUNvQjtDQUNwQixNQUFNLE1BQU0sQ0FBQyxHQUFJLEVBQUUsVUFBVSxFQUFFLFdBQVcsS0FBSyxNQUFNLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFFLENBQUMsQ0FBQyxNQUNuRixHQUFHLE1BQU0sSUFBSSxDQUNoQjtDQUNBLE9BQU8sSUFBSSxLQUFLLElBQUksV0FBVztFQUM3QjtFQUNBLE1BQU0sVUFBVSxJQUFJO0dBQUUsR0FBRztHQUFLLEdBQUc7RUFBSSxJQUFJO0dBQUUsR0FBRyxPQUFPLFFBQVEsS0FBSztHQUFJLEdBQUc7RUFBSTtFQUM3RSxRQUFRLFVBQVUsSUFBSTtHQUFFLEdBQUc7R0FBSyxHQUFHO0VBQUksSUFBSTtHQUFFLEdBQUcsT0FBTyxRQUFRLEtBQUs7R0FBSSxHQUFHO0VBQUk7Q0FDakYsRUFBRTtBQUNKOztBQUdBLE9BQU8sU0FBUyxvQkFDZCxNQUNBLE1BQ21EO0NBQ25ELElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQztDQUNuQixNQUFNLFVBQTZELENBQUM7Q0FDcEUsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLE1BQU0sUUFBUSxLQUFLLEVBQUUsSUFBSSxRQUFRLENBQUM7TUFDcEQsSUFBSSxLQUFLLFFBQVEsS0FBSyxRQUFRLFVBQVUsSUFBSSxJQUFJLFVBQVUsSUFBSSxHQUNqRSxRQUFRLEtBQUs7RUFBRSxJQUFJO0VBQVMsVUFBVSxVQUFVLElBQUk7Q0FBRSxDQUFDO0NBQ3pELEtBQUssTUFBTSxZQUFZLEtBQUssV0FBVztFQUNyQyxNQUFNLE1BQU0sS0FBSyxVQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sU0FBUyxFQUFFO0VBQzNELElBQUksQ0FBQyxLQUFLLFFBQVEsS0FBSyxFQUFFLElBQUksU0FBUyxHQUFHLENBQUM7T0FDckMsSUFBSSxTQUFTLE9BQU8sSUFBSSxNQUFNLFFBQVEsS0FBSztHQUFFLElBQUksU0FBUztHQUFJLFVBQVUsSUFBSTtFQUFLLENBQUM7Q0FDekY7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxNQUFNLG1CQUFtQixLQUN2QixhQUFhO0FBV2YsTUFBTSxTQUFTLEdBQUcsT0FBeUI7Q0FDekMsSUFBSSxJQUFJO0NBQ1IsS0FBSyxNQUFNLEtBQUssSUFBSTtFQUNsQixLQUFLLElBQUk7RUFDVCxJQUFJLEtBQUssS0FBSyxHQUFHLFFBQVE7RUFDekIsS0FBSyxNQUFNO0NBQ2I7Q0FDQSxPQUFPLE1BQU07QUFDZjtBQUNBLE9BQU8sTUFBTSxZQUFZLE1BQU0sSUFBSSxLQUFLLE1BQ3RDLEtBQUssT0FBTyxJQUFJLFFBQVEsSUFBSSxJQUFJLGtCQUFrQixJQUFJLE9BQVMsS0FBUTs7QUFFekUsT0FBTyxNQUFNLGFBQWEsTUFBTSxJQUFJLEtBQUssTUFDdkMsSUFBSSxTQUFTLElBQ2IsSUFBSSxXQUFXLElBQUksS0FDbkIsSUFBSSxXQUFXLElBQUksT0FDbkIsSUFBSSxnQkFBZ0IsSUFBSTtBQUMxQixNQUFNLGNBQWM7O0FBRXBCLE9BQU8sTUFBTSxhQUFhLE1BQ3hCLEVBQUUsU0FBUyxVQUFVLFNBQVMsSUFBSSxFQUFFLFNBQVMsSUFBSSxJQUFJOztBQUV2RCxPQUFPLFNBQVMsVUFBVSxHQUFZLFNBQStCLElBQWMsQ0FBQyxHQUFjO0NBQ2hHLE1BQU0sT0FBTyxFQUFFO0NBQ2YsTUFBTSxTQUFTLE1BQU0sYUFBYSxDQUFDLEVBQUMsQ0FBRSxRQUFRLE1BQzNDLFVBQWdDLFNBQVMsRUFBRSxFQUFFLENBQ2hEO0NBQ0EsTUFBTSxPQUFPLElBQUksSUFBSSxFQUFFLFFBQVEsTUFBTSxLQUFLLE1BQU0sRUFBRSxFQUFFLENBQUM7Q0FDckQsTUFBTSxZQUFZLE1BQU0sS0FBSyxPQUFPO0VBQ2xDLElBQUksRUFBRTtFQUNOLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsRUFBRSxTQUFTLENBQUMsQ0FBQztFQUMzQyxPQUFPLENBQUMsS0FBSyxJQUFJLEVBQUUsRUFBRTtDQUN2QixFQUFFO0NBQ0YsTUFBTSxPQUFPLE9BQXdCLFVBQVUsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFO0NBQ3RFLE1BQU0sT0FDSixNQUFNLFNBQ0wsS0FBSyxTQUFTLFdBQVksVUFBZ0MsU0FBUyxLQUFLLElBQUksTUFDN0UsQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUNWO0VBQ0UsSUFBSSxLQUFLO0VBQ1QsU0FBUyxLQUFLLGdCQUFnQjtFQUM5QixPQUFPLEtBQUs7Q0FDZCxJQUNBO0NBQ04sTUFBTSxNQUFNLFNBQVMsRUFBRSxHQUFHO0NBQzFCLE1BQU0sT0FBTyxNQUFNLEVBQUUsUUFBUSxHQUFHLEdBQUc7O0NBRW5DLE1BQU0sVUFBbUIsQ0FBQztDQUMxQixJQUFJLFNBQVM7RUFDWCxNQUFNLFNBQVMsUUFBUSxTQUFTLENBQUMsRUFBQyxDQUFFLFFBQ2pDLE1BQU0sQ0FBQyxFQUFFLFVBQVUsRUFBRSxXQUFXLEtBQUssRUFBRSxPQUFPLE1BQU0sQ0FBQyxVQUFVLEtBQUssRUFBRSxJQUFJLENBQzdFO0VBQ0EsTUFBTSxPQUFPLE1BQU0sU0FDZixNQUFNLEtBQUssTUFBTSxFQUFFLElBQUksSUFDdkIsTUFBTSxLQUNKLEVBQ0UsUUFBUSxLQUFLLElBQ1gsYUFDQSxLQUFLLElBQUksSUFBSSxRQUFRLFlBQVksTUFBTSxRQUFRLFVBQVUsRUFBRSxDQUM3RCxFQUNGLFNBRUUsS0FBSyxPQUNGLFFBQVEsTUFBTSxRQUFRLEtBQ3JCLEtBQUssSUFBSSxJQUFJLFFBQVEsWUFBWSxNQUFNLFFBQVEsVUFBVSxFQUFFLENBQy9ELENBQ0o7RUFDSixNQUFNLFFBQVEsS0FDWCxLQUFLLEdBQUcsT0FBTztHQUFFO0dBQUc7RUFBRSxFQUFFLENBQUMsQ0FDekIsTUFBTSxHQUFHLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FDdEMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxDQUNyQixNQUFNLEdBQUcsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDO0VBQzNCLE1BQU0sU0FBUyxRQUFRLE9BQU8sVUFBVSxLQUFLLE1BQU0sUUFBUSxXQUFXLFVBQVUsS0FBSztFQUNyRixNQUFNLE9BQU8sUUFBUSxRQUFRO0VBQzdCLE1BQU0sTUFBTSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSTtFQUNwQyxNQUFNLFNBQVMsRUFBRSxLQUFLLE1BQU07R0FDMUIsTUFBTSxRQUFRLFNBQVMsTUFBTSxNQUFNLFNBQVMsR0FDMUMsTUFBTSxRQUFRLE1BQU0sSUFBSSxPQUFPO0dBQ2pDLFFBQVEsS0FBSztJQUNYLElBQUk7SUFDSixLQUFLLEVBQUU7SUFDUCxNQUFNLEtBQUssSUFBSSxZQUFZLEtBQUssTUFBTSxVQUFVO0lBQ2hEO0lBQ0E7SUFDQSxJQUFJO0dBQ04sQ0FBQztFQUNILENBQUM7O0VBRUQsTUFBTSxPQUFPLEtBQUssR0FDaEIsTUFBTSxRQUFRLFNBQVMsSUFBSSxLQUFLLElBQUksS0FBSyxRQUFRLFFBQVEsU0FBUyxFQUFFLElBQUk7RUFDMUUsUUFBUSxTQUFTLEdBQUcsTUFBTTtHQUN4QixFQUFFLEtBQUssS0FBTSxJQUFJO0VBQ25CLENBQUM7Q0FDSDs7O0NBR0EsTUFBTSxVQUFvQixDQUFDOzs7Q0FHM0IsTUFBTSxJQUFJLEVBQUUsTUFDVixTQUFTLEdBQUcsTUFBTSxNQUFNLE1BQU0sRUFBRSxPQUFPLFFBQVE7Q0FDakQsTUFBTSxRQUNKLEtBQUssV0FBVyxPQUFPLFVBQVUsVUFBVSxPQUFPLFVBQzlDO0VBQ0UsT0FBTyxFQUFFLFlBQVksU0FBUyxFQUFFLFFBQVEsSUFBSSxTQUFTO0VBQ3JELE1BQU0sRUFBRTtFQUNSLE9BQU8sT0FBTztFQUNkLE1BQU0sT0FBTztDQUNmLElBQ0E7Q0FDTixJQUFJLE9BQU8sVUFBVSxRQUNuQixRQUFRLEtBQUs7RUFBRSxJQUFJO0VBQVMsTUFBTTtFQUFTLE9BQU8sSUFBSSxNQUFNO0NBQU8sQ0FBQztDQUN0RSxNQUFNLFdBQXlCLE1BQU0sV0FBVyxDQUFDLEVBQUMsQ0FBRSxLQUFLLE9BQU87RUFDOUQsSUFBSSxFQUFFO0VBQ04sTUFBTSxFQUFFO0VBQ1IsS0FBSyxDQUFDLENBQUMsRUFBRTtFQUNULE9BQU8sRUFBRTtFQUNULFFBQVEsQ0FBQyxDQUFDLEVBQUU7RUFDWixNQUFNLEVBQUUsUUFBUTtDQUNsQixFQUFFO0NBQ0YsSUFBSSxJQUFJLFlBQVksTUFBTSxFQUFFLEtBQUssS0FBSyxLQUFLLEdBQ3pDLFFBQVEsS0FBSztFQUNYLElBQUk7RUFDSixNQUFNO0VBQ04sT0FBTyxFQUFFLEtBQUssUUFBMkIsWUFBWSxFQUFFLElBQUksVUFBVTtDQUN2RSxDQUFDO0NBQ0gsSUFBSSxJQUFJLE1BQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxLQUFLLEVBQUUsWUFDNUMsUUFBUSxLQUFLO0VBQUUsSUFBSTtFQUFRLE1BQU07Q0FBTyxDQUFDO0NBQzNDLE1BQU0sU0FBUyxJQUFJLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztDQUNyQyxLQUFLLE1BQU0sS0FBSyxXQUNkLElBQUksUUFBUSxTQUFTLEtBQUssQ0FBQyxPQUFPLElBQUksRUFBRSxFQUFFLEtBQUssQ0FBQyxRQUFRLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFLEdBQy9FLFFBQVEsS0FBSztFQUFFLElBQUksRUFBRTtFQUFJLE1BQU07Q0FBTyxDQUFDO0NBQzNDLE9BQU87RUFDTCxNQUFNLE1BQU0sU0FBUztFQUNyQjtFQUNBO0VBQ0EsT0FBTyxVQUFVO0VBQ2pCO0VBQ0EsUUFBUTtFQUNSLE1BQU07R0FBRSxLQUFLLEVBQUUsU0FBUztHQUFXLE1BQU0sRUFBRTtFQUFLO0VBQ2hELFVBQ0UsTUFBTSxTQUFTLFFBQ1gsQ0FBQyxJQUNBO0dBQUM7R0FBUztHQUFRO0VBQVEsQ0FBQyxDQUFXLFFBQVEsT0FBTyxFQUFFLGtCQUFrQixHQUFHLENBQUMsU0FBUztFQUM3RixXQUNFLEVBQUUsWUFDRSxRQUFRLE1BQU8sRUFBRSxlQUFlLFlBQVksRUFBRSxlQUFlLFNBQVMsRUFBRSxVQUFVLE1BQU8sQ0FBQyxDQUMzRixLQUFLLE9BQU87R0FDWCxJQUFJLEVBQUU7R0FDTixLQUFLLEVBQUU7R0FDUCxNQUFNLEVBQUU7R0FDUixTQUFTLEVBQUUsVUFBVSxXQUFXLEVBQUUsU0FBUyxLQUFLLEVBQUUsZUFBZTtHQUNqRSxPQUNFLEVBQUUsZUFBZSxFQUFFLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxpQkFBaUIsUUFBUTtFQUNoRixFQUFFLE1BQ0gsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDO0dBQUUsSUFBSSxFQUFFLHNCQUFzQjtHQUFHLEtBQUssRUFBRSxTQUFTO0dBQVcsTUFBTSxFQUFFO0VBQUssQ0FBQztFQUM1RixjQUFjLEVBQUUsc0JBQXNCO0VBQ3RDLFNBQVMsRUFBRSxZQUFZLEtBQUssTUFBTSxFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUUsc0JBQXNCLENBQUMsRUFBQyxDQUFFLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQztFQUM1RixPQUFPLEVBQUUsU0FBUyxDQUFDLEVBQUMsQ0FBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUUsSUFBSTtFQUNuRCxRQUFRLElBQUksUUFBUSxLQUFLLEVBQUUsVUFBVSxDQUFDLEVBQUMsQ0FBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDM0U7RUFDQSxTQUFTLFFBQVEsTUFBTSxHQUFHLENBQUM7RUFDM0IsT0FBTyxFQUFFLGNBQWM7RUFDdkIsT0FBTyxDQUFDLENBQUMsRUFBRTtFQUNYLE9BQU8sTUFBTSxTQUFTLFNBQVMsTUFBTSxlQUFlLFlBQVk7RUFDaEUsU0FBUyxNQUFNLFNBQVMsUUFBUSxDQUFDLElBQUk7Q0FDdkM7QUFDRjtBQU1BLElBQUksU0FBMEY7QUFDOUYsU0FBUyxhQUF1RjtDQUM5RixXQUFXLE1BQU0sR0FBRyxZQUFZLElBQUksU0FBUyxlQUFlLENBQUMsQ0FDMUQsTUFBTSxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FDckIsTUFDRSxNQUNDLElBQUksU0FBUyxRQUFRO0VBQ25CLE1BQU0sTUFBTSxJQUFJLE1BQU07RUFDdEIsSUFBSSxlQUFlLElBQUk7R0FBRTtHQUFLLFFBQVEsRUFBRSxVQUFVLENBQUM7RUFBRSxDQUFDO0VBQ3RELElBQUksZ0JBQWdCLElBQUksSUFBSTtFQUM1QixJQUFJLE1BQU0sR0FBRyxZQUFZLElBQUksU0FBUyxNQUFNLEVBQUUsU0FBUztDQUN6RCxDQUFDLENBQ0wsQ0FBQyxDQUNBLFlBQVksSUFBSTtDQUNuQixPQUFPO0FBQ1Q7QUFDQSxNQUFNLFFBQVE7O0FBRWQsTUFBTSxjQUF3QztDQUM1QyxPQUFPO0VBQUM7RUFBSztFQUFJO0NBQUc7Q0FDcEIsUUFBUTtFQUFDO0VBQUk7RUFBSztDQUFFO0NBQ3BCLFFBQVE7RUFBQztFQUFJO0VBQUk7Q0FBRztDQUNwQixTQUFTO0VBQUM7RUFBSztFQUFLO0NBQUc7QUFDekI7O0FBRUEsTUFBTSxTQUE2QjtDQUNqQyxDQUFDLHVCQUF1QixHQUFHO0NBQzNCLENBQUMsc0JBQXNCLEtBQUs7Q0FDNUIsQ0FBQyx3QkFBd0IsS0FBSztDQUM5QixDQUFDLHlCQUF5QixLQUFLO0NBQy9CLENBQUMsZUFBZSxJQUFJO0NBQ3BCLENBQUMsbUNBQW1DLElBQUk7Q0FDeEMsQ0FBQyxjQUFjLElBQUk7Q0FDbkIsQ0FBQyxlQUFlLEdBQUk7Q0FDcEIsQ0FBQyxrQkFBa0IsR0FBRztDQUN0QixDQUFDLGNBQWMsR0FBRztDQUNsQixDQUFDLGtCQUFrQixFQUFHO0NBQ3RCLENBQUMscURBQXFELEVBQUc7Q0FDekQsQ0FBQyxzQkFBc0IsR0FBSTtDQUMzQixDQUFDLDREQUE0RCxHQUFHO0NBQ2hFLENBQUMsaUJBQWlCLEdBQUk7Q0FDdEIsQ0FBQyxvQkFBb0IsR0FBRztDQUN4QixDQUFDLGNBQWMsRUFBRztDQUNsQixDQUFDLGNBQWMsR0FBSTtDQUNuQixDQUFDLGtCQUFrQixFQUFHO0NBQ3RCLENBQUMsY0FBYyxDQUFDO0NBQ2hCLENBQUMsUUFBUSxDQUFDO0FBQ1o7QUFDQSxPQUFPLE1BQU0sVUFBVTtDQUNyQixBQUFTO0NBQ1QsQUFBUztDQUNULFVBQVU7Q0FDVixBQUFRLFFBQVEsSUFBSSxJQUFrQjtDQUN0QyxBQUFRLEtBQUs7Q0FDYixBQUFRLEtBQUs7Q0FDYixBQUFRLEtBQUs7Q0FDYixBQUFRLE1BQXVFO0NBQy9FLFFBQVE7Q0FDUixBQUFRLFNBQVM7Q0FDakIsY0FBYztFQUNaLEtBQUssU0FBUyxTQUFTLGNBQWMsUUFBUTtFQUM3QyxLQUFLLE9BQU8sUUFBUTtFQUNwQixLQUFLLE9BQU8sU0FBUztFQUNyQixLQUFLLE1BQU0sS0FBSyxPQUFPLFdBQVcsTUFBTSxFQUFFLG9CQUFvQixLQUFLLENBQUM7RUFDcEUsS0FBSyxXQUFXLENBQUMsQ0FBQyxNQUFNLE1BQU07R0FDNUIsS0FBSyxNQUFNO0dBQ1gsS0FBSyxRQUFRO0dBQ2IsS0FBSyxNQUFNO0VBQ2IsQ0FBQztDQUNIO0NBQ0EsSUFBSSxJQUFxQjtFQUN2QixPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssT0FBTztDQUM1Qjs7Q0FFQSxPQUFPLE9BQWUsT0FBcUI7RUFDekMsT0FBTyxLQUFLLElBQ1Ysc0JBQXNCLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxLQUFLLENBQUMsS0FDbkQsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLEtBQUssQ0FBQyxDQUMvQjtDQUNGOzs7Q0FHQSxLQUFLLEtBQXdCLEdBQWlCO0VBQzVDLE1BQU0sT0FBTyxLQUFLLElBQUksS0FBSyxDQUFDO0VBQzVCLE1BQU0sTUFBTSxRQUFRLE1BQU0sUUFBUSxHQUFHLElBQUksSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJLEdBQUc7RUFDaEUsTUFBTSxNQUFNLEtBQUssTUFBTSxJQUFJLEdBQUc7RUFDOUIsSUFBSSxLQUFLLE9BQU87RUFDaEIsTUFBTSxJQUFJLEtBQUs7RUFDZixJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksT0FBTztHQUMzQixLQUFLLE1BQU0sS0FBSyxLQUFLO0dBQ3JCLEtBQUssS0FBSztHQUNWLEtBQUssS0FBSztFQUNaO0VBQ0EsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLE9BQU87R0FDM0IsS0FBSyxNQUFNO0dBQ1gsT0FBTyxLQUFLLElBQUksS0FBSyxDQUFDO0VBQ3hCO0VBQ0EsTUFBTSxJQUFJLEtBQUssSUFDYixJQUFJLEtBQUs7RUFDWCxLQUFLLE1BQU0sSUFBSTtFQUNmLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLENBQUM7RUFDN0IsTUFBTSxJQUFJLEtBQUssSUFBSSxhQUFhLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQyxHQUM1RCxJQUFJLEVBQUU7RUFDUixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssR0FBRztHQUNwQyxNQUFNLElBQUksUUFBUyxFQUFFLEtBQU0sUUFBUyxFQUFFLElBQUksS0FBTSxRQUFTLEVBQUUsSUFBSTtHQUMvRCxFQUFFLEtBQUssSUFBSSxLQUFNLE1BQU07R0FDdkIsRUFBRSxJQUFJLEtBQUssSUFBSSxLQUFNLE1BQU07R0FDM0IsRUFBRSxJQUFJLEtBQUssSUFBSSxLQUFNLE1BQU07R0FDM0IsRUFBRSxJQUFJLEtBQUssRUFBRSxJQUFJLEtBQU07RUFDekI7RUFDQSxLQUFLLElBQUksYUFBYSxHQUFHLEdBQUcsQ0FBQztFQUM3QixNQUFNLE9BQWE7R0FDakI7R0FDQTtHQUNBO0dBQ0E7R0FDQSxJQUFJLElBQUk7R0FDUixJQUFJLEtBQUssSUFBSSxLQUFLO0dBQ2xCLEtBQUssSUFBSSxLQUFLO0dBQ2QsSUFBSSxJQUFJLElBQUk7RUFDZDtFQUNBLEtBQUssTUFBTSxJQUFJLEtBQUssSUFBSTtFQUN4QixLQUFLO0VBQ0wsT0FBTztDQUNUO0NBQ0EsQUFBUSxPQUFPLEtBQWUsR0FBaUI7RUFDN0MsTUFBTSxPQUFPLEtBQUssSUFBSSxLQUFLLENBQUMsR0FDMUIsTUFBTSxVQUFVLElBQUksS0FBSyxHQUFHLEVBQUUsR0FBRztFQUNuQyxNQUFNLFNBQVMsS0FBSyxNQUFNLElBQUksR0FBRztFQUNqQyxJQUFJLFFBQVEsT0FBTztFQUNuQixNQUFNLElBQUksS0FBSyxJQUFJLEdBQ2pCLEtBQUssS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLElBQUksRUFBRyxDQUFDO0VBQ3RDLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxPQUFPO0dBQzNCLEtBQUssTUFBTSxLQUFLLEtBQUs7R0FDckIsS0FBSyxLQUFLO0dBQ1YsS0FBSyxLQUFLO0VBQ1o7RUFDQSxJQUFJLEtBQUssS0FBSyxLQUFLLElBQUksT0FBTztHQUM1QixLQUFLLE1BQU07R0FDWCxPQUFPLEtBQUssT0FBTyxLQUFLLENBQUM7RUFDM0I7RUFDQSxNQUFNLElBQUksS0FBSyxJQUNiLElBQUksS0FBSztFQUNYLEtBQUssTUFBTSxJQUFJO0VBQ2YsS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLElBQUksRUFBRTtFQUM5QixNQUFNLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSSxHQUFJO0VBQ3RDLEtBQUssSUFBSSx3QkFBd0I7RUFDakMsS0FBSyxJQUFJLFVBQVUsS0FBSyxRQUFRLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLE9BQU8sR0FBRyxHQUFHLEtBQUssR0FBRyxLQUFLO0VBQ2xGLEtBQUssSUFBSSxVQUNQLEtBQUssUUFDTCxLQUFLLEdBQ0wsS0FBSyxJQUFJLE9BQ1QsS0FBSyxHQUNMLEtBQUssSUFBSSxPQUNULElBQUksR0FDSixJQUFJLE9BQ0osS0FBSyxJQUFJLEdBQ1QsS0FBSyxLQUNQO0VBQ0EsTUFBTSxPQUFPO0dBQ1g7R0FDQTtHQUNBO0dBQ0EsR0FBRztHQUNILElBQUksSUFBSTtHQUNSLElBQUksS0FBSyxJQUFJLE1BQU07R0FDbkIsS0FBSyxJQUFJLEtBQUs7R0FDZCxJQUFJLElBQUksSUFBSTtFQUNkO0VBQ0EsS0FBSyxNQUFNLElBQUksS0FBSyxJQUFJO0VBQ3hCLEtBQUs7RUFDTCxPQUFPO0NBQ1Q7Q0FDQSxBQUFRLFFBQWM7RUFDcEIsS0FBSyxNQUFNLE1BQU07RUFDakIsS0FBSyxLQUFLO0VBQ1YsS0FBSyxLQUFLO0VBQ1YsS0FBSyxLQUFLO0VBQ1YsS0FBSyxJQUFJLFVBQVUsR0FBRyxHQUFHLE9BQU8sS0FBSztFQUNyQyxLQUFLO0NBQ1A7O0NBRUEsSUFBSSxLQUF3QixHQUFpQjtFQUMzQyxNQUFNLFlBQVksTUFBTSxRQUFRLEdBQUcsSUFBSSxNQUFNLENBQUMsR0FBRztFQUNqRCxJQUFJLFVBQVUsRUFBRSxFQUFFLFdBQVcsY0FBYyxHQUN6QyxPQUFPLEtBQUssT0FDVixVQUFVLEtBQUssT0FBTyxHQUFHLFFBQVEsaUJBQWlCLEVBQUUsQ0FBQyxHQUNyRCxDQUNGO0VBQ0YsTUFBTSxPQUFPLE1BQU0sUUFBUSxHQUFHLElBQUksTUFBTSxDQUFDLEdBQUc7RUFDNUMsTUFBTSxLQUFLLEtBQUssTUFBTSxNQUFNLEtBQUssS0FBSyxPQUFPLEVBQUUsS0FBSyxLQUFLO0VBQ3pELE1BQU0sTUFBTSxHQUFHLEdBQUcsR0FBRztFQUNyQixNQUFNLElBQUksS0FBSyxNQUFNLElBQUksR0FBRztFQUM1QixJQUFJLEdBQUcsT0FBTztFQUNkLE1BQU0sSUFBSSxLQUFLLEtBQUssT0FBTztFQUMzQixNQUFNLGNBQWMsNkJBQTZCLEtBQUssRUFBRTtFQUN4RCxNQUFNLElBQUksY0FDTixPQUFPLFlBQVksRUFBRSxJQUNyQixJQUNFLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTyxJQUFJLEVBQUUsSUFBSyxFQUFFLENBQUMsQ0FBQyxJQUN2QyxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sS0FBSyxPQUFPLE1BQU0sQ0FBQyxRQUFRLEdBQUcsS0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHLE1BQU0sRUFBRSxDQUFDO0VBQ2hGLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxPQUFPO0dBQzNCLEtBQUssTUFBTSxLQUFLLEtBQUs7R0FDckIsS0FBSyxLQUFLO0dBQ1YsS0FBSyxLQUFLO0VBQ1o7RUFDQSxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksT0FBTyxLQUFLLE1BQU07RUFDeEMsTUFBTSxJQUFJLEtBQUssSUFDYixJQUFJLEtBQUs7RUFDWCxLQUFLLE1BQU0sSUFBSTtFQUNmLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLENBQUM7RUFDN0IsTUFBTSxPQUFhO0dBQ2pCO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsSUFBSSxJQUFJO0dBQ1IsSUFBSSxLQUFLLElBQUksS0FBSztHQUNsQixLQUFLLElBQUksS0FBSztHQUNkLElBQUksSUFBSSxJQUFJO0VBQ2Q7RUFDQSxLQUFLLE1BQU0sSUFBSSxLQUFLLElBQUk7RUFDeEIsS0FBSyxTQUFTO0VBQ2QsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssR0FBRyxJQUFJO09BQzVDLElBQUksQ0FBQyxpQkFBaUIsS0FBSyxLQUFLLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLGNBQWMsS0FBSyxLQUFLLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUM1RixLQUFLO0VBQ0wsT0FBTztDQUNUOztDQUVBLEFBQVEsSUFBSSxLQUF1QixHQUFVLEdBQWU7RUFDMUQsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUc7R0FDOUIsS0FBSyxJQUFJLHdCQUF3QjtHQUNqQyxLQUFLLElBQUksVUFBVSxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7R0FDOUQ7RUFDRjtFQUNBLE1BQU0sSUFBSSxTQUFTLGNBQWMsUUFBUTtFQUN6QyxFQUFFLFFBQVEsRUFBRTtFQUNaLEVBQUUsU0FBUyxFQUFFO0VBQ2IsTUFBTSxJQUFJLEVBQUUsV0FBVyxNQUFNLEVBQUUsb0JBQW9CLEtBQUssQ0FBQztFQUN6RCxFQUFFLHdCQUF3QjtFQUMxQixFQUFFLHdCQUF3QjtFQUMxQixFQUFFLFVBQVUsS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7RUFDbkQsTUFBTSxJQUFJLEVBQUUsYUFBYSxHQUFHLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUNyQyxJQUFJLEVBQUU7RUFDUixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssR0FBRyxFQUFFLEtBQUssRUFBRSxLQUFNLE1BQU0sSUFBSTs7RUFFL0QsTUFBTSxPQUNKLFlBQ0UsK0JBQStCLEtBQUssTUFBTSxZQUFZLEtBQUssS0FBSyxNQUFNLENBQUMsR0FBRyxNQUFNO0VBRXBGLElBQUksTUFDRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssR0FBRztHQUNwQyxJQUFJLENBQUMsRUFBRSxJQUFJLElBQUk7R0FDZixNQUFNLElBQUksRUFBRSxJQUNWLEtBQUssRUFBRSxJQUFJLElBQ1gsSUFBSSxFQUFFLElBQUksSUFDVixLQUFLLFFBQVMsSUFBSSxRQUFTLEtBQUssUUFBUyxLQUFLO0dBQ2hELElBQUksSUFBSSxPQUFRLElBQUksTUFBUSxJQUFJLEtBQUssT0FBTyxJQUFJLElBQUksS0FBTTtHQUMxRCxNQUFNLElBQUksT0FBUSxJQUFJLEtBQUssSUFBSSxJQUFJLEdBQUksSUFBSTtHQUMzQyxFQUFFLEtBQUssS0FBSyxLQUFLLEtBQU0sSUFBSSxJQUFJLEtBQUs7R0FDcEMsRUFBRSxJQUFJLEtBQUssTUFBTSxLQUFLLEtBQU0sSUFBSSxJQUFJLE1BQU07R0FDMUMsRUFBRSxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQU0sSUFBSSxJQUFJLEtBQUs7RUFDMUM7RUFDRixLQUFLLElBQUksYUFBYSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7Q0FDbkM7QUFDRjs7QUFFQSxTQUFTLGNBQ1AsR0FDQSxJQUNBLEdBQ0EsR0FDQSxHQUNBLEdBQ007Q0FDTixNQUFNLEtBQUssR0FBVyxHQUFXLEdBQVcsSUFBWSxPQUFxQjtFQUMzRSxFQUFFLFlBQVk7RUFDZCxFQUFFLFNBQ0EsSUFBSSxLQUFLLE1BQU0sQ0FBQyxHQUNoQixJQUFJLEtBQUssTUFBTSxDQUFDLEdBQ2hCLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxFQUFFLENBQUMsR0FDMUIsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLEVBQUUsQ0FBQyxDQUM1QjtDQUNGO0NBQ0EsTUFBTSxPQUFPLEdBQVcsSUFBWSxJQUFZLElBQVksSUFBWSxPQUFxQjtFQUMzRixFQUFFLFlBQVk7RUFDZCxFQUFFLFVBQVU7RUFDWixFQUFFLE9BQU8sSUFBSSxJQUFJLElBQUksRUFBRTtFQUN2QixFQUFFLE9BQU8sSUFBSSxJQUFJLElBQUksRUFBRTtFQUN2QixFQUFFLE9BQU8sSUFBSSxJQUFJLElBQUksRUFBRTtFQUN2QixFQUFFLFVBQVU7RUFDWixFQUFFLEtBQUs7Q0FDVDtDQUNBLE1BQU0sU0FBUyxNQUFjLE1BQWMsTUFBb0I7RUFDN0QsRUFBRSxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxFQUFFLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxJQUFJLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO0NBQ2xGO0NBQ0EsSUFBSSxHQUFHLFdBQVcscUJBQXFCLEdBQUc7OztFQUd4QyxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssR0FBRyxNQUN2QixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssR0FBRyxNQUFNO0dBQzdCLE1BQU0sSUFDSixLQUFLLEtBQUssS0FBSyxLQUFNLElBQUksTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQU0sSUFBSSxNQUFNLElBQUksSUFBSSxDQUFDO0dBQ3RGLElBQUksS0FBSyxHQUNQLEVBQ0UsSUFBSSxNQUNBLHVCQUNBLElBQUksTUFDRix1QkFDQSxzQkFDTixJQUNBLElBQ0EsR0FDQSxDQUNGO0VBQ0o7Q0FDSixPQUFPLElBQUksR0FBRyxXQUFXLGtCQUFrQixHQUFHO0VBQzVDLE1BQU0sT0FBTyxPQUFPLEdBQUcsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUk7O0VBRTVDLEtBQUssTUFBTSxDQUFDLE1BQU0sTUFBTSxTQUFTO0dBQy9CO0lBQUMsSUFBSTtJQUFNLElBQUk7SUFBTSxDQUFDO0dBQUM7R0FDdkI7SUFBQyxJQUFJO0lBQUs7SUFBRztHQUFDO0dBQ2Q7SUFBQyxJQUFJO0lBQU0sSUFBSTtJQUFLO0dBQUM7RUFDdkIsR0FBRztHQUNELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFPLEtBQUs7SUFDOUIsTUFBTSxPQUFPLEtBQUssT0FBTyxPQUFPLFFBQVMsS0FBSyxJQUFJLElBQUksTUFBTyxJQUFJLENBQUM7SUFDbEUsRUFDRSxNQUFNLEtBQUssS0FBSyxJQUFLLElBQUksSUFBSSxZQUFZLFdBQ3pDLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxJQUFJLEdBQUcsT0FBUSxJQUFJLENBQUMsR0FDekMsSUFBSSxJQUFJLEdBQ1IsR0FDQSxDQUNGO0dBQ0Y7RUFDRjtDQUNGLE9BQU8sSUFBSSxHQUFHLFdBQVcsZ0JBQWdCLEdBQUcsTUFBTSxXQUFXLFdBQVcsRUFBRTtNQUNyRSxJQUFJLEdBQUcsV0FBVyxlQUFlLEdBQUcsTUFBTSxXQUFXLFdBQVcsRUFBRTtNQUNsRSxJQUFJLEdBQUcsV0FBVyxnQkFBZ0IsR0FBRztFQUN4QyxNQUFNLFdBQVcsV0FBVyxFQUFFO0VBQzlCLEVBQUUsV0FBVyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3ZCLEVBQUUsV0FBVyxHQUFHLEdBQUcsR0FBRyxDQUFDO0NBQ3pCLE9BQU8sSUFBSSxHQUFHLFdBQVcsZ0JBQWdCLEdBQUcsTUFBTSxXQUFXLFdBQVcsRUFBRTtNQUNyRSxJQUFJLEdBQUcsV0FBVyxnQkFBZ0IsR0FBRyxNQUFNLFdBQVcsV0FBVyxFQUFFO01BQ25FLElBQUksR0FBRyxXQUFXLGVBQWUsR0FBRztFQUN2QyxFQUFFLFdBQVcsSUFBSSxJQUFLLElBQUksS0FBTSxJQUFJLElBQUssSUFBSSxHQUFJO0VBQ2pELEVBQUUsWUFBWTtFQUNkLEVBQUUsVUFBVTtFQUNaLEVBQUUsUUFBUSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksSUFBSyxJQUFJLElBQUssSUFBSSxLQUFNLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztFQUN0RSxFQUFFLEtBQUs7Q0FDVCxPQUFPLElBQUksR0FBRyxXQUFXLFlBQVksR0FBRztFQUN0QyxFQUFFLFdBQVcsR0FBRyxJQUFJLEtBQU0sR0FBRyxJQUFJLEdBQUk7RUFDckMsRUFBRSxZQUFZO0VBQ2QsRUFBRSxVQUFVO0VBQ1osRUFBRSxRQUFRLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUFNLElBQUksSUFBSyxJQUFJLEtBQU0sR0FBRyxLQUFLLElBQUksQ0FBQztFQUNuRSxFQUFFLEtBQUs7RUFDUCxFQUFFLFdBQVcsSUFBSSxJQUFLLElBQUksS0FBTSxJQUFJLElBQUssSUFBSSxHQUFJO0NBQ25ELE9BQU8sSUFBSSxrQ0FBa0MsS0FBSyxFQUFFLEdBQUc7RUFDckQsTUFBTSxNQUFNLGFBQWEsS0FBSyxFQUFFLElBQzVCLENBQUMsV0FBVyxTQUFTLElBQ3JCLE9BQU8sS0FBSyxFQUFFLElBQ1osQ0FBQyxXQUFXLFNBQVMsSUFDckIsQ0FBQyxXQUFXLFNBQVM7RUFDM0IsRUFBRSxJQUFJLElBQUssSUFBSSxLQUFNLElBQUksS0FBTSxJQUFJLEtBQU0sSUFBSSxHQUFJO0VBQ2pELElBQUksSUFBSSxJQUFLLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxNQUFPLElBQUksS0FBTSxHQUFHLElBQUksR0FBSTtFQUN4RCxFQUFFLFdBQVcsSUFBSSxLQUFNLElBQUksS0FBTSxJQUFJLEtBQU0sSUFBSSxHQUFJO0VBQ25ELElBQUksYUFBYSxLQUFLLEVBQUUsR0FBRyxFQUFFLFdBQVcsSUFBSSxLQUFNLElBQUksSUFBSyxJQUFJLEtBQU0sSUFBSSxFQUFHO0VBQzVFLElBQUksT0FBTyxLQUFLLEVBQUUsR0FBRztHQUNuQixFQUFFLFlBQVk7R0FDZCxFQUFFLFVBQVU7R0FDWixFQUFFLElBQUksSUFBSSxJQUFJLElBQUssSUFBSSxJQUFJLElBQUssS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFJLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztHQUNyRSxFQUFFLEtBQUs7RUFDVDtDQUNGLE9BQU8sSUFBSSxHQUFHLFdBQVcsV0FBVyxHQUFHO0VBQ3JDLElBQUksV0FBVyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUNoQyxJQUFJLFdBQVcsSUFBSSxHQUFHLElBQUksS0FBTSxJQUFJLEtBQU0sSUFBSSxLQUFNLENBQUM7Q0FDdkQsT0FBTyxJQUFJLEdBQUcsV0FBVyxZQUFZLEdBQUc7RUFDdEMsRUFBRSxXQUFXLElBQUksS0FBTSxJQUFJLElBQUssR0FBRyxJQUFJLEVBQUc7RUFDMUMsRUFBRSxXQUFXLElBQUksSUFBSyxJQUFJLElBQUssR0FBRyxJQUFJLEVBQUc7RUFDekMsRUFBRSxXQUFXLEdBQUcsR0FBRyxHQUFHLElBQUksRUFBRztFQUM3QixFQUFFLFdBQVcsSUFBSSxJQUFLLElBQUksS0FBTSxJQUFJLElBQUssSUFBSSxHQUFJO0NBQ25ELE9BQU8sSUFBSSxHQUFHLFdBQVcsWUFBWSxHQUFHO0VBQ3RDLEVBQUUsV0FBVyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3ZCLEVBQUUsV0FBVyxHQUFHLElBQUksR0FBRyxHQUFHLENBQUM7RUFDM0IsRUFBRSxXQUFXLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQztDQUM3QixPQUFPLElBQUksR0FBRyxXQUFXLGVBQWUsR0FBRztFQUN6QyxFQUFFLFdBQVcsR0FBRyxJQUFJLEtBQU0sR0FBRyxJQUFJLEdBQUk7RUFDckMsSUFBSSxHQUFHLFNBQVMsSUFBSSxJQUFJLFlBQVksV0FBVyxJQUFJLEdBQUcsR0FBRyxJQUFJLEtBQU0sSUFBSSxLQUFNLElBQUksRUFBRztDQUN0RixPQUFPLElBQUksR0FBRyxXQUFXLFdBQVcsR0FBRztFQUNyQyxLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUssRUFBRyxHQUFHLEVBQUUsV0FBVyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUssR0FBRyxJQUFJLEVBQUc7RUFDdkUsRUFBRSxXQUFXLElBQUksSUFBSyxJQUFJLEtBQU0sSUFBSSxJQUFLLENBQUM7Q0FDNUMsT0FBTyxJQUFJLEdBQUcsV0FBVyxlQUFlLEdBQUc7RUFDekMsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLEdBQUcsS0FBSztHQUMzQixFQUFFLFlBQWEsSUFBSSxLQUFLLElBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUN2QyxFQUFFLFdBQVcsSUFBSyxJQUFJLEtBQUssSUFBSyxHQUFHLEdBQUcsQ0FBQztFQUN6QztDQUNGLE9BQU8sSUFBSSxHQUFHLFdBQVcsV0FBVyxHQUFHO0VBQ3JDLEVBQUUsWUFBWTtFQUNkLEVBQUUsVUFBVTtFQUNaLEVBQUUsUUFBUSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksSUFBSyxJQUFJLEtBQU0sSUFBSSxJQUFLLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztFQUN0RSxFQUFFLEtBQUs7RUFDUCxFQUFFLFdBQVcsSUFBSSxJQUFLLElBQUksSUFBSyxJQUFJLElBQUssSUFBSSxHQUFJO0NBQ2xELE9BQU8sSUFBSSxHQUFHLFdBQVcsaUJBQWlCLEdBQUc7O0VBRTNDLE1BQU0sT0FBTyxHQUFHLFNBQVMsT0FBTyxHQUM5QixPQUFPLEdBQUcsU0FBUyxPQUFPO0VBQzVCLElBQUksTUFBTTtHQUNSLEVBQUUsV0FBVyxJQUFJLEtBQU0sR0FBRyxJQUFJLEtBQU0sSUFBSSxFQUFHO0dBQzNDLEVBQUUsV0FBVyxJQUFJLEtBQU0sSUFBSSxJQUFLLElBQUksS0FBTSxJQUFJLEdBQUk7RUFDcEQ7RUFDQSxFQUFFLFdBQVcsSUFBSSxLQUFNLElBQUksS0FBTSxJQUFJLEtBQU0sSUFBSSxHQUFJO0VBQ25ELEVBQUUsV0FBVyxJQUFJLEtBQU0sSUFBSSxJQUFLLElBQUksS0FBTSxDQUFDO0VBQzNDLEVBQUUsV0FBVyxJQUFJLElBQUssSUFBSSxLQUFNLEdBQUcsSUFBSSxHQUFJO0VBQzNDLEVBQUUsV0FBVyxJQUFJLElBQUssSUFBSSxLQUFNLEdBQUcsSUFBSSxHQUFJO0VBQzNDLElBQUksQ0FBQyxNQUFNLEVBQUUsV0FBVyxJQUFJLEtBQU0sSUFBSSxLQUFNLElBQUksS0FBTSxJQUFJLEdBQUk7RUFDOUQsRUFBRSxXQUFXLElBQUksS0FBTSxJQUFJLEtBQU0sSUFBSSxJQUFLLElBQUksR0FBSTtFQUNsRCxJQUFJLE1BQU07R0FDUixFQUFFLFdBQVcsSUFBSSxLQUFNLElBQUksS0FBTSxJQUFJLEtBQU0sSUFBSSxFQUFHO0dBQ2xELEVBQUUsV0FBVyxJQUFJLEtBQU0sSUFBSSxLQUFNLEdBQUcsSUFBSSxHQUFJO0dBQzVDLEVBQUUsV0FBVyxJQUFJLEtBQU0sSUFBSSxLQUFNLElBQUksS0FBTSxDQUFDO0VBQzlDO0NBQ0YsT0FBTyxJQUFJLEdBQUcsV0FBVyxjQUFjLEdBQUc7O0VBRXhDLE1BQU0sT0FBTyxHQUFHLFFBQVEsc0JBQXNCLEVBQUU7RUFDaEQsTUFBTSxPQUErQjtHQUNuQyxRQUFRO0dBQ1IsWUFBWTtHQUNaLE9BQU87R0FDUCxhQUFhO0dBQ2IsYUFBYTtHQUNiLFFBQVE7R0FDUixPQUFPO0dBQ1AsT0FBTztHQUNQLGVBQWU7RUFDakI7RUFDQSxNQUFNLEtBQUssNENBQTRDLEtBQUssSUFBSSxJQUFJLElBQUksTUFBTztFQUMvRSxFQUFFLEtBQUssU0FBUyxXQUFXLEtBQUssS0FBTSxJQUFJLEtBQU0sS0FBSyxLQUFNLElBQUksRUFBRztFQUNsRSxFQUFFLFdBQVcsS0FBSyxLQUFNLElBQUksS0FBTSxLQUFLLEtBQU0sSUFBSSxFQUFHO0VBQ3BELEVBQUUsV0FBVyxLQUFLLEtBQU0sSUFBSSxLQUFNLEtBQUssS0FBTSxJQUFJLEdBQUk7RUFDckQsRUFBRSxXQUFXLEtBQUssS0FBTSxJQUFJLEtBQU0sS0FBSyxLQUFNLElBQUksR0FBSTtFQUNyRCxNQUFNLEtBQUssR0FBVyxHQUFXLEdBQVcsSUFBWSxPQUN0RCxFQUFFLEdBQUcsTUFBTSxJQUFJLE1BQU0sR0FBRyxJQUFJLElBQUksSUFBSSxNQUFNLElBQUksSUFBSSxFQUFFO0VBQ3RELElBQUksU0FBUyxVQUFVO0dBQ3JCLEVBQUUsV0FBVyxLQUFNLEtBQU0sSUFBSyxFQUFHO0dBQ2pDLEVBQUUsV0FBVyxLQUFNLEtBQU0sSUFBSyxHQUFJO0dBQ2xDLEVBQUUsV0FBVyxJQUFLLEtBQU0sS0FBTSxHQUFJO0VBQ3BDLE9BQU8sSUFBSSxTQUFTLGNBQWM7R0FDaEMsRUFBRSxXQUFXLElBQUssS0FBTSxJQUFLLEVBQUc7R0FDaEMsRUFBRSxXQUFXLEtBQU0sS0FBTSxJQUFLLEdBQUk7R0FDbEMsRUFBRSxXQUFXLEtBQU0sS0FBTSxJQUFLLEdBQUk7RUFDcEMsT0FBTyxJQUFJLFNBQVMsZUFBZTtHQUNqQyxFQUFFLFdBQVcsSUFBSyxLQUFNLElBQUssRUFBRztHQUNoQyxFQUFFLFdBQVcsS0FBTSxLQUFNLEtBQU0sR0FBSTtHQUNuQyxFQUFFLFdBQVcsSUFBSyxLQUFNLElBQUssR0FBSTtFQUNuQyxPQUFPLElBQUksU0FBUyxlQUFlO0dBQ2pDLEVBQUUsV0FBVyxJQUFLLEtBQU0sSUFBSyxHQUFJO0dBQ2pDLEVBQUUsV0FBVyxLQUFNLElBQUssSUFBSyxFQUFHO0dBQ2hDLEVBQUUsV0FBVyxLQUFNLElBQUssSUFBSyxFQUFHO0VBQ2xDLE9BQU8sSUFBSSxTQUFTLFNBQVMsRUFBRSxXQUFXLEtBQUssSUFBSyxJQUFJLElBQUssS0FBSyxLQUFNLElBQUksR0FBSTtPQUMzRSxJQUFJLFNBQVMsVUFBVTtHQUMxQixFQUFFLFdBQVcsS0FBSyxJQUFLLElBQUksS0FBTSxLQUFLLEtBQU0sSUFBSSxFQUFHO0dBQ25ELEVBQUUsV0FBVyxLQUFLLEtBQU0sSUFBSSxLQUFNLEtBQUssS0FBTSxJQUFJLEVBQUc7RUFDdEQsT0FBTyxJQUFJLFNBQVMsU0FBUztHQUMzQixFQUFFLFdBQVcsS0FBSyxLQUFNLElBQUksSUFBSyxLQUFLLEtBQU0sSUFBSSxHQUFJO0dBQ3BELEVBQUUsV0FBVyxLQUFLLEtBQU0sSUFBSSxLQUFNLEdBQUcsSUFBSSxHQUFJO0VBQy9DLE9BQU8sSUFBSSxTQUFTLFNBQVM7R0FDM0IsRUFBRSxXQUFXLEtBQUssS0FBTSxJQUFJLEtBQU0sS0FBSyxJQUFLLElBQUksR0FBSTtHQUNwRCxFQUFFLFdBQVcsS0FBSyxLQUFNLElBQUksS0FBTSxLQUFLLEtBQU0sSUFBSSxHQUFJO0dBQ3JELEVBQUUsV0FBVyxLQUFLLEtBQU0sSUFBSSxLQUFNLEtBQUssSUFBSyxJQUFJLEdBQUk7RUFDdEQsT0FBTyxJQUFJLFNBQVMsaUJBQWlCO0dBQ25DLEVBQUUsV0FBVyxLQUFLLElBQUssSUFBSSxJQUFLLEtBQUssS0FBTSxJQUFJLEdBQUk7R0FDbkQsRUFBRSxXQUFXLEtBQUssSUFBSyxJQUFJLEtBQU0sS0FBSyxLQUFNLElBQUksR0FBSTtFQUN0RDtDQUNGLE9BQU8sSUFBSSxHQUFHLFdBQVcsWUFBWSxHQUFHO0VBQ3RDLEVBQUUsV0FBVyxHQUFHLElBQUksSUFBSyxHQUFHLElBQUksRUFBRztFQUNuQyxFQUFFLFdBQVcsR0FBRyxJQUFJLElBQUssR0FBRyxDQUFDO0VBQzdCLEVBQUUsV0FBVyxJQUFJLEtBQU0sSUFBSSxLQUFNLElBQUksS0FBTSxJQUFJLEVBQUc7Q0FDcEQsT0FBTyxJQUFJLEdBQUcsV0FBVyxXQUFXLEdBQUc7RUFDckMsRUFBRSxXQUFXLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDdkIsRUFBRSxHQUFHLFNBQVMsSUFBSSxJQUFJLFlBQVksV0FBVyxHQUFHLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRztDQUNuRSxPQUFPLElBQUksR0FBRyxXQUFXLFdBQVcsR0FBRztFQUNyQyxFQUFFLFdBQVcsSUFBSSxJQUFLLElBQUksSUFBSyxJQUFJLElBQUssSUFBSSxFQUFHO0VBQy9DLEVBQUUsR0FBRyxTQUFTLElBQUksSUFBSSxZQUFZLFdBQVcsSUFBSSxLQUFNLEdBQUcsSUFBSSxJQUFLLElBQUksR0FBSTtDQUM3RSxPQUFPLElBQUksR0FBRyxXQUFXLFVBQVUsR0FBRztFQUNwQyxNQUFNLElBQUksS0FBSyxNQUFNLElBQUksQ0FBQztFQUMxQixFQUFFLFdBQVcsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUN2QixFQUFFLFdBQVcsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUN2QixFQUFFLFdBQVcsSUFBSSxHQUFHLElBQUksR0FBRyxHQUFHLENBQUM7Q0FDakMsT0FBTyxJQUFJLE9BQU8sZ0JBQWdCOztFQUVoQyxFQUFFLFdBQVcsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUN2QixFQUFFLFdBQVcsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUN2QixFQUFFLFdBQVcsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUN2QixFQUFFLFdBQVcsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUN2QixFQUFFLFdBQVcsR0FBRyxHQUFHLEdBQUcsQ0FBQztDQUN6QixPQUFPLElBQUksR0FBRyxXQUFXLFNBQVMsR0FBRyxFQUFFLElBQUksR0FBRyxNQUFNLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxDQUFDO01BQy9ELElBQUksaUJBQWlCLEtBQUssRUFBRSxHQUFHO0VBQ2xDLE1BQU0sT0FBTyxRQUFRLEtBQUssRUFBRSxJQUN4QixZQUNBLFNBQVMsS0FBSyxFQUFFLElBQ2QsWUFDQSxTQUFTLEtBQUssRUFBRSxJQUNkLFlBQ0E7RUFDUixFQUFFLFdBQVcsSUFBSSxLQUFNLElBQUksS0FBTSxJQUFJLElBQUssSUFBSSxFQUFHO0VBQ2pELEVBQUUsTUFBTSxJQUFJLEtBQU0sSUFBSSxJQUFLLElBQUksSUFBSyxJQUFJLEdBQUk7RUFDNUMsRUFBRSxXQUFXLElBQUksS0FBTSxJQUFJLEtBQU0sSUFBSSxLQUFNLElBQUksR0FBSTtFQUNuRCxFQUFFLFdBQVcsSUFBSSxJQUFLLElBQUksS0FBTSxJQUFJLEtBQU0sSUFBSSxHQUFJO0VBQ2xELEVBQUUsV0FBVyxJQUFJLEtBQU0sSUFBSSxLQUFNLElBQUksS0FBTSxJQUFJLEdBQUk7Q0FDckQsT0FBTztFQUNMLEVBQUUsV0FBVyxJQUFJLElBQUssSUFBSSxLQUFNLElBQUksSUFBSyxJQUFJLEdBQUk7RUFDakQsRUFBRSxXQUFXLElBQUksS0FBTSxJQUFJLEtBQU0sSUFBSSxLQUFNLElBQUksR0FBSTtFQUNuRCxFQUFFLFdBQVcsSUFBSSxJQUFLLElBQUksS0FBTSxJQUFJLEtBQU0sSUFBSSxHQUFJO0VBQ2xELEVBQUUsV0FBVyxJQUFJLEtBQU0sSUFBSSxLQUFNLElBQUksSUFBSyxJQUFJLEVBQUc7Q0FDbkQ7QUFDRjs7QUFvQ0EsT0FBTyxTQUFTLFFBQVEsTUFBc0I7Q0FDNUMsTUFBTSxLQUFNLE9BQU8sS0FBTSxNQUFNO0NBQy9CLElBQUksS0FBSyxNQUFNLElBQUksR0FBRyxPQUFPO0NBQzdCLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxPQUFPO0NBQzdCLE9BQU8sSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNO0FBQzlDO0FBQ0EsTUFBTSxRQUFRLEdBQWEsR0FBYSxNQUF3QztDQUM5RSxFQUFFLE1BQU8sRUFBRSxLQUFNLEVBQUUsTUFBTztDQUMxQixFQUFFLE1BQU8sRUFBRSxLQUFNLEVBQUUsTUFBTztDQUMxQixFQUFFLE1BQU8sRUFBRSxLQUFNLEVBQUUsTUFBTztBQUM1QjtBQUNBLE1BQU0sVUFBVTtDQUFDO0NBQUs7Q0FBTTtBQUFJLEdBQzlCLFdBQVc7Q0FBQztDQUFNO0NBQU07QUFBSSxHQUM1QixZQUFZO0NBQUM7Q0FBTTtDQUFNO0FBQUk7QUFDL0IsT0FBTyxTQUFTLFVBQVUsT0FBeUM7Q0FDakUsT0FBTyxRQUFRLEtBQ1gsS0FBSyxTQUFTLFVBQVUsUUFBUSxDQUFDLElBQ2pDLEtBQUssVUFBVSxZQUFZLFFBQVEsTUFBTyxDQUFDO0FBQ2pEO0FBd0JBLE1BQU0sUUFBUTtBQUNkLFNBQVMsVUFBVSxLQUFXLElBQVksUUFBUSxPQUFPLE1BQWEsQ0FBQyxHQUFXO0NBQ2hGLElBQUksSUFBSTtDQUNSLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSztFQUNuQyxNQUFNLElBQUksS0FBSyxJQUFJLElBQUksSUFBSyxJQUFJLEVBQUc7RUFDbkMsSUFBSSxJQUFJLEtBQU07RUFDZCxJQUFJLEtBQUs7R0FBRSxJQUFJO0dBQUcsSUFBSSxJQUFJLElBQUk7R0FBTyxHQUFHLElBQUksSUFBSTtHQUFLLEdBQUcsSUFBSTtFQUFJLENBQUM7RUFDakUsS0FBSyxJQUFJO0NBQ1g7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFNBQ1AsR0FDQSxHQUM4RDtDQUM5RCxJQUFJLElBQUksRUFBRSxRQUFRLElBQUksRUFBRSxJQUFJLE9BQU87Q0FDbkMsTUFBTSxPQUFPLEVBQUU7Q0FDZixJQUFJLEVBQUUsVUFBVSxLQUFLLFVBQVUsS0FBSyxLQUFLLFNBQVMsRUFBRSxDQUFFLEtBQUssSUFBSSxJQUFJLEVBQUUsT0FBTyxDQUFDO0NBQzdFLElBQUksQ0FBQyxLQUFLLFFBQVEsT0FBTztDQUN6QixJQUFJLEtBQUssS0FBSyxFQUFFLENBQUUsSUFBSSxPQUFPO0VBQUUsR0FBRyxLQUFLLEVBQUUsQ0FBRSxFQUFFO0VBQUcsR0FBRyxLQUFLLEVBQUUsQ0FBRSxFQUFFO0VBQUcsUUFBUTtFQUFPLElBQUk7Q0FBRTtDQUN0RixJQUFJLEtBQUssR0FDUCxLQUFLLEtBQUssU0FBUztDQUNyQixPQUFPLEtBQUssSUFBSTtFQUNkLE1BQU0sSUFBSyxLQUFLLEtBQUssS0FBTTtFQUMzQixJQUFJLEtBQUssRUFBRSxDQUFFLE1BQU0sR0FBRyxLQUFLO09BQ3RCLEtBQUssSUFBSTtDQUNoQjtDQUNBLE1BQU0sSUFBSSxLQUFLO0NBQ2YsSUFBSSxLQUFLLEVBQUUsSUFBSSxPQUFPO0VBQUUsR0FBRyxFQUFFLEVBQUU7RUFBRyxHQUFHLEVBQUUsRUFBRTtFQUFHLFFBQVE7RUFBTyxJQUFJO0NBQUU7Q0FDakUsTUFBTSxLQUFLLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFO0NBQ2pDLE9BQU87RUFDTCxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLO0VBQzdCLEdBQUcsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUs7RUFDN0IsUUFBUTtFQUNSLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFO0NBQ2xCO0FBQ0Y7QUFlQSxNQUFNLFFBQVE7Q0FBQztDQUFVO0NBQVU7QUFBUSxHQUN6QyxRQUFRO0NBQUM7Q0FBVTtDQUFVO0FBQVEsR0FDckMsT0FBTztDQUFDO0NBQVU7Q0FBVTtBQUFRO0FBK0R0QyxNQUFNLFVBQVUsS0FDZCxXQUFXLElBQ1gsV0FBVztBQUViLElBQUksY0FBZ0M7QUFDcEMsSUFBSSxXQUE0RTtBQUNoRixJQUFJLG9CQUE0Qzs7QUFFaEQsT0FBTyxTQUFTLHNCQUErQjtDQUM3QyxPQUFPLFlBQVksSUFBSSxNQUFNLG9CQUFvQixJQUFJO0FBQ3ZEO0FBQ0EsT0FBTyxTQUFTLGVBQWUsTUFBNkI7Q0FDMUQsTUFBTSxLQUFLOztDQUVYLE1BQU0sT0FBTyxZQUFZLENBQUMsU0FBUyxHQUFHLE9BQU8sSUFBSSxXQUFXO0NBQzVELElBQUksWUFBWSxDQUFDLE1BQU0sU0FBUyxHQUFHLFFBQVE7Q0FDM0MsV0FBVztDQUNYLE1BQU0sV0FBVyxNQUFNLFVBQVUsU0FBUyxjQUFjLFFBQVE7Q0FDaEUsU0FBUyxZQUFZO0NBQ3JCLFNBQVMsYUFBYSxlQUFlLE1BQU07Q0FDM0MsR0FBRyxZQUFZLFFBQVE7Q0FDdkIsTUFBTSxRQUFTLGdCQUFnQixJQUFJLFVBQVU7Q0FDN0MsSUFBSSxLQUFvQjtDQUN4QixJQUFJLE1BQU07RUFDUixLQUFLLEtBQUs7RUFDVixHQUFHLFNBQVM7Q0FDZCxPQUNFLElBQUk7RUFDRixLQUFLLElBQUksT0FBTyxVQUFVLEtBQUs7Q0FDakMsU0FBUyxHQUFHO0VBQ1YsUUFBUSxLQUFLLHlDQUF5QyxDQUFDO0VBQ3ZELEtBQUs7Q0FDUDtDQUNGLElBQUksTUFBZ0M7Q0FDcEMsTUFBTSxlQUFrQztFQUN0QyxJQUFJLEtBQUssT0FBTztFQUNoQixNQUFNLFNBQVMsY0FBYyxRQUFRO0VBQ3JDLElBQUksWUFBWTtFQUNoQixJQUFJLGFBQWEsZUFBZSxNQUFNO0VBQ3RDLEdBQUcsWUFBWSxHQUFHO0VBQ2xCLE9BQU87Q0FDVDtDQUNBLElBQUksU0FBUztDQUNiLE1BQU0sVUFBVSxNQUFtQjtFQUNqQyxFQUFFLGVBQWU7RUFDakIsU0FBUztFQUNULGNBQWM7Q0FDaEI7Q0FDQSxNQUFNLG1CQUF5QjtFQUM3QixTQUFTO0VBQ1QsSUFBSSxTQUFTO0VBQ2IsY0FBYztDQUNoQjtDQUNBLFNBQVMsaUJBQWlCLG9CQUFvQixNQUFNO0NBQ3BELFNBQVMsaUJBQWlCLHdCQUF3QixVQUFVO0NBRTVELElBQUksUUFBMEI7Q0FDOUIsSUFBSSxVQUFvQixDQUFDO0NBQ3pCLElBQUksWUFBZ0MsQ0FBQztDQUNyQyxNQUFNLFFBQWdCLENBQUM7Q0FDdkIsSUFBSSxJQUFJLEdBQ04sT0FBTyxZQUFZLElBQUksR0FDdkIsTUFBTSxHQUNOLFNBQVMsR0FDVCxXQUFXO0NBQ2IsTUFBTSxTQUFtQixDQUFDLEdBQ3hCLE1BQWdCLENBQUM7Q0FDbkIsSUFBSSxZQUFZLFlBQVksSUFBSSxHQUM5QixXQUFXO0NBQ2IsSUFBSSxlQUE4QjtDQUNsQyxJQUFJLGNBQWM7Q0FDbEIsTUFBTSxZQUE0QixDQUFDO0NBQ25DLE1BQU0sY0FBYyxJQUFJLElBQW9CO0NBQzVDLElBQUksY0FBYztDQUNsQixNQUFNLHVCQUNKLENBQUMsaUJBQWlCLFdBQ2xCLENBQUMsU0FBUyxVQUNWLGFBQWEsTUFBTSxTQUNuQixTQUFTLGdCQUFnQixRQUFRLFVBQVU7Q0FDN0MsSUFBSSxVQUFVLElBQUksSUFBb0I7Q0FDdEMsSUFBSSxPQUFzQjtDQUMxQixNQUFNLGNBQThCLENBQUM7Q0FDckMsSUFBSSxZQUFpRTtDQUNyRSxJQUFJLFVBQVU7Q0FDZCxNQUFNLFNBQVMsSUFBSSxJQUFtQjtDQUN0QyxNQUFNLElBQWU7RUFDbkIsSUFBSTtFQUNKLElBQUk7RUFDSixHQUFHO0VBQ0gsR0FBRztFQUNILEdBQUc7RUFDSCxHQUFHO0VBQ0gsR0FBRztFQUNILE9BQU8sQ0FBQztFQUNSLEdBQUc7RUFDSCxTQUFTO0VBQ1QsV0FBVztFQUNYLFFBQVEsQ0FBQztFQUNULEtBQUs7R0FBQztHQUFHO0dBQUc7RUFBQztFQUNiLE9BQU87RUFDUCxNQUFNO0NBQ1I7Q0FDQSxJQUFJLFlBQVksSUFBSSxLQUFLLDBCQUEyQixNQUFNLENBQUMsU0FBUyxHQUFHLGdCQUFnQixDQUFDLElBQUk7Q0FDNUYsSUFBSSxnQkFBZ0IsR0FDbEIsaUJBQWlCO0NBQ25CLElBQUksWUFBWSxHQUNkLGdCQUFnQjtDQUNsQixNQUFNLG1CQUFtQixXQUFXLGtDQUFrQztDQUN0RSxNQUFNLE9BQU8sTUFBdUIsTUFBTSxPQUFPLFFBQVEsR0FBRyxDQUFDLElBQUksTUFBVTs7Q0FHM0UsU0FBUyxNQUFNLGNBQWMsT0FBYTtFQUN4QyxNQUFNLElBQUk7RUFDVixVQUFVLENBQUM7RUFDWCxNQUFNLE1BQU0sRUFBRSxLQUFLLEtBQ2pCLFVBQVU7R0FDUixHQUFJLEVBQUUsS0FBSyxPQUFPLENBQUMsUUFBUSxJQUFJLEdBQUcsRUFBRSxLQUFLLE1BQU0sSUFBSSxDQUFDO0dBQ3BELFFBQVE7R0FDUjtFQUNGLEdBQ0EsVUFBVSxDQUFDLFFBQVEsT0FBTyxHQUFHLE9BQU87RUFDdEMsSUFBSSxJQUFJO0VBQ1IsTUFBTSxXQUFXLEVBQUUsUUFBUSxTQUFTLEVBQUUsUUFBUSxFQUFFLFFBQVEsU0FBUyxFQUFFLENBQUUsS0FBSyxJQUFJO0VBQzlFLEtBQUssTUFBTSxLQUFLLEVBQUUsU0FBUztHQUN6QixNQUFNLE9BQWMsQ0FBQztHQUNyQixNQUFNLE1BQU0sVUFBVSxNQUFNLE1BQU0sRUFBRSxFQUFFLEdBQUcsRUFBRSxJQUFJLE9BQU8sSUFBSTtHQUMxRCxNQUFNLElBQVk7SUFDaEIsSUFBSSxRQUFRO0lBQ1osUUFBUTtJQUNSLE1BQU07SUFDTixHQUFHO0lBQ0g7SUFDQSxNQUFNLEVBQUU7SUFDUixJQUFJLE1BQU07SUFDVixLQUFLO0lBQ0wsUUFBUTtJQUNSLFFBQVE7SUFDUixPQUFPLEVBQUUsUUFBUSxvQkFBb0IsRUFBRSxPQUFPLGFBQWEsRUFBRSxTQUFTO0lBQ3RFLFFBQVEsRUFBRSxRQUFRLElBQUksRUFBRSxTQUFTLFVBQVUsSUFBSTtHQUNqRDtHQUNBLFFBQVEsS0FBSyxDQUFDO0dBQ2QsSUFBSSxFQUFFLEtBQ0osUUFBUSxLQUFLO0lBQ1gsSUFBSSxHQUFHLEVBQUUsR0FBRztJQUNaLFFBQVEsQ0FBQyxFQUFFLEtBQUssVUFBVTtJQUMxQixNQUFNLENBQUMsRUFBRSxLQUFLLFVBQVU7SUFDeEIsR0FBRztJQUNIO0lBQ0EsTUFBTSxFQUFFLEtBQUs7SUFDYixJQUFJLE1BQU07SUFDVixLQUFLO0lBQ0wsUUFBUTtJQUNSLFFBQVE7SUFDUixRQUFRO0lBQ1IsS0FBSztHQUNQLENBQUM7RUFDTDtFQUNBLFVBQVU7RUFDVixJQUFJLENBQUMsRUFBRSxNQUFNO0dBQ1gsT0FBTztHQUNQLFVBQVU7R0FDVjtFQUNGOztFQUVBLE1BQU0sUUFBUTtHQUNaO0dBQ0EsRUFBRSxVQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sWUFBWSxJQUFJLFVBQVU7R0FDM0Q7RUFDRjtFQUNBLE9BQU87RUFDUCxNQUFNLFlBQVksRUFBRSxhQUFhLENBQy9CO0dBQUUsSUFBSSxFQUFFLGdCQUFnQjtHQUFHLEtBQUssRUFBRSxLQUFLO0dBQUssTUFBTSxFQUFFLEtBQUs7RUFBSyxDQUNoRTtFQUNBLEtBQUssTUFBTSxZQUFZLFdBQVc7R0FDaEMsSUFBSSxJQUFJLGNBQWMsS0FBSyxLQUFLLE1BQU0sSUFBSSxTQUFTLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxTQUFTLE1BQU0sR0FDaEYsSUFBSTtHQUNOLE1BQU0sTUFBTTtJQUNWLEdBQUksU0FBUyxPQUFPLENBQUMsUUFBUSxTQUFTLElBQUksR0FBRyxTQUFTLE1BQU0sSUFBSSxDQUFDO0lBQ2pFLFFBQVEsU0FBUztJQUNqQjtHQUNGO0dBQ0EsTUFBTSxRQUFnQjtJQUNwQixJQUFJLFlBQVksU0FBUztJQUN6QixZQUFZO0tBQUUsS0FBTSxTQUFTLEtBQUssS0FBSyxJQUFLLEtBQUs7S0FBSSxHQUFHO0lBQUU7SUFDMUQsUUFBUTtJQUNSLE1BQU0sQ0FBQyxRQUFRLFNBQVMsT0FBTyxHQUFHLEdBQUc7SUFDckMsR0FBRztJQUNILE1BQU0sQ0FBQztJQUNQLE1BQU07SUFDTixJQUFJO0lBQ0osS0FBSyxTQUFTLEtBQUs7SUFDbkIsU0FBUyxNQUFNO0tBQ2IsSUFBSSxLQUFLLEVBQUUsS0FBSyxTQUFTLEVBQUUsS0FBSyxFQUFFLEtBQUssU0FBUyxFQUFFLENBQUUsS0FBSztLQUN6RCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO01BQzFCLE1BQU0sSUFBSSxNQUFNLElBQUksSUFDbEIsSUFBSSxPQUFPLElBQUksS0FBSztNQUN0QjtNQUNBLE1BQU0sUUFBUSxJQUFJLElBQUksTUFBTSxTQUFTLEtBQUssTUFBTSxHQUFHLElBQUk7TUFDdkQsTUFBTSxLQUFLLE1BQU07TUFDakIsRUFBRSxLQUFLLEtBQUs7T0FBRSxJQUFJO09BQUksSUFBSSxLQUFLO09BQU8sR0FBRztPQUFJLEdBQUc7TUFBRyxDQUFDO01BQ3BELE1BQU07TUFDTixLQUFLLFVBQVUsTUFBTSxHQUFHLENBQUMsR0FBRyxJQUFJLFFBQVEsSUFBSyxFQUFFLElBQUk7S0FDckQ7SUFDRjtHQUNGO0dBQ0EsSUFBSSxTQUFTLFVBQVUsbUJBQW1CLEVBQUUsVUFBVSxTQUFTLFFBQVEsR0FBRztJQUN4RSxNQUFNLGFBQWE7S0FBRSxHQUFHO0tBQUcsR0FBRztJQUFFO0lBQ2hDLE1BQU0sZ0JBQWdCO0lBQ3RCLE1BQU0sSUFBSSxVQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sU0FBUyxFQUFFLENBQUMsQ0FBRTtJQUN2RCxNQUFNLE9BQU8sQ0FBQztLQUFFLElBQUk7S0FBVSxJQUFJO0tBQVUsR0FBRztLQUFHLEdBQUc7SUFBRSxDQUFDO0lBQ3hELE1BQU0sU0FBUztHQUNqQixPQUFPLElBQUksU0FBUyxXQUFXLEVBQUUsVUFBVSxTQUFTLE1BQU0sR0FBRztJQUMzRCxNQUFNLGFBQWE7S0FBRSxHQUFHO0tBQUcsR0FBRztJQUFFO0lBQ2hDLE1BQU0sU0FBUyxJQUFJLEtBQUssT0FBTyxlQUFlLElBQUk7SUFDbEQsTUFBTSxPQUFPLE1BQU07SUFDbkIsTUFBTSxJQUFJLFVBQVUsTUFBTSxNQUFNLEVBQUUsT0FBTyxTQUFTLEVBQUUsQ0FBQyxDQUFFO0lBQ3ZELE1BQU0sT0FBTyxDQUFDO0tBQUUsSUFBSTtLQUFVLElBQUk7S0FBVSxHQUFHO0tBQUcsR0FBRztJQUFFLENBQUM7SUFDeEQsTUFBTSxTQUFTO0dBQ2pCLE9BQU8sTUFBTSxPQUFRLEtBQUs7R0FDMUIsUUFBUSxLQUFLLEtBQUs7R0FDbEIsSUFBSSxTQUFTLFFBQVEsRUFBRSxnQkFBZ0IsSUFBSSxPQUFPO0VBQ3BEO0VBQ0EsSUFBSSxNQUNGLEVBQUUsS0FBSyxTQUFTLEdBQUcsTUFDakIsUUFBUSxLQUFLO0dBQ1gsSUFBSSxNQUFNO0dBQ1YsUUFBUSxDQUFDLEdBQUcsVUFBVTtHQUN0QixNQUFNLENBQUMsR0FBRyxVQUFVO0dBQ3BCLEdBQUc7R0FDSCxNQUFNLEtBQU07R0FDWixNQUFNO0dBQ04sSUFBSTtHQUNKLEtBQUssS0FBTSxJQUFJO0dBQ2YsUUFBUTtHQUNSLEtBQUs7RUFDUCxDQUFDLENBQ0g7RUFDRixVQUFVO0NBQ1o7O0NBRUEsSUFBSSxZQUErQyxDQUFDO0NBQ3BELFNBQVMsWUFBa0I7RUFDekIsWUFBWSxDQUFDO0VBQ2IsTUFBTSxRQUNKLElBQ0EsUUFDQSxHQUNBLE9BQ0EsT0FDQSxTQUNBLFNBQ0EsVUFDQSxVQUNTO0dBQ1QsSUFBSSxJQUFJLEdBQ04sSUFBSTtHQUNOLE1BQU0sSUFBbUM7SUFDdkM7SUFDQSxRQUFRLENBQUMsTUFBTTtJQUNmLE1BQU0sQ0FBQyxNQUFNO0lBQ2I7SUFDQSxNQUFNLENBQUM7SUFDUCxNQUFNO0lBQ04sSUFBSTtJQUNKLEtBQUssSUFBSSxNQUFNLEdBQUcsTUFBTSxJQUFJO0lBQzVCO0lBQ0E7SUFDQSxRQUFRO0lBQ1IsU0FBUyxPQUFPO0tBQ2QsSUFBSSxLQUFLLEdBQUcsS0FBSyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUUsS0FBSyxJQUFJLE1BQU0sR0FBRyxNQUFNLElBQUk7S0FDbkYsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztNQUMxQixNQUFNLElBQUksTUFBTSxJQUFJLE1BQU0sU0FDeEIsSUFBSSxPQUFPLElBQUksS0FBSyxNQUFNO01BQzVCO01BQ0EsTUFBTSxRQUFRLFVBQVUsSUFBSSxNQUFNLE1BQU0sR0FBRyxTQUFTLEVBQUUsS0FBSyxVQUFVO01BQ3JFLE1BQU0sS0FBSyxNQUFNO01BQ2pCLEdBQUcsS0FBSyxLQUFLO09BQUUsSUFBSTtPQUFJLElBQUksS0FBSztPQUFPLEdBQUc7T0FBSSxHQUFHO01BQUcsQ0FBQztNQUNyRCxNQUFNO01BQ04sS0FBSyxVQUFVLE1BQU0sR0FBRyxDQUFDLEdBQUcsSUFBSSxPQUFPLEdBQUcsSUFBSTtLQUNoRDtJQUNGO0dBQ0Y7R0FDQSxFQUFFLE9BQVEsQ0FBQztHQUNYLFVBQVUsS0FBSyxDQUFDO0VBQ2xCO0VBQ0EsS0FDRSxTQUNBLGNBQ0EsSUFDQTtHQUFDO0dBQVM7R0FBUztHQUFTO0VBQU8sR0FDbkMsUUFBUSxNQUNSLElBQ0EsS0FDQSxDQUNGO0VBQ0EsS0FDRSxVQUNBLGVBQ0EsSUFDQTtHQUFDO0dBQVE7R0FBUztHQUFVO0VBQU8sR0FDbkMsUUFBUSxJQUNSLEdBQ0EsR0FDQSxVQUFVLFFBQ1YsV0FDRjtDQUNGO0NBQ0EsU0FBUyxZQUFrQjtFQUN6QixVQUFVLFFBQVEsUUFBUSxNQUFNLENBQUMsRUFBRSxHQUFHLFdBQVcsUUFBUSxDQUFDO0VBQzFELE1BQU0sUUFBUSxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsUUFBUSxNQUFNLE1BQU0sUUFBUSxNQUFNLE1BQU0sR0FDdkUsVUFBVTtHQUFDO0dBQVc7R0FBUztHQUFVO0VBQVE7RUFDbkQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsS0FBSztHQUNoQyxNQUFNLE1BQU0sUUFBUSxJQUFJO0dBQ3hCLElBQUksS0FBSyxNQUFNLElBQUksTUFBTTtHQUN6QixJQUFJLElBQUk7R0FDUixNQUFNLElBQVk7SUFDaEIsSUFBSSxTQUFTO0lBQ2IsUUFBUSxDQUFDLFFBQVEsS0FBSztJQUN0QixNQUFNLENBQUMsUUFBUSxPQUFPLFFBQVEsS0FBSztJQUNuQyxHQUFHO0lBQ0gsTUFBTSxDQUFDO0lBQ1AsTUFBTTtJQUNOLElBQUk7SUFDSixLQUFLO0lBQ0wsU0FBUyxPQUFPO0tBQ2QsSUFBSSxLQUFLLEdBQUcsS0FBSyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUUsS0FBSztLQUM1RCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO01BQzFCLE1BQU0sS0FBSyxNQUFNLE1BQU0sR0FBRyxLQUFLLEVBQUUsSUFBSSxNQUFNO01BQzNDLElBQUksT0FBTyxJQUFJO01BQ2YsR0FBRyxLQUFLLEtBQUs7T0FBRSxJQUFJO09BQUksSUFBSSxLQUFLO09BQUssR0FBRyxNQUFNO09BQU0sR0FBRyxNQUFNO01BQUssQ0FBQztNQUNuRSxLQUFLLFVBQVUsTUFBTSxJQUFJLEVBQUUsR0FBRyxLQUFLLElBQUssT0FBTyxHQUFHLElBQUk7TUFDdEQsS0FBSztLQUNQO0lBQ0Y7R0FDRjtHQUNBLEVBQUUsT0FBUSxDQUFDO0dBQ1gsUUFBUSxLQUFLLENBQUM7RUFDaEI7Q0FDRjs7Q0FHQSxNQUFNLFFBQ0osR0FDQSxHQUNBLEdBQ0EsR0FDQSxPQUFPLE9BQ1AsTUFBTSxHQUNOLE9BQU8sR0FDUCxJQUFJLEVBQUUsR0FDTixJQUFJLEVBQUUsTUFDRztFQUNULElBQUksSUFBSSxFQUFFLE1BQU0sRUFBRTtFQUNsQixJQUFJLENBQUMsR0FBRztHQUNOLElBQUk7SUFBRTtJQUFHO0lBQUc7SUFBRztJQUFHO0lBQUc7SUFBRztJQUFNO0lBQUs7R0FBSztHQUN4QyxFQUFFLE1BQU0sRUFBRSxLQUFLO0VBQ2pCLE9BQU87R0FDTCxFQUFFLElBQUk7R0FDTixFQUFFLElBQUk7R0FDTixFQUFFLElBQUk7R0FDTixFQUFFLElBQUk7R0FDTixFQUFFLElBQUk7R0FDTixFQUFFLElBQUk7R0FDTixFQUFFLE9BQU87R0FDVCxFQUFFLE1BQU07R0FDUixFQUFFLE9BQU87R0FDVCxFQUFFLFNBQVM7RUFDYjtFQUNBLEVBQUU7Q0FDSjtDQUNBLE1BQU0sT0FBTyxVQUEwQixJQUFJLFFBQVE7Q0FDbkQsTUFBTSxVQUFVLEdBQVcsR0FBVyxHQUFXLE1BQy9DLElBQUksSUFBSSxLQUFLLEVBQUUsS0FBSyxLQUNwQixJQUFJLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRSxJQUFJLEtBQzFCLEtBQUssRUFBRSxLQUFLLEtBQ1osSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFLElBQUk7Q0FDeEIsU0FBUyxVQUFVLEdBQVcsR0FBVyxPQUFlLFFBQWdCLE9BQU8sR0FBUztFQUN0RixNQUFNLFFBQVEsVUFBVSxJQUN0QixJQUFJLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxTQUFTLFFBQVEsTUFBTyxHQUFJLENBQUM7RUFDMUQsTUFBTSxRQUFRLFFBQVEsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLFFBQVEsR0FBSSxDQUFDLENBQUMsSUFBSTtFQUM1RSxNQUFNLFVBQVUsTUFBTSxPQUFPLEdBQUcsS0FBSztFQUNyQyxLQUNFLFNBQ0EsS0FBSyxNQUFNLENBQUMsR0FDWixLQUFLLE1BQU0sSUFBSSxRQUFRLElBQUksQ0FBQyxHQUM1QixLQUNBLE9BQ0EsR0FDQSxLQUFLLElBQUksTUFBTSxFQUFFLFFBQVEsR0FBSSxDQUMvQjs7O0VBR0EsSUFBSSxFQUFFLFFBQVEsS0FBTTtHQUNsQixNQUFNLE9BQU8sTUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLElBQUksR0FBRyxTQUFTLFFBQVEsSUFBSSxFQUFFO0dBQ3ZFLEtBQ0UsTUFDQSxLQUFLLE1BQU0sSUFBSSxTQUFTLEdBQUksR0FDNUIsS0FBSyxNQUFNLElBQUksS0FBSyxJQUFJLENBQUMsR0FDekIsS0FDQSxPQUNBLEdBQ0EsS0FBSyxJQUFJLE1BQU0sTUFBTyxFQUFFLFFBQVEsR0FBSSxDQUN0QztFQUNGO0NBQ0Y7Q0FDQSxTQUFTLE9BQ1AsS0FDQSxHQUNBLEdBQ0EsR0FDQSxJQU9JLENBQUMsR0FDQztFQUNOLE1BQU0sSUFBSSxNQUFNLElBQUksS0FBSyxDQUFDO0VBQzFCLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLEdBQUc7RUFDN0IsTUFBTSxLQUFLLE1BQU0sUUFBUSxHQUFHLElBQUksSUFBSSxLQUFNO0VBQzFDLElBQ0UsRUFBRSxVQUNGLHlLQUF5SyxLQUN2SyxFQUNGLEdBQ0E7R0FDQSxVQUFVLEdBQUcsRUFBRSxXQUFXLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLFFBQVEsQ0FBQztFQUNwRDtFQUNBLEtBQUssR0FBRyxLQUFLLE1BQU0sQ0FBQyxHQUFHLEtBQUssTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxPQUFPLEdBQUcsRUFBRSxRQUFRLENBQUM7OztFQUd0RixNQUFNLFlBQVksTUFBTSxRQUFRLEdBQUcsSUFBSSxNQUFNLENBQUMsR0FBRyxFQUFDLENBQUUsTUFBTSxRQUFRLE1BQU0sSUFBSSxHQUFHLENBQUM7RUFDaEYsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUUsVUFDZixvQkFBb0IsSUFBSSxXQUFXLFFBQVEsSUFBSSxPQUMvQyxhQUFhLHNCQUNWLElBQ0EsYUFBYSxrQkFDWCxhQUFhLHVCQUNiLGFBQWEsaUJBQ2IsSUFDQTtDQUNWOztDQUVBLFNBQVMsU0FBZTtFQUN0QixNQUFNLElBQUksT0FDUixNQUFNLEdBQUcsRUFBRSxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsVUFBVSxPQUFPLElBQUksRUFBRSxZQUFZLENBQUMsRUFBQyxDQUFFLEtBQUssR0FBRyxFQUFFLEdBQUcsRUFBRSxVQUNqRixLQUFLLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FDaEIsS0FBSyxDQUFDLENBQ04sS0FBSyxHQUFHLEVBQUUsR0FBRyx1QkFBdUI7RUFDekMsSUFBSSxRQUFRLEVBQUUsV0FBVztFQUN6QixFQUFFLFlBQVk7RUFDZCxNQUFNLFdBQVcsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLFVBQVUsS0FBSyxNQUFNLEtBQUssRUFBRSxHQUFHLEdBQUcsR0FBSSxFQUFFLFlBQVksQ0FBQyxDQUFFLENBQUM7RUFDdkYsTUFBTSxVQUFVLFlBQVksSUFBSTtFQUNoQyxFQUFFLFVBQVUsaUJBQWlCO0dBQzNCLE9BQU8sUUFBUTtHQUNmLFFBQVEsUUFBUTtHQUNoQixRQUFRLENBQ04sR0FBRyxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsS0FBSyxTQUFTLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLFFBQVE7SUFDL0UsR0FBRyxNQUFNO0lBQ1QsR0FBRyxNQUFNO0lBQ1QsR0FBRyxJQUFJO0dBQ1QsRUFBRSxHQUNGLElBQUksRUFBRSxZQUFZLENBQUMsRUFBQyxDQUNqQixRQUFRLE9BQU8sT0FBTyxVQUFVLE9BQU8sUUFBUSxDQUFDLENBQ2hELFNBQVMsT0FBTztJQUNmLE1BQU0sU0FBUyxVQUFVLEtBQUssU0FBUyxLQUFLLEdBQXdCO0lBQ3BFLE9BQU8sT0FBTyxTQUNWLENBQ0U7S0FBRSxHQUFHLE1BQU07S0FBTSxHQUFHLE9BQU87S0FBSyxHQUFHO0lBQUUsR0FDckMsR0FBRyxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE9BQU87S0FBRSxHQUFHLE9BQU87S0FBSyxHQUFHO0tBQUcsR0FBRztJQUFFLEVBQUUsQ0FDbEUsSUFDQSxDQUFDO0dBQ1AsQ0FBQyxDQUNMO0dBQ0EsTUFBTSxNQUFNO0dBQ1osT0FBTyxFQUFFLFNBQVMsVUFBVTtHQUM1QixRQUFRO0lBQ04sR0FBSSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDO0lBQzlCLEdBQUcsRUFBRSxVQUFVLEtBQUssTUFBTSxNQUFNLEVBQUUsR0FBRztJQUNyQyxJQUFJLEVBQUUsWUFBWSxDQUFDLEVBQUMsQ0FBRSxLQUFLLE9BQU8sTUFBTSxHQUFHO0dBQzdDO0dBQ0E7R0FDQSxTQUFTO0VBQ1gsQ0FBQztFQUNELGlCQUFpQixZQUFZLElBQUksSUFBSTtFQUNyQztDQUNGO0NBQ0EsU0FBUyxZQUFrQjtFQUN6QixZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLE1BQU0sUUFBUSxhQUFhO0VBQzNCLElBQUksQ0FBQyxFQUFFLFdBQVcsVUFBVSxTQUFTLGlCQUFpQixTQUFTO0VBQy9ELE1BQU0sUUFBUSxlQUFlLEVBQUUsT0FBTyxHQUNwQyxTQUFTLFVBQVUsUUFBUSxJQUFJO0VBQ2pDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSyxRQUFRO0dBQzdDLE1BQU0sSUFBSSxNQUFNO0dBQ2hCLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFLEdBQUcsR0FBRyxFQUFFLENBQUMsR0FBRzs7R0FFL0IsTUFBTSxPQUFPLEtBQUssSUFBSSxJQUFJLE1BQU8sRUFBRSxJQUFJLE9BQVEsRUFBRSxJQUFJLElBQUs7R0FDMUQsTUFBTSxPQUFPLEtBQUssSUFDaEIsR0FDQSxLQUFLLElBQUksR0FBRyxJQUFJLEtBQUssT0FBTyxPQUFPLEtBQU0sS0FBSyxJQUFJLElBQUksTUFBTSxFQUFFLEtBQUssSUFBSSxNQUFPLENBQUMsQ0FBQyxDQUNsRjtHQUNBLE1BQU0sT0FBTyxNQUFNLElBQUksbUJBQW1CLFFBQVEsRUFBRSxDQUFDO0dBQ3JELEtBQUssTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUssT0FBTyxJQUFLLEdBQUk7R0FDMUM7R0FDQSxnQkFBaUIsS0FBSyxLQUFLLGVBQWUsRUFBRSxJQUFJLE9BQU8sTUFBTztFQUNoRTtDQUNGOztDQUVBLE1BQU0sWUFBWSxNQUNoQixJQUFJLE1BQU0sS0FBSyxJQUFJLElBQUksRUFBRSxJQUFJLEtBQUssTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLElBQUksTUFBTSxJQUFJLElBQUk7Q0FDeEUsTUFBTSxXQUFXLE1BQXNCLEtBQU0sS0FBTSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxNQUFNLElBQUksR0FBRyxHQUFHLEdBQUc7Q0FDaEcsTUFBTSxPQUErQjtFQUNuQyxZQUFZO0VBQ1osTUFBTTtFQUNOLFFBQVE7Q0FDVjtDQUNBLE1BQU0sUUFBUSxJQUFJLElBQUk7RUFBQyxHQUFHLE9BQU8sT0FBTyxJQUFJO0VBQUc7RUFBUztFQUFRO0NBQVEsQ0FBQzs7Q0FFekUsSUFBSSxRQUF3RCxDQUFDO0NBQzdELFNBQVMsU0FBZTtFQUN0QixRQUFRLENBQUM7RUFDVCxNQUFNLFFBQVEsTUFBbUI7R0FDL0IsSUFBSSxFQUFFLEtBQUssTUFBTSxNQUFNLFFBQVMsRUFBRSxLQUFLLEtBQUssUUFBUSxRQUFRLEVBQUUsS0FBSyxLQUFLLFFBQVEsTUFDOUUsT0FBTztHQUNULElBQ0UsTUFBTSxNQUNILENBQUMsR0FBRyxHQUFHLFFBQ0wsQ0FBRTtJQUFDO0lBQVM7SUFBUTtHQUFRLENBQUMsQ0FBYyxTQUFTLENBQUMsS0FDcEQsT0FBTyxVQUFVLFNBQVMsQ0FBYyxNQUMxQyxRQUFRLEdBQUcsTUFBTSxJQUFLLE1BQU0sRUFBRyxNQUFNLElBQUksTUFBTyxJQUNwRCxHQUVBLE9BQU87R0FDVCxJQUFJLEtBQUssR0FBRyxNQUFNLElBQUksSUFBSSxJQUFJLE1BQU0sT0FBTztHQUMzQyxJQUNFLE1BQU0sTUFDSCxNQUNDLEtBQUssSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLElBQUksTUFBTSxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLE1BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxNQUFNLElBQ25GLEdBRUEsT0FBTztHQUNULEtBQUssTUFBTSxNQUFNLENBQUMsUUFBUSxRQUFRLEdBQVk7SUFDNUMsSUFBSSxDQUFDLE9BQU8sVUFBVSxTQUFTLEVBQUUsR0FBRztJQUNwQyxNQUFNLFNBQVMsVUFBVSxLQUFLLFNBQVMsS0FBSyxHQUFHO0lBQy9DLElBQ0UsT0FBTyxNQUNKLFNBQVMsS0FBSyxJQUFJLEVBQUUsSUFBSSxLQUFLLENBQUMsSUFBSSxNQUFNLEVBQUUsSUFBSSxLQUFLLElBQUksTUFBTSxFQUFFLElBQUksS0FBSyxJQUFJLEVBQy9FLEdBRUEsT0FBTztJQUNULElBQUksT0FBTyxNQUFNLE1BQU0sTUFBTSxRQUFRLEdBQUcsSUFBSSxPQUFPLElBQUksS0FBTSxNQUFNLEtBQU0sSUFBSSxJQUFJLEVBQUUsR0FDakYsT0FBTztHQUNYO0dBQ0EsSUFBSSxPQUFPLE9BQU8sT0FBTyxDQUFDLENBQUMsTUFBTSxNQUFNLEtBQUssR0FBRyxDQUFDLElBQUksTUFBTSxJQUFJLEdBQUcsT0FBTztHQUN4RSxLQUFLLE1BQU0sQ0FBQyxJQUFJLE9BQU8sT0FBTyxRQUFRLEtBQUssR0FBRztJQUM1QyxLQUFLLE9BQU8sV0FBVyxPQUFPLFVBQVUsT0FBTyxhQUFhLENBQUMsT0FBTyxVQUFVLFNBQVMsRUFBRSxHQUN2RjtJQUNGLE1BQU0sS0FDSixPQUFPLFVBQVUsTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLFVBQVUsTUFBTSxPQUFPLE1BQU07SUFDckYsSUFBSSxLQUFLLElBQUksRUFBRSxJQUFJLEdBQUcsQ0FBQyxJQUFJLE1BQU0sRUFBRSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksT0FBUSxFQUFFLElBQUksR0FBRyxJQUFJLE1BQU0sTUFDOUUsT0FBTztHQUNYO0dBQ0EsT0FBTztFQUNUO0VBQ0EsS0FBSyxJQUFJLEtBQUssTUFBTSxJQUFJLEtBQUssT0FBTyxNQUFNLE1BQ3hDLEtBQUssSUFBSSxLQUFLLElBQUssS0FBSyxPQUFPLE1BQU0sTUFBTTtHQUN6QyxNQUFNLElBQUksTUFBTSxLQUFLLE1BQU0sS0FBSyxFQUFFLEdBQUcsS0FBSyxNQUFNLEtBQUssRUFBRSxHQUFHLENBQUM7R0FDM0QsTUFBTSxJQUFJO0lBQ1IsSUFBSSxNQUFPLElBQUksTUFBTyxNQUFNLE1BQU8sTUFBTztJQUMxQyxJQUFJLE9BQVEsS0FBSyxLQUFLLE1BQU8sTUFBTSxNQUFPLE1BQU87R0FDbkQ7R0FDQSxLQUFLLEtBQUssTUFBTSxNQUFNLElBQUk7R0FDMUIsSUFBSSxLQUFLLENBQUMsR0FDUixNQUFNLEtBQUs7SUFDVCxHQUFHO0lBQ0gsSUFBSSxLQUFLLEtBQUssTUFBTTtJQUNwQixHQUFHLEtBQU0sSUFBSSxJQUFLO0lBQ2xCLEdBQUcsT0FBUyxLQUFLLEtBQUssSUFBSztHQUM3QixDQUFDO0VBQ0w7O0VBRUYsS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLE1BQU0sSUFBSSxNQUFNLEtBQ3RDLEtBQUssSUFBSSxLQUFLLElBQUssS0FBSyxPQUFPLE1BQU0sS0FBSztHQUN4QyxNQUFNLElBQUksTUFBTSxLQUFLLE1BQU0sS0FBSyxFQUFFLEdBQUcsS0FBSyxNQUFNLEtBQUssRUFBRSxHQUFHLEVBQUU7R0FDNUQsTUFBTSxJQUFJO0lBQ1IsSUFBSSxNQUFPLElBQUksTUFBTyxNQUFNLE1BQU8sT0FBTztJQUMxQyxJQUFJLE9BQVEsS0FBSyxLQUFLLE1BQU8sTUFBTSxNQUFPLE1BQU87R0FDbkQ7R0FDQSxLQUFLLEtBQUssTUFBTSxNQUFNLE1BQU0sS0FBSyxJQUFJLEVBQUUsSUFBSSxNQUFNLE1BQU0sQ0FBQyxJQUFJLE1BQU0sTUFBTTtHQUN4RSxNQUFNLEtBQUs7SUFDVCxHQUFHO0lBQ0gsSUFBSSxLQUFLLEtBQUssTUFBTTtJQUNwQixHQUFHLEtBQU0sSUFBSSxJQUFLO0lBQ2xCLEdBQUcsUUFBUSxFQUFFLElBQUksT0FBTyxFQUFHLElBQUk7R0FDakMsQ0FBQztFQUNIO0VBQ0YsTUFBTSxNQUFNLEdBQUcsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDO0NBQ2hDO0NBQ0EsT0FBTztDQUVQLElBQUksV0FBVzs7Q0FFZixTQUFTLFNBQ1AsSUFDQSxHQUNBLE9BQ0EsR0FDQSxNQUNBLE9BQU8sS0FDUCxRQUFRLEdBQ0Y7RUFDTixNQUFNLElBQUk7RUFDVixNQUFNLE9BQU8sRUFBRSxPQUFPLEVBQUUsR0FBRyxRQUFRLFFBQVEsSUFBSSxNQUFNLENBQUM7RUFDdEQsS0FBSyxNQUFNLENBQUMsSUFBSSxJQUFJLE1BQU0sTUFBTTtHQUM5QixNQUFNLEtBQUssT0FBTyxRQUFRLFNBQVMsS0FBSyxLQUFLO0dBQzdDLElBQUksSUFBSSxPQUFRLEVBQUUsT0FBTyxVQUFVLFlBQVk7R0FDL0MsRUFBRSxPQUFPLEtBQUs7SUFDWixHQUFHLEVBQUUsSUFBSSxLQUFNO0lBQ2YsR0FBRyxFQUFFLElBQUksS0FBTTtJQUNmLEdBQUcsS0FBSyxLQUFNLE1BQU8sS0FBSyxNQUFNLFFBQVE7SUFDeEMsR0FBRztLQUFDLElBQU07S0FBRyxNQUFPO0tBQUcsS0FBTTtJQUFDO0dBQ2hDLENBQUM7RUFDSDtDQUNGO0NBQ0EsTUFBTSxrQkFBMkIsQ0FBQztDQUNsQyxTQUFTLFFBQVEsR0FBVyxHQUFXLE1BQWUsT0FBZSxPQUFPLEdBQVM7RUFDbkYsTUFBTSxXQUFXLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxJQUFJLFFBQVEsT0FBUSxHQUFJLENBQUMsS0FBSyxJQUFJO0VBQ3hFLElBQUksWUFBWSxLQUFLLENBQUMsT0FBTyxHQUFHLEdBQUcsSUFBSSxFQUFFLEdBQUc7RUFDNUMsTUFBTSxLQUFLLEtBQUssT0FBTyxDQUFDLElBQUksSUFDMUIsS0FBSyxJQUFJO0VBQ1gsT0FBTyxnQkFBZ0IsR0FBRyxJQUFJLEtBQUssR0FBRztHQUFFLEdBQUcsSUFBSSxDQUFDLElBQUk7R0FBUSxNQUFNLElBQUk7RUFBUyxDQUFDO0VBQ2hGLE1BQU0sSUFBSSxXQUFXO0VBQ3JCLGdCQUFnQixLQUFLO0dBQUUsR0FBRztHQUFJLEdBQUc7R0FBSSxHQUFHO0dBQUksR0FBRztJQUFDO0lBQUcsSUFBSTtJQUFNLElBQUk7R0FBRztFQUFFLENBQUM7Q0FDekU7OztDQUdBLFNBQVMsS0FBSyxHQUFjLE9BQXFCO0VBQy9DLElBQUksQ0FBQyxFQUFFLE1BQU07RUFDYixNQUFNLE9BQU8sSUFBWSxPQUFPLFFBQWdCLEtBQUssTUFBTSxJQUFJLE9BQU8sRUFBRSxJQUFJO0VBQzVFLElBQUksRUFBRSxVQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sWUFBWSxHQUFHO0dBQ2xELE1BQU0sSUFBSSxRQUFRO0dBQ2xCLE9BQU8sY0FBYyxJQUFJLEVBQUUsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFLLEdBQUcsR0FBRyxFQUFFLE1BQU0sTUFBTSxDQUFDO0dBQ2xFLFFBQVEsRUFBRSxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUssR0FBRyxHQUFHLE9BQU8sS0FBSztFQUNoRDtFQUNBLElBQUksRUFBRSxTQUFTLEdBQUc7R0FDaEIsTUFBTSxJQUFJLFFBQVE7R0FDbEIsT0FBTyxpQkFBaUIsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSyxFQUFHLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztHQUNwRSxRQUFRLEVBQUUsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFLLEVBQUcsR0FBRyxNQUFNLEtBQUs7RUFDL0M7RUFDQSxLQUFLLE1BQU0sS0FBSyxXQUFXO0dBQ3pCLElBQUksRUFBRSxXQUFXLEVBQUUsT0FBTztHQUMxQixNQUFNLEtBQUssU0FBUyxHQUFHLENBQUM7R0FDeEIsSUFBSSxDQUFDLElBQUk7R0FDVCxNQUFNLE9BQU8sR0FBRyxXQUFXLEtBQUssTUFBTSxJQUFJLElBQUksRUFBRSxHQUFHLElBQUksT0FBTztHQUM5RCxPQUFPLEVBQUUsUUFBUSxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsS0FBSyxPQUFPLElBQUksSUFBSSxFQUFFLE1BQU0sR0FBRyxLQUFLLENBQUMsSUFBSyxDQUFDO0dBQzFFLFFBQVEsR0FBRyxHQUFHLEdBQUcsS0FBSyxPQUFPLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxLQUFNLEtBQUs7R0FDekQsSUFBSSxFQUFFLE9BQ0osT0FBTyxFQUFFLE9BQU8sRUFBRSxVQUFVLElBQUksR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLE1BQU8sS0FBSyxDQUFDLEtBQUssR0FBRyxHQUFHO0lBQ3ZFLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDZixHQUFHLElBQUksR0FBRyxDQUFDLElBQUk7R0FDakIsQ0FBQztFQUNMOztFQUVBLElBQUksUUFBUSxLQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7R0FDM0IsTUFBTSxLQUFLLE1BQU0sR0FBRyxFQUFFLEdBQ3BCLEtBQUssTUFBTSxHQUFHLEVBQUU7R0FDbEIsTUFBTSxLQUFLLE1BQU0sS0FBSyxLQUFNLEtBQUssTUFBUSxNQUFPLEtBQUssSUFBSSxNQUN2RCxLQUFLLE1BQU0sS0FBSyxLQUFNLEtBQUssTUFBUSxNQUFPLEtBQUssSUFBSTtHQUNyRCxNQUFNLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxNQUFPLENBQUMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLE1BQU0sSUFBSSxHQUFHLElBQUksR0FDekUsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLE1BQU8sSUFBSSxHQUFHLElBQUk7R0FDMUMsTUFBTSxRQUFRLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxLQUFLLEtBQU8sS0FBSyxJQUFLLE1BQU0sSUFBSSxHQUFHLENBQUM7R0FDdkUsSUFBSSxRQUFRLEtBQU07R0FDbEIsT0FBTyxpQkFBaUIsR0FBRyxHQUFHLEdBQUc7SUFBRSxHQUFHO0lBQU0sTUFBTSxJQUFJO0dBQU0sQ0FBQztHQUM3RCxJQUFJLFFBQVEsTUFBTyxFQUFFLE9BQU8sU0FBUyxhQUFhLEdBQ2hELEVBQUUsT0FBTyxLQUFLO0lBQUU7SUFBRztJQUFHLEdBQUc7SUFBRyxHQUFHO0tBQUMsS0FBTTtLQUFPLEtBQU07S0FBTyxNQUFPO0lBQUs7R0FBRSxDQUFDO0VBQzdFO0NBQ0o7Q0FDQSxTQUFTLGdCQUFnQixHQUF1QixJQUE4QjtFQUM1RSxJQUFJLE9BQU8sYUFBYSxJQUFJLEtBQUssb0JBQW9CLElBQUksTUFBTSxZQUFZO0VBQzNFLE1BQU0sS0FBSyxJQUFJLEtBQUsscUJBQXFCLGFBQWE7RUFDdEQsT0FBTyxZQUFZLGFBQWEsTUFBTSxRQUFRLElBQUksR0FBRyxFQUFFLElBQUksSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLElBQUksSUFBSSxHQUFHO0dBQ3BGLEdBQUc7R0FDSCxNQUFNLEtBQUssSUFBSSxHQUFHLElBQUksTUFBTSxFQUFHO0VBQ2pDLENBQUM7Q0FDSDtDQUNBLFNBQVMsZUFBZSxJQUEwQixNQUFvQjtFQUNwRSxNQUFNLElBQUksTUFBTSxLQUNkLEtBQUssUUFBUSxJQUFJLEVBQUU7RUFDckIsTUFBTSxNQUFNLE9BQU8sWUFBWSxhQUFhLElBQUk7RUFDaEQsTUFBTSxPQUFPLE1BQXdCLENBQUMsUUFBUSxHQUFHLEdBQUcsS0FBSyxRQUFRLEdBQUcsR0FBRztFQUN2RSxJQUFJLE9BQU8sYUFBYSxPQUFPLGtCQUFrQixPQUFPLElBQUksSUFBSSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO09BQzNFO0dBQ0gsTUFBTSxVQUFVLFlBQVksSUFBSSxFQUFFO0dBQ2xDLElBQUksWUFBWSxXQUFXLE9BQU8sSUFBSSxPQUFPLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7UUFDeEQsT0FBTyxhQUFhLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztHQUNyQyxNQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLElBQUksTUFBTSxNQUFPLEVBQUcsQ0FBQztHQUN6RCxPQUFPLGlCQUFpQixZQUFZLFlBQVksS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRztJQUNsRSxNQUFNO0lBQ04sUUFBUTtHQUNWLENBQUM7R0FDRCxJQUFJLFNBQVMsR0FBRyxPQUFPLElBQUksSUFBSSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsTUFBTSxJQUFJLE9BQU8sQ0FBQztFQUN2RTtFQUNBLGdCQUFnQixHQUFHLEVBQUU7Q0FDdkI7Q0FDQSxTQUFTLFFBQWM7RUFDckIsTUFBTSxJQUFJO0VBQ1YsSUFBSSxDQUFDLGVBQWUsR0FBRztHQUNyQixRQUFRLE1BQU07R0FDZCxZQUFZLE1BQU07R0FDbEIsT0FBTyxNQUFNO0dBQ2IsS0FBSyxJQUFJLElBQUksTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUssSUFBSSxNQUFNLEVBQUUsQ0FBRSxTQUFTLFFBQVEsTUFBTSxPQUFPLEdBQUcsQ0FBQztFQUM5RixPQUNFLEtBQUssTUFBTSxDQUFDLElBQUksT0FBTyxTQUNyQixJQUFJLElBQUksTUFBTSxZQUFZO0dBQ3hCLFFBQVEsT0FBTyxFQUFFO0dBQ2pCLFlBQVksT0FBTyxFQUFFO0dBQ3JCLE9BQU8sT0FBTyxFQUFFO0VBQ2xCO0VBQ0osRUFBRSxJQUFJO0VBQ04sRUFBRSxPQUFPLFNBQVM7RUFDbEIsZ0JBQWdCLFNBQVM7RUFDekIsTUFBTSxPQUFPLGdCQUFnQixVQUFVO0VBQ3ZDLEVBQUUsUUFBUSxRQUFRLElBQUk7RUFDdEIsRUFBRSxNQUFNLFVBQVUsRUFBRSxLQUFLO0VBQ3pCLE1BQU0sUUFBUSxFQUFFO0VBQ2hCLE9BQU87RUFDUCxVQUFVOztFQUVWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztHQUNyQyxNQUFNLElBQUksTUFBTSxJQUNkLEtBQUssTUFBTSxJQUFJLEVBQUUsSUFBSSxvQkFBb0IsbUJBQW1CLEVBQUUsQ0FBQztHQUNqRSxJQUFJLE9BQU8sRUFBRSxHQUFHLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQzdCLEtBQUssSUFBSSxLQUFLLE1BQU0sRUFBRSxDQUFDLEdBQUcsS0FBSyxNQUFNLEVBQUUsQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDLEdBQUcsT0FBTyxFQUFFLEtBQUssQ0FBQztFQUN4RTs7RUFFQSxNQUFNLElBQUksTUFBTTtFQUNoQixPQUFPLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7RUFDekMsTUFBTSxLQUFLLEtBQUssTUFBTSxJQUFJLENBQUMsSUFBSTtFQUMvQixLQUFLO0VBQ0wsU0FBUyxtQkFBbUIsR0FBRyxPQUFPLElBQUksSUFBSyxFQUFHOztFQUVsRCxNQUFNLElBQUksTUFBTTtFQUNoQixJQUFJLEVBQUUsTUFDSixPQUFPLENBQUMsaUJBQWlCLEtBQUssTUFBTSxJQUFJLENBQUMsSUFBSSxLQUFLLGlCQUFpQixHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO0VBQ3JGLE1BQU0sUUFBUSxLQUFNLEtBQU0sS0FBSyxJQUFJLElBQUksRUFBRSxJQUFJLEtBQUssSUFBSSxJQUFJLEdBQUc7RUFDN0QsSUFBSSxFQUFFLE1BQ0osRUFBRSxPQUFPLEtBQUs7R0FDWixHQUFHLEVBQUU7R0FDTCxHQUFHLEVBQUUsSUFBSTtHQUNULElBQUksS0FBSyxRQUFRLE1BQU07R0FDdkIsR0FBRztJQUFDO0lBQUs7SUFBSztHQUFJLENBQUMsQ0FBQyxLQUFLLE1BQU0sS0FBSyxNQUFPLFFBQVEsT0FBTyxLQUFLO0VBS2pFLENBQUM7RUFDSCxXQUFXO0VBQ1gsSUFBSSxFQUFFLE1BQU07R0FDVixNQUFNLElBQUksTUFBTSxPQUNkLE9BQU8sVUFBVSxDQUFDO0dBQ3BCLGVBQWUsU0FBUyxJQUFJO0dBQzVCLFNBQVMsY0FBYyxRQUFRLEdBQUcsT0FBTyxJQUFJLEdBQUcsS0FBSyxFQUFFLElBQUksRUFBRTtFQUMvRDtFQUNBLElBQUksRUFBRSxRQUFRLFFBQVEsSUFDcEIsRUFBRSxPQUFPLEtBQUs7R0FBRSxHQUFHLE1BQU0sS0FBSztHQUFHLEdBQUcsTUFBTSxLQUFLLElBQUk7R0FBRyxHQUFHO0dBQUksR0FBRztJQUFDO0lBQUs7SUFBTTtHQUFJO0VBQUUsQ0FBQztFQUNyRixJQUFJLEVBQUUsTUFBTSxPQUFPLGNBQWMsTUFBTSxNQUFNLEdBQUcsTUFBTSxNQUFNLEdBQUcsTUFBTSxNQUFNLENBQUM7O0VBRTVFLEtBQUssTUFBTSxLQUFLLE9BQU87R0FDckIsSUFBSSxFQUFFLFFBQVEsRUFBRSxTQUFVLENBQUMsRUFBRSxRQUFRLEVBQUUsVUFBVSxHQUFJO0dBQ3JELE9BQU8sRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLEtBQUssQ0FBQztHQUM1QyxJQUFJLEVBQUUsUUFBUSxRQUFRLE9BQVEsRUFBRSxPQUFPLFNBQVMsWUFBWTtJQUMxRCxNQUFNLEtBQUssS0FBTSxRQUFRLFFBQVE7SUFDakMsRUFBRSxPQUFPLEtBQUs7S0FDWixHQUFHLEVBQUUsSUFBSTtLQUNULEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSTtLQUNmLEdBQUcsS0FBSyxRQUFRO0tBQ2hCLEdBQUc7TUFBQyxJQUFNO01BQUcsTUFBTztNQUFHLE1BQU87S0FBQztJQUNqQyxDQUFDO0dBQ0g7R0FDQSxJQUFJLEVBQUUsT0FBTyxjQUFjLFNBQVMsY0FBYyxHQUFHLE9BQU8sSUFBSSxHQUFHLElBQUssRUFBRSxJQUFJLEVBQUU7RUFDbEY7RUFDQSxLQUFLLE1BQU0sTUFBTSxFQUFFLFlBQVksQ0FBQyxHQUFHO0dBQ2pDLE1BQU0sSUFBSSxjQUFjO0dBQ3hCLE1BQU0sZ0JBQ0osT0FBTyxZQUFZLEVBQUUsV0FBVyxNQUFNLE1BQU0sRUFBRSxVQUFVLGVBQWU7R0FDekUsTUFBTSxVQUFVLENBQUMsaUJBQWlCLFdBQVcsYUFBYSxNQUFNO0dBQ2hFLE1BQU0sV0FDSixPQUFPLFlBQVksZ0JBQ2YsOEJBQThCLFVBQVUsS0FBSyxNQUFNLElBQUksQ0FBQyxJQUFJLElBQUksTUFDaEUsZ0JBQWdCO0dBQ3RCLE9BQU8sVUFBVSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLFFBQVEsS0FBSyxDQUFDO0dBQ2hELElBQUksT0FBTyxRQUFRO0lBQ2pCLEtBQUssTUFBTSxRQUFRLFdBQ2pCLE9BQU8sY0FBYyxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxJQUFJLEdBQUcsRUFBRSxRQUFRLEtBQUssQ0FBQztJQUN4RSxJQUFJLFNBQVM7S0FDWCxNQUFNLFFBQVEsYUFBYSxNQUFNLFFBQVEsSUFBSTtLQUM3QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxLQUN6QixPQUNFLGlCQUNBLEdBQ0EsRUFBRSxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxLQUFNLENBQUMsSUFBSSxDQUFDLEdBQ3hELEVBQUUsSUFBSSxLQUFLLElBQUksR0FDZjtNQUFFLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSTtNQUFRLE1BQU07S0FBSSxDQUNwQztJQUNKO0dBQ0Y7R0FDQSxJQUFJLE9BQU8sVUFDVCxLQUFLLE1BQU0sUUFBUSxXQUNqQixPQUFPLHdCQUF3QixHQUFHLEtBQUssT0FBTyxHQUFHLEtBQUssT0FBTyxJQUFJLEdBQUcsRUFBRSxRQUFRLEtBQUssQ0FBQztHQUN4RixJQUFJLFFBQVEsT0FBUSxFQUFFLE9BQU8sU0FBUyxZQUFZO0lBQ2hELE1BQU0sS0FBSyxPQUFPLFVBQVUsRUFBRSxJQUFJLEtBQUssT0FBTyxXQUFXLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFBSTtJQUMxRSxNQUFNLEtBQUssT0FBTyxVQUFVLEVBQUUsSUFBSSxLQUFLLE9BQU8sV0FBVyxFQUFFLElBQUksSUFBSSxFQUFFLElBQUk7SUFDekUsSUFBSSxPQUFPLFFBQVEsT0FBTyxnQkFBZ0IsR0FBRyxJQUFJLElBQUksRUFBRSxRQUFRLEtBQUssQ0FBQztJQUNyRSxNQUFNLElBQUksUUFBUTtJQUNsQixFQUFFLE9BQU8sS0FBSztLQUFFLEdBQUc7S0FBSSxHQUFHO0tBQUksR0FBRyxPQUFPLFNBQVMsS0FBSztLQUFJLEdBQUc7TUFBQztNQUFHLE1BQU87TUFBRyxLQUFNO0tBQUM7SUFBRSxDQUFDO0dBQ3ZGO0VBQ0Y7RUFDQSxLQUFLLEdBQUcsS0FBSztFQUNiLElBQUksRUFBRSxPQUFPLE9BQU8sY0FBYyxNQUFNLE1BQU0sR0FBRyxNQUFNLE1BQU0sR0FBRyxNQUFNLE1BQU0sQ0FBQzs7RUFFN0UsS0FBSyxNQUFNLEtBQUssRUFBRSxXQUFXO0dBQzNCLE1BQU0sSUFBSSxNQUFNLEVBQUU7R0FDbEIsZUFBZSxFQUFFLElBQUksRUFBRSxJQUFJOztHQUUzQixTQUNFLFFBQVEsRUFBRSxHQUFHLEdBQUcsRUFBRSxRQUNsQixHQUNBLE9BQ0EsRUFBRSxPQUFPLGVBQWUsS0FBSyxJQUM3QixFQUFFLE9BQU8sZUFBZSxNQUFPLENBQ2pDO0VBQ0Y7RUFDQSxJQUFJLEVBQUUsUUFBUTtHQUNaLE1BQU0sSUFBSSxNQUFNLEVBQUUsT0FBTzs7R0FFekIsSUFBSSxDQUFDLEVBQUUsT0FBTyxTQUFTLEVBQUUsT0FBTyxPQUFPLFNBQVMsT0FBTyxhQUFhLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztFQUNsRjs7RUFFQSxJQUFJLEVBQUUsT0FBTztHQUNYLE1BQU0sSUFBSSxVQUNSLEtBQUssRUFBRSxNQUFNLE9BQ2IsT0FBTyxPQUFPO0dBQ2hCLE1BQU0sTUFBTSxPQUFPLENBQUMsS0FBSyxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSTtHQUNuRSxPQUNFLENBQUMsa0JBQWtCLE9BQU8sV0FBVyxLQUFLLElBQUksUUFBUSxpQkFBaUIsR0FDdkUsRUFBRSxHQUNGLEVBQUUsR0FDRixFQUFFLElBQUksR0FDUjtHQUNBLElBQUksTUFBTTtJQUNSLE1BQU0sSUFBSyxJQUFJLEtBQU87SUFDdEIsT0FBTyxZQUFZLEdBQUcsRUFBRSxJQUFJLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxJQUFJLEtBQUs7S0FDbEQsR0FBRztLQUNILE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLElBQUksRUFBRyxJQUFJLEdBQUc7SUFDM0MsQ0FBQztJQUNELElBQUksRUFBRSxPQUFPLFNBQVMsWUFDcEIsRUFBRSxPQUFPLEtBQUs7S0FBRSxHQUFHLEVBQUU7S0FBRyxHQUFHLEVBQUUsSUFBSTtLQUFHLEdBQUcsS0FBSyxRQUFRO0tBQUcsR0FBRztNQUFDO01BQUs7TUFBTTtLQUFHO0lBQUUsQ0FBQztHQUNoRjtFQUNGOzs7RUFHQSxLQUFLLE1BQU0sS0FBSyxFQUFFLFNBQVM7R0FDekIsTUFBTSxJQUFJLFNBQVMsQ0FBQztHQUNwQixJQUFJLENBQUMsR0FBRztHQUNSLElBQUksSUFBSSxFQUFFLEdBQ1IsSUFBSSxFQUFFLEdBQ04sU0FBUyxPQUNULE9BQU87R0FDVCxNQUFNLE9BQU8sT0FBTyxJQUFJLEVBQUUsRUFBRTtHQUM1QixJQUFJLE1BQU0sUUFBUTtJQUNoQixNQUFNLEtBQUssU0FBUztLQUFFO0tBQU0sTUFBTSxLQUFLLEVBQUUsQ0FBRTtLQUFJLElBQUk7SUFBUyxHQUFhLENBQUM7SUFDMUUsSUFBSSxNQUFNLElBQUksS0FBSyxLQUFLLFNBQVMsRUFBRSxDQUFFLElBQUk7S0FDdkMsSUFBSSxHQUFHO0tBQ1AsSUFBSSxHQUFHO0tBQ1AsU0FBUyxHQUFHO0tBQ1osT0FBTyxHQUFHLEtBQUssQ0FBQztJQUNsQixPQUFPLE9BQU8sT0FBTyxFQUFFLEVBQUU7R0FDM0I7R0FDQSxNQUFNLElBQUksTUFBTSxFQUFFLEdBQUcsUUFBUSxFQUFFLEdBQUcsV0FBVyxDQUFDLEdBQUcsRUFBRSxHQUFHLFdBQVcsRUFBRSxHQUFHLFNBQVMsQ0FBQyxDQUFDO0dBQ2pGLE1BQU0sT0FBTyxLQUFPLElBQUksS0FBTSxLQUM1QixRQUFTLElBQUksS0FBTTtHQUNyQixNQUFNLE9BQU8sV0FBVyxLQUFLLE1BQU0sSUFBSSxHQUFHLElBQUksT0FBTztHQUNyRCxNQUFNLFNBQVMsRUFBRSxPQUFPLFNBQVMsSUFBSSxLQUFLLE9BQU8sSUFBSSxTQUFTLElBQUksSUFBSTtHQUN0RSxJQUFJLEVBQUUsS0FBSztJQUNULE1BQU0sSUFBSSxNQUFNLEtBQUssVUFBVSxFQUFFLEVBQUUsR0FBRyxFQUFFO0lBQ3hDLElBQUksT0FBTyxHQUFHLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHO0tBQzFCLFVBQVUsR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7S0FDeEIsS0FBSyxHQUFHLEtBQUssTUFBTSxDQUFDLEdBQUcsS0FBSyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxNQUFNLEdBQUcsQ0FBQztJQUMxRDtHQUNGLE9BQ0UsT0FBTyxVQUFVLEVBQUUsSUFBSSxNQUFNLEdBQUcsSUFBSSxHQUFHLEtBQUssT0FBTyxJQUFJLElBQUk7SUFDekQ7SUFDQSxLQUFLLEVBQUUsU0FBUyxLQUFNO0dBQ3hCLENBQUM7O0dBRUgsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLE9BQU8sR0FDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsT0FBTyxHQUFHLEtBQzlCLE9BQU8saUJBQWlCLEdBQUcsS0FBSyxFQUFFLE9BQU8sS0FBSyxNQUFNLElBQUksR0FBRyxJQUFJLE1BQU0sT0FBTyxJQUFJLElBQUksRUFDbEYsR0FBRyxJQUFJLENBQUMsSUFBSSxLQUNkLENBQUM7R0FDTCxJQUFJLENBQUMsRUFBRSxLQUFLLFFBQVEsR0FBRyxLQUFLLE9BQU8sSUFBSSxJQUFJLE1BQU0sS0FBSztFQUN4RDs7RUFFQSxFQUFFLE9BQU8sU0FBUyxHQUFHLE1BQU07R0FDekIsTUFBTSxJQUFJLE1BQU07R0FDaEIsT0FBTyxDQUFDLEdBQUcsVUFBVSxHQUFHLElBQUksRUFBRSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUUsSUFBSSxHQUFHO0lBQUUsTUFBTSxJQUFJLE1BQU07SUFBRyxRQUFRO0dBQUssQ0FBQztFQUM3RixDQUFDOztFQUVELElBQUksT0FBTztFQUNYLEtBQUssTUFBTSxLQUFLLFNBQVM7R0FDdkIsTUFBTSxLQUFLLEVBQUUsU0FBUyxTQUFTLEVBQUUsUUFBUSxJQUFJLEVBQUUsR0FBRyxJQUFJLFNBQVMsR0FBRyxDQUFDO0dBQ25FLElBQUksQ0FBQyxNQUFPLEVBQUUsVUFBVSxJQUFJLEVBQUUsUUFBUyxJQUFJLEVBQUUsSUFBSTtHQUNqRCxNQUFNLFVBQVUsRUFBRSxVQUFVLEVBQUMsQ0FBRTtHQUMvQixJQUFJLElBQUksR0FBRyxLQUFLLFFBQVEsS0FBSyxJQUMzQixJQUFJLEdBQUcsS0FBSyxRQUFRLEtBQUs7R0FDM0IsSUFBSSxFQUFFLFVBQVUsR0FBRyxRQUFRO0lBQ3pCLEtBQUssS0FBSyxLQUFLLEdBQUcsRUFBRSxJQUFJO0lBQ3hCLEtBQUs7R0FDUDtHQUNBLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQztHQUN0QixJQUFJLE9BQU87R0FDWCxJQUFJLEVBQUUsUUFBUTtJQUNaLE1BQU0sTUFBTSxJQUFJLEVBQUU7SUFDbEIsSUFBSSxNQUFNLElBQUssT0FBTyxJQUFJLE1BQU07R0FDbEM7R0FDQSxJQUFJLEVBQUUsVUFBVSxFQUFFLEtBQUssSUFBSSxJQUFLLE9BQU8sS0FBSyxJQUFJLE1BQU0sS0FBSyxFQUFFLEtBQUssS0FBSyxFQUFHO0dBQzFFLElBQUksTUFBTSxRQUFRLFdBQVc7SUFDM0IsTUFBTSxLQUFLLElBQUksVUFBVSxPQUFPLFVBQVUsS0FBSyxVQUFVO0lBQ3pELElBQUksSUFBSSxLQUFNLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxPQUFRLENBQUM7R0FDakQ7R0FDQSxJQUFJLEVBQUUsZUFDSixPQUFPLEtBQUssSUFDVixNQUNBLGlCQUFpQixXQUFXLGFBQWEsTUFBTSxRQUMzQyxNQUNBLEtBQU0sS0FBSyxJQUFJLElBQUksQ0FBQyxJQUFJLEdBQzlCO0dBQ0YsTUFBTSxPQUFPLEdBQUcsV0FBVyxLQUFLLE1BQU0sSUFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLElBQUksT0FBTztHQUNwRSxNQUFNLE1BQU0sT0FBTyxFQUFFLE9BQU8sRUFBRTtHQUM5QixNQUFNLGdCQUFnQixFQUFFO0dBQ3hCLE1BQU0sYUFDSixFQUFFLE9BQU8sT0FBTyxrQkFDaEIsRUFBRSxPQUFPLE9BQU8sdUJBQ2Ysb0JBQW9CLEtBQUssV0FBVyxFQUFFLE9BQU8sRUFBRSxNQUFNO0dBQ3hELE9BQU8sS0FBSyxFQUFFLEdBQUcsR0FBRyxLQUFLLE9BQU8sSUFBSSxJQUFJO0lBQ3RDO0lBQ0E7SUFDQSxRQUFRO0lBQ1IsU0FBUyxtQkFBbUIsS0FBSyxhQUFhLElBQUk7R0FDcEQsQ0FBQztHQUNELElBQUksRUFBRSxJQUFJLGlCQUFpQixDQUFDLFlBQVksRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUUsU0FBUztHQUNuRSxJQUFJLENBQUMsRUFBRSxLQUFLLFFBQVEsR0FBRyxLQUFLLE9BQU8sSUFBSSxJQUFJLE1BQU0sT0FBTyxJQUFJO0dBQzVELElBQUksRUFBRSxPQUFPO0lBQ1gsTUFBTSxRQUFRLE9BQU8sQ0FBQyxJQUFJLE1BQU0sRUFBRSxVQUFVLG9CQUFvQixJQUFJO0lBQ3BFLE9BQU8sRUFBRSxPQUFPLEVBQUUsVUFBVSxHQUFHLElBQUksTUFBTSxJQUFJLEtBQUssRUFBRSxVQUFVLE1BQU0sT0FBTyxJQUFJLElBQUk7S0FDakYsR0FBRyxJQUFJLENBQUMsSUFBSTtLQUNaO0tBQ0E7SUFDRixDQUFDO0lBQ0QsSUFBSSxFQUFFLFVBQVUsbUJBQ2QsRUFBRSxPQUFPLEtBQUs7S0FBRSxHQUFHLElBQUk7S0FBTSxHQUFHLElBQUk7S0FBRyxHQUFHO0tBQUksR0FBRztNQUFDO01BQUs7TUFBTTtLQUFHO0lBQUUsQ0FBQztHQUN2RTtHQUNBO0VBQ0Y7RUFDQSxFQUFFLE9BQU87O0VBRVQsVUFBVSxLQUFLO0VBQ2YsS0FBSyxNQUFNLEtBQUssT0FBTztHQUNyQixNQUFNLE9BQU8sRUFBRSxNQUFNLEVBQUU7R0FDdkIsT0FBTyxVQUFVLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRztJQUNyQyxHQUFHLEVBQUUsU0FBUyxVQUFVLE1BQU07SUFDOUIsTUFBTSxFQUFFLFNBQVMsVUFBVSxLQUFLLElBQUksR0FBRyxPQUFPLE1BQU0sRUFBRyxJQUFJLEtBQUssSUFBSSxHQUFHLE9BQU8sTUFBTSxFQUFHO0dBQ3pGLENBQUM7R0FDRCxJQUFJLEVBQUUsU0FBUyxXQUFXLFFBQVEsTUFBTyxFQUFFLE9BQU8sU0FBUyxZQUN6RCxFQUFFLE9BQU8sS0FBSztJQUFFLEdBQUcsRUFBRTtJQUFHLEdBQUcsRUFBRTtJQUFHLEdBQUc7SUFBRyxHQUFHO0tBQUM7S0FBRztLQUFLO0lBQUc7R0FBRSxDQUFDO0VBQzVEOztFQUVBLEVBQUUsT0FBTyxRQUFRLEdBQUcsZUFBZTtFQUNuQyxFQUFFLE9BQU8sU0FBUyxLQUFLLElBQUksRUFBRSxPQUFPLFFBQVEsVUFBVTtDQUN4RDtDQUNBLElBQUksUUFBUSxHQUNWLFNBQVMsR0FDVCxRQUFRO0NBQ1YsU0FBUyxVQUFVLE9BQXFCO0VBQ3RDLEtBQUs7RUFDTCxNQUFNLEtBQUssS0FBSyxJQUFJLElBQUssSUFBSSxLQUFLO0VBQ2xDLFFBQVE7RUFDUixNQUFNLElBQUksTUFBTTtFQUNoQixNQUFNLE9BQU8sS0FBSztFQUNsQixJQUFJLE1BQU8sUUFBUSxLQUFLLElBQUksS0FBSyxHQUMvQixNQUFNLEtBQUs7R0FDVCxHQUFHLEVBQUUsS0FBSyxLQUFLLElBQUksTUFBTztHQUMxQixHQUFHLEVBQUUsSUFBSTtHQUNULEtBQUssS0FBSyxJQUFJLE1BQU87R0FDckIsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJO0dBQ25CLEtBQUs7R0FDTCxNQUFNLE1BQU0sS0FBSztHQUNqQixNQUFNO0dBQ04sR0FBRyxNQUFNLEtBQUssTUFBTSxLQUFLLElBQUksQ0FBQztHQUM5QixHQUFHLEtBQUssSUFBSSxLQUFNLElBQUk7RUFDeEIsQ0FBQztFQUNILElBQUksTUFBTyxRQUFRLEtBQUssSUFBSSxLQUFLLEdBQy9CLE1BQU0sS0FBSztHQUNULEdBQUcsRUFBRSxLQUFLLEtBQUssSUFBSSxNQUFPO0dBQzFCLEdBQUcsRUFBRSxJQUFJO0dBQ1QsS0FBSyxLQUFLLElBQUksTUFBTztHQUNyQixJQUFJLENBQUMsS0FBSyxLQUFLLElBQUk7R0FDbkIsS0FBSztHQUNMLE1BQU0sS0FBTSxLQUFLLElBQUk7R0FDckIsTUFBTTtHQUNOLEdBQUcsTUFBTSxLQUFLLE1BQU0sS0FBSyxJQUFJLENBQUM7R0FDOUIsR0FBRztFQUNMLENBQUM7RUFDSCxNQUFNLFFBQVEsTUFBTyxVQUFVLE1BQzVCLE1BQ0MsRUFBRSxPQUFPLGdCQUFnQixFQUFFLFFBQVEsSUFBSSxFQUFFLEVBQUUsS0FBSyxJQUFJLFFBQVEsSUFBSSxFQUFFLEVBQUUsSUFBSyxpQkFDN0U7RUFDQSxJQUFJLE9BQU87R0FDVCxNQUFNLElBQUksTUFBTTtHQUNoQixJQUFJLElBQUksU0FBUyxNQUFPLE1BQU0sS0FBSyxNQUFNLENBQUMsQ0FBQyxJQUFJLEtBQU0sSUFBSTtJQUN2RCxTQUFTO0lBQ1QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FDckIsTUFBTSxLQUFLO0tBQ1QsR0FBRyxFQUFFLElBQUk7S0FDVCxHQUFHLEVBQUUsSUFBSTtLQUNULEtBQUssS0FBSyxJQUFJLE1BQU87S0FDckIsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJO0tBQ25CLEtBQUs7S0FDTCxNQUFNLEtBQU0sS0FBSyxJQUFJO0tBQ3JCLE1BQU07S0FDTixHQUFHLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSSxDQUFDO0tBQzlCLEdBQUc7SUFDTCxDQUFDO0dBQ0w7R0FDQSxJQUFJLElBQUksUUFBUSxLQUFNO0lBQ3BCLFFBQVE7SUFDUixNQUFNLEtBQUs7S0FDVCxHQUFHLEVBQUUsSUFBSSxNQUFNLEtBQUssSUFBSSxNQUFPO0tBQy9CLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSTtLQUNmLElBQUksSUFBSSxLQUFLLElBQUk7S0FDakIsSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJO0tBQ2xCLEtBQUs7S0FDTCxNQUFNLE1BQU0sS0FBSztLQUNqQixNQUFNO0tBQ04sR0FBRyxNQUFNLEtBQUssTUFBTSxLQUFLLElBQUksQ0FBQztLQUM5QixHQUFHO0lBQ0wsQ0FBQztHQUNIO0VBQ0Y7RUFDQSxLQUFLLE1BQU0sQ0FBQyxJQUFJLE9BQU8sU0FDckIsSUFBSSxlQUFlLEtBQUssSUFBSSxNQUFNLG9CQUFvQixDQUFDLE9BQU8sSUFBSSxFQUFFLEdBQUc7R0FDckUsT0FBTyxJQUFJLEVBQUU7R0FDYixNQUFNLElBQUksTUFBTTtHQUNoQixLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssYUFBYSxNQUFNLFFBQVEsSUFBSSxLQUFLLEtBQUs7SUFDNUQsTUFBTSxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssR0FDM0IsSUFBSSxLQUFLLEtBQUssSUFBSTtJQUNwQixNQUFNLEtBQUs7S0FDVCxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJO0tBQ3ZCLEdBQUcsRUFBRSxJQUFJO0tBQ1QsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJO0tBQ2xCLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLEtBQU07S0FDNUIsS0FBSztLQUNMLE1BQU0sS0FBTSxLQUFLLElBQUk7S0FDckIsTUFBTTtLQUNOLElBQUksT0FBTyxlQUFlLFFBQVEsS0FBSSxDQUFFLEtBQUssTUFBTSxLQUFLLElBQUksQ0FBQztLQUM3RCxHQUFHO0lBQ0wsQ0FBQztHQUNIO0VBQ0Y7RUFDRixLQUFLLElBQUksSUFBSSxNQUFNLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztHQUMxQyxNQUFNLElBQUksTUFBTTtHQUNoQixFQUFFLE9BQU87R0FDVCxJQUFJLEVBQUUsT0FBTyxFQUFFLE1BQU07SUFDbkIsTUFBTSxPQUFPLEdBQUcsQ0FBQztJQUNqQjtHQUNGO0dBQ0EsSUFBSSxFQUFFLFNBQVMsU0FBUztJQUN0QixFQUFFLE1BQU0sS0FBSyxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksS0FBSztJQUNyQyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxLQUFNLElBQUksRUFBRTtHQUNyQztHQUNBLElBQUksRUFBRSxTQUFTLFNBQVMsRUFBRSxNQUFNLEtBQUs7R0FDckMsSUFBSSxFQUFFLFNBQVMsUUFBUTtJQUNyQixFQUFFLE1BQU0sSUFBSSxLQUFLO0lBQ2pCLEVBQUUsTUFBTSxJQUFJLEtBQUs7R0FDbkI7R0FDQSxFQUFFLEtBQUssRUFBRSxLQUFLO0dBQ2QsRUFBRSxLQUFLLEVBQUUsS0FBSztFQUNoQjtFQUNBLElBQUksTUFBTSxTQUFTLEtBQUssTUFBTSxPQUFPLEdBQUcsTUFBTSxTQUFTLEdBQUc7Q0FDNUQ7Q0FDQSxNQUFNLFNBQVMsSUFBSSxJQUFZOztDQUcvQixTQUFTLE1BQVk7RUFDbkIsTUFBTSxJQUFJO0VBQ1YsSUFBSSxDQUFDLEdBQUc7RUFDUixNQUFNLElBQUksR0FBRyxzQkFBc0I7RUFDbkMsTUFBTSxNQUFNLE9BQU8sb0JBQW9CO0VBQ3ZDLE1BQU0sSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sRUFBRSxRQUFRLEdBQUcsQ0FBQyxHQUM3QyxJQUFJLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxFQUFFLFNBQVMsR0FBRyxDQUFDOztFQUU1QyxJQUFJLEtBQUssVUFDUCxLQUFLLFVBQ0wsS0FBSyxDQUFDLFVBQ04sS0FBSyxDQUFDO0VBQ1IsTUFBTSxPQUFPLEdBQXVCLE9BQXFCO0dBQ3ZELEtBQUssS0FBSyxJQUFJLElBQUksRUFBRSxJQUFJLEVBQUU7R0FDMUIsS0FBSyxLQUFLLElBQUksSUFBSSxFQUFFLElBQUksRUFBRTtHQUMxQixLQUFLLEtBQUssSUFBSSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUM7R0FDM0IsS0FBSyxLQUFLLElBQUksSUFBSSxFQUFFLElBQUksQ0FBQztFQUMzQjtFQUNBLElBQUksTUFBTSxPQUFPLEVBQUU7RUFDbkIsSUFBSSxNQUFNLE1BQU0sRUFBRTtFQUNsQixJQUFJLE1BQU0sTUFBTSxFQUFFO0VBQ2xCLElBQUksTUFBTSxPQUFPLEVBQUU7RUFDbkIsS0FBSyxNQUFNLEtBQUssRUFBRSxXQUFXLElBQUksTUFBTSxFQUFFLEtBQUssRUFBRTtFQUNoRCxLQUFLLE1BQU0sTUFBTSxFQUFFLFlBQVksQ0FBQyxHQUM5QixJQUFJLE1BQU0sS0FBSyxPQUFPLFVBQVUsS0FBSyxPQUFPLFNBQVMsS0FBSyxFQUFFO0VBQzlELEtBQUssTUFBTSxNQUFNLENBQUMsUUFBUSxRQUFRLEdBQ2hDLElBQUksRUFBRSxVQUFVLFNBQVMsRUFBRSxHQUFHLEtBQUssTUFBTSxRQUFRLFdBQVcsSUFBSTtHQUFFLEdBQUcsS0FBSztHQUFLLEdBQUc7RUFBRyxHQUFHLEVBQUU7RUFDNUYsS0FBSyxNQUFNLEtBQUssRUFBRSxTQUFTO0dBQ3pCLE1BQU0sSUFBSSxTQUFTLENBQUM7R0FDcEIsSUFBSSxHQUFHLElBQUk7SUFBRSxHQUFHO0lBQUcsR0FBRztHQUFHLEdBQUcsRUFBRTtFQUNoQztFQUNBLElBQUksRUFBRSxRQUFRLElBQUk7R0FBRSxHQUFHLE1BQU0sRUFBRSxPQUFPO0dBQUssR0FBRztFQUFHLEdBQUcsRUFBRTtFQUN0RCxLQUFLLE1BQU0sS0FBSyxPQUNkLElBQUksRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFFBQVEsS0FBSyxFQUFFLElBQUksTUFBTSxPQUFPLElBQUksTUFBTSxNQUFNLElBQUksR0FBRyxFQUFFO0VBQ3ZGLE1BQU0sSUFBSTtFQUNWLE1BQU07RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLE1BQU0sSUFBSTs7RUFFVixNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFHO0VBQ2hELE1BQU0sS0FBSyxLQUFLLEtBQUssRUFBRSxHQUNyQixTQUFTLElBQUksTUFBTSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxNQUFNLEtBQUssS0FBSyxJQUFJLElBQUk7O0VBRXhFLE1BQU0sSUFDSixLQUFLLE1BQU0sU0FBUyxLQUFLLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFO0VBQ3ZGLE1BQU0sSUFBSSxLQUFLLEtBQUssSUFBSSxDQUFDLEdBQ3ZCLElBQUksS0FBSyxLQUFLLElBQUksQ0FBQztFQUNyQixJQUFJLE1BQU0sS0FBSyxNQUFNLEdBQ25CLE1BQU0sS0FBSyxNQUFNO0VBQ25CLEtBQUssS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLElBQUksUUFBUSxPQUFPLElBQUksR0FBRyxFQUFFLENBQUM7RUFDdkQsS0FBSyxLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssSUFBSSxRQUFRLE9BQU8sSUFBSSxHQUFHLEVBQUUsQ0FBQztFQUN2RCxNQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSSxDQUFDLEdBQy9CLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSSxDQUFDO0VBQzdCLElBQ0UsUUFBUSxFQUFFLE1BQ1YsUUFBUSxFQUFFLE1BQ1YsTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFLEdBQ1I7R0FDQSxFQUFFLEtBQUs7R0FDUCxFQUFFLEtBQUs7R0FDUCxFQUFFLElBQUk7R0FDTixFQUFFLElBQUk7R0FDTixFQUFFLElBQUk7R0FDTixFQUFFLElBQUk7R0FDTixFQUFFLElBQUk7R0FDTixjQUFjO0dBQ2QsS0FBSyxNQUFNLE1BQU0sYUFBYSxHQUFHO0VBQ25DO0NBQ0Y7Q0FFQSxTQUFTLEtBQUssS0FBbUI7RUFDL0IsTUFBTTtFQUNOLElBQUksVUFBVTtFQUNkLElBQUksU0FBUyxRQUFRO0dBQ25CLE9BQU87R0FDUDtFQUNGO0VBQ0EsSUFBSSxDQUFDLEdBQUcsYUFBYTtHQUNuQixPQUFPO0dBQ1AsTUFBTSxzQkFBc0IsSUFBSTtHQUNoQztFQUNGO0VBQ0EsTUFBTSxPQUFPLE1BQU0sWUFBWTs7O0VBRy9CLE1BQU0sTUFBTSxTQUFTLGdCQUFnQixRQUFRLFVBQVUsUUFBUSxXQUFXLE9BQU8sV0FBVztFQUM1RixJQUFJLE9BQU8sTUFBTSxXQUFXLE1BQU8sTUFBTSxHQUFHO0dBQzFDLE1BQU0sc0JBQXNCLElBQUk7R0FDaEM7RUFDRjtFQUNBLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBTSxNQUFNLFFBQVEsR0FBSTtFQUM1QyxPQUFPO0VBQ1AsV0FBVztFQUNYLEtBQUs7RUFDTCxJQUFJLE9BQU87R0FDVCxNQUFNLEtBQUssWUFBWSxJQUFJO0dBQzNCLElBQUk7R0FDSixNQUFNO0dBQ04sSUFBSSxNQUFNLENBQUMsUUFBUTtJQUNqQixHQUFHLE9BQU8sQ0FBQztJQUNYLElBQUksS0FBSyxJQUFJLE1BQU0sVUFBVTtHQUMvQixPQUFPO0lBQ0wsTUFBTSxJQUFJLE9BQU87SUFDakIsRUFBRSxNQUFNLFVBQVU7SUFDbEIsV0FBVyxHQUFHLEdBQUcsTUFBTSxNQUFNO0dBQy9CO0dBQ0EsSUFBSSxLQUFLLFlBQVksSUFBSSxJQUFJLEVBQUU7R0FDL0IsSUFBSSxJQUFJLFNBQVMsS0FBSyxJQUFJLE1BQU07R0FDaEMsS0FBSyxNQUFNLE1BQU0sYUFBYSxHQUFHO0dBQ2pDO0dBQ0EsT0FBTyxLQUFLLEdBQUc7R0FDZixPQUFPLE9BQU8sVUFBVSxPQUFPLEtBQU0sTUFBTSxLQUFNLE9BQU8sTUFBTTtHQUM5RCxJQUFJLGFBQWEsS0FBSyxVQUFVLElBQUk7SUFDbEMsTUFBTSxJQUFJLFVBQVU7SUFDcEIsWUFBWTtJQUNaLEVBQUU7R0FDSjtHQUNBLElBQUksYUFBYTtJQUNmLGNBQWM7SUFDZCxLQUFLLE1BQU0sTUFBTSxXQUFXLEdBQUc7R0FDakM7RUFDRjtFQUNBLE1BQU0sc0JBQXNCLElBQUk7Q0FDbEM7Q0FDQSxNQUFNLGNBQW9CO0VBQ3hCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVTtHQUNyQixPQUFPLFlBQVksSUFBSTtHQUN2QixNQUFNLHNCQUFzQixJQUFJO0VBQ2xDO0NBQ0Y7Q0FDQSxNQUFNLGNBQW9CO0VBQ3hCLElBQUksQ0FBQyxTQUFTLFFBQVEsTUFBTTtDQUM5QjtDQUNBLFNBQVMsaUJBQWlCLG9CQUFvQixLQUFLO0NBQ25ELE1BQU0sYUFBbUI7RUFDdkIsWUFBWSxZQUFZLElBQUk7Q0FDOUI7Q0FDQSxNQUFNLFNBQVM7RUFBQztFQUFlO0VBQWU7RUFBVztFQUFTO0NBQVk7Q0FDOUUsS0FBSyxNQUFNLE1BQU0sUUFBUSxPQUFPLGlCQUFpQixJQUFJLE1BQU0sRUFBRSxTQUFTLEtBQUssQ0FBQztDQUM1RSxNQUFNLEtBQ0osT0FBTyxtQkFBbUIsY0FDdEIsSUFBSSxxQkFBcUI7RUFDdkIsSUFBSTtFQUNKLGNBQWM7Q0FDaEIsQ0FBQyxJQUNEO0NBQ04sSUFBSSxRQUFRLEVBQUU7Q0FFZCxNQUFNLE9BQU8sR0FBVyxNQUFrQjtFQUN4QyxNQUFNLE1BQU0sT0FBTyxvQkFBb0I7RUFDdkMsT0FBTztHQUFFLElBQUssSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFLO0dBQUssSUFBSyxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUs7RUFBSTtDQUNwRTtDQUNBLE1BQU0sYUFBYSxPQUFzRTtFQUN2RixNQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU0sRUFBRSxPQUFPLFlBQVksSUFBSTtFQUMzRCxJQUFJLENBQUMsT0FBTyxPQUFPO0VBQ25CLE1BQU0sS0FBSyxTQUFTLE9BQU8sQ0FBQztFQUM1QixJQUFJLENBQUMsSUFBSSxPQUFPO0VBQ2hCLE1BQU0sT0FBTyxNQUFNLElBQUksTUFBTSxRQUFRLE1BQU0sQ0FBQztFQUM1QyxNQUFNLElBQUksR0FBRyxLQUFLLE1BQU0sWUFBWSxLQUFLLElBQ3ZDLElBQUksR0FBRyxLQUFLLE1BQU0sWUFBWSxLQUFLO0VBQ3JDLE1BQU0sSUFBSSxJQUFJLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLENBQUMsR0FDdEMsSUFBSSxJQUFJLElBQUksS0FBSyxJQUFJLEdBQUcsQ0FBQztFQUMzQixPQUFPO0dBQUUsR0FBRyxFQUFFO0dBQUcsR0FBRyxFQUFFO0dBQUcsR0FBRyxFQUFFLElBQUksRUFBRTtHQUFHLEdBQUcsRUFBRSxJQUFJLEVBQUU7RUFBRTtDQUN0RDtDQUNBLE9BQU87RUFDTDtFQUNBLFNBQVMsR0FBRztHQUNWLE1BQU0sT0FBTztHQUNiLFFBQVE7R0FDUixZQUFZLGtCQUFrQixDQUFDO0dBQy9CLElBQUksTUFDRixLQUFLLE1BQU0sTUFBTSxRQUFRLEtBQUssR0FBRztJQUMvQixNQUFNLFVBQ0osT0FBTyxVQUFVLFVBQVUsSUFBSSxJQUFJLEtBQUssVUFBVSxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFO0lBQzlFLE1BQU0sV0FDSixPQUFPLFVBQ0gsRUFBRSxPQUNBLFVBQVUsQ0FBQyxJQUNYLFlBQ0YsRUFBRSxVQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7SUFDNUMsSUFBSSxhQUFhLGFBQWMsWUFBWSxhQUFhLFdBQVcsU0FBVTtLQUMzRSxRQUFRLE9BQU8sRUFBRTtLQUNqQixZQUFZLE9BQU8sRUFBRTtLQUNyQixPQUFPLE9BQU8sRUFBRTtJQUNsQjtHQUNGO0dBQ0YsTUFBTSxVQUFVLG9CQUFvQixNQUFNLENBQUM7R0FDM0MsZUFBZSxRQUFRO0dBQ3ZCLElBQUksUUFBUSxVQUFVLGVBQWUsR0FBRyxLQUFLO0dBQzdDLElBQUksZUFBZSxHQUNqQixLQUFLLE1BQU0sVUFBVSxTQUFTO0lBQzVCLFFBQVEsSUFBSSxPQUFPLElBQUksQ0FBQztJQUN4QixPQUFPLE9BQU8sT0FBTyxFQUFFO0lBQ3ZCLElBQUksT0FBTyxhQUFhLFdBQVcsWUFBWSxJQUFJLE9BQU8sSUFBSSxPQUFPLFFBQVE7U0FDeEUsWUFBWSxPQUFPLE9BQU8sRUFBRTtHQUNuQzs7R0FFRixJQUFJLE1BQ0YsS0FBSyxNQUFNLEtBQUssRUFBRSxTQUFTO0lBQ3pCLElBQUksRUFBRSxPQUFPLEtBQUssUUFBUSxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsR0FBRyxHQUFHO0lBQ2hFLE1BQU0sSUFBSSxTQUFTLENBQUM7SUFDcEIsSUFBSSxDQUFDLEdBQUc7SUFDUixNQUFNLE9BQWMsQ0FBQztJQUNyQixVQUFVO0tBQUMsTUFBTTtLQUFPLEdBQUcsTUFBTSxRQUFRLFlBQVksQ0FBQyxDQUFDO0tBQUc7SUFBQyxHQUFHLElBQUksSUFBSyxRQUFRLEtBQUssSUFBSTtJQUN4RixPQUFPLElBQUksRUFBRSxJQUFJLElBQUk7R0FDdkI7R0FDRixJQUNFLENBQUMsUUFDRCxLQUFLLFVBQVUsQ0FBQyxLQUFLLFVBQVUsS0FBSyxRQUFRLE1BQU0sQ0FBQyxNQUNqRCxLQUFLLFVBQVUsQ0FBQyxFQUFFLFVBQVUsRUFBRSxRQUFRLE1BQU0sQ0FBQyxHQUUvQyxPQUFPO0dBQ1QsTUFBTSxPQUFPLE1BQ1gsSUFDSSxLQUFLLFVBQVU7SUFDYixFQUFFO0lBQ0YsRUFBRTtJQUNGLEVBQUU7SUFDRixFQUFFO0lBQ0YsRUFBRTtJQUNGLEVBQUU7SUFDRixFQUFFO0lBQ0YsRUFBRSxRQUFRO0lBQ1YsRUFBRSxVQUFVLEtBQUssTUFBTSxFQUFFLEVBQUU7SUFDM0IsRUFBRTtHQUNKLENBQUMsSUFDRDtHQUNOLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU0sTUFBTSxTQUFTLFNBQVMsRUFBRSxJQUFJO0dBQ3ZFLElBQ0UsTUFBTSxTQUFTLFNBQ2YsRUFBRSxRQUNGLFFBQ0EsQ0FBQyxXQUFXLGtDQUFrQyxDQUFDLENBQUMsU0FDaEQ7SUFDQSxNQUFNLGNBQWMsTUFBTTtJQUMxQixLQUFLLE9BQU8sSUFBSTtJQUNoQixLQUFLLE9BQU8sQ0FBQztJQUNiLFVBQ0UsQ0FBQztLQUFFLEdBQUcsWUFBWSxJQUFJO0tBQUssR0FBRyxZQUFZLElBQUk7SUFBRyxHQUFHLFdBQVcsR0FDL0QsSUFBSSxJQUNKLEtBQ0EsS0FBSyxJQUNQO0dBQ0Y7R0FDQSxJQUFJO0dBQ0osY0FBYztHQUNkLE1BQU07RUFDUjtFQUNBLFlBQVk7R0FDVixJQUFJLENBQUMsTUFBTTtHQUNYLE1BQU0sS0FBSyxTQUFTLE1BQU0sQ0FBQztHQUMzQixJQUFJLENBQUMsSUFBSTtHQUNULE1BQU0sSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUM7R0FDeEIsTUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0dBQ3ZDLEtBQUssWUFBWTtHQUNqQixLQUFLLGFBQWEsZUFBZSxNQUFNO0dBQ3ZDLEtBQUssTUFBTSxPQUFPLEdBQUcsRUFBRSxFQUFFO0dBQ3pCLEtBQUssTUFBTSxNQUFNLEdBQUcsRUFBRSxFQUFFO0dBQ3hCLEdBQUcsWUFBWSxJQUFJO0dBQ25CLE9BQU8saUJBQWlCLEtBQUssT0FBTyxHQUFHLElBQUk7R0FDM0MsS0FBSztHQUNMLE1BQU07RUFDUjtFQUNBLE9BQU8sS0FBSyxLQUFLO0dBQ2YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLE9BQU8sUUFBUSxRQUFRO0dBQzVDLElBQUksV0FDRixPQUFPLElBQUksU0FBUyxRQUFRO0lBQzFCLE1BQU0sSUFBSSxVQUFXO0lBQ3JCLFVBQVcsYUFBYTtLQUN0QixFQUFFO0tBQ0YsSUFBSTtJQUNOO0dBQ0YsQ0FBQztHQUNILE1BQU0sS0FBSyxTQUFTLE1BQU0sQ0FBQyxLQUFLO0lBQUUsR0FBRyxNQUFNLEtBQU07SUFBRyxHQUFHLE1BQU0sS0FBTTtHQUFFO0dBQ3JFLE1BQU0sTUFBTSxDQUFDO0lBQUUsR0FBRyxHQUFHO0lBQUcsR0FBRyxHQUFHO0dBQUUsR0FBRyxHQUFHLE1BQU0sWUFBWSxFQUFFLEdBQUcsSUFBSSxDQUFDO0dBQ2xFLElBQUksTUFBTTtHQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLElBQUssSUFBSSxFQUFHO0dBQ3JFLE1BQU0sTUFBTSxLQUFLO0dBQ2pCLEtBQUssT0FBTyxLQUFLLElBQUksS0FBSyxNQUFNLENBQUM7R0FDakMsS0FBSyxPQUFPLENBQUM7R0FDYixLQUFLLFNBQVM7R0FDZCxLQUFLLEtBQUssSUFBSSxNQUFNO0dBQ3BCLEtBQUssU0FBUztHQUNkLFVBQVUsS0FBSyxHQUFHLEtBQUssSUFBSSxPQUFPLE1BQU0sR0FBRyxHQUFHLEtBQUssSUFBSTtHQUN2RCxLQUFLO0dBQ0wsT0FBTyxJQUFJLFNBQVMsUUFBUTtJQUMxQixZQUFZO0tBQUUsSUFBSTtLQUFHLElBQUksSUFBSTtLQUFLLE1BQU07SUFBSTtJQUM1QyxNQUFNO0dBQ1IsQ0FBQztFQUNIO0VBQ0EsU0FBUztHQUNQLElBQUk7R0FDSixjQUFjO0VBQ2hCO0VBQ0EsT0FBTyxJQUFJO0dBQ1QsSUFBSSxDQUFDLE9BQU8sT0FBTztHQUNuQixJQUFJLE9BQU8sV0FBVyxHQUFHLFdBQVcsU0FBUyxHQUFHOztJQUU5QyxNQUFNLEtBQUssT0FBTyxVQUFVLE9BQU8sTUFBTSxRQUFRLE1BQU0sTUFBTSxVQUFVLEVBQUUsU0FBUyxFQUFFO0lBQ3BGLE1BQU0sSUFBSSxPQUFPLFVBQVcsTUFBTSxRQUFRLFdBQVcsT0FBUSxLQUFLLFNBQVMsRUFBRSxJQUFJO0lBQ2pGLElBQUksQ0FBQyxHQUFHLE9BQU87SUFDZixNQUFNLElBQ0osT0FBTyxVQUNILE1BQU0sSUFBSSxDQUFDLGlCQUFpQixHQUFHLFNBQVMsQ0FBQyxJQUN6QyxNQUFNLElBQUksVUFBVSxHQUFJLEVBQUUsR0FBRyxFQUFFO0lBQ3JDLE1BQU0sSUFBSSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDLEdBQ3BDLElBQUksSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEdBQUcsRUFBRSxDQUFDO0lBQzVCLE9BQU87S0FBRSxHQUFHLEVBQUU7S0FBRyxHQUFHLEVBQUU7S0FBRyxHQUFHLEVBQUUsSUFBSSxFQUFFO0tBQUcsR0FBRyxFQUFFLElBQUksRUFBRTtJQUFFO0dBQ3REO0dBQ0EsS0FBSyxPQUFPLFdBQVcsT0FBTyxVQUFVLE9BQU8sYUFBYSxDQUFDLE1BQU0sVUFBVSxTQUFTLEVBQUUsR0FDdEYsT0FBTztHQUNULE1BQU0sT0FDSixPQUFPLFdBQVksTUFBTSxTQUFTLE1BQU0sTUFBTSxPQUFPLE1BQU0sT0FBUSxNQUFNO0dBQzNFLElBQUksQ0FBQyxNQUFNLE9BQU87R0FDbEIsTUFBTSxNQUFnQztJQUNwQyxPQUFPLENBQUMsaUJBQWlCO0lBQ3pCLE1BQU0sQ0FBQyxpQkFBaUI7SUFDeEIsTUFBTSxDQUFDLFdBQVc7SUFDbEIsT0FBTyxDQUFDLFlBQVk7SUFDcEIsT0FBTyxDQUFDLFlBQVk7SUFDcEIsT0FBTyxDQUFDLG9CQUFvQjtJQUM1QixNQUFNLENBQUMsbUJBQW1CO0lBQzFCLFFBQVEsQ0FBQyxxQkFBcUI7R0FDaEM7R0FDQSxJQUFJO0dBQ0osSUFBSSxPQUFPLFVBQVUsTUFBTSxNQUN6QixJQUFJLE1BQU0sSUFBSSxDQUFDLGNBQWMsVUFBVSxLQUFLLEtBQUssY0FBYyxHQUFHLE1BQU0sTUFBTSxDQUFDO1FBQzVFLElBQUksT0FBTyxVQUFVLElBQUksTUFBTSxJQUFJLGFBQWEsRUFBRTtRQUNsRCxJQUFLLFVBQWdDLFNBQVMsRUFBRSxHQUFHO0lBQ3RELE1BQU0sSUFBSSxNQUFNLFVBQVUsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFO0lBQ2pELElBQUksQ0FBQyxHQUFHLE9BQU87SUFDZixJQUFJLE1BQU0sSUFBSSxDQUFDLFFBQVEsR0FBRyxHQUFHLEVBQUUsUUFBUSxRQUFRLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQztHQUNoRSxPQUFPLElBQUksTUFBTSxJQUFJLElBQUksT0FBTyxDQUFDLEVBQUUsR0FBRyxLQUFLLENBQUM7R0FDNUMsTUFBTSxJQUFJLElBQUksS0FBSyxJQUFJLEVBQUUsSUFBSSxHQUFHLEtBQUssSUFBSSxFQUFFLENBQUMsR0FDMUMsSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFLElBQUksR0FBRyxLQUFLLENBQUM7R0FDbEMsT0FBTztJQUFFLEdBQUcsRUFBRTtJQUFHLEdBQUcsRUFBRTtJQUFHLEdBQUcsRUFBRSxJQUFJLEVBQUU7SUFBRyxHQUFHLEVBQUUsSUFBSSxFQUFFO0dBQUU7RUFDdEQ7RUFDQSxTQUFTLElBQUk7R0FDWCxVQUFVLEtBQUssRUFBRTtFQUNuQjtFQUNBLFNBQVMsSUFBSTtHQUNYLFlBQVksS0FBSyxFQUFFO0VBQ3JCO0VBQ0E7RUFDQSxlQUFlO0dBQ2IsUUFBUSxPQUFPLGFBQWEsQ0FBQyxFQUFDLENBQUUsU0FBUyxhQUFhO0lBQ3BELE1BQU0sSUFBSSxVQUFVLFNBQVMsRUFBRTtJQUMvQixJQUFJLENBQUMsR0FBRyxPQUFPLENBQUM7SUFDaEIsTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUUsQ0FBQyxHQUN4QixJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUUsQ0FBQztJQUN0QixPQUFPLENBQ0w7S0FDRSxJQUFJLFNBQVM7S0FDYixHQUFHLEtBQUssTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLElBQUksSUFBSSxDQUFDO0tBQ25DLEdBQUcsS0FBSyxNQUFNLEVBQUUsSUFBSSxFQUFFLElBQUksSUFBSSxJQUFJLENBQUM7S0FDbkMsR0FBRyxLQUFLLE1BQU0sQ0FBQztLQUNmLEdBQUcsS0FBSyxNQUFNLENBQUM7SUFDakIsQ0FDRjtHQUNGLENBQUM7RUFDSDtFQUNBLFFBQVE7R0FDTixNQUFNLElBQUk7R0FDVixNQUFNLFNBQVMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQztHQUM1QyxPQUFPO0lBQ0wsS0FBSyxPQUFPO0lBQ1o7SUFDQSxPQUFPLElBQUksSUFBSSxTQUFTLE1BQU07SUFDOUIsUUFBUSxPQUFPLEtBQUssTUFBTSxPQUFPLFNBQVMsRUFBRyxNQUFNO0lBQ25ELFFBQVEsT0FBTyxLQUFLLE1BQU0sT0FBTyxTQUFTLEdBQUksTUFBTTtJQUNwRCxTQUFTLEVBQUU7SUFDWCxNQUFNLE1BQU0sQ0FBQyxTQUFTLE9BQU87SUFDN0I7SUFDQSxHQUFHLEVBQUU7SUFDTCxPQUFPLEVBQUU7SUFDVCxpQkFBaUIsZ0JBQWdCO0lBQ2pDLGtCQUFrQixNQUFNLENBQUMsVUFBVSxtQkFBbUI7SUFDdEQsZUFBZSxFQUFFLE1BQ2QsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQ2IsUUFBUSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQ3ZCLEtBQUssT0FBTztLQUFFLE1BQU0sRUFBRTtLQUFRLE1BQU0sRUFBRTtLQUFNLEdBQUcsRUFBRTtLQUFHLEdBQUcsRUFBRTtJQUFFLEVBQUU7SUFDaEUsUUFBUSxFQUFFLE9BQU87SUFDakIsTUFBTSxZQUFZLElBQUksSUFBSSxZQUFZO0lBQ3RDLFNBQVMsQ0FBQyxDQUFDO0lBQ1g7SUFDQTtJQUNBO0lBQ0E7SUFDQSxXQUFXLEdBQUcsVUFBVSxLQUFLLE1BQU0sRUFBRSxFQUFFLEtBQUssQ0FBQztJQUM3QyxVQUFVLEdBQUcsWUFBWSxDQUFDO0lBQzFCLGdCQUNFLEdBQUcsV0FBVyxLQUFLLE9BQU87S0FBRSxJQUFJLEVBQUU7S0FBSSxTQUFTLENBQUMsQ0FBQyxFQUFFO0tBQVMsT0FBTyxFQUFFO0lBQU0sRUFBRSxLQUFLLENBQUM7SUFDckYsY0FBYyxDQUFDLEdBQUcsUUFBUSxLQUFLLENBQUM7SUFDaEM7SUFDQSxXQUFXLE1BQU0sUUFBUSxNQUFNLEVBQUUsU0FBUyxNQUFNLENBQUMsQ0FBQztJQUNsRCxRQUFRLEdBQUcsUUFBUTtJQUNuQixTQUFTLEdBQUcsUUFBUSxLQUFLLE1BQU0sR0FBRyxFQUFFLEtBQUssR0FBRyxFQUFFLElBQUksS0FBSyxDQUFDO0lBQ3hELE1BQU07S0FBQyxFQUFFO0tBQUksRUFBRTtLQUFJLEVBQUU7S0FBRyxFQUFFO0lBQUM7SUFDM0IsT0FBTyxHQUFHLE9BQU87SUFDakIsU0FBUyxHQUFHLFFBQVEsS0FBSyxNQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxVQUFVLEVBQUUsU0FBUyxVQUFVLElBQUksS0FBSyxDQUFDO0lBQzFGLE9BQU8sT0FBTyxhQUNYLEdBQUcsV0FBVyxDQUFDLEVBQUMsQ0FBRSxRQUFRLE1BQU0sQ0FBQyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUNsRjtHQUNGO0VBQ0Y7RUFDQSxPQUFPLEdBQUc7R0FDUixVQUFVO0dBQ1YsSUFBSSxPQUFPLFVBQVU7RUFDdkI7RUFDQSxRQUFRLEdBQUc7R0FDVCxlQUFlO0VBQ2pCO0VBQ0E7RUFDQSxVQUFVO0dBQ1IsV0FBVztHQUNYLElBQUksS0FBSyxxQkFBcUIsR0FBRztHQUNqQyxNQUFNO0dBQ04sU0FBUyxvQkFBb0Isb0JBQW9CLEtBQUs7R0FDdEQsS0FBSyxNQUFNLE1BQU0sUUFBUSxPQUFPLG9CQUFvQixJQUFJLElBQUk7R0FDNUQsSUFBSSxXQUFXO0dBQ2YsU0FBUyxvQkFBb0Isb0JBQW9CLE1BQU07R0FDdkQsU0FBUyxvQkFBb0Isd0JBQXdCLFVBQVU7R0FDL0QsU0FBUyxPQUFPO0dBQ2hCLEtBQUssT0FBTzs7O0dBR1osSUFBSSxNQUFNLENBQUMsUUFBUTtJQUNqQixVQUFVLEdBQUcsUUFBUTtJQUNyQixXQUFXO0tBQUUsUUFBUTtLQUFVO0tBQUksTUFBTTtJQUFNO0dBQ2pELE9BQU8sSUFBSSxRQUFRO0VBQ3JCO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsUUFBUSxHQUFPLEdBQU8sR0FBZTtDQUM1QyxNQUFNLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FDakIsS0FBSyxFQUFFLElBQUksRUFBRSxHQUNiLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDdEIsTUFBTSxJQUFJLEtBQUssS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssTUFBTSxFQUFFLENBQUMsSUFBSTtDQUN0RixPQUFPLEtBQUssTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRSxJQUFJLElBQUksR0FBRztBQUM5RDs7QUFJQSxNQUFNLGFBQWE7QUFDbkIsU0FBUyxxQkFBOEI7Q0FDckMsT0FDRSxZQUFZLElBQUksT0FDaEIsQ0FBQyxVQUFVLFFBQVEsQ0FBQyxDQUFDLFNBQVMsSUFBSSxnQkFBZ0IsU0FBUyxNQUFNLENBQUMsQ0FBQyxJQUFJLFdBQVcsS0FBSyxFQUFFLEtBQ3pGLGFBQWEsTUFBTTtBQUV2QjtBQUNBLFNBQVMsc0JBQStCO0NBQ3RDLE9BQ0UsWUFBWSxJQUFJLE9BQ2hCLElBQUksZ0JBQWdCLFNBQVMsTUFBTSxDQUFDLENBQUMsSUFBSSxXQUFXLE1BQU0sWUFDMUQsYUFBYSxNQUFNO0FBRXZCOzs7O0FBS0EsTUFBTSxjQUF5QjtFQUM3QixZQUFZOzs7d0JBR1UsV0FBVzt3QkFDWCxXQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3dCQTRCWCxXQUFXOzs7Ozs7Ozs7OztBQVduQyxNQUFNLFlBQXVCO0FBQzdCLE1BQU0sWUFBdUI7RUFDM0IsWUFBWTs7Ozs7OztrQkFPSSxXQUFXO2tCQUNYLFdBQVc7Ozs7RUFJM0IsV0FBVzs7Ozs7Ozt3QkFPVyxXQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBc0JuQyxNQUFNLE9BQU87Q0FDWCxBQUFRO0NBQ1IsQUFBUTtDQUNSLEFBQVEsUUFBUSxJQUFJLE1BQU0sTUFBTTtDQUNoQyxBQUFRLFNBQVMsSUFBSSxNQUFNLG1CQUFtQixDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUc7Q0FDbEUsQUFBUTtDQUNSLEFBQVE7Q0FDUixBQUFRO0NBQ1IsQUFBUTtDQUNSLEFBQVE7Q0FDUixBQUFRLFlBQVksSUFBSSxNQUFNLE1BQU07Q0FDcEMsQUFBUSxVQUFVLElBQUksTUFBTSxtQkFBbUIsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO0NBQ2pFLEFBQVE7Q0FDUixBQUFRLFlBQVk7Q0FDcEIsQUFBUSxTQUFTLENBQUM7Q0FDbEIsQUFBUSxLQUFLLE1BQU0sS0FBSyxFQUFFLFFBQVEsV0FBVyxTQUFTLElBQUksTUFBTSxRQUFRLENBQUM7Q0FDekUsQUFBUSxLQUFLLE1BQU0sS0FBSyxFQUFFLFFBQVEsV0FBVyxTQUFTLElBQUksTUFBTSxRQUFRLENBQUM7Q0FDekUsQUFBUSxlQUFlLENBQUMsSUFBSSxNQUFNLFFBQVEsR0FBRyxJQUFJLE1BQU0sUUFBUSxDQUFDO0NBQ2hFLEFBQVE7Q0FDUixBQUFRO0NBQ1IsWUFBWSxRQUEyQixPQUFrQjtFQUN2RCxLQUFLLFNBQVM7RUFDZCxLQUFLLFFBQVE7RUFDYixLQUFLLFdBQVcsSUFBSSxNQUFNLGNBQWM7R0FDdEM7R0FDQSxXQUFXO0dBQ1gsT0FBTztHQUNQLFNBQVM7R0FDVCxPQUFPO0dBQ1AsaUJBQWlCO0dBQ2pCLG9CQUFvQjtFQUN0QixDQUFDO0VBQ0QsS0FBSyxTQUFTLGNBQWMsQ0FBQztFQUM3QixLQUFLLEtBQUssSUFBSSxNQUFNLGtCQUFrQixHQUFHLEdBQUc7R0FDMUMsV0FBVyxNQUFNO0dBQ2pCLFdBQVcsTUFBTTtHQUNqQixpQkFBaUI7R0FDakIsYUFBYTtHQUNiLGVBQWU7R0FDZixZQUFZLE1BQU07RUFDcEIsQ0FBQztFQUNELEtBQUssTUFBTSxJQUFJLE1BQU0sY0FBYyxNQUFNLE1BQU07RUFDL0MsT0FBTyxPQUFPLEtBQUssS0FBSztHQUN0QixXQUFXLE1BQU07R0FDakIsV0FBVyxNQUFNO0dBQ2pCLGlCQUFpQjtHQUNqQixZQUFZLE1BQU07R0FDbEIsT0FBTztHQUNQLGtCQUFrQjtFQUNwQixDQUFDO0VBQ0QsS0FBSyxhQUFhLElBQUksTUFBTSxjQUFjLFNBQVMsY0FBYyxRQUFRLENBQUM7RUFDMUUsT0FBTyxPQUFPLEtBQUssWUFBWTtHQUM3QixXQUFXLE1BQU07R0FDakIsV0FBVyxNQUFNO0dBQ2pCLGlCQUFpQjtHQUNqQixZQUFZLE1BQU07R0FDbEIsT0FBTztFQUNULENBQUM7RUFDRCxLQUFLLFVBQVUsSUFBSSxVQUFVLEtBQUssWUFBWSxHQUFHLEdBQUcsQ0FBQztFQUNyRCxLQUFLLE9BQU8sSUFBSSxVQUFVLEtBQUssS0FBSyxNQUFNLEdBQUcsQ0FBQztFQUM5QyxLQUFLLFVBQVUsSUFBSSxVQUFVLEtBQUssS0FBSyxLQUFLLEdBQUcsQ0FBQztFQUNoRCxNQUFNLFlBQVksS0FBSyxLQUFLLEtBQUs7RUFDakMsVUFBVSxlQUFlLFVBQVUsYUFDaEMsUUFBUSxxQkFBcUIsNkRBQTZELENBQUMsQ0FDM0YsUUFBUSxvQkFBb0IsMENBQTBDLENBQUMsQ0FDdkUsUUFBUSxpQkFBaUIseUNBQXlDO0VBQ3JFLFVBQVUsaUJBQWlCLFVBQVUsZUFDbEMsUUFBUSxpQkFBaUIsR0FBRyxZQUFZLGdCQUFnQixDQUFDLENBQ3pELFFBQ0MsZ0VBQ0Esd0JBQ0Y7RUFDRixPQUFPLE9BQU8sVUFBVSxVQUFVO0dBQ2hDLFdBQVcsRUFBRSxPQUFPLEVBQUU7R0FDdEIsY0FBYyxFQUFFLE9BQU8sS0FBSyxhQUFhO0dBQ3pDLFdBQVcsRUFBRSxPQUFPLEVBQUU7R0FDdEIsY0FBYyxFQUFFLE9BQU8sRUFBRTtHQUN6QixVQUFVLEVBQUUsT0FBTyxLQUFLLEdBQUc7R0FDM0IsVUFBVSxFQUFFLE9BQU8sS0FBSyxHQUFHO0dBQzNCLFVBQVUsRUFBRSxPQUFPLEVBQUU7RUFDdkIsQ0FBQzs7O0VBR0QsTUFBTSxZQUFZLEtBQUssUUFBUSxLQUFLO0VBQ3BDLFVBQVUsaUJBQWlCLFVBQVUsZUFDbEMsUUFBUSwyQkFBMkIsMEJBQTBCLENBQUMsQ0FDOUQsUUFBUSxzRUFBc0UsRUFBRSxDQUFDLENBQ2pGLFFBQ0MsbUNBQ0EsbURBQ0Y7RUFDRixVQUFVLGNBQWM7RUFDeEIsVUFBVSxhQUFhO0VBQ3ZCLEtBQUssTUFBTSxJQUFJLEtBQUssUUFBUSxNQUFNLEtBQUssS0FBSyxNQUFNLEtBQUssUUFBUSxJQUFJO0VBQ25FLEtBQUssT0FBTyxTQUFTLElBQUksR0FBRyxHQUFHLEdBQUc7RUFDbEMsS0FBSyxNQUFNLElBQUksTUFBTSxlQUFlO0dBQ2xDLGNBQWM7R0FDZCxnQkFBZ0I7R0FDaEIsV0FBVztHQUNYLFlBQVk7R0FDWixVQUFVO0lBQ1IsS0FBSyxFQUFFLE9BQU8sS0FBSyxHQUFHLFFBQVE7SUFDOUIsT0FBTyxFQUFFLE9BQU8sSUFBSSxNQUFNLFFBQVEsR0FBRyxDQUFDLEVBQUU7SUFDeEMsSUFBSSxFQUFFLE9BQU8sRUFBRTtJQUNmLE9BQU8sRUFBRSxPQUFPLEVBQUU7SUFDbEIsTUFBTSxFQUFFLE9BQU8sSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsRUFBRTtJQUMxQyxRQUFRLEVBQUUsT0FBTyxFQUFFO0lBQ25CLElBQUksRUFBRSxPQUFPLEtBQUssR0FBRztJQUNyQixJQUFJLEVBQUUsT0FBTyxLQUFLLEdBQUc7SUFDckIsSUFBSSxFQUFFLE9BQU8sRUFBRTtJQUNmLFNBQVMsRUFBRSxPQUFPLElBQUksTUFBTSxRQUFRLEVBQUU7SUFDdEMsT0FBTyxFQUFFLE9BQU8sRUFBRTtJQUNsQixXQUFXLEVBQUUsT0FBTyxFQUFFO0lBQ3RCLGNBQWMsRUFBRSxPQUFPLEtBQUssYUFBYTtHQUMzQztFQUNGLENBQUM7RUFDRCxLQUFLLFVBQVUsSUFBSSxJQUFJLE1BQU0sS0FBSyxJQUFJLE1BQU0sY0FBYyxHQUFHLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQztDQUM1RTtDQUNBLFdBQWlCO0VBQ2YsS0FBSyxZQUFZO0VBQ2pCLEtBQUssU0FBUyxDQUFDO0VBQ2YsS0FBSyxJQUFJLGNBQWM7RUFDdkIsS0FBSyxXQUFXLGNBQWM7Q0FDaEM7O0NBRUEsU0FBa0I7RUFDaEIsT0FBTyxLQUFLLFNBQVMsV0FBVyxDQUFDLENBQUMsY0FBYztDQUNsRDtDQUNBLGdCQUFnQixHQUF1QjtFQUNyQyxNQUFNLFdBQXlCLENBQUM7RUFDaEMsS0FBSyxNQUFNLFdBQVcsQ0FBQyxPQUFPLElBQUksR0FBRztHQUNuQyxLQUFLLE9BQU8sR0FBRyxTQUFTLENBQUM7R0FDekIsTUFBTSxTQUFTLElBQUksV0FBVyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUM7R0FDM0MsS0FBSyxTQUFTLHVCQUF1QixLQUFLLElBQUksR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsTUFBTTtHQUNwRSxTQUFTLEtBQUssTUFBTTtFQUN0QjtFQUNBLElBQUksVUFBVSxHQUNaLFdBQVcsR0FDWCxlQUFlLEdBQ2YsTUFBTSxHQUNOLE1BQU07RUFDUixNQUFNLE9BQU8sRUFBRSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsTUFBTSxFQUFFLE1BQU07RUFDekQsTUFBTSxnQkFBd0MsQ0FBQztFQUMvQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxHQUFHLEtBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLEdBQUcsS0FBSztHQUM1QixNQUFNLEtBQUssSUFBSSxFQUFFLElBQUksS0FBSztHQUMxQixNQUFNLFFBQVEsS0FBSyxJQUNqQixHQUFHO0lBQUM7SUFBRztJQUFHO0dBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxLQUFLLElBQUksU0FBUyxFQUFFLENBQUUsSUFBSSxLQUFNLFNBQVMsRUFBRSxDQUFFLElBQUksRUFBRyxDQUFDLENBQy9FO0dBQ0EsSUFBSSxTQUFTLEVBQUUsQ0FBRSxJQUFJLE9BQU8sU0FBUyxFQUFFLENBQUUsSUFBSSxJQUFJO0dBQ2pELElBQUksQ0FBQyxPQUFPO0dBQ1o7R0FDQSxPQUFPO0dBQ1AsTUFBTSxLQUFLLElBQUksS0FBSyxLQUFLO0dBQ3pCLE1BQU0sS0FBSyxFQUFFLEtBQUssSUFBSSxJQUNwQixLQUFLLEVBQUUsS0FBSyxFQUFFLElBQUksSUFBSTtHQUN4QixLQUFLLE1BQU0sS0FBSyxNQUFNO0lBQ3BCLElBQUksTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEtBQUssTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEtBQUssTUFBTSxFQUFFLEtBQUssTUFBTSxFQUFFLElBQUksRUFBRSxHQUMzRSxjQUFjLEVBQUUsV0FBWSxjQUFjLEVBQUUsV0FBWSxLQUFLO0dBQ2pFO0dBQ0EsSUFDRSxDQUFDLEtBQUssTUFDSCxNQUFNLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxLQUFLLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxLQUFLLE1BQU0sRUFBRSxLQUFLLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FDbEYsR0FFQTtFQUNKO0VBQ0YsTUFBTSxTQUFTLFNBQVMsS0FBSyxXQUFXO0dBQ3RDLE1BQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtHQUM5QyxPQUFPLFFBQVEsRUFBRTtHQUNqQixPQUFPLFNBQVMsRUFBRTtHQUNsQixNQUFNLE1BQU0sT0FBTyxXQUFXLElBQUksR0FDaEMsUUFBUSxJQUFJLGdCQUFnQixFQUFFLEdBQUcsRUFBRSxDQUFDO0dBQ3RDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLEdBQUcsS0FDdkIsTUFBTSxLQUFLLElBQUksT0FBTyxTQUFTLElBQUksRUFBRSxJQUFJLElBQUksSUFBSSxLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLElBQUksS0FBSyxFQUFFLElBQUksQ0FBQztHQUN6RixJQUFJLGFBQWEsT0FBTyxHQUFHLENBQUM7R0FDNUIsT0FBTyxPQUFPLFVBQVU7RUFDMUIsQ0FBQztFQUNELEtBQUssT0FBTyxDQUFDO0VBQ2IsTUFBTSxXQUFXLEtBQUssS0FBSyxLQUFLO0VBQ2hDLE9BQU87R0FDTCxPQUFPLEVBQUU7R0FDVCxRQUFRLEVBQUU7R0FDVixPQUFPLEVBQUU7R0FDVDtHQUNBO0dBQ0E7R0FDQSxVQUFVO0dBQ1Ysa0JBQWtCLFVBQVUsTUFBTSxVQUFVO0dBQzVDO0dBQ0EsYUFBYSxLQUFLLEtBQUssT0FBTztJQUFFLE1BQU0sRUFBRTtJQUFRLEdBQUcsRUFBRTtJQUFHLEdBQUcsRUFBRTtJQUFHLE1BQU0sRUFBRTtHQUFLLEVBQUU7R0FDL0UsZUFDRSxTQUFTLGVBQWUsU0FBUyx3QkFBd0IsS0FDekQsU0FBUyxhQUFhLFNBQVMsd0JBQXdCO0dBQ3pEO0VBQ0Y7Q0FDRjtDQUNBLE9BQU8sR0FBYyxnQkFBMEIsY0FBNkI7RUFDMUUsTUFBTSxJQUFJLEtBQUs7RUFDZixJQUFJLEtBQUssT0FBTyxVQUFVLEVBQUUsS0FBSyxLQUFLLE9BQU8sV0FBVyxFQUFFLEdBQUcsRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFFLEdBQUcsS0FBSztFQUN0RixJQUFJLEtBQUssR0FBRyxVQUFVLEVBQUUsS0FBSyxLQUFLLEdBQUcsV0FBVyxFQUFFLEdBQUcsS0FBSyxHQUFHLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQztFQUM3RSxJQUFJLEtBQUssTUFBTSxZQUFZLEtBQUssUUFBUTtHQUN0QyxLQUFLLFNBQVMsS0FBSyxNQUFNO0dBQ3pCLEtBQUssSUFBSSxjQUFjO0VBQ3pCO0VBQ0EsSUFBSSxFQUFFLGNBQWMsS0FBSyxXQUFXO0dBQ2xDLEtBQUssWUFBWSxFQUFFO0dBQ25CLE1BQU0sSUFBSSxLQUFLO0dBQ2YsRUFBRSxNQUFNO0dBQ1IsSUFBSSxFQUFFLFNBQVM7SUFDYixLQUFLLFdBQVcsUUFBUSxFQUFFO0lBQzFCLEtBQUssV0FBVyxjQUFjO0lBQzlCLEVBQUUsS0FBTSxRQUFRLE9BQVEsR0FBRyxDQUFDLFFBQVEsTUFBTSxHQUFHLFFBQVEsTUFBTSxRQUFRLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUNyRjtHQUNBLEVBQUUsSUFBSTtFQUNSO0VBQ0EsTUFBTSxJQUFJLEtBQUssTUFDYixJQUFJLEtBQUs7RUFDWCxFQUFFLE1BQU07RUFDUixFQUFFLE1BQU07RUFDUixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxHQUFHLEtBQUs7R0FDNUIsTUFBTSxJQUFJLEVBQUUsTUFBTTs7R0FFbEIsTUFBTSxRQUFRLEVBQUUsTUFBTSxPQUFRLEVBQUUsTUFBTSxNQUFPLElBQUk7R0FDakQsTUFBTSxLQUNKLEVBQUUsR0FDRixDQUFDLEVBQUUsR0FDSCxFQUFFLEdBQ0YsRUFBRSxHQUNGLEVBQUUsR0FDRixFQUFFLEVBQUUsSUFDSixFQUFFLEVBQUUsSUFDSixFQUFFLEVBQUUsSUFDSixFQUFFLEVBQUUsSUFDSixFQUFFLEtBQ0YsRUFBRSxVQUFVLEdBQ1osRUFBRSxNQUNGLEVBQUUsT0FBTyxJQUFJLENBQ2Y7RUFDRjtFQUNBLEVBQUUsSUFBSTtFQUNOLEVBQUUsSUFBSTtFQUNOLE1BQU0sSUFBSSxLQUFLO0VBQ2YsRUFBRSxPQUFPLEVBQUU7RUFDWCxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUU7RUFDbkIsRUFBRSxNQUFNLENBQUMsRUFBRTtFQUNYLEVBQUUsU0FBUyxFQUFFLEVBQUUsS0FBSyxFQUFFO0VBQ3RCLEVBQUUsdUJBQXVCO0VBQ3pCLE1BQU0sU0FBVSxLQUFLLEtBQUssS0FBSyxTQUFrQztFQUNqRSxPQUFPLFVBQVcsUUFBUyxrQkFBa0IsbUJBQW1CLElBQUssSUFBSTtFQUN6RSxNQUFNLFNBQVMsb0JBQW9CLE1BQU0sa0JBQWtCO0VBQzNELE9BQU8sVUFBVyxRQUFRLFNBQVMsSUFBSTtFQUN2QyxLQUFLLE1BQU0sS0FBSyxLQUFLLGNBQWMsRUFBRSxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDbkQsSUFBSSxRQUFRO0VBQ1osSUFBSSxRQUNGLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLEtBQUssUUFBUSxHQUFHLEtBQUs7R0FDekMsTUFBTSxJQUFJLEVBQUUsTUFBTTtHQUNsQixJQUFJLEVBQUUsV0FBVyxLQUFLLEVBQUUsV0FBVyxHQUNqQyxLQUFLLGFBQWEsUUFBUSxDQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxHQUFHLEVBQUUsSUFBSSxLQUFNLEtBQUssSUFBSSxHQUFHLEVBQUUsSUFBSSxHQUFJLENBQUM7RUFDckY7RUFDRixPQUFPLGFBQWMsUUFBUSxFQUFFO0VBQy9CLE9BQU8sU0FBVSxRQUFRLEtBQUssSUFBSSxZQUFZLEVBQUUsT0FBTyxNQUFNO0VBQzdELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFNBQVUsT0FBTyxLQUFLO0dBQy9DLE1BQU0sUUFBUSxFQUFFLE9BQU87R0FDdkIsS0FBSyxHQUFHLEVBQUUsQ0FBRSxJQUFJLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLENBQUM7R0FDNUMsS0FBSyxHQUFHLEVBQUUsQ0FBRSxJQUFJLEdBQUcsTUFBTSxDQUFDO0VBQzVCO0VBQ0EsRUFBRSxnQkFBZ0IsS0FBSyxFQUFFO0VBQ3pCLEVBQUUsY0FBYyxTQUFVLENBQUM7RUFDM0IsRUFBRSxNQUFNO0VBQ1IsRUFBRSxPQUFPLEtBQUssT0FBTyxDQUFDO0VBQ3RCLE1BQU0sSUFBSSxLQUFLLElBQUk7RUFDbkIsRUFBRSxVQUFXLFFBQVEsU0FBUyxJQUFJO0VBQ2xDLEFBQUMsRUFBRSxNQUFPLE1BQXdCLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztFQUM5QyxFQUFFLEdBQUksUUFBUSxFQUFFO0VBQ2hCLEVBQUUsTUFBTyxRQUFRLEVBQUU7RUFDbkIsQUFBQyxFQUFFLEtBQU0sTUFBd0IsSUFBSSxHQUFHLEVBQUUsR0FBRztFQUM3QyxFQUFFLE9BQVEsUUFBUSxFQUFFO0VBQ3BCLE1BQU0sSUFBSSxLQUFLLElBQUksWUFBWSxFQUFFLE9BQU8sTUFBTTtFQUM5QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0dBQzFCLE1BQU0sSUFBSSxFQUFFLE9BQU87R0FDbkIsS0FBSyxHQUFHLEVBQUUsQ0FBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQztHQUM5QyxLQUFLLEdBQUcsRUFBRSxDQUFFLElBQUksR0FBRyxFQUFFLENBQUM7RUFDeEI7RUFDQSxFQUFFLEdBQUksUUFBUTtFQUNkLEFBQUMsRUFBRSxRQUFTLE1BQXdCLElBQUksRUFBRSxJQUFJLEVBQUUsRUFBRTtFQUNsRCxFQUFFLE1BQU8sUUFBUSxnQkFBZ0IsWUFBWSxJQUFJLElBQUk7RUFDckQsRUFBRSxnQkFBZ0IsSUFBSTtFQUN0QixFQUFFLE9BQU8sS0FBSyxXQUFXLEtBQUssT0FBTztDQUN2Qzs7O0NBR0EsVUFBZ0I7RUFDZCxLQUFLLFFBQVEsUUFBUTtFQUNyQixLQUFLLEtBQUssUUFBUTtFQUNsQixLQUFLLFFBQVEsUUFBUTtFQUNyQixLQUFLLElBQUksUUFBUTtFQUNqQixLQUFLLEdBQUcsUUFBUTtFQUNoQixLQUFLLElBQUksUUFBUTtFQUNqQixLQUFLLFdBQVcsUUFBUTtFQUN4QixLQUFLLFNBQVMsUUFBUTtFQUN0QixLQUFLLFNBQVMsaUJBQWlCO0NBQ2pDO0FBQ0YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidG93bi50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDdXQgMzAgwqczIOKAlCB0aGUgdG93biBodWIgKGRvY3MvVE9XTi5tZCwgdGFyZ2V0cyBhcnQvdWkvdGFyZ2V0cy90b3duLyk6IHRoZSBjYW1wIGFzIGEgcGxhY2UuIEEgZml4ZWQgdGlsZSBtYXAgd2l0aCBuYW1lZCBwbG90cyBhbmRcbi8vIGEgcGF0aCBncmFwaDsgYHRvd25TdGF0ZShsaW5lYWdlLCBhYnNlbmNlKWAgdHVybnMgdGhlIGNvcmUncyBgTGluZWFnZS50b3duYCBpbnRvIHdoYXQgc3RhbmRzIGFuZCB3aGF0IHdhbGtzIChidWlsZGluZ3Mgd2l0aCB0aGVpclxuLy8gbG9vaywgdGhlIG5leHQgcGxvdCBzdGFrZWQsIHRoZSBoZXJvJ3MgbG9vcCwgdGhlIGFic2VuY2UncyBwYXJ0aWVzIHdhbGtpbmcgb3V0IG9mIHRoZSBtb3V0aCwgcGV0cywgbWFya2Vycyk7IHRoZSB2aWV3IGRyYXdzIGl0IGluXG4vLyB0aGUgcGl4ZWwgcGlwZWxpbmUncyByZWdpc3RlciDigJQgb25lIGxvdy1yZXMgdGFyZ2V0IG9mIHRvd24gdGV4ZWxzIChhIGNhY2hlZCB0ZXJyYWluIGJpdG1hcCBhbmQgaW5zdGFuY2VkIHNwcml0ZSBxdWFkcywgYGxheWVycy50c2ApLCB1cHNjYWxlZCBrw5cgd2l0aCBuZWFyZXN0XG4vLyBzYW1wbGluZywgbGl0IGJ5IGEgc21hbGwgbGlnaHQgcGFzcyAodGhlIGZpcmUsIHRoZSBtb3V0aCdzIHRvcmNoZXMsIHRoZSBmb3JnZSwgd2luZG93cyBhdCBuaWdodDsgZGF5IGFuZCBuaWdodCBmcm9tIHRoZSBsb2NhbFxuLy8gY2xvY2spLiBUaGUgQ2FudmFzLTJEIGZhbGxiYWNrIChgdmlldzJkLnRzYCBgZHJhd1Rvd24yRGApIGRyYXdzIHRoZSBzYW1lIGZyYW1lIHdoaWxlIHRoZSBHTCBjb250ZXh0IGlzIGxvc3Qgb3Igd2hlbiBub25lIGV4aXN0cy5cbi8vXG4vLyBDb29yZGluYXRlczogdGV4ZWxzLCB4IHJpZ2h0LCB5IERPV04gdGhlIG1hcCAoYSB0aWxlIGlzIDE2IHRleGVscyk7IHRocmVlJ3Mgd29ybGQgaXMgKHgsIOKIknkpLiBFdmVyeSBzcHJpdGUgaXMgYW5jaG9yZWQgYXQgaXRzIGZvb3Rcbi8vIChib3R0b20gY2VudHJlKSBhbmQgZGVwdGgtc29ydGVkIGJ5IGZvb3QgeS4gV2Fsa2VycyBhcmUgY29zbWV0aWM6IHNlZWRlZCBieSB0aGUgbGluZWFnZSdzIHNlZWQgKyB0aGUgbG9jYWwgZGF5LCBuZXZlciByZWFkIGJhY2suXG4vLyBBcnQgbmV2ZXIgYmxvY2tzIHRoZSBzY2VuZTogZXZlcnkgc3ByaXRlIGlkIGhhcyBhIHByaW1pdGl2ZSBmYWxsYmFjayAoYSBjb2xvdXJlZCBibG9jayBpbiB0aGUgdGhpbmcncyBzaGFwZSkgdW50aWwgdGhlIGF0bGFzIGhhcyBpdC5cbmltcG9ydCAqIGFzIFRIUkVFIGZyb20gXCJ0aHJlZVwiO1xuaW1wb3J0IHsgUXVhZExheWVyLCBCQVlFUl9HTFNMIH0gZnJvbSBcIi4vbGF5ZXJzXCI7XG5pbXBvcnQgeyBkcmF3VG93bjJEIH0gZnJvbSBcIi4vdmlldzJkXCI7XG5pbXBvcnQgdHlwZSB7IExpbmVhZ2UsIFJldHVyblJlcG9ydCB9IGZyb20gXCIuLi9lbmdpbmUvdHlwZXNcIjtcbmltcG9ydCB7IHBhaW50VG93blRlcnJhaW4sIHRlcnJhaW5NYXRlcmlhbFZlcnNpb24sIHRvd25HcmFzc1Jvb3RzIH0gZnJvbSBcIi4vdG93bi10ZXJyYWluXCI7XG5pbXBvcnQgeyBlZmZlY3RzTGV2ZWwgfSBmcm9tIFwiLi9meHByZWZcIjtcbmltcG9ydCB7IHBhaW50SG9tZVNlcnZpY2UgfSBmcm9tIFwiLi9ob21lLXNlcnZpY2UtYXJ0XCI7XG5pbXBvcnQgeyB2b2x1bWVLaW5kLCBWT0xVTUVfR0xTTCB9IGZyb20gXCIuL3Rvd24tdm9sdW1lXCI7XG5pbXBvcnQgTElHSFRTIGZyb20gXCIuL3Rvd25fbGlnaHRzLmpzb25cIjsgLy8gYSBjb3B5IG9mIGFydC90b3duX2xpZ2h0cy5qc29uIChgcHl0aG9uMyBhcnQvdG93bl9saWdodHMucHlgKTogZWFjaCBzcHJpdGUncyBwYWludGVkIHdhcm0gZW1pdHRlcnNcblxuZXhwb3J0IGNvbnN0IFRJTEUgPSAxNjtcbmV4cG9ydCBjb25zdCBNQVBfVyA9IDU2LFxuICBNQVBfSCA9IDQwO1xuY29uc3QgQ1ggPSAyOCxcbiAgT1kgPSA1OyAvLyB0aGUgbGF5b3V0J3MgY2VudHJlIGNvbHVtbjsgaXRzIHJvd3Mgc3RhcnQgT1kgdGlsZXMgZG93biAodGhlIGNsaWZmIGFib3ZlIHRoZSBtb3V0aClcbmNvbnN0IFQgPSAoeDogbnVtYmVyLCB5OiBudW1iZXIpOiBQdCA9PiAoeyB4OiB4ICogVElMRSwgeTogKHkgKyBPWSkgKiBUSUxFIH0pO1xuZXhwb3J0IHR5cGUgUHQgPSB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH07XG5cbi8vIC0tLS0gdGhlIG1hcDogcGxvdHMsIHBhdGhzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGNvbnN0IEJVSUxESU5HUyA9IFtcImJsYWNrc21pdGhcIiwgXCJrZW5uZWxcIiwgXCJiYW5rXCJdIGFzIGNvbnN0O1xuZXhwb3J0IHR5cGUgQnVpbGRpbmdJZCA9ICh0eXBlb2YgQlVJTERJTkdTKVtudW1iZXJdO1xuZXhwb3J0IHR5cGUgU2VydmljZUlkID0gXCJndWlsZFwiIHwgXCJwb29sXCIgfCBcImRldmljZVwiO1xuZXhwb3J0IGNvbnN0IFNFUlZJQ0VfUExPVFMgPSB7XG4gIGd1aWxkOiB7IHg6IDM4NiwgeTogNDAyLCBoOiA0MiB9LFxuICBwb29sOiB7IHg6IDM1NiwgeTogMzM4LCBoOiAyMiB9LFxuICBkZXZpY2U6IHsgeDogNTY4LCB5OiAzMTgsIGg6IDM2IH0sXG59IGFzIGNvbnN0O1xuZXhwb3J0IHR5cGUgUGxvdElkID1cbiAgfCBTZXJ2aWNlSWRcbiAgfCBcIm1vdXRoXCJcbiAgfCBcImZpcmVcIlxuICB8IFwidGVudFwiXG4gIHwgXCJob3VzZVwiXG4gIHwgXCJjcmF0ZVwiXG4gIHwgXCJib2FyZFwiXG4gIHwgQnVpbGRpbmdJZDtcbi8qKiBlYWNoIHBsb3QncyBmb290ICh0ZXhlbHMpIGFuZCBpdHMgZHJhd24gaGVpZ2h0ICovXG5leHBvcnQgY29uc3QgUExPVFM6IFJlY29yZDxQbG90SWQsIFB0ICYgeyBoOiBudW1iZXIgfT4gPSB7XG4gIC4uLlNFUlZJQ0VfUExPVFMsXG4gIG1vdXRoOiB7IC4uLlQoQ1gsIDYuNiksIGg6IDY0IH0sXG4gIGZpcmU6IHsgLi4uVChDWCwgMTQuNyksIGg6IDE2IH0sXG4gIHRlbnQ6IHsgLi4uVChDWCArIDMuMywgMTQuMCksIGg6IDMyIH0sXG4gIGhvdXNlOiB7IC4uLlQoQ1ggKyAzLjMsIDE0LjApLCBoOiA1NiB9LFxuICBjcmF0ZTogeyAuLi5UKENYICsgNS4wLCAxNC45KSwgaDogMTYgfSxcbiAgYm9hcmQ6IHsgLi4uVChDWCAtIDIuMiwgNy42KSwgaDogMjggfSwgLy8gQ3V0IDMwIMKnNTogdGhlIG5vdGljZSBib2FyZCBieSB0aGUgbW91dGggKHRoZSBxdWVzdCksIGZyb20gdGhlIFdhcmxvcmQgc2xhaW5cbiAgYmxhY2tzbWl0aDogeyAuLi5UKENYIC0gNC42LCAxMC43KSwgaDogNjQgfSxcbiAgYmFuazogeyAuLi5UKENYICsgNC42LCAxMC43KSwgaDogNjQgfSxcbiAga2VubmVsOiB7IC4uLlQoQ1ggKyA0LjcsIDE5LjgpLCBoOiA2NCB9LFxufTtcbmNvbnN0IE5PREVTOiBSZWNvcmQ8c3RyaW5nLCBQdD4gPSB7XG4gIGluOiBUKENYLCA2LjMpLFxuICBtb3V0aDogVChDWCwgNy41KSxcbiAgY3Jvc3M6IFQoQ1gsIDExLjYpLFxuICBzbWl0aDogVChDWCAtIDQuNCwgMTEuMCksXG4gIGJhbms6IFQoQ1ggKyA0LjQsIDExLjApLFxuICBmaXJlTjogVChDWCwgMTMuMSksXG4gIGZpcmVXOiBUKENYIC0gMS41LCAxNC45NSksXG4gIGZpcmVFOiBUKENYICsgMS41LCAxNC45NSksXG4gIHRlbnQ6IFQoQ1ggKyAyLjQ1LCAxNC40NSksXG4gIGNyYXRlOiBUKENYICsgNC4zLCAxNS41NSksXG4gIGZpcmVTOiBUKENYLCAxNi43KSxcbiAgc291dGg6IFQoQ1gsIDE4LjYpLFxuICBrZW5uZWw6IFQoQ1ggKyA0LjMsIDIwLjEpLFxuICBleGl0OiBUKENYLCAyNSksXG4gIGd1aWxkOiB7IHg6IDM4NiwgeTogNDEwIH0sXG4gIHBvb2w6IHsgeDogMzU2LCB5OiAzNTMgfSxcbiAgZGV2aWNlOiB7IHg6IDU2OCwgeTogMzMwIH0sXG59O1xuY29uc3QgRURHRVM6IFtzdHJpbmcsIHN0cmluZywgbnVtYmVyXVtdID0gW1xuICAvLyBbYSwgYiwgaGFsZi13aWR0aCBvZiB0aGUgZGlydCBpbiB0aWxlc11cbiAgW1wiaW5cIiwgXCJtb3V0aFwiLCAwLjldLFxuICBbXCJtb3V0aFwiLCBcImNyb3NzXCIsIDAuOF0sXG4gIFtcImNyb3NzXCIsIFwic21pdGhcIiwgMC41XSxcbiAgW1wiY3Jvc3NcIiwgXCJiYW5rXCIsIDAuNV0sXG4gIFtcImNyb3NzXCIsIFwiZmlyZU5cIiwgMC44XSxcbiAgW1wiZmlyZU5cIiwgXCJmaXJlV1wiLCAwLjU1XSxcbiAgW1wiZmlyZU5cIiwgXCJmaXJlRVwiLCAwLjU1XSxcbiAgW1wiZmlyZUVcIiwgXCJ0ZW50XCIsIDAuNV0sXG4gIFtcInRlbnRcIiwgXCJjcmF0ZVwiLCAwLjQ1XSxcbiAgW1wiZmlyZVdcIiwgXCJmaXJlU1wiLCAwLjU1XSxcbiAgW1wiZmlyZUVcIiwgXCJmaXJlU1wiLCAwLjU1XSxcbiAgW1wiZmlyZVNcIiwgXCJzb3V0aFwiLCAwLjddLFxuICBbXCJzb3V0aFwiLCBcImtlbm5lbFwiLCAwLjVdLFxuICBbXCJzb3V0aFwiLCBcImV4aXRcIiwgMC43XSxcbiAgW1wic291dGhcIiwgXCJndWlsZFwiLCAwLjRdLFxuICBbXCJmaXJlV1wiLCBcInBvb2xcIiwgMC40XSxcbiAgW1wiY3JhdGVcIiwgXCJkZXZpY2VcIiwgMC40XSxcbl07XG5jb25zdCBBREogPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nW10+KCk7XG5mb3IgKGNvbnN0IFthLCBiXSBvZiBFREdFUykge1xuICBBREouc2V0KGEsIFsuLi4oQURKLmdldChhKSA/PyBbXSksIGJdKTtcbiAgQURKLnNldChiLCBbLi4uKEFESi5nZXQoYikgPz8gW10pLCBhXSk7XG59XG5jb25zdCBkaXN0ID0gKGE6IFB0LCBiOiBQdCk6IG51bWJlciA9PiBNYXRoLmh5cG90KGEueCAtIGIueCwgYS55IC0gYi55KTtcbi8qKiB0aGUgc2hvcnRlc3Qgcm91dGUgYmV0d2VlbiB0d28gbm9kZXMgKERpamtzdHJhIG92ZXIgdGhlIHBhdGggZ3JhcGgpLCBhcyBwb2ludHMgKi9cbmV4cG9ydCBmdW5jdGlvbiByb3V0ZShmcm9tOiBzdHJpbmcsIHRvOiBzdHJpbmcpOiBQdFtdIHtcbiAgY29uc3QgZCA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KFtbZnJvbSwgMF1dKSxcbiAgICBwcmV2ID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKSxcbiAgICBvcGVuID0gbmV3IFNldChbZnJvbV0pO1xuICB3aGlsZSAob3Blbi5zaXplKSB7XG4gICAgbGV0IHUgPSBcIlwiO1xuICAgIGxldCBiZXN0ID0gSW5maW5pdHk7XG4gICAgZm9yIChjb25zdCBuIG9mIG9wZW4pXG4gICAgICBpZiAoKGQuZ2V0KG4pID8/IEluZmluaXR5KSA8IGJlc3QpIHtcbiAgICAgICAgYmVzdCA9IGQuZ2V0KG4pITtcbiAgICAgICAgdSA9IG47XG4gICAgICB9XG4gICAgb3Blbi5kZWxldGUodSk7XG4gICAgaWYgKHUgPT09IHRvKSBicmVhaztcbiAgICBmb3IgKGNvbnN0IHYgb2YgQURKLmdldCh1KSA/PyBbXSkge1xuICAgICAgY29uc3QgbmQgPSBiZXN0ICsgZGlzdChOT0RFU1t1XSEsIE5PREVTW3ZdISk7XG4gICAgICBpZiAobmQgPCAoZC5nZXQodikgPz8gSW5maW5pdHkpKSB7XG4gICAgICAgIGQuc2V0KHYsIG5kKTtcbiAgICAgICAgcHJldi5zZXQodiwgdSk7XG4gICAgICAgIG9wZW4uYWRkKHYpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBjb25zdCBvdXQ6IHN0cmluZ1tdID0gW3RvXTtcbiAgd2hpbGUgKG91dFswXSAhPT0gZnJvbSkge1xuICAgIGNvbnN0IHAgPSBwcmV2LmdldChvdXRbMF0hKTtcbiAgICBpZiAoIXApIHJldHVybiBbTk9ERVNbZnJvbV0hLCBOT0RFU1t0b10hXTtcbiAgICBvdXQudW5zaGlmdChwKTtcbiAgfVxuICByZXR1cm4gb3V0Lm1hcCgobikgPT4gTk9ERVNbbl0hKTtcbn1cbmNvbnN0IG5lYXJlc3ROb2RlID0gKHA6IFB0KTogc3RyaW5nID0+IHtcbiAgbGV0IGIgPSBcImZpcmVOXCIsXG4gICAgYmQgPSBJbmZpbml0eTtcbiAgZm9yIChjb25zdCBbaywgbl0gb2YgT2JqZWN0LmVudHJpZXMoTk9ERVMpKSB7XG4gICAgaWYgKGsgPT09IFwiaW5cIiB8fCBrID09PSBcImV4aXRcIikgY29udGludWU7XG4gICAgY29uc3QgZSA9IGRpc3QocCwgbik7XG4gICAgaWYgKGUgPCBiZCkge1xuICAgICAgYmQgPSBlO1xuICAgICAgYiA9IGs7XG4gICAgfVxuICB9XG4gIHJldHVybiBiO1xufTtcblxuLy8gLS0tLSB0aGUgc3RhdGU6IHdoYXQgc3RhbmRzIGFuZCB3aGF0IHdhbGtzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IHR5cGUgTWFya2VyID0ge1xuICBhdDogUGxvdElkIHwgXCJjaGVzdFwiO1xuICBraW5kOiBcImNvaW5cIiB8IFwicnVuZVwiIHwgXCJzd29yZFwiIHwgXCJjaGVzdFwiO1xuICBsYWJlbD86IHN0cmluZztcbn07XG4vKiogQ3V0IDMwLjUgKGRvY3MvQVVUT01BVElPTl9UUkVFLm1kIMKnM0MpOiB0aGUgaGF1bCBjaGVzdCBieSB0aGUgbW91dGggKGJlZm9yZSB0aGUgcG9ydGVyKSBhbmQgdGhlIHdvcmtlcnMgYXQgdGhlaXIgcG9zdHMgKi9cbmV4cG9ydCB0eXBlIENoZXN0U3RhdGUgPSB7XG4gIHN0YXRlOiBcImNsb3NlZFwiIHwgXCJmdWxsXCIgfCBcIm9wZW5cIjtcbiAgZ29sZDogbnVtYmVyO1xuICBjb3VudD86IG51bWJlcjtcbiAgbmVlZD86IG51bWJlcjtcbn07XG5leHBvcnQgdHlwZSBXb3JrZXJTcG90ID0ge1xuICBpZDogc3RyaW5nO1xuICBwb3N0OiBzdHJpbmc7XG4gIGxpdDogYm9vbGVhbjtcbiAgcHJpY2U/OiBudW1iZXI7XG4gIHBhdXNlZDogYm9vbGVhbjtcbiAgcmFuazogbnVtYmVyO1xufTtcbi8qKiB0aGUgY2hlc3QncyBmb290LCBiZXNpZGUgdGhlIHBhdGggdW5kZXIgdGhlIG1vdXRoICovXG5leHBvcnQgY29uc3QgQ0hFU1RfQVQ6IFB0ICYgeyBoOiBudW1iZXIgfSA9IHsgLi4uVChDWCArIDEuNiwgOC4zKSwgaDogMTIgfTtcbi8qKiBhIHdvcmtlcidzIHNwb3QgKHRleGVscywgaXRzIGZvb3QpOiBieSBpZCwgZWxzZSBieSBpdHMgcG9zdCdzIHBsb3Qg4oCUIGFydC90b3duLWlkcy5tZCdzIHBvc3RzICh0aGUgc2hlZXQncyB1bml0cyDDlyB+MC42IG9udG8gdGhlIG1hcCdzXG4gKiAgdGlsZXMpLCB0aGUgaGVyYWxkIGFuZCB0aGUgc2NvdXQgbW92ZWQgdG8gdGhlIG1hcCdzIG93biBib2FyZCAobGVmdCBvZiB0aGUgbW91dGgpICovXG5jb25zdCBXT1JLRVJfQVQ6IFJlY29yZDxzdHJpbmcsIFB0PiA9IHtcbiAgcXVhcnRlcm1hc3RlcjogVChDWCArIDQuOSwgMTUuNyksXG4gIHBvcnRlcjogVChDWCArIDEuMSwgMTAuMiksXG4gIHNjb3V0OiB7IHg6IFNFUlZJQ0VfUExPVFMuZ3VpbGQueCArIDEzLCB5OiBTRVJWSUNFX1BMT1RTLmd1aWxkLnkgKyA3IH0sXG4gIGFwcHJlbnRpY2U6IFQoQ1ggLSAxLjksIDExLjYpLFxuICBjbGVyazogVChDWCArIDIuOCwgMTEuNyksXG4gIGRyaWxsbWFzdGVyOiBUKENYICsgMS40LCAxNi4zKSxcbiAga2VubmVsX2hhbmQ6IFQoQ1ggKyAyLjQsIDE5LjcpLFxuICBoZXJhbGQ6IFQoQ1ggLSAzLjYsIDcuOSksXG4gIGd1aWRlOiBUKENYICsgMS42NSwgNy4zNSksXG59O1xuLyoqIEN1dCAxMDk6IHRoZSB0b3duJ3MgZHJlc3Npbmcg4oCUIHByb3BzIHRoYXQgYXJyaXZlIHdpdGggdGhlIHN0YWdlIChidWlsZGluZ3Mgc3RhbmRpbmcpLCBlYWNoIGEgZm9vdCwgYSBkcmF3biBoZWlnaHQgYW5kIHRoZSBzdGFnZSBpdFxuICogIG5lZWRzOyB0aGUgZm9yZXN0IGxlYXZlcyB0aGVpciBnbGFkZXMgY2xlYXIgZnJvbSBkYXkgMCwgc28gYSBwcm9wIGFycml2aW5nIG5ldmVyIHN0YW5kcyBpbiBhIHRyZWUgKi9cbnR5cGUgUHJvcCA9IFB0ICYgeyBpZDogc3RyaW5nOyBoOiBudW1iZXI7IHN0YWdlOiBudW1iZXI7IGxhbXA/OiBib29sZWFuOyBmbGlwPzogYm9vbGVhbiB9O1xuY29uc3QgUFJPUFM6IFByb3BbXSA9IFtcbiAgeyBpZDogXCJ0b3duX3dvb2RwaWxlXCIsIC4uLlQoQ1ggLSAyLjc1LCAxMy45NSksIGg6IDEzLCBzdGFnZTogMCB9LFxuICB7IGlkOiBcInRvd25fbGFtcHBvc3RcIiwgLi4uVChDWCArIDEuMywgMTIuMzUpLCBoOiAyNiwgc3RhZ2U6IDEsIGxhbXA6IHRydWUgfSxcbiAgeyBpZDogXCJ0b3duX3dlbGxcIiwgLi4uVChDWCAtIDIuOSwgMTcuMSksIGg6IDI2LCBzdGFnZTogMiB9LFxuICB7IGlkOiBcInRvd25fbGFtcHBvc3RcIiwgLi4uVChDWCAtIDEuMjUsIDIxLjkpLCBoOiAyNiwgc3RhZ2U6IDIsIGxhbXA6IHRydWUgfSxcbiAgeyBpZDogXCJ0b3duX3N0YWxsXCIsIC4uLlQoQ1ggKyAzLjEsIDIyLjYpLCBoOiAzNCwgc3RhZ2U6IDMgfSxcbiAgeyBpZDogXCJ0b3duX2NhcnRcIiwgLi4uVChDWCAtIDMuMywgMjIuOSksIGg6IDIwLCBzdGFnZTogMywgZmxpcDogdHJ1ZSB9LFxuICB7IGlkOiBcInRvd25fbGFtcHBvc3RcIiwgLi4uVChDWCArIDEuMjUsIDI2LjQpLCBoOiAyNiwgc3RhZ2U6IEJVSUxESU5HUy5sZW5ndGgsIGxhbXA6IHRydWUgfSxcbl07XG4vKiogQ3V0IDEwOTogdG93bnNmb2xrIGJ5IHN0YWdlIChkb2NzL1RPV04ubWQgwqczOiBcInRvd25zZm9sayBtdWx0aXBseSB3aXRoIHRoZSBob3VzZXNcIikg4oCUIGNvc21ldGljLCBzZWVkZWQsIG5ldmVyIHJlYWQgYmFjayAqL1xuY29uc3QgRk9MS19BVCA9IHsgc21pdGg6IFQoQ1ggLSA2LjAsIDExLjM1KSwgbWVyY2hhbnQ6IFQoQ1ggKyA0Ljc1LCAyMi43NSkgfTtcbmV4cG9ydCBjb25zdCB3b3JrZXJBdCA9ICh3OiB7IGlkOiBzdHJpbmc7IHBvc3Q6IHN0cmluZyB9KTogUHQgfCBudWxsID0+XG4gIFdPUktFUl9BVFt3LmlkXSA/PyAoUExPVFMgYXMgUmVjb3JkPHN0cmluZywgUHQgfCB1bmRlZmluZWQ+KVt3LnBvc3RdID8/IG51bGw7XG4vKiogYSB3b3JrZXIncyBmcmFtZXMgKGFydC90b3duLWlkcy5tZDogYHRvd25fd29ya2VyXzxpZD5gLCBgXzFgIHRoZSBpZGxlIGJlYXQpICovXG5leHBvcnQgY29uc3Qgd29ya2VySWRzID0gKGlkOiBzdHJpbmcsIGZyYW1lID0gMCk6IHN0cmluZ1tdID0+XG4gIGZyYW1lID8gW2B0b3duX3dvcmtlcl8ke2lkfV8xYCwgYHRvd25fd29ya2VyXyR7aWR9YF0gOiBbYHRvd25fd29ya2VyXyR7aWR9YF07XG5leHBvcnQgdHlwZSBQYXJ0eSA9IHtcbiAgYXQ6IG51bWJlcjtcbiAgY2xzOiBzdHJpbmc7XG4gIHNhY2s/OiBcInNtYWxsXCIgfCBcImxhcmdlXCI7XG4gIGNoZXN0PzogYm9vbGVhbjtcbiAgcGV0Pzogc3RyaW5nO1xuICB0bzogXCJ0ZW50XCI7XG59O1xuZXhwb3J0IHR5cGUgVG93blN0YXRlID0ge1xuICBob21lOiBib29sZWFuO1xuICBzZWVkOiBudW1iZXI7XG4gIGRheTogbnVtYmVyO1xuICBzdGFnZTogbnVtYmVyOyAvLyBidWlsZGluZ3Mgc3RhbmRpbmcgKDAgPSB0aGUgY2FtcClcbiAgYnVpbGRpbmdzOiB7IGlkOiBCdWlsZGluZ0lkOyBsb29rOiBudW1iZXI7IGZyZXNoOiBib29sZWFuIH1bXTtcbiAgc3Rha2VkPzogeyBpZDogQnVpbGRpbmdJZCB8IFwiaG91c2VcIjsgdHJpZ2dlcjogc3RyaW5nOyByZWFkeT86IGJvb2xlYW4gfTtcbiAgaGVybzogeyBjbHM6IHN0cmluZzsgbG9vaz86IHN0cmluZyB9O1xuICByZXNpZGVudHM/OiB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBjbHM6IHN0cmluZztcbiAgICBsb29rPzogc3RyaW5nO1xuICAgIHJlc3Rpbmc/OiBib29sZWFuO1xuICAgIHBoYXNlPzogXCJhd2F5XCIgfCBcInJlaW5jYXJuYXRpbmdcIiB8IFwicmVjb3ZlcmluZ1wiIHwgXCJyZWFkeVwiO1xuICB9W107XG4gIHNlcnZpY2VzPzogU2VydmljZUlkW107XG4gIHNlbGVjdGVkSGVybz86IG51bWJlcjtcbiAgcm9zdGVyPzogbnVtYmVyW107IC8vIGFjdHVhbCBmdWxsIHJvc3RlciwgaW5jbHVkaW5nIHJlc2lkZW50cyBjdXJyZW50bHkgZGVsdmluZ1xuICBwZXRzOiBzdHJpbmdbXTsgLy8gY29tcGFuaW9ucyBmb2xsb3dpbmcgdGhlIGhlcm9cbiAgcGVubmVkOiBzdHJpbmdbXTsgLy8gY29tcGFuaW9ucyBseWluZyBpbiB0aGUga2VubmVsJ3MgcGVuXG4gIHBhcnRpZXM6IFBhcnR5W107IC8vIHRoZSBhYnNlbmNlJ3MgcnVucyB3YWxraW5nIG91dCBvZiB0aGUgbW91dGhcbiAgbWFya2VyczogTWFya2VyW107IC8vIOKJpCAzXG4gIGJvYXJkOiBib29sZWFuOyAvLyB0aGUgcXVlc3QgYm9hcmQgc3RhbmRzIGJ5IHRoZSBtb3V0aFxuICBkZXB0aDogbnVtYmVyOyAvLyB0aGUgYmVzdCBkZXB0aCAodGhlIG1vdXRoJ3MgcGxhcXVlKVxuICBjaGVzdD86IENoZXN0U3RhdGU7IC8vIEN1dCAzMC41OiB0aGUgaGF1bCBjaGVzdCAobm9uZSBvbmNlIHRoZSBwb3J0ZXIgY2FycmllcyB0aGUgaGF1bHMpXG4gIHdvcmtlcnM6IFdvcmtlclNwb3RbXTsgLy8gQ3V0IDMwLjU6IGhpcmVkIHdvcmtlcnMgYXQgdGhlaXIgcG9zdHM7IHRoZSBsaXQgbm9kZSdzIGdyZXllZFxufTtcbmV4cG9ydCB0eXBlIEhvbWVSZXNpZGVudFNwb3QgPSB7IGlkOiBudW1iZXI7IHBvb2w6IFB0OyBkZXZpY2U6IFB0IH07XG4vKiogU3RhYmxlIGdyb3VuZHMgYWxsb2NhdGVkIHRvIGFjdHVhbCByb3N0ZXIgSURzLCB1bmFmZmVjdGVkIGJ5IHNlbGVjdGVkL2F3YXkgc3RhdGUuICovXG5leHBvcnQgZnVuY3Rpb24gaG9tZVJlc2lkZW50U3BvdHMoXG4gIHM6IFBpY2s8VG93blN0YXRlLCBcInJvc3RlclwiIHwgXCJyZXNpZGVudHNcIiB8IFwic2VsZWN0ZWRIZXJvXCI+LFxuKTogSG9tZVJlc2lkZW50U3BvdFtdIHtcbiAgY29uc3QgaWRzID0gWy4uLihzLnJvc3RlciA/PyBzLnJlc2lkZW50cz8ubWFwKChyKSA9PiByLmlkKSA/PyBbcy5zZWxlY3RlZEhlcm8gPz8gMV0pXS5zb3J0KFxuICAgIChhLCBiKSA9PiBhIC0gYixcbiAgKTtcbiAgcmV0dXJuIGlkcy5tYXAoKGlkLCBpbmRleCkgPT4gKHtcbiAgICBpZCxcbiAgICBwb29sOiBpbmRleCA9PT0gMCA/IHsgeDogMzA2LCB5OiAzNDggfSA6IHsgeDogMzA2ICsgKGluZGV4IC0gMSkgKiA3MiwgeTogNDIwIH0sXG4gICAgZGV2aWNlOiBpbmRleCA9PT0gMCA/IHsgeDogNTgwLCB5OiAzNDggfSA6IHsgeDogNTgwIC0gKGluZGV4IC0gMSkgKiA3MiwgeTogNDIwIH0sXG4gIH0pKTtcbn1cbmV4cG9ydCB0eXBlIFRvd25BY3RvclRhcmdldCA9IHsgaWQ6IG51bWJlcjsgeDogbnVtYmVyOyB5OiBudW1iZXI7IHc6IG51bWJlcjsgaDogbnVtYmVyIH07XG4vKiogT25seSBzdGF0ZSB0cmFuc2l0aW9ucyBvYnNlcnZlZCBieSB0aGlzIG1vdW50ZWQgdmlldyBwcm9kdWNlIGNvbnN0cnVjdGlvbiBGWC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb25zdHJ1Y3Rpb25DaGFuZ2VzKFxuICBwcmV2OiBUb3duU3RhdGUgfCBudWxsLFxuICBuZXh0OiBUb3duU3RhdGUsXG4pOiB7IGlkOiBCdWlsZGluZ0lkIHwgXCJob3VzZVwiOyBmcm9tTG9vaz86IG51bWJlciB9W10ge1xuICBpZiAoIXByZXYpIHJldHVybiBbXTtcbiAgY29uc3QgY2hhbmdlczogeyBpZDogQnVpbGRpbmdJZCB8IFwiaG91c2VcIjsgZnJvbUxvb2s/OiBudW1iZXIgfVtdID0gW107XG4gIGlmICghcHJldi5ob21lICYmIG5leHQuaG9tZSkgY2hhbmdlcy5wdXNoKHsgaWQ6IFwiaG91c2VcIiB9KTtcbiAgZWxzZSBpZiAocHJldi5ob21lICYmIG5leHQuaG9tZSAmJiBob3VzZUxvb2sobmV4dCkgPiBob3VzZUxvb2socHJldikpXG4gICAgY2hhbmdlcy5wdXNoKHsgaWQ6IFwiaG91c2VcIiwgZnJvbUxvb2s6IGhvdXNlTG9vayhwcmV2KSB9KTtcbiAgZm9yIChjb25zdCBidWlsZGluZyBvZiBuZXh0LmJ1aWxkaW5ncykge1xuICAgIGNvbnN0IG9sZCA9IHByZXYuYnVpbGRpbmdzLmZpbmQoKGIpID0+IGIuaWQgPT09IGJ1aWxkaW5nLmlkKTtcbiAgICBpZiAoIW9sZCkgY2hhbmdlcy5wdXNoKHsgaWQ6IGJ1aWxkaW5nLmlkIH0pO1xuICAgIGVsc2UgaWYgKGJ1aWxkaW5nLmxvb2sgPiBvbGQubG9vaykgY2hhbmdlcy5wdXNoKHsgaWQ6IGJ1aWxkaW5nLmlkLCBmcm9tTG9vazogb2xkLmxvb2sgfSk7XG4gIH1cbiAgcmV0dXJuIGNoYW5nZXM7XG59XG5jb25zdCBCVUlMRF9BU1NFTUJMWV9TID0gMS4yLFxuICBCVUlMRF9GWF9TID0gMi4yO1xuZXhwb3J0IHR5cGUgVG93bk9wdHMgPSB7XG4gIGJvYXJkPzogYm9vbGVhbjtcbiAgc2Vlbj86IHN0cmluZ1tdO1xuICBvcGVuZWQ/OiBzdHJpbmdbXTtcbiAga2l0PzogeyBuOiBudW1iZXI7IHByaWNlPzogbnVtYmVyIH07XG4gIG5vdz86IERhdGU7XG4gIGFic2VuY2VOZXc/OiBib29sZWFuO1xuICBjaGVzdE9wZW4/OiBib29sZWFuO1xufTtcblxuY29uc3QgaGFzaE4gPSAoLi4ueHM6IG51bWJlcltdKTogbnVtYmVyID0+IHtcbiAgbGV0IGggPSAyMTY2MTM2MjYxO1xuICBmb3IgKGNvbnN0IHggb2YgeHMpIHtcbiAgICBoIF49IHggfCAwO1xuICAgIGggPSBNYXRoLmltdWwoaCwgMTY3Nzc2MTkpO1xuICAgIGggXj0gaCA+Pj4gMTM7XG4gIH1cbiAgcmV0dXJuIGggPj4+IDA7XG59O1xuZXhwb3J0IGNvbnN0IGxvY2FsRGF5ID0gKG5vdyA9IG5ldyBEYXRlKCkpOiBudW1iZXIgPT5cbiAgTWF0aC5mbG9vcigobm93LmdldFRpbWUoKSAtIG5vdy5nZXRUaW1lem9uZU9mZnNldCgpICogNjAwMDApIC8gODY0MDAwMDApO1xuLyoqIExvY2FsIHdhbGwgY2xvY2ssIHNhbXBsZWQgb25jZTsgbGlnaHRpbmcgc3RheXMgY29udGludW91cyBhY3Jvc3MgbWludXRlIGJvdW5kYXJpZXMuICovXG5leHBvcnQgY29uc3QgbG9jYWxIb3VyID0gKG5vdyA9IG5ldyBEYXRlKCkpOiBudW1iZXIgPT5cbiAgbm93LmdldEhvdXJzKCkgK1xuICBub3cuZ2V0TWludXRlcygpIC8gNjAgK1xuICBub3cuZ2V0U2Vjb25kcygpIC8gMzYwMCArXG4gIG5vdy5nZXRNaWxsaXNlY29uZHMoKSAvIDM2MDAwMDA7XG5jb25zdCBQQVJUSUVTX01BWCA9IDY7XG4vKiogQ3V0IDEwOTogdGhlIGhlcm8ncyBob3VzZSBncm93cyB3aXRoIHRoZSB0b3duIChjb3R0YWdlIMK3IGxlYW4tdG8gwrcgdHdvIHN0b3JleXMgYXQyIGFuZCBhbGwgcmVtYWluaW5nIGZhY2lsaXRpZXMgc3RhbmRpbmcpIOKAlCBhIGxvb2ssIG5vIHJ1bGUgKi9cbmV4cG9ydCBjb25zdCBob3VzZUxvb2sgPSAoczogeyBzdGFnZTogbnVtYmVyIH0pOiBudW1iZXIgPT5cbiAgcy5zdGFnZSA+PSBCVUlMRElOR1MubGVuZ3RoID8gMyA6IHMuc3RhZ2UgPj0gMiA/IDIgOiAxO1xuLyoqIFRoZSBjb3JlJ3MgdG93biAoYExpbmVhZ2UudG93bmApIGFuZCB0aGUgYWJzZW5jZSdzIHJlcG9ydCDihpIgdGhlIHNjZW5lLiBQdXJlICh3YWxrZXJzIGFyZSBzZWVkZWQsIG5ldmVyIHJlYWQgYmFjaykuICovXG5leHBvcnQgZnVuY3Rpb24gdG93blN0YXRlKEw6IExpbmVhZ2UsIGFic2VuY2U/OiBSZXR1cm5SZXBvcnQgfCBudWxsLCBvOiBUb3duT3B0cyA9IHt9KTogVG93blN0YXRlIHtcbiAgY29uc3QgdG93biA9IEwudG93bjtcbiAgY29uc3QgYnVpbHQgPSAodG93bj8uYnVpbGRpbmdzID8/IFtdKS5maWx0ZXIoKGIpOiBiIGlzIHR5cGVvZiBiICYgeyBpZDogQnVpbGRpbmdJZCB9ID0+XG4gICAgKEJVSUxESU5HUyBhcyByZWFkb25seSBzdHJpbmdbXSkuaW5jbHVkZXMoYi5pZCksXG4gICk7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0KG8uc2VlbiA/PyBidWlsdC5tYXAoKGIpID0+IGIuaWQpKTtcbiAgY29uc3QgYnVpbGRpbmdzID0gYnVpbHQubWFwKChiKSA9PiAoe1xuICAgIGlkOiBiLmlkLFxuICAgIGxvb2s6IE1hdGgubWF4KDEsIE1hdGgubWluKDMsIGIubGV2ZWwgfHwgMSkpLFxuICAgIGZyZXNoOiAhc2Vlbi5oYXMoYi5pZCksXG4gIH0pKTtcbiAgY29uc3QgaGFzID0gKGlkOiBzdHJpbmcpOiBib29sZWFuID0+IGJ1aWxkaW5ncy5zb21lKChiKSA9PiBiLmlkID09PSBpZCk7XG4gIGNvbnN0IG5leHQgPVxuICAgIHRvd24/Lm5leHQgJiZcbiAgICAodG93bi5uZXh0ID09PSBcImhvdXNlXCIgfHwgKEJVSUxESU5HUyBhcyByZWFkb25seSBzdHJpbmdbXSkuaW5jbHVkZXModG93bi5uZXh0KSkgJiZcbiAgICAhaGFzKHRvd24ubmV4dClcbiAgICAgID8ge1xuICAgICAgICAgIGlkOiB0b3duLm5leHQgYXMgQnVpbGRpbmdJZCB8IFwiaG91c2VcIixcbiAgICAgICAgICB0cmlnZ2VyOiB0b3duLm5leHRfdHJpZ2dlciA/PyBcIlwiLFxuICAgICAgICAgIHJlYWR5OiB0b3duLm5leHRfcmVhZHksXG4gICAgICAgIH1cbiAgICAgIDogdW5kZWZpbmVkO1xuICBjb25zdCBkYXkgPSBsb2NhbERheShvLm5vdyk7XG4gIGNvbnN0IHNlZWQgPSBoYXNoTihMLnNlZWQgPz8gMCwgZGF5KTtcbiAgLy8gdGhlIGFic2VuY2UncyBwYXJ0aWVzOiBvbmUgcGVyIHJ1biB0aGF0IGNhbWUgaG9tZSAoYSBkZWF0aCB3YWxrcyBub2JvZHkgb3V0KSwgdGhlIGJpZ2dlc3QgZmlyc3QsIOKJpCBQQVJUSUVTX01BWFxuICBjb25zdCBwYXJ0aWVzOiBQYXJ0eVtdID0gW107XG4gIGlmIChhYnNlbmNlKSB7XG4gICAgY29uc3QgZXhpdHMgPSAoYWJzZW5jZS5leGl0cyA/PyBbXSkuZmlsdGVyKFxuICAgICAgKHgpID0+ICF4LmNhdXNlICYmICh4LmtlZXBfcGN0ID4gMCB8fCB4LmtlcHQgPiAwKSAmJiAhL15kaWVkXFxiLy50ZXN0KHgudGV4dCksXG4gICAgKTtcbiAgICBjb25zdCBob21lID0gZXhpdHMubGVuZ3RoXG4gICAgICA/IGV4aXRzLm1hcCgoeCkgPT4geC5rZXB0KVxuICAgICAgOiBBcnJheS5mcm9tKFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGxlbmd0aDogTWF0aC5taW4oXG4gICAgICAgICAgICAgIFBBUlRJRVNfTUFYLFxuICAgICAgICAgICAgICBNYXRoLm1heCgwLCAoYWJzZW5jZS5yZXR1cm5lZCA/PyAwKSArIChhYnNlbmNlLmJhbmtlZCA/PyAwKSksXG4gICAgICAgICAgICApLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgKCkgPT5cbiAgICAgICAgICAgIE1hdGgucm91bmQoXG4gICAgICAgICAgICAgIChhYnNlbmNlLmdvbGQ/LmhvbWUgPz8gMCkgL1xuICAgICAgICAgICAgICAgIE1hdGgubWF4KDEsIChhYnNlbmNlLnJldHVybmVkID8/IDApICsgKGFic2VuY2UuYmFua2VkID8/IDApKSxcbiAgICAgICAgICAgICksXG4gICAgICAgICk7XG4gICAgY29uc3Qgb3JkZXIgPSBob21lXG4gICAgICAubWFwKChnLCBpKSA9PiAoeyBnLCBpIH0pKVxuICAgICAgLnNvcnQoKGEsIGIpID0+IGIuZyAtIGEuZyB8fCBhLmkgLSBiLmkpXG4gICAgICAuc2xpY2UoMCwgUEFSVElFU19NQVgpXG4gICAgICAuc29ydCgoYSwgYikgPT4gYS5pIC0gYi5pKTtcbiAgICBjb25zdCBmaW5kcyA9IChhYnNlbmNlLmZvdW5kPy5sZW5ndGggPz8gMCkgPiAwIHx8IChhYnNlbmNlLm5ld19maW5kcz8ubGVuZ3RoID8/IDApID4gMDtcbiAgICBjb25zdCB0YW1lID0gYWJzZW5jZS50YW1lZD8uWzBdO1xuICAgIGNvbnN0IGJpZyA9IE1hdGgubWF4KDYwLCAuLi5ob21lKSAqIDAuNTtcbiAgICBvcmRlci5mb3JFYWNoKCh7IGcgfSwgaykgPT4ge1xuICAgICAgY29uc3QgY2hlc3QgPSBmaW5kcyAmJiBrID09PSBvcmRlci5sZW5ndGggLSAxLFxuICAgICAgICBwZXQgPSB0YW1lICYmIGsgPT09IDAgPyB0YW1lIDogdW5kZWZpbmVkO1xuICAgICAgcGFydGllcy5wdXNoKHtcbiAgICAgICAgYXQ6IDAsXG4gICAgICAgIGNsczogTC5jbGFzcyxcbiAgICAgICAgc2FjazogZyA8PSAwID8gdW5kZWZpbmVkIDogZyA+PSBiaWcgPyBcImxhcmdlXCIgOiBcInNtYWxsXCIsXG4gICAgICAgIGNoZXN0LFxuICAgICAgICBwZXQsXG4gICAgICAgIHRvOiBcInRlbnRcIixcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIC8vIH4yMCBzIGluIGFsbCwg4omkIDMgb24gc2NyZWVuIChhIHdhbGsgb3V0IGlzIH42IHMpXG4gICAgY29uc3Qgc3BhbiA9IDIwIC0gNixcbiAgICAgIGdhcCA9IHBhcnRpZXMubGVuZ3RoID4gMSA/IE1hdGgubWF4KDIuMiwgc3BhbiAvIChwYXJ0aWVzLmxlbmd0aCAtIDEpKSA6IDA7XG4gICAgcGFydGllcy5mb3JFYWNoKChwLCBpKSA9PiB7XG4gICAgICBwLmF0ID0gMC42ICsgaSAqIGdhcDtcbiAgICB9KTtcbiAgfVxuICAvLyBtYXJrZXJzICjiiaQgMyk6IGEgc3dvcmQgb3ZlciB0aGUgZm9yZ2Ugd2hlbiBhIGtpdCBzdGVwIGlzIGFmZm9yZGFibGUsIGEgY29pbiBvdmVyIHRoZSBiYW5rIHdoZW4gYSBuaWdodCdzIGludGVyZXN0IGNhbWUgaW4sIGEgYCFgXG4gIC8vIG92ZXIgYSBidWlsZGluZyBub3QgeWV0IG9wZW5lZCBzaW5jZSBpdCB3YXMgYnVpbHRcbiAgY29uc3QgbWFya2VyczogTWFya2VyW10gPSBbXTtcbiAgLy8gQ3V0IDMwLjU6IHRoZSBjaGVzdCBiZWZvcmUgdGhlIHBvcnRlciDigJQgY2xvc2VkIGFuZCBlbXB0eSBmcm9tIGRheSAwIChkcmF3biwgbm90IGEgc3VyZmFjZSksIGZ1bGwgd2l0aCBnb2xkIChhIGAhYCBhbmQgdGhlIHN1bSksIG9wZW5cbiAgLy8ganVzdCBhZnRlciBhIHRhcDsgdGhlIHBvcnRlcidzIGhpcmUgcmV0aXJlcyBpdFxuICBjb25zdCBXID0gTC50cmVlLFxuICAgIHBvcnRlciA9IFc/Lm5vZGVzLmZpbmQoKG4pID0+IG4uaWQgPT09IFwicG9ydGVyXCIpO1xuICBjb25zdCBjaGVzdDogQ2hlc3RTdGF0ZSB8IHVuZGVmaW5lZCA9XG4gICAgVyAmJiBwb3J0ZXIgJiYgKHBvcnRlci5zdGF0ZSAhPT0gXCJkb25lXCIgfHwgcG9ydGVyLnBhdXNlZClcbiAgICAgID8ge1xuICAgICAgICAgIHN0YXRlOiBvLmNoZXN0T3BlbiA/IFwib3BlblwiIDogVy5jaGVzdCA+IDAgPyBcImZ1bGxcIiA6IFwiY2xvc2VkXCIsXG4gICAgICAgICAgZ29sZDogVy5jaGVzdCxcbiAgICAgICAgICBjb3VudDogcG9ydGVyLmNvdW50LFxuICAgICAgICAgIG5lZWQ6IHBvcnRlci5uZWVkLFxuICAgICAgICB9XG4gICAgICA6IHVuZGVmaW5lZDtcbiAgaWYgKGNoZXN0Py5zdGF0ZSA9PT0gXCJmdWxsXCIpXG4gICAgbWFya2Vycy5wdXNoKHsgYXQ6IFwiY2hlc3RcIiwga2luZDogXCJjaGVzdFwiLCBsYWJlbDogYCQke2NoZXN0LmdvbGR9YCB9KTtcbiAgY29uc3Qgd29ya2VyczogV29ya2VyU3BvdFtdID0gKHRvd24/LndvcmtlcnMgPz8gW10pLm1hcCgodykgPT4gKHtcbiAgICBpZDogdy5pZCxcbiAgICBwb3N0OiB3LnBvc3QsXG4gICAgbGl0OiAhIXcubGl0LFxuICAgIHByaWNlOiB3LnByaWNlLFxuICAgIHBhdXNlZDogISF3LnBhdXNlZCxcbiAgICByYW5rOiB3LnJhbmsgPz8gMSxcbiAgfSkpO1xuICBpZiAoaGFzKFwiYmxhY2tzbWl0aFwiKSAmJiAoby5raXQ/Lm4gPz8gMCkgPiAwKVxuICAgIG1hcmtlcnMucHVzaCh7XG4gICAgICBhdDogXCJibGFja3NtaXRoXCIsXG4gICAgICBraW5kOiBcInN3b3JkXCIsXG4gICAgICBsYWJlbDogby5raXQ/LnByaWNlID8gLyogY29weTpjYWxsb3V0ICovIGBVcGdyYWRlICQke28ua2l0LnByaWNlfWAgOiB1bmRlZmluZWQsXG4gICAgfSk7XG4gIGlmIChoYXMoXCJiYW5rXCIpICYmICh0b3duPy5iYW5rID8/IDApID4gMCAmJiBvLmFic2VuY2VOZXcpXG4gICAgbWFya2Vycy5wdXNoKHsgYXQ6IFwiYmFua1wiLCBraW5kOiBcImNvaW5cIiB9KTtcbiAgY29uc3Qgb3BlbmVkID0gbmV3IFNldChvLm9wZW5lZCA/PyBbXSk7XG4gIGZvciAoY29uc3QgYiBvZiBidWlsZGluZ3MpXG4gICAgaWYgKG1hcmtlcnMubGVuZ3RoIDwgMyAmJiAhb3BlbmVkLmhhcyhiLmlkKSAmJiAhbWFya2Vycy5zb21lKChtKSA9PiBtLmF0ID09PSBiLmlkKSlcbiAgICAgIG1hcmtlcnMucHVzaCh7IGF0OiBiLmlkLCBraW5kOiBcInJ1bmVcIiB9KTtcbiAgcmV0dXJuIHtcbiAgICBob21lOiB0b3duPy5ob21lICE9PSBmYWxzZSxcbiAgICBzZWVkLFxuICAgIGRheSxcbiAgICBzdGFnZTogYnVpbGRpbmdzLmxlbmd0aCxcbiAgICBidWlsZGluZ3MsXG4gICAgc3Rha2VkOiBuZXh0LFxuICAgIGhlcm86IHsgY2xzOiBMLmNsYXNzIHx8IFwiZmlnaHRlclwiLCBsb29rOiBMLmxvb2sgfSxcbiAgICBzZXJ2aWNlczpcbiAgICAgIHRvd24/LmhvbWUgPT09IGZhbHNlXG4gICAgICAgID8gW11cbiAgICAgICAgOiAoW1wiZ3VpbGRcIiwgXCJwb29sXCIsIFwiZGV2aWNlXCJdIGFzIGNvbnN0KS5maWx0ZXIoKGlkKSA9PiBMLnBlcnNpc3RlbnRfaGVybz8uW2lkXS5hdmFpbGFibGUpLFxuICAgIHJlc2lkZW50czpcbiAgICAgIEwuaGVyb19zbG90c1xuICAgICAgICA/LmZpbHRlcigoaCkgPT4gKGgubGlmZV9zdGF0ZSAhPT0gdW5kZWZpbmVkID8gaC5saWZlX3N0YXRlICE9PSBcImF3YXlcIiA6IGguc3RhdGUgIT09IFwibGl2ZVwiKSlcbiAgICAgICAgLm1hcCgoaCkgPT4gKHtcbiAgICAgICAgICBpZDogaC5pZCxcbiAgICAgICAgICBjbHM6IGguY2xhc3MsXG4gICAgICAgICAgbG9vazogaC5sb29rLFxuICAgICAgICAgIHJlc3Rpbmc6IGguc3RhdGUgPT09IFwicmVzdHNcIiB8fCBoLnJlc3RfcyA+IDAgfHwgaC5saWZlX3N0YXRlID09PSBcInJlY292ZXJpbmdcIixcbiAgICAgICAgICBwaGFzZTpcbiAgICAgICAgICAgIGgubGlmZV9zdGF0ZSA/PyAoaC5pZCA9PT0gTC5zZWxlY3RlZF9ibG9vZGxpbmUgPyBMLnBlcnNpc3RlbnRfaGVybz8uc3RhdGUgOiB1bmRlZmluZWQpLFxuICAgICAgICB9KSkgPz9cbiAgICAgIChMLmxpdmUgPyBbXSA6IFt7IGlkOiBMLnNlbGVjdGVkX2Jsb29kbGluZSA/PyAxLCBjbHM6IEwuY2xhc3MgfHwgXCJmaWdodGVyXCIsIGxvb2s6IEwubG9vayB9XSksXG4gICAgc2VsZWN0ZWRIZXJvOiBMLnNlbGVjdGVkX2Jsb29kbGluZSA/PyAxLFxuICAgIHJvc3RlcjogKEwuaGVyb19zbG90cz8ubWFwKChoKSA9PiBoLmlkKSA/PyBbTC5zZWxlY3RlZF9ibG9vZGxpbmUgPz8gMV0pLnNvcnQoKGEsIGIpID0+IGEgLSBiKSxcbiAgICBwZXRzOiAoTC5wYXJ0eSA/PyBbXSkuc2xpY2UoMCwgMikubWFwKChjKSA9PiBjLmtpbmQpLFxuICAgIHBlbm5lZDogaGFzKFwia2VubmVsXCIpID8gKEwua2VubmVsID8/IFtdKS5zbGljZSgwLCAyKS5tYXAoKGMpID0+IGMua2luZCkgOiBbXSxcbiAgICBwYXJ0aWVzLFxuICAgIG1hcmtlcnM6IG1hcmtlcnMuc2xpY2UoMCwgMyksXG4gICAgZGVwdGg6IEwuYmVzdF9kZXB0aCA/PyAwLFxuICAgIGJvYXJkOiAhIW8uYm9hcmQsXG4gICAgY2hlc3Q6IHRvd24/LmhvbWUgPT09IGZhbHNlIHx8IHRvd24/LmF1dG9fY29sbGVjdCA/IHVuZGVmaW5lZCA6IGNoZXN0LFxuICAgIHdvcmtlcnM6IHRvd24/LmhvbWUgPT09IGZhbHNlID8gW10gOiB3b3JrZXJzLFxuICB9O1xufVxuXG4vLyAtLS0tIHRoZSBhdGxhczogdG93biBzcHJpdGVzIGN1dCB0byB0aGVpciBkcmF3biBzaXplLCBhIHByaW1pdGl2ZSBmb3IgYW55dGhpbmcgbm90IHBhY2tlZCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbnR5cGUgRnJhbWUgPSB7IHg6IG51bWJlcjsgeTogbnVtYmVyOyB3OiBudW1iZXI7IGg6IG51bWJlciB9O1xuZXhwb3J0IHR5cGUgU2xvdCA9IEZyYW1lICYgeyB1MDogbnVtYmVyOyB2MDogbnVtYmVyOyB1MTogbnVtYmVyOyB2MTogbnVtYmVyIH07XG5sZXQgcGFja2VkOiBQcm9taXNlPHsgaW1nOiBIVE1MSW1hZ2VFbGVtZW50OyBmcmFtZXM6IFJlY29yZDxzdHJpbmcsIEZyYW1lPiB9IHwgbnVsbD4gfCBudWxsID0gbnVsbDtcbmZ1bmN0aW9uIGxvYWRQYWNrZWQoKTogUHJvbWlzZTx7IGltZzogSFRNTEltYWdlRWxlbWVudDsgZnJhbWVzOiBSZWNvcmQ8c3RyaW5nLCBGcmFtZT4gfSB8IG51bGw+IHtcbiAgcGFja2VkID8/PSBmZXRjaChgJHtpbXBvcnQubWV0YS5lbnYuQkFTRV9VUkx9YXJ0L2F0bGFzLmpzb25gKVxuICAgIC50aGVuKChyKSA9PiByLmpzb24oKSlcbiAgICAudGhlbihcbiAgICAgIChqOiB7IGZyYW1lcz86IFJlY29yZDxzdHJpbmcsIEZyYW1lPjsgaW1hZ2U/OiBzdHJpbmcgfSkgPT5cbiAgICAgICAgbmV3IFByb21pc2UoKHJlcykgPT4ge1xuICAgICAgICAgIGNvbnN0IGltZyA9IG5ldyBJbWFnZSgpO1xuICAgICAgICAgIGltZy5vbmxvYWQgPSAoKSA9PiByZXMoeyBpbWcsIGZyYW1lczogai5mcmFtZXMgPz8ge30gfSk7XG4gICAgICAgICAgaW1nLm9uZXJyb3IgPSAoKSA9PiByZXMobnVsbCk7XG4gICAgICAgICAgaW1nLnNyYyA9IGAke2ltcG9ydC5tZXRhLmVudi5CQVNFX1VSTH1hcnQvJHtqLmltYWdlID8/IFwiYXRsYXMucG5nXCJ9YDtcbiAgICAgICAgfSksXG4gICAgKVxuICAgIC5jYXRjaCgoKSA9PiBudWxsKSBhcyBQcm9taXNlPHsgaW1nOiBIVE1MSW1hZ2VFbGVtZW50OyBmcmFtZXM6IFJlY29yZDxzdHJpbmcsIEZyYW1lPiB9IHwgbnVsbD47XG4gIHJldHVybiBwYWNrZWQ7XG59XG5jb25zdCBBVExBUyA9IDEwMjQ7XG4vKiogYSB3YWxrZXIncyBjb2F0IGh1ZSBieSBjbGFzcyAocmdiIDAuLjI1NSwgYXBwbGllZCB0byB0aGUgbWlkLXRvbmVzIGF0IGEgcGl4ZWwncyBvd24gdmFsdWUpICovXG5jb25zdCBXQUxLRVJfVElOVDogUmVjb3JkPHN0cmluZywgbnVtYmVyW10+ID0ge1xuICByb2d1ZTogWzEyMCwgNzAsIDE0MF0sXG4gIHJhbmdlcjogWzgwLCAxNDAsIDcyXSxcbiAgY2FzdGVyOiBbNzAsIDk2LCAyMDBdLFxuICBmaWdodGVyOiBbMTUwLCAxNjAsIDE3Nl0sXG59O1xuLyoqIGZhbGxiYWNrIGFzcGVjdCAodyAvIGgpIHBlciBpZCBmYW1pbHkgKi9cbmNvbnN0IEFTUEVDVDogW1JlZ0V4cCwgbnVtYmVyXVtdID0gW1xuICBbL150b3duX3NlcnZpY2VfZ3VpbGQvLCAxLjVdLFxuICBbL150b3duX3NlcnZpY2VfcG9vbC8sIDIuNjM2XSxcbiAgWy9edG93bl9zZXJ2aWNlX2RldmljZS8sIDEuMjIyXSxcbiAgWy9edG93bl9zZXJ2aWNlX3N0YXRpb24vLCAzLjMzM10sXG4gIFsvXnRvd25fbW91dGgvLCAxLjU1XSxcbiAgWy9edG93bl8oYmxhY2tzbWl0aHxiYW5rfGtlbm5lbClfLywgMS4yNV0sXG4gIFsvXnRvd25fdGVudC8sIDEuMDVdLFxuICBbL150b3duX2JvYXJkLywgMC44NV0sXG4gIFsvXnRvd25fY2FtcGZpcmUvLCAxLjFdLFxuICBbL150b3duX3Bsb3QvLCAxLjFdLFxuICBbL150b3duX3NjYWZmb2xkLywgMC45XSxcbiAgWy9eKGhlcm9ffHdhbGtffHRvd25fKHNtaXRofG1lcmNoYW50fGNhcnRlcnxjaGlsZCkpLywgMC43XSxcbiAgWy9edG93bl8oc2Fja3xjaGVzdCkvLCAwLjk1XSxcbiAgWy9edG93bl93b3JrZXJfKHBvcnRlcnxhcHByZW50aWNlfGRyaWxsbWFzdGVyfGtlbm5lbF9oYW5kKS8sIDEuMl0sXG4gIFsvXnRvd25fd29ya2VyXy8sIDAuNzVdLFxuICBbL150b3duX2hhdWxfY2hlc3QvLCAxLjVdLFxuICBbL150b3duX2ZsYWcvLCAwLjZdLFxuICBbL15lbnZfdG9yY2gvLCAwLjY2XSxcbiAgWy9edG93bl9lbnZfdHJlZS8sIDAuNV0sXG4gIFsvXnRvd25fZW52Xy8sIDFdLFxuICBbL15meF8vLCAxXSxcbl07XG5leHBvcnQgY2xhc3MgVG93bkF0bGFzIHtcbiAgcmVhZG9ubHkgY2FudmFzOiBIVE1MQ2FudmFzRWxlbWVudDtcbiAgcmVhZG9ubHkgY3R4OiBDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQ7XG4gIHZlcnNpb24gPSAwO1xuICBwcml2YXRlIHNsb3RzID0gbmV3IE1hcDxzdHJpbmcsIFNsb3Q+KCk7XG4gIHByaXZhdGUgc3ggPSAxO1xuICBwcml2YXRlIHN5ID0gMTtcbiAgcHJpdmF0ZSBzaCA9IDA7XG4gIHByaXZhdGUgc3JjOiB7IGltZzogSFRNTEltYWdlRWxlbWVudDsgZnJhbWVzOiBSZWNvcmQ8c3RyaW5nLCBGcmFtZT4gfSB8IG51bGwgPSBudWxsO1xuICByZWFkeSA9IGZhbHNlO1xuICBwcml2YXRlIGxhc3RJZCA9IFwiXCI7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKTtcbiAgICB0aGlzLmNhbnZhcy53aWR0aCA9IEFUTEFTO1xuICAgIHRoaXMuY2FudmFzLmhlaWdodCA9IEFUTEFTO1xuICAgIHRoaXMuY3R4ID0gdGhpcy5jYW52YXMuZ2V0Q29udGV4dChcIjJkXCIsIHsgd2lsbFJlYWRGcmVxdWVudGx5OiB0cnVlIH0pITtcbiAgICB2b2lkIGxvYWRQYWNrZWQoKS50aGVuKChwKSA9PiB7XG4gICAgICB0aGlzLnNyYyA9IHA7XG4gICAgICB0aGlzLnJlYWR5ID0gdHJ1ZTtcbiAgICAgIHRoaXMucmVzZXQoKTtcbiAgICB9KTtcbiAgfVxuICBoYXMoaWQ6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIHJldHVybiAhIXRoaXMuc3JjPy5mcmFtZXNbaWRdO1xuICB9XG4gIC8qKiBDYWNoZWQgc3RlcHBlZCBwaWdtZW50IGVsbGlwc2U7IGdlb21ldHJ5IHN0YXlzIGluIGludGVnZXIgdG93biB0ZXhlbHMuICovXG4gIHNoYWRvdyh3aWR0aDogbnVtYmVyLCBkZXB0aDogbnVtYmVyKTogU2xvdCB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0KFxuICAgICAgYHRvd25fZ3JvdW5kX3NoYWRvd18ke01hdGgubWF4KDYsIE1hdGgucm91bmQod2lkdGgpKX1gLFxuICAgICAgTWF0aC5tYXgoMywgTWF0aC5yb3VuZChkZXB0aCkpLFxuICAgICk7XG4gIH1cbiAgLyoqIEN1dCAzMC41OiB0aGUgc2xvdCBvZiBgaWRzYCBncmV5ZWQg4oCUIGEgbGl0IG5vZGUncyB3b3JrZXIgbm90IHlldCBoaXJlZCAoYXJ0L3Rvd25fc2hlZXQucHkgYGdyZXkoKWA6IHRoZSB2YWx1ZXMgb25seSwgbGlmdGVkIHRvd2FyZCBhXG4gICAqICBwYWxlIE1JU1QgZ3JleSwgYWxwaGEgw5cgMC44KSwgY3V0IG9uY2UgaW50byBpdHMgb3duIHNsb3QgKi9cbiAgZ3JleShpZHM6IHN0cmluZyB8IHN0cmluZ1tdLCBoOiBudW1iZXIpOiBTbG90IHtcbiAgICBjb25zdCBiYXNlID0gdGhpcy5nZXQoaWRzLCBoKTtcbiAgICBjb25zdCBrZXkgPSBgZ3JleToke0FycmF5LmlzQXJyYXkoaWRzKSA/IGlkcy5qb2luKFwifFwiKSA6IGlkc31AJHtofWA7IC8vIChhIHJlc2V0IOKAlCB0aGUgcGFja2VkIGF0bGFzIGxhbmRpbmcg4oCUIGNsZWFycyBpdCB3aXRoIHRoZSByZXN0KVxuICAgIGNvbnN0IGhpdCA9IHRoaXMuc2xvdHMuZ2V0KGtleSk7XG4gICAgaWYgKGhpdCkgcmV0dXJuIGhpdDtcbiAgICBjb25zdCB3ID0gYmFzZS53O1xuICAgIGlmICh0aGlzLnN4ICsgdyArIDEgPiBBVExBUykge1xuICAgICAgdGhpcy5zeSArPSB0aGlzLnNoICsgMTtcbiAgICAgIHRoaXMuc3ggPSAxO1xuICAgICAgdGhpcy5zaCA9IDA7XG4gICAgfVxuICAgIGlmICh0aGlzLnN5ICsgaCArIDEgPiBBVExBUykge1xuICAgICAgdGhpcy5yZXNldCgpO1xuICAgICAgcmV0dXJuIHRoaXMuZ2V0KGlkcywgaCk7XG4gICAgfVxuICAgIGNvbnN0IHggPSB0aGlzLnN4LFxuICAgICAgeSA9IHRoaXMuc3k7XG4gICAgdGhpcy5zeCArPSB3ICsgMTtcbiAgICB0aGlzLnNoID0gTWF0aC5tYXgodGhpcy5zaCwgaCk7XG4gICAgY29uc3QgZCA9IHRoaXMuY3R4LmdldEltYWdlRGF0YShiYXNlLngsIGJhc2UueSwgYmFzZS53LCBiYXNlLmgpLFxuICAgICAgcCA9IGQuZGF0YTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHAubGVuZ3RoOyBpICs9IDQpIHtcbiAgICAgIGNvbnN0IGwgPSAwLjIxMjYgKiBwW2ldISArIDAuNzE1MiAqIHBbaSArIDFdISArIDAuMDcyMiAqIHBbaSArIDJdITtcbiAgICAgIHBbaV0gPSBsICogMC40ICsgMTY0ICogMC40MjtcbiAgICAgIHBbaSArIDFdID0gbCAqIDAuNCArIDE4OCAqIDAuNDI7XG4gICAgICBwW2kgKyAyXSA9IGwgKiAwLjQgKyAyMTQgKiAwLjQyO1xuICAgICAgcFtpICsgM10gPSBwW2kgKyAzXSEgKiAwLjg7XG4gICAgfVxuICAgIHRoaXMuY3R4LnB1dEltYWdlRGF0YShkLCB4LCB5KTtcbiAgICBjb25zdCBzbG90OiBTbG90ID0ge1xuICAgICAgeCxcbiAgICAgIHksXG4gICAgICB3LFxuICAgICAgaCxcbiAgICAgIHUwOiB4IC8gQVRMQVMsXG4gICAgICB2MDogMSAtICh5ICsgaCkgLyBBVExBUyxcbiAgICAgIHUxOiAoeCArIHcpIC8gQVRMQVMsXG4gICAgICB2MTogMSAtIHkgLyBBVExBUyxcbiAgICB9O1xuICAgIHRoaXMuc2xvdHMuc2V0KGtleSwgc2xvdCk7XG4gICAgdGhpcy52ZXJzaW9uKys7XG4gICAgcmV0dXJuIHNsb3Q7XG4gIH1cbiAgcHJpdmF0ZSBzZWF0ZWQoaWRzOiBzdHJpbmdbXSwgaDogbnVtYmVyKTogU2xvdCB7XG4gICAgY29uc3QgYmFzZSA9IHRoaXMuZ2V0KGlkcywgaCksXG4gICAgICBrZXkgPSBgc2VhdGVkOiR7aWRzLmpvaW4oXCJ8XCIpfUAke2h9YDtcbiAgICBjb25zdCBjYWNoZWQgPSB0aGlzLnNsb3RzLmdldChrZXkpO1xuICAgIGlmIChjYWNoZWQpIHJldHVybiBjYWNoZWQ7XG4gICAgY29uc3QgdyA9IGJhc2UudyArIDMsXG4gICAgICBzaCA9IE1hdGgubWF4KDgsIE1hdGgucm91bmQoaCAqIDAuOCkpO1xuICAgIGlmICh0aGlzLnN4ICsgdyArIDEgPiBBVExBUykge1xuICAgICAgdGhpcy5zeSArPSB0aGlzLnNoICsgMTtcbiAgICAgIHRoaXMuc3ggPSAxO1xuICAgICAgdGhpcy5zaCA9IDA7XG4gICAgfVxuICAgIGlmICh0aGlzLnN5ICsgc2ggKyAxID4gQVRMQVMpIHtcbiAgICAgIHRoaXMucmVzZXQoKTtcbiAgICAgIHJldHVybiB0aGlzLnNlYXRlZChpZHMsIGgpO1xuICAgIH1cbiAgICBjb25zdCB4ID0gdGhpcy5zeCxcbiAgICAgIHkgPSB0aGlzLnN5O1xuICAgIHRoaXMuc3ggKz0gdyArIDE7XG4gICAgdGhpcy5zaCA9IE1hdGgubWF4KHRoaXMuc2gsIHNoKTtcbiAgICBjb25zdCB0b3JzbyA9IE1hdGgucm91bmQoYmFzZS5oICogMC42OCk7XG4gICAgdGhpcy5jdHguaW1hZ2VTbW9vdGhpbmdFbmFibGVkID0gZmFsc2U7XG4gICAgdGhpcy5jdHguZHJhd0ltYWdlKHRoaXMuY2FudmFzLCBiYXNlLngsIGJhc2UueSwgYmFzZS53LCB0b3JzbywgeCwgeSwgYmFzZS53LCB0b3Jzbyk7XG4gICAgdGhpcy5jdHguZHJhd0ltYWdlKFxuICAgICAgdGhpcy5jYW52YXMsXG4gICAgICBiYXNlLngsXG4gICAgICBiYXNlLnkgKyB0b3JzbyxcbiAgICAgIGJhc2UudyxcbiAgICAgIGJhc2UuaCAtIHRvcnNvLFxuICAgICAgeCArIDIsXG4gICAgICB5ICsgdG9yc28sXG4gICAgICBiYXNlLncgKyAxLFxuICAgICAgc2ggLSB0b3JzbyxcbiAgICApO1xuICAgIGNvbnN0IHNsb3QgPSB7XG4gICAgICB4LFxuICAgICAgeSxcbiAgICAgIHcsXG4gICAgICBoOiBzaCxcbiAgICAgIHUwOiB4IC8gQVRMQVMsXG4gICAgICB2MDogMSAtICh5ICsgc2gpIC8gQVRMQVMsXG4gICAgICB1MTogKHggKyB3KSAvIEFUTEFTLFxuICAgICAgdjE6IDEgLSB5IC8gQVRMQVMsXG4gICAgfTtcbiAgICB0aGlzLnNsb3RzLnNldChrZXksIHNsb3QpO1xuICAgIHRoaXMudmVyc2lvbisrO1xuICAgIHJldHVybiBzbG90O1xuICB9XG4gIHByaXZhdGUgcmVzZXQoKTogdm9pZCB7XG4gICAgdGhpcy5zbG90cy5jbGVhcigpO1xuICAgIHRoaXMuc3ggPSAxO1xuICAgIHRoaXMuc3kgPSAxO1xuICAgIHRoaXMuc2ggPSAwO1xuICAgIHRoaXMuY3R4LmNsZWFyUmVjdCgwLCAwLCBBVExBUywgQVRMQVMpO1xuICAgIHRoaXMudmVyc2lvbisrO1xuICB9XG4gIC8qKiB0aGUgc2xvdCBvZiBgaWRgIGRyYXduIGBoYCB0ZXhlbHMgdGFsbCAodGhlIGZpcnN0IGlkIG9mIGBpZHNgIHRoZSBhdGxhcyBoYXMsIGVsc2UgYSBwcmltaXRpdmUgb2YgdGhlIGZpcnN0KSAqL1xuICBnZXQoaWRzOiBzdHJpbmcgfCBzdHJpbmdbXSwgaDogbnVtYmVyKTogU2xvdCB7XG4gICAgY29uc3QgcmVxdWVzdGVkID0gQXJyYXkuaXNBcnJheShpZHMpID8gaWRzIDogW2lkc107XG4gICAgaWYgKHJlcXVlc3RlZFswXT8uc3RhcnRzV2l0aChcInRvd25fc2VhdGVkOlwiKSlcbiAgICAgIHJldHVybiB0aGlzLnNlYXRlZChcbiAgICAgICAgcmVxdWVzdGVkLm1hcCgoaWQpID0+IGlkLnJlcGxhY2UoL150b3duX3NlYXRlZDovLCBcIlwiKSksXG4gICAgICAgIGgsXG4gICAgICApO1xuICAgIGNvbnN0IGxpc3QgPSBBcnJheS5pc0FycmF5KGlkcykgPyBpZHMgOiBbaWRzXTtcbiAgICBjb25zdCBpZCA9IGxpc3QuZmluZCgoeCkgPT4gdGhpcy5zcmM/LmZyYW1lc1t4XSkgPz8gbGlzdFswXSE7XG4gICAgY29uc3Qga2V5ID0gYCR7aWR9QCR7aH1gO1xuICAgIGNvbnN0IHMgPSB0aGlzLnNsb3RzLmdldChrZXkpO1xuICAgIGlmIChzKSByZXR1cm4gcztcbiAgICBjb25zdCBmID0gdGhpcy5zcmM/LmZyYW1lc1tpZF07XG4gICAgY29uc3Qgc2hhZG93V2lkdGggPSAvXnRvd25fZ3JvdW5kX3NoYWRvd18oXFxkKykkLy5leGVjKGlkKTtcbiAgICBjb25zdCB3ID0gc2hhZG93V2lkdGhcbiAgICAgID8gTnVtYmVyKHNoYWRvd1dpZHRoWzFdKVxuICAgICAgOiBmXG4gICAgICAgID8gTWF0aC5tYXgoMSwgTWF0aC5yb3VuZCgoaCAqIGYudykgLyBmLmgpKVxuICAgICAgICA6IE1hdGgubWF4KDEsIE1hdGgucm91bmQoaCAqIChBU1BFQ1QuZmluZCgoW3JlXSkgPT4gcmUudGVzdChpZCkpPy5bMV0gPz8gMSkpKTtcbiAgICBpZiAodGhpcy5zeCArIHcgKyAxID4gQVRMQVMpIHtcbiAgICAgIHRoaXMuc3kgKz0gdGhpcy5zaCArIDE7XG4gICAgICB0aGlzLnN4ID0gMTtcbiAgICAgIHRoaXMuc2ggPSAwO1xuICAgIH1cbiAgICBpZiAodGhpcy5zeSArIGggKyAxID4gQVRMQVMpIHRoaXMucmVzZXQoKTsgLy8gKG5ldmVyIGluIHByYWN0aWNlOiBhIGZ1bGwgc2hlZXQgc3RhcnRzIG92ZXIpXG4gICAgY29uc3QgeCA9IHRoaXMuc3gsXG4gICAgICB5ID0gdGhpcy5zeTtcbiAgICB0aGlzLnN4ICs9IHcgKyAxO1xuICAgIHRoaXMuc2ggPSBNYXRoLm1heCh0aGlzLnNoLCBoKTtcbiAgICBjb25zdCBzbG90OiBTbG90ID0ge1xuICAgICAgeCxcbiAgICAgIHksXG4gICAgICB3LFxuICAgICAgaCxcbiAgICAgIHUwOiB4IC8gQVRMQVMsXG4gICAgICB2MDogMSAtICh5ICsgaCkgLyBBVExBUyxcbiAgICAgIHUxOiAoeCArIHcpIC8gQVRMQVMsXG4gICAgICB2MTogMSAtIHkgLyBBVExBUyxcbiAgICB9O1xuICAgIHRoaXMuc2xvdHMuc2V0KGtleSwgc2xvdCk7XG4gICAgdGhpcy5sYXN0SWQgPSBpZDtcbiAgICBpZiAoZiAmJiB0aGlzLnNyYykgdGhpcy5jdXQodGhpcy5zcmMuaW1nLCBmLCBzbG90KTtcbiAgICBlbHNlIGlmICghcGFpbnRIb21lU2VydmljZSh0aGlzLmN0eCwgaWQsIHgsIHksIHcsIGgpKSBkcmF3UHJpbWl0aXZlKHRoaXMuY3R4LCBpZCwgeCwgeSwgdywgaCk7XG4gICAgdGhpcy52ZXJzaW9uKys7XG4gICAgcmV0dXJuIHNsb3Q7XG4gIH1cbiAgLyoqIGEgcGFja2VkIG1hc3RlciBjdXQgdG8gaXRzIGRyYXduIHNpemUgYnkgYXJlYSAoc21vb3RoZWQsIHRoZW4gdGhlIGFscGhhIHRocmVzaG9sZGVkOiBhIGNyaXNwIHNpbGhvdWV0dGUpICovXG4gIHByaXZhdGUgY3V0KGltZzogSFRNTEltYWdlRWxlbWVudCwgZjogRnJhbWUsIHM6IFNsb3QpOiB2b2lkIHtcbiAgICBpZiAoZi53ID09PSBzLncgJiYgZi5oID09PSBzLmgpIHtcbiAgICAgIHRoaXMuY3R4LmltYWdlU21vb3RoaW5nRW5hYmxlZCA9IGZhbHNlO1xuICAgICAgdGhpcy5jdHguZHJhd0ltYWdlKGltZywgZi54LCBmLnksIGYudywgZi5oLCBzLngsIHMueSwgcy53LCBzLmgpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKTtcbiAgICBjLndpZHRoID0gcy53O1xuICAgIGMuaGVpZ2h0ID0gcy5oO1xuICAgIGNvbnN0IGcgPSBjLmdldENvbnRleHQoXCIyZFwiLCB7IHdpbGxSZWFkRnJlcXVlbnRseTogdHJ1ZSB9KSE7XG4gICAgZy5pbWFnZVNtb290aGluZ0VuYWJsZWQgPSB0cnVlO1xuICAgIGcuaW1hZ2VTbW9vdGhpbmdRdWFsaXR5ID0gXCJoaWdoXCI7XG4gICAgZy5kcmF3SW1hZ2UoaW1nLCBmLngsIGYueSwgZi53LCBmLmgsIDAsIDAsIHMudywgcy5oKTtcbiAgICBjb25zdCBkID0gZy5nZXRJbWFnZURhdGEoMCwgMCwgcy53LCBzLmgpLFxuICAgICAgcCA9IGQuZGF0YTtcbiAgICBmb3IgKGxldCBpID0gMzsgaSA8IHAubGVuZ3RoOyBpICs9IDQpIHBbaV0gPSBwW2ldISA8IDExMCA/IDAgOiAyNTU7XG4gICAgLy8gdGhlIGFydCBub3RlIChcInRoZSBmb3VyIHdhbGtlcnMgbG9vayBhbGlrZVwiKTogYSB3YWxrZXIncyBjb2F0IHRha2VzIGl0cyBjbGFzcydzIGh1ZSDigJQgbWlkLXRvbmVzLCBuZXZlciB0aGUgQkxPT0QgY2xvYWsgb3IgdGhlIGlua1xuICAgIGNvbnN0IHRpbnQgPVxuICAgICAgV0FMS0VSX1RJTlRbXG4gICAgICAgIC9eKD86d2Fsa3xoZXJvKV8oXFx3Kz8pKD86X3wkKS8uZXhlYyhmID09PSB1bmRlZmluZWQgPyBcIlwiIDogdGhpcy5sYXN0SWQpPy5bMV0gPz8gXCJcIlxuICAgICAgXTtcbiAgICBpZiAodGludClcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcC5sZW5ndGg7IGkgKz0gNCkge1xuICAgICAgICBpZiAoIXBbaSArIDNdKSBjb250aW51ZTtcbiAgICAgICAgY29uc3QgciA9IHBbaV0hLFxuICAgICAgICAgIGdnID0gcFtpICsgMV0hLFxuICAgICAgICAgIGIgPSBwW2kgKyAyXSEsXG4gICAgICAgICAgbCA9ICgwLjIxMjYgKiByICsgMC43MTUyICogZ2cgKyAwLjA3MjIgKiBiKSAvIDI1NTtcbiAgICAgICAgaWYgKGwgPCAwLjEyIHx8IGwgPiAwLjggfHwgKHIgPiBnZyAqIDEuNSAmJiByID4gYiAqIDEuNCkpIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCBtID0gMC40MiAqICgxIC0gTWF0aC5hYnMobCAtIDAuNDIpICogMS42KTtcbiAgICAgICAgcFtpXSA9IHIgKyAodGludFswXSEgKiBsICogMiAtIHIpICogbTtcbiAgICAgICAgcFtpICsgMV0gPSBnZyArICh0aW50WzFdISAqIGwgKiAyIC0gZ2cpICogbTtcbiAgICAgICAgcFtpICsgMl0gPSBiICsgKHRpbnRbMl0hICogbCAqIDIgLSBiKSAqIG07XG4gICAgICB9XG4gICAgdGhpcy5jdHgucHV0SW1hZ2VEYXRhKGQsIHMueCwgcy55KTtcbiAgfVxufVxuLyoqIHRoZSBwcmltaXRpdmUgZm9yIGFuIGlkIHRoZSBhdGxhcyBsYWNrczogYSBjb2xvdXJlZCBibG9jayBpbiB0aGUgdGhpbmcncyBzaGFwZSAoZG9jcy9UT1dOLm1kIMKnNzogXCJhIGNvbG91cmVkIGJsb2NrICsgaXRzIGljb25cIikgKi9cbmZ1bmN0aW9uIGRyYXdQcmltaXRpdmUoXG4gIGc6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRCxcbiAgaWQ6IHN0cmluZyxcbiAgeDogbnVtYmVyLFxuICB5OiBudW1iZXIsXG4gIHc6IG51bWJlcixcbiAgaDogbnVtYmVyLFxuKTogdm9pZCB7XG4gIGNvbnN0IFIgPSAoYzogc3RyaW5nLCBhOiBudW1iZXIsIGI6IG51bWJlciwgY3c6IG51bWJlciwgY2g6IG51bWJlcik6IHZvaWQgPT4ge1xuICAgIGcuZmlsbFN0eWxlID0gYztcbiAgICBnLmZpbGxSZWN0KFxuICAgICAgeCArIE1hdGgucm91bmQoYSksXG4gICAgICB5ICsgTWF0aC5yb3VuZChiKSxcbiAgICAgIE1hdGgubWF4KDEsIE1hdGgucm91bmQoY3cpKSxcbiAgICAgIE1hdGgubWF4KDEsIE1hdGgucm91bmQoY2gpKSxcbiAgICApO1xuICB9O1xuICBjb25zdCB0cmkgPSAoYzogc3RyaW5nLCB4MDogbnVtYmVyLCB5MDogbnVtYmVyLCB4MTogbnVtYmVyLCB4MjogbnVtYmVyLCB5YjogbnVtYmVyKTogdm9pZCA9PiB7XG4gICAgZy5maWxsU3R5bGUgPSBjO1xuICAgIGcuYmVnaW5QYXRoKCk7XG4gICAgZy5tb3ZlVG8oeCArIHgwLCB5ICsgeTApO1xuICAgIGcubGluZVRvKHggKyB4MSwgeSArIHliKTtcbiAgICBnLmxpbmVUbyh4ICsgeDIsIHkgKyB5Yik7XG4gICAgZy5jbG9zZVBhdGgoKTtcbiAgICBnLmZpbGwoKTtcbiAgfTtcbiAgY29uc3Qgc3BlY2sgPSAoYmFzZTogc3RyaW5nLCBkYXJrOiBzdHJpbmcsIG46IG51bWJlcik6IHZvaWQgPT4ge1xuICAgIFIoYmFzZSwgMCwgMCwgdywgaCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBuOyBpKyspIFIoZGFyaywgaGFzaE4oaSwgeCwgeSkgJSB3LCBoYXNoTih5LCBpLCA3KSAlIGgsIDEsIDEpO1xuICB9O1xuICBpZiAoaWQuc3RhcnRzV2l0aChcInRvd25fZ3JvdW5kX3NoYWRvd19cIikpIHtcbiAgICAvLyBUaHJlZSBxdWlldCBpbmsgd2FzaGVzLCBhIGNyaXNwIG91dGVyIGVkZ2UgYW5kIGEgZGVuc2UgZm9vdCBjb250YWN0LlxuICAgIC8vIE5vIGJsdXIgb3IgZ3JhZGllbnQ6IGJvdGggcmVuZGVyZXIgcGF0aHMgc2FtcGxlIHRoZSBzYW1lIHNtYWxsIGJpdG1hcC5cbiAgICBmb3IgKGxldCB5eSA9IDA7IHl5IDwgaDsgeXkrKylcbiAgICAgIGZvciAobGV0IHh4ID0gMDsgeHggPCB3OyB4eCsrKSB7XG4gICAgICAgIGNvbnN0IGQgPVxuICAgICAgICAgIE1hdGgucG93KCh4eCArIDAuNSAtIHcgLyAyKSAvICh3IC8gMiksIDIpICsgTWF0aC5wb3coKHl5ICsgMC41IC0gaCAvIDIpIC8gKGggLyAyKSwgMik7XG4gICAgICAgIGlmIChkIDw9IDEpXG4gICAgICAgICAgUihcbiAgICAgICAgICAgIGQgPCAwLjI0XG4gICAgICAgICAgICAgID8gXCJyZ2JhKDEzLDE3LDI0LC4zMilcIlxuICAgICAgICAgICAgICA6IGQgPCAwLjYzXG4gICAgICAgICAgICAgICAgPyBcInJnYmEoMTMsMTcsMjQsLjIxKVwiXG4gICAgICAgICAgICAgICAgOiBcInJnYmEoMTMsMTcsMjQsLjA5KVwiLFxuICAgICAgICAgICAgeHgsXG4gICAgICAgICAgICB5eSxcbiAgICAgICAgICAgIDEsXG4gICAgICAgICAgICAxLFxuICAgICAgICAgICk7XG4gICAgICB9XG4gIH0gZWxzZSBpZiAoaWQuc3RhcnRzV2l0aChcInRvd25fd2luZF9ncmFzc19cIikpIHtcbiAgICBjb25zdCBsZWFuID0gTnVtYmVyKGlkLnNwbGl0KFwiX1wiKS5hdCgtMSkpIC0gMjtcbiAgICAvLyBTdGVwcGVkIGluay93YXNoIGJsYWRlIGNsdXN0ZXJzLCBmaXZlIGJlbmRzIHdpdGggdGhlIHNhbWUgcm9vdGVkIGJhc2VzLlxuICAgIGZvciAoY29uc3QgW3Jvb3QsIHRhbGwsIGJpYXNdIG9mIFtcbiAgICAgIFt3ICogMC4yNSwgaCAqIDAuNzIsIC0xXSxcbiAgICAgIFt3ICogMC41LCBoLCAwXSxcbiAgICAgIFt3ICogMC43NSwgaCAqIDAuNiwgMV0sXG4gICAgXSkge1xuICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCB0YWxsITsgaisrKSB7XG4gICAgICAgIGNvbnN0IGJlbmQgPSBNYXRoLnJvdW5kKChsZWFuICsgYmlhcyEpICogTWF0aC5wb3coaiAvIHRhbGwhLCAxLjM1KSk7XG4gICAgICAgIFIoXG4gICAgICAgICAgaiA9PT0gTWF0aC5jZWlsKHRhbGwhKSAtIDEgPyBcIiM2MDcxNWVcIiA6IFwiIzM5NGI0MFwiLFxuICAgICAgICAgIE1hdGgubWF4KDAsIE1hdGgubWluKHcgLSAxLCByb290ISArIGJlbmQpKSxcbiAgICAgICAgICBoIC0gMSAtIGosXG4gICAgICAgICAgMSxcbiAgICAgICAgICAxLFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIGlmIChpZC5zdGFydHNXaXRoKFwidG93bl9lbnZfZ3Jhc3NcIikpIHNwZWNrKFwiIzNkNWEyYVwiLCBcIiMyZjQ3MjBcIiwgMjIpO1xuICBlbHNlIGlmIChpZC5zdGFydHNXaXRoKFwidG93bl9lbnZfZGlydFwiKSkgc3BlY2soXCIjN2E1YTNhXCIsIFwiIzVlNDQyYVwiLCAxOCk7XG4gIGVsc2UgaWYgKGlkLnN0YXJ0c1dpdGgoXCJ0b3duX2Vudl9wbGF6YVwiKSkge1xuICAgIHNwZWNrKFwiIzhhODQ3OFwiLCBcIiM2YjY2NWNcIiwgMTApO1xuICAgIFIoXCIjNWM1NzRlXCIsIDAsIDcsIHcsIDEpO1xuICAgIFIoXCIjNWM1NzRlXCIsIDcsIDAsIDEsIDgpO1xuICB9IGVsc2UgaWYgKGlkLnN0YXJ0c1dpdGgoXCJ0b3duX2Vudl9jbGlmZlwiKSkgc3BlY2soXCIjM2IzYTNmXCIsIFwiIzJhMjkyZVwiLCAyNik7XG4gIGVsc2UgaWYgKGlkLnN0YXJ0c1dpdGgoXCJ0b3duX2Vudl93YXRlclwiKSkgc3BlY2soXCIjMmE0YTYyXCIsIFwiIzNmNmE4NlwiLCAxMik7XG4gIGVsc2UgaWYgKGlkLnN0YXJ0c1dpdGgoXCJ0b3duX2Vudl90cmVlXCIpKSB7XG4gICAgUihcIiM0YTMyMWZcIiwgdyAqIDAuNCwgaCAqIDAuNjUsIHcgKiAwLjIsIGggKiAwLjM1KTtcbiAgICBnLmZpbGxTdHlsZSA9IFwiIzI0NDAxZlwiO1xuICAgIGcuYmVnaW5QYXRoKCk7XG4gICAgZy5lbGxpcHNlKHggKyB3IC8gMiwgeSArIGggKiAwLjQsIHcgKiAwLjUsIGggKiAwLjM4LCAwLCAwLCBNYXRoLlBJICogMik7XG4gICAgZy5maWxsKCk7XG4gIH0gZWxzZSBpZiAoaWQuc3RhcnRzV2l0aChcInRvd25fbW91dGhcIikpIHtcbiAgICBSKFwiIzRhNDc0ZVwiLCAwLCBoICogMC4xNSwgdywgaCAqIDAuODUpO1xuICAgIGcuZmlsbFN0eWxlID0gXCIjMGMwYjEwXCI7XG4gICAgZy5iZWdpblBhdGgoKTtcbiAgICBnLmVsbGlwc2UoeCArIHcgLyAyLCB5ICsgaCAqIDAuNjIsIHcgKiAwLjIsIGggKiAwLjM2LCAwLCBNYXRoLlBJLCAwKTtcbiAgICBnLmZpbGwoKTtcbiAgICBSKFwiIzBjMGIxMFwiLCB3ICogMC4zLCBoICogMC42MiwgdyAqIDAuNCwgaCAqIDAuMzgpO1xuICB9IGVsc2UgaWYgKC9edG93bl8oYmxhY2tzbWl0aHxiYW5rfGtlbm5lbClfLy50ZXN0KGlkKSkge1xuICAgIGNvbnN0IGNvbCA9IC9ibGFja3NtaXRoLy50ZXN0KGlkKVxuICAgICAgPyBbXCIjNGI0NjUwXCIsIFwiIzdhMmExY1wiXVxuICAgICAgOiAvYmFuay8udGVzdChpZClcbiAgICAgICAgPyBbXCIjYjhiMGEwXCIsIFwiIzVhNmY4NlwiXVxuICAgICAgICA6IFtcIiM4YzZhNDRcIiwgXCIjNmE0YTJhXCJdO1xuICAgIFIoY29sWzBdISwgdyAqIDAuMDgsIGggKiAwLjQyLCB3ICogMC44NCwgaCAqIDAuNTgpO1xuICAgIHRyaShjb2xbMV0hLCB3IC8gMiwgMCwgLXcgKiAwLjAyICsgdyAqIDAuMDIsIHcsIGggKiAwLjQ2KTtcbiAgICBSKFwiIzFlMTkxNFwiLCB3ICogMC40MiwgaCAqIDAuNjgsIHcgKiAwLjE2LCBoICogMC4zMik7XG4gICAgaWYgKC9ibGFja3NtaXRoLy50ZXN0KGlkKSkgUihcIiNlMDdhMmFcIiwgdyAqIDAuMTYsIGggKiAwLjcsIHcgKiAwLjE0LCBoICogMC4xKTtcbiAgICBpZiAoL2JhbmsvLnRlc3QoaWQpKSB7XG4gICAgICBnLmZpbGxTdHlsZSA9IFwiI2UzYzI0YVwiO1xuICAgICAgZy5iZWdpblBhdGgoKTtcbiAgICAgIGcuYXJjKHggKyB3ICogMC41LCB5ICsgaCAqIDAuMywgTWF0aC5tYXgoMiwgaCAqIDAuMDgpLCAwLCBNYXRoLlBJICogMik7XG4gICAgICBnLmZpbGwoKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoaWQuc3RhcnRzV2l0aChcInRvd25fdGVudFwiKSkge1xuICAgIHRyaShcIiNjOWI0OGFcIiwgdyAvIDIsIDAsIDAsIHcsIGgpO1xuICAgIHRyaShcIiMyYTIyMThcIiwgdyAvIDIsIGggKiAwLjQ1LCB3ICogMC4zNiwgdyAqIDAuNjQsIGgpO1xuICB9IGVsc2UgaWYgKGlkLnN0YXJ0c1dpdGgoXCJ0b3duX2JvYXJkXCIpKSB7XG4gICAgUihcIiM0YTMyMWZcIiwgdyAqIDAuMTUsIGggKiAwLjMsIDIsIGggKiAwLjcpO1xuICAgIFIoXCIjNGEzMjFmXCIsIHcgKiAwLjgsIGggKiAwLjMsIDIsIGggKiAwLjcpO1xuICAgIFIoXCIjNmE1MDM0XCIsIDAsIDAsIHcsIGggKiAwLjYpO1xuICAgIFIoXCIjZDhjOGEwXCIsIHcgKiAwLjIsIGggKiAwLjEyLCB3ICogMC4zLCBoICogMC4yNSk7XG4gIH0gZWxzZSBpZiAoaWQuc3RhcnRzV2l0aChcInRvd25fY3JhdGVcIikpIHtcbiAgICBSKFwiIzhhNjAzNFwiLCAwLCAwLCB3LCBoKTtcbiAgICBSKFwiIzVhM2MxZVwiLCAwLCBoIC8gMiwgdywgMSk7XG4gICAgUihcIiM1YTNjMWVcIiwgdyAvIDIsIDAsIDEsIGgpO1xuICB9IGVsc2UgaWYgKGlkLnN0YXJ0c1dpdGgoXCJ0b3duX2NhbXBmaXJlXCIpKSB7XG4gICAgUihcIiM0YTMyMWZcIiwgMCwgaCAqIDAuNzUsIHcsIGggKiAwLjI1KTtcbiAgICB0cmkoaWQuZW5kc1dpdGgoXCJfMVwiKSA/IFwiI2ZmY2Y1YVwiIDogXCIjZjA4YTJhXCIsIHcgLyAyLCAwLCB3ICogMC4xNSwgdyAqIDAuODUsIGggKiAwLjgpO1xuICB9IGVsc2UgaWYgKGlkLnN0YXJ0c1dpdGgoXCJ0b3duX3Bsb3RcIikpIHtcbiAgICBmb3IgKGNvbnN0IGEgb2YgWzAuMSwgMC45XSkgUihcIiM2YTRhMmFcIiwgdyAqIGEgLSAxLCBoICogMC4yLCAyLCBoICogMC44KTtcbiAgICBSKFwiI2Q4YzhhMFwiLCB3ICogMC4xLCBoICogMC4zNSwgdyAqIDAuOCwgMSk7XG4gIH0gZWxzZSBpZiAoaWQuc3RhcnRzV2l0aChcInRvd25fc2NhZmZvbGRcIikpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8PSAzOyBpKyspIHtcbiAgICAgIFIoXCIjN2E1NTM0XCIsICgodyAtIDIpICogaSkgLyAzLCAwLCAyLCBoKTtcbiAgICAgIFIoXCIjN2E1NTM0XCIsIDAsICgoaCAtIDIpICogaSkgLyAzLCB3LCAyKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoaWQuc3RhcnRzV2l0aChcInRvd25fc2Fja1wiKSkge1xuICAgIGcuZmlsbFN0eWxlID0gXCIjYjg5YTYyXCI7XG4gICAgZy5iZWdpblBhdGgoKTtcbiAgICBnLmVsbGlwc2UoeCArIHcgLyAyLCB5ICsgaCAqIDAuNiwgdyAqIDAuNDUsIGggKiAwLjQsIDAsIDAsIE1hdGguUEkgKiAyKTtcbiAgICBnLmZpbGwoKTtcbiAgICBSKFwiI2UzYzI0YVwiLCB3ICogMC40LCBoICogMC4xLCB3ICogMC4yLCBoICogMC4yNSk7XG4gIH0gZWxzZSBpZiAoaWQuc3RhcnRzV2l0aChcInRvd25faGF1bF9jaGVzdFwiKSkge1xuICAgIC8vIHRoZSBoYXVsIGNoZXN0OiBjbG9zZWQgwrcgZnVsbCAoYSBjb2luIGhlYXAgYW5kIGEgZ2xpbnQpIMK3IG9wZW4gKHRoZSBsaWQgdXAgYmVoaW5kLCBkYXJrIGluc2lkZSlcbiAgICBjb25zdCBvcGVuID0gaWQuZW5kc1dpdGgoXCJfb3BlblwiKSxcbiAgICAgIGZ1bGwgPSBpZC5lbmRzV2l0aChcIl9mdWxsXCIpO1xuICAgIGlmIChvcGVuKSB7XG4gICAgICBSKFwiIzRhMzIyMFwiLCB3ICogMC4wOCwgMCwgdyAqIDAuODQsIGggKiAwLjQpO1xuICAgICAgUihcIiMwZDBjMTRcIiwgdyAqIDAuMTIsIGggKiAwLjQsIHcgKiAwLjc2LCBoICogMC4xNCk7XG4gICAgfVxuICAgIFIoXCIjNWEzYzIyXCIsIHcgKiAwLjA2LCBoICogMC40NSwgdyAqIDAuODgsIGggKiAwLjQ3KTtcbiAgICBSKFwiIzJiMzM1MFwiLCB3ICogMC4wNiwgaCAqIDAuNiwgdyAqIDAuODgsIDEpO1xuICAgIFIoXCIjMmIzMzUwXCIsIHcgKiAwLjMsIGggKiAwLjQ1LCAxLCBoICogMC40Nyk7XG4gICAgUihcIiMyYjMzNTBcIiwgdyAqIDAuNywgaCAqIDAuNDUsIDEsIGggKiAwLjQ3KTtcbiAgICBpZiAoIW9wZW4pIFIoXCIjNmE0YTJjXCIsIHcgKiAwLjA0LCBoICogMC4zMiwgdyAqIDAuOTIsIGggKiAwLjE1KTtcbiAgICBSKFwiI2I4OTQ0OFwiLCB3ICogMC40NSwgaCAqIDAuNTIsIHcgKiAwLjEsIGggKiAwLjE0KTtcbiAgICBpZiAoZnVsbCkge1xuICAgICAgUihcIiNiODk0NDhcIiwgdyAqIDAuMTIsIGggKiAwLjIyLCB3ICogMC43NiwgaCAqIDAuMSk7XG4gICAgICBSKFwiI2VhZGZjNVwiLCB3ICogMC42MiwgaCAqIDAuMDgsIDEsIGggKiAwLjE2KTtcbiAgICAgIFIoXCIjZWFkZmM1XCIsIHcgKiAwLjU2LCBoICogMC4xNSwgdyAqIDAuMTQsIDEpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChpZC5zdGFydHNXaXRoKFwidG93bl93b3JrZXJfXCIpKSB7XG4gICAgLy8gYSB3b3JrZXI6IGEgdG93bnNwZXJzb24gKG5vIEJMT09EKSBhbmQgdGhlIHJvbGUncyB0YWcgaW4gaXRzIG93biBjb2xvdXIgKGFydC90b3duLWlkcy5tZCwgd29ya2VycylcbiAgICBjb25zdCByb2xlID0gaWQucmVwbGFjZSgvXnRvd25fd29ya2VyX3xfMSQvZywgXCJcIik7XG4gICAgY29uc3QgY29hdDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgICAgIHBvcnRlcjogXCIjM2EzNDQ4XCIsXG4gICAgICBhcHByZW50aWNlOiBcIiM1YTNjMjJcIixcbiAgICAgIGNsZXJrOiBcIiMxYzFiMmJcIixcbiAgICAgIGRyaWxsbWFzdGVyOiBcIiM2YTVhNDBcIixcbiAgICAgIGtlbm5lbF9oYW5kOiBcIiM0YTNhMmFcIixcbiAgICAgIGhlcmFsZDogXCIjMmIzMzUwXCIsXG4gICAgICBndWlkZTogXCIjN2Q4ZWE0XCIsXG4gICAgICBzY291dDogXCIjNGEzYTJhXCIsXG4gICAgICBxdWFydGVybWFzdGVyOiBcIiM2YTVhNDBcIixcbiAgICB9O1xuICAgIGNvbnN0IGZ3ID0gL3BvcnRlcnxhcHByZW50aWNlfGRyaWxsbWFzdGVyfGtlbm5lbF9oYW5kLy50ZXN0KHJvbGUpID8gdyAqIDAuNTUgOiB3OyAvLyB0aGUgZmlndXJlJ3Mgc2hhcmUgKHRoZSB0YWcgb2JqZWN0IHJpZ2h0IG9mIGl0KVxuICAgIFIoY29hdFtyb2xlXSA/PyBcIiMzYTM0NDhcIiwgZncgKiAwLjIyLCBoICogMC4yOCwgZncgKiAwLjU2LCBoICogMC41KTtcbiAgICBSKFwiI2VhZGZjNVwiLCBmdyAqIDAuMzIsIGggKiAwLjA2LCBmdyAqIDAuMzYsIGggKiAwLjIpO1xuICAgIFIoXCIjMWMxYjJiXCIsIGZ3ICogMC4yNiwgaCAqIDAuNzgsIGZ3ICogMC4xOCwgaCAqIDAuMjIpO1xuICAgIFIoXCIjMWMxYjJiXCIsIGZ3ICogMC41NiwgaCAqIDAuNzgsIGZ3ICogMC4xOCwgaCAqIDAuMjIpO1xuICAgIGNvbnN0IFQgPSAoYzogc3RyaW5nLCBhOiBudW1iZXIsIGI6IG51bWJlciwgY3c6IG51bWJlciwgY2g6IG51bWJlcik6IHZvaWQgPT5cbiAgICAgIFIoYywgZncgKyAodyAtIGZ3KSAqIGEsIGggKiBiLCAodyAtIGZ3KSAqIGN3LCBoICogY2gpO1xuICAgIGlmIChyb2xlID09PSBcInBvcnRlclwiKSB7XG4gICAgICBUKFwiIzZhNGEyY1wiLCAwLjA1LCAwLjQ1LCAwLjksIDAuMyk7XG4gICAgICBUKFwiI2VhZGZjNVwiLCAwLjE1LCAwLjI1LCAwLjcsIDAuMjIpO1xuICAgICAgVChcIiMxYzFiMmJcIiwgMC4zLCAwLjcyLCAwLjM1LCAwLjI4KTtcbiAgICB9IGVsc2UgaWYgKHJvbGUgPT09IFwiYXBwcmVudGljZVwiKSB7XG4gICAgICBUKFwiIzBkMGMxNFwiLCAwLjEsIDAuNTUsIDAuOCwgMC4yKTtcbiAgICAgIFQoXCIjMGQwYzE0XCIsIDAuMzUsIDAuNzUsIDAuMywgMC4yNSk7XG4gICAgICBUKFwiI2U4OTIzYVwiLCAwLjI1LCAwLjQ4LCAwLjUsIDAuMDcpO1xuICAgIH0gZWxzZSBpZiAocm9sZSA9PT0gXCJkcmlsbG1hc3RlclwiKSB7XG4gICAgICBUKFwiI2I4OTQ0OFwiLCAwLjQsIDAuMTUsIDAuMiwgMC4zKTtcbiAgICAgIFQoXCIjNmE0YTJjXCIsIDAuNDcsIDAuNDUsIDAuMDYsIDAuNTUpO1xuICAgICAgVChcIiM2YTRhMmNcIiwgMC4xLCAwLjMyLCAwLjgsIDAuMDYpO1xuICAgIH0gZWxzZSBpZiAocm9sZSA9PT0gXCJrZW5uZWxfaGFuZFwiKSB7XG4gICAgICBUKFwiIzRkNmM5OVwiLCAwLjEsIDAuNTUsIDAuNywgMC4yNSk7XG4gICAgICBUKFwiIzRkNmM5OVwiLCAwLjU1LCAwLjQsIDAuMywgMC4yKTtcbiAgICAgIFQoXCIjMWMxYjJiXCIsIDAuMTUsIDAuOCwgMC4xLCAwLjIpO1xuICAgIH0gZWxzZSBpZiAocm9sZSA9PT0gXCJjbGVya1wiKSBSKFwiI2VhZGZjNVwiLCBmdyAqIDAuNSwgaCAqIDAuNCwgZncgKiAwLjQ1LCBoICogMC4xNik7XG4gICAgZWxzZSBpZiAocm9sZSA9PT0gXCJoZXJhbGRcIikge1xuICAgICAgUihcIiNlYWRmYzVcIiwgZncgKiAwLjYsIGggKiAwLjQyLCBmdyAqIDAuMjUsIGggKiAwLjQpO1xuICAgICAgUihcIiNiODk0NDhcIiwgZncgKiAwLjc4LCBoICogMC4yNSwgZncgKiAwLjE2LCBoICogMC4xKTtcbiAgICB9IGVsc2UgaWYgKHJvbGUgPT09IFwiZ3VpZGVcIikge1xuICAgICAgUihcIiNlODkyM2FcIiwgZncgKiAwLjc2LCBoICogMC40LCBmdyAqIDAuMTgsIGggKiAwLjEyKTtcbiAgICAgIFIoXCIjNmE0YTJjXCIsIGZ3ICogMC4xMiwgaCAqIDAuMDUsIDEsIGggKiAwLjk1KTtcbiAgICB9IGVsc2UgaWYgKHJvbGUgPT09IFwic2NvdXRcIikge1xuICAgICAgUihcIiMxYzFiMmJcIiwgZncgKiAwLjE1LCBoICogMC4wMiwgZncgKiAwLjcsIGggKiAwLjA4KTtcbiAgICAgIFIoXCIjYjg5NDQ4XCIsIGZ3ICogMC42MiwgaCAqIDAuMTIsIGZ3ICogMC4zMiwgaCAqIDAuMDYpO1xuICAgICAgUihcIiNlYWRmYzVcIiwgZncgKiAwLjc4LCBoICogMC4zNSwgZncgKiAwLjIsIGggKiAwLjA2KTtcbiAgICB9IGVsc2UgaWYgKHJvbGUgPT09IFwicXVhcnRlcm1hc3RlclwiKSB7XG4gICAgICBSKFwiIzVhM2MyMlwiLCBmdyAqIDAuNSwgaCAqIDAuMywgZncgKiAwLjQ1LCBoICogMC4zNSk7XG4gICAgICBSKFwiI2VhZGZjNVwiLCBmdyAqIDAuNSwgaCAqIDAuMjYsIGZ3ICogMC40NSwgaCAqIDAuMDYpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChpZC5zdGFydHNXaXRoKFwidG93bl9jaGVzdFwiKSkge1xuICAgIFIoXCIjN2E0YTFlXCIsIDAsIGggKiAwLjMsIHcsIGggKiAwLjcpO1xuICAgIFIoXCIjZmZkNzZhXCIsIDAsIGggKiAwLjMsIHcsIDIpO1xuICAgIFIoXCIjZmZkNzZhXCIsIHcgKiAwLjQyLCBoICogMC40NSwgdyAqIDAuMTYsIGggKiAwLjIpO1xuICB9IGVsc2UgaWYgKGlkLnN0YXJ0c1dpdGgoXCJ0b3duX2ZsYWdcIikpIHtcbiAgICBSKFwiIzRhMzIxZlwiLCAwLCAwLCAxLCBoKTtcbiAgICBSKGlkLmVuZHNXaXRoKFwiXzFcIikgPyBcIiNhMDFhMjhcIiA6IFwiI2MwMTUzMFwiLCAxLCAxLCB3IC0gMSwgaCAqIDAuNCk7XG4gIH0gZWxzZSBpZiAoaWQuc3RhcnRzV2l0aChcImVudl90b3JjaFwiKSkge1xuICAgIFIoXCIjNGEzMjFmXCIsIHcgKiAwLjQsIGggKiAwLjQsIHcgKiAwLjIsIGggKiAwLjYpO1xuICAgIFIoaWQuZW5kc1dpdGgoXCJfMVwiKSA/IFwiI2ZmY2Y1YVwiIDogXCIjZjA4YTJhXCIsIHcgKiAwLjI1LCAwLCB3ICogMC41LCBoICogMC40NSk7XG4gIH0gZWxzZSBpZiAoaWQuc3RhcnRzV2l0aChcImZ4X2dsaW50XCIpKSB7XG4gICAgY29uc3QgYyA9IE1hdGguZmxvb3IodyAvIDIpO1xuICAgIFIoXCIjZmZmYmU4XCIsIGMsIDAsIDEsIGgpO1xuICAgIFIoXCIjZmZmYmU4XCIsIDAsIGMsIHcsIDEpO1xuICAgIFIoXCIjZmZmZmZmXCIsIGMgLSAxLCBjIC0gMSwgMywgMyk7XG4gIH0gZWxzZSBpZiAoaWQgPT09IFwidG93bl9sYW50ZXJuXCIpIHtcbiAgICAvLyBJbmsgY2FnZSBhbmQgb3JhbmdlIGVtYmVyIHdpY2ssIHNoYXJlZCBieSBHTCBhbmQgQ2FudmFzLlxuICAgIFIoXCIjNGQ2Yzk5XCIsIDEsIDAsIDMsIDEpO1xuICAgIFIoXCIjMGQwYzE0XCIsIDEsIDEsIDEsIDMpO1xuICAgIFIoXCIjMGQwYzE0XCIsIDMsIDEsIDEsIDMpO1xuICAgIFIoXCIjZTg5MjNhXCIsIDIsIDEsIDEsIDMpO1xuICAgIFIoXCIjYjg5NDQ4XCIsIDEsIDQsIDMsIDEpO1xuICB9IGVsc2UgaWYgKGlkLnN0YXJ0c1dpdGgoXCJmeF9kb3RfXCIpKSBSKGAjJHtpZC5zbGljZSg3KX1gLCAwLCAwLCB3LCBoKTtcbiAgZWxzZSBpZiAoL14oaGVyb198d2Fsa18pLy50ZXN0KGlkKSkge1xuICAgIGNvbnN0IGJvZHkgPSAvcm9ndWUvLnRlc3QoaWQpXG4gICAgICA/IFwiIzRhM2E1YVwiXG4gICAgICA6IC9yYW5nZXIvLnRlc3QoaWQpXG4gICAgICAgID8gXCIjM2Y1YTMyXCJcbiAgICAgICAgOiAvY2FzdGVyLy50ZXN0KGlkKVxuICAgICAgICAgID8gXCIjM2E0YTdhXCJcbiAgICAgICAgICA6IFwiIzhhOGY5OFwiO1xuICAgIFIoXCIjYzAxNTMwXCIsIHcgKiAwLjE1LCBoICogMC4zMiwgdyAqIDAuMywgaCAqIDAuNSk7XG4gICAgUihib2R5LCB3ICogMC4yNSwgaCAqIDAuMywgdyAqIDAuNSwgaCAqIDAuNDUpO1xuICAgIFIoXCIjZThkY2M4XCIsIHcgKiAwLjMyLCBoICogMC4wOCwgdyAqIDAuMzYsIGggKiAwLjIyKTtcbiAgICBSKFwiIzJhMjQyMFwiLCB3ICogMC4zLCBoICogMC43NSwgdyAqIDAuMTUsIGggKiAwLjI1KTtcbiAgICBSKFwiIzJhMjQyMFwiLCB3ICogMC41NSwgaCAqIDAuNzUsIHcgKiAwLjE1LCBoICogMC4yNSk7XG4gIH0gZWxzZSB7XG4gICAgUihcIiM3YTZhNGFcIiwgdyAqIDAuMSwgaCAqIDAuMzUsIHcgKiAwLjgsIGggKiAwLjQ1KTtcbiAgICBSKFwiIzVhNGEzMlwiLCB3ICogMC4xNSwgaCAqIDAuNzUsIHcgKiAwLjEyLCBoICogMC4yNSk7XG4gICAgUihcIiM1YTRhMzJcIiwgdyAqIDAuNywgaCAqIDAuNzUsIHcgKiAwLjEyLCBoICogMC4yNSk7XG4gICAgUihcIiM3YTZhNGFcIiwgdyAqIDAuNjUsIGggKiAwLjE1LCB3ICogMC4zLCBoICogMC4zKTtcbiAgfSAvLyBhIGJlYXN0XG59XG5cbi8vIC0tLS0gdGhlIGZyYW1lOiB3aGF0IG9uZSBwYWludCBkcmF3cyAoYm90aCB2aWV3cyByZWFkIGl0KSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgdHlwZSBRdWFkID0ge1xuICBzOiBTbG90O1xuICB4OiBudW1iZXI7XG4gIHk6IG51bWJlcjtcbiAgejogbnVtYmVyO1xuICB3OiBudW1iZXI7XG4gIGg6IG51bWJlcjtcbiAgZmxpcDogYm9vbGVhbjtcbiAgZGltOiBudW1iZXI7XG4gIGZhZGU6IG51bWJlcjtcbiAgcmVsaWVmPzogbnVtYmVyO1xufTtcbmV4cG9ydCB0eXBlIExpZ2h0ID0geyB4OiBudW1iZXI7IHk6IG51bWJlcjsgcjogbnVtYmVyOyBjOiBbbnVtYmVyLCBudW1iZXIsIG51bWJlcl0gfTtcbmV4cG9ydCB0eXBlIFRvd25GcmFtZSA9IHtcbiAgeDA6IG51bWJlcjtcbiAgeTA6IG51bWJlcjtcbiAgdzogbnVtYmVyO1xuICBoOiBudW1iZXI7XG4gIGs6IG51bWJlcjtcbiAgVzogbnVtYmVyO1xuICBIOiBudW1iZXI7XG4gIHF1YWRzOiBRdWFkW107XG4gIG46IG51bWJlcjtcbiAgdGVycmFpbjogSFRNTENhbnZhc0VsZW1lbnQgfCBudWxsO1xuICBncm91bmRLZXk6IHN0cmluZztcbiAgbGlnaHRzOiBMaWdodFtdO1xuICBhbWI6IFtudW1iZXIsIG51bWJlciwgbnVtYmVyXTtcbiAgbmlnaHQ6IG51bWJlcjtcbiAgbGl2ZTogbnVtYmVyO1xufTtcblxuLyoqIGhvdXIgKDAuLjI0KSDihpIgbmlnaHQgMC4uMTogZGF5IDfigJMxNywgZHVzayAxN+KAkzIxLCBuaWdodCAyMeKAkzUsIGRhd24gNeKAkzcgKi9cbmV4cG9ydCBmdW5jdGlvbiBuaWdodE9mKGhvdXI6IG51bWJlcik6IG51bWJlciB7XG4gIGNvbnN0IGggPSAoKGhvdXIgJSAyNCkgKyAyNCkgJSAyNDtcbiAgaWYgKGggPj0gMjEgfHwgaCA8IDUpIHJldHVybiAxO1xuICBpZiAoaCA+PSA3ICYmIGggPCAxNykgcmV0dXJuIDA7XG4gIHJldHVybiBoIDwgNyA/IDEgLSAoaCAtIDUpIC8gMiA6IChoIC0gMTcpIC8gNDtcbn1cbmNvbnN0IG1peDMgPSAoYTogbnVtYmVyW10sIGI6IG51bWJlcltdLCB0OiBudW1iZXIpOiBbbnVtYmVyLCBudW1iZXIsIG51bWJlcl0gPT4gW1xuICBhWzBdISArIChiWzBdISAtIGFbMF0hKSAqIHQsXG4gIGFbMV0hICsgKGJbMV0hIC0gYVsxXSEpICogdCxcbiAgYVsyXSEgKyAoYlsyXSEgLSBhWzJdISkgKiB0LFxuXTtcbmNvbnN0IEFNQl9EQVkgPSBbMS4xLCAxLjA4LCAxLjA2XSxcbiAgQU1CX0RVU0sgPSBbMC44NiwgMC42OCwgMC42Ml0sXG4gIEFNQl9OSUdIVCA9IFswLjI3LCAwLjM0LCAwLjU4XTsgLy8gbW9vbmxpZ2h0OiBjb29sIGFuZCBsb3csIHNvIHRoZSB3YXJtIHdpbmRvd3MgYW5kIHRoZSBmaXJlIGNhcnJ5IHRoZSBuaWdodCAodGhlIGNvb3JkaW5hdG9yOiBuaWdodCByZWFkIGFzIGp1c3QgZGFya2VyKVxuZXhwb3J0IGZ1bmN0aW9uIGFtYmllbnRPZihuaWdodDogbnVtYmVyKTogW251bWJlciwgbnVtYmVyLCBudW1iZXJdIHtcbiAgcmV0dXJuIG5pZ2h0IDwgMC41XG4gICAgPyBtaXgzKEFNQl9EQVksIEFNQl9EVVNLLCBuaWdodCAqIDIpXG4gICAgOiBtaXgzKEFNQl9EVVNLLCBBTUJfTklHSFQsIChuaWdodCAtIDAuNSkgKiAyKTtcbn1cblxuLy8gLS0tLSB3YWxrZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG50eXBlIExlZyA9IHsgdDA6IG51bWJlcjsgdDE6IG51bWJlcjsgYTogUHQ7IGI6IFB0IH07XG50eXBlIFdhbGtlciA9IHtcbiAgaWQ6IHN0cmluZztcbiAgaG9tZU9mZnNldD86IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfTtcbiAgc3ByaXRlOiBzdHJpbmdbXTtcbiAgd2Fsazogc3RyaW5nW107XG4gIGg6IG51bWJlcjtcbiAgbGVnczogTGVnW107XG4gIGZyb206IG51bWJlcjtcbiAgdG86IG51bWJlcjtcbiAgY2Fycnk/OiBzdHJpbmc7XG4gIGNhcnJ5SD86IG51bWJlcjtcbiAgbGFnOiBudW1iZXI7XG4gIGZvbGxvdz86IFdhbGtlcjtcbiAgZW1lcmdlPzogYm9vbGVhbjtcbiAgdmFuaXNoPzogYm9vbGVhbjtcbiAgZXh0ZW5kPzogKHc6IFdhbGtlcikgPT4gdm9pZDtcbiAgcGV0PzogYm9vbGVhbjtcbiAgcmVpbmNhcm5hdGluZz86IGJvb2xlYW47XG59O1xuY29uc3QgU1BFRUQgPSA0MDtcbmZ1bmN0aW9uIGxlZ3NBbG9uZyhwdHM6IFB0W10sIHQwOiBudW1iZXIsIHNwZWVkID0gU1BFRUQsIG91dDogTGVnW10gPSBbXSk6IG51bWJlciB7XG4gIGxldCB0ID0gdDA7XG4gIGZvciAobGV0IGkgPSAxOyBpIDwgcHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgZCA9IGRpc3QocHRzW2kgLSAxXSEsIHB0c1tpXSEpO1xuICAgIGlmIChkIDwgMC4wMSkgY29udGludWU7XG4gICAgb3V0LnB1c2goeyB0MDogdCwgdDE6IHQgKyBkIC8gc3BlZWQsIGE6IHB0c1tpIC0gMV0hLCBiOiBwdHNbaV0hIH0pO1xuICAgIHQgKz0gZCAvIHNwZWVkO1xuICB9XG4gIHJldHVybiB0O1xufVxuZnVuY3Rpb24gd2Fsa2VyQXQoXG4gIHc6IFdhbGtlcixcbiAgdDogbnVtYmVyLFxuKTogeyB4OiBudW1iZXI7IHk6IG51bWJlcjsgbW92aW5nOiBib29sZWFuOyBkeDogbnVtYmVyIH0gfCBudWxsIHtcbiAgaWYgKHQgPCB3LmZyb20gfHwgdCA+IHcudG8pIHJldHVybiBudWxsO1xuICBjb25zdCBsZWdzID0gdy5sZWdzO1xuICBpZiAody5leHRlbmQgJiYgbGVncy5sZW5ndGggJiYgbGVnc1tsZWdzLmxlbmd0aCAtIDFdIS50MSA8IHQgKyAzMCkgdy5leHRlbmQodyk7XG4gIGlmICghbGVncy5sZW5ndGgpIHJldHVybiBudWxsO1xuICBpZiAodCA8PSBsZWdzWzBdIS50MCkgcmV0dXJuIHsgeDogbGVnc1swXSEuYS54LCB5OiBsZWdzWzBdIS5hLnksIG1vdmluZzogZmFsc2UsIGR4OiAwIH07XG4gIGxldCBsbyA9IDAsXG4gICAgaGkgPSBsZWdzLmxlbmd0aCAtIDE7XG4gIHdoaWxlIChsbyA8IGhpKSB7XG4gICAgY29uc3QgbSA9IChsbyArIGhpICsgMSkgPj4gMTtcbiAgICBpZiAobGVnc1ttXSEudDAgPD0gdCkgbG8gPSBtO1xuICAgIGVsc2UgaGkgPSBtIC0gMTtcbiAgfVxuICBjb25zdCBMID0gbGVnc1tsb10hO1xuICBpZiAodCA+PSBMLnQxKSByZXR1cm4geyB4OiBMLmIueCwgeTogTC5iLnksIG1vdmluZzogZmFsc2UsIGR4OiAwIH07XG4gIGNvbnN0IGYgPSAodCAtIEwudDApIC8gKEwudDEgLSBMLnQwKTtcbiAgcmV0dXJuIHtcbiAgICB4OiBMLmEueCArIChMLmIueCAtIEwuYS54KSAqIGYsXG4gICAgeTogTC5hLnkgKyAoTC5iLnkgLSBMLmEueSkgKiBmLFxuICAgIG1vdmluZzogdHJ1ZSxcbiAgICBkeDogTC5iLnggLSBMLmEueCxcbiAgfTtcbn1cblxuLy8gLS0tLSBwYXJ0aWNsZXMgKGNvc21ldGljKSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbnR5cGUgUGFydCA9IHtcbiAgeDogbnVtYmVyO1xuICB5OiBudW1iZXI7XG4gIHZ4OiBudW1iZXI7XG4gIHZ5OiBudW1iZXI7XG4gIGFnZTogbnVtYmVyO1xuICBsaWZlOiBudW1iZXI7XG4gIGtpbmQ6IFwic21va2VcIiB8IFwiZW1iZXJcIiB8IFwic3BhcmtcIiB8IFwiZHVzdFwiO1xuICBjOiBzdHJpbmc7XG4gIHM6IG51bWJlcjtcbn07XG5jb25zdCBTTU9LRSA9IFtcIjlhOTU4Y1wiLCBcIjdkN2E3NFwiLCBcImI0YWZhNFwiXSxcbiAgRU1CRVIgPSBbXCJmZmIwNGFcIiwgXCJmZjdhMmFcIiwgXCJmZmQ3NmFcIl0sXG4gIERVU1QgPSBbXCJiODlhNmFcIiwgXCI5YTdlNTZcIiwgXCJjZGI0OGFcIl07XG5cbi8vIC0tLS0gdGhlIHZpZXcgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCB0eXBlIFRvd25TdGF0cyA9IHtcbiAgZnBzOiBudW1iZXI7XG4gIGZyYW1lczogbnVtYmVyO1xuICBjcHVNczogbnVtYmVyO1xuICBjcHVQNTA6IG51bWJlcjtcbiAgY3B1UDk1OiBudW1iZXI7XG4gIHdhbGtlcnM6IG51bWJlcjtcbiAgbW9kZTogXCJnbFwiIHwgXCIyZFwiO1xuICBnbExvc3Q6IGJvb2xlYW47XG4gIGs6IG51bWJlcjtcbiAgbmlnaHQ6IG51bWJlcjtcbiAgY2hhcmFjdGVyTGlnaHRzOiBudW1iZXI7XG4gIGxpZ2h0czogbnVtYmVyO1xuICBpZGxlOiBib29sZWFuO1xuICBydW5uaW5nOiBib29sZWFuO1xuICB0ZXJyYWluUGFpbnRzOiBudW1iZXI7XG4gIHRlcnJhaW5QYWludE1zOiBudW1iZXI7XG4gIHdpbmRUdWZ0czogbnVtYmVyO1xuICB3aW5kU2lnbmF0dXJlOiBudW1iZXI7XG4gIHNlcnZpY2VzPzogU2VydmljZUlkW107XG4gIHJlc2lkZW50U3RhdGVzPzoge1xuICAgIGlkOiBudW1iZXI7XG4gICAgcmVzdGluZzogYm9vbGVhbjtcbiAgICBwaGFzZT86IFwiYXdheVwiIHwgXCJyZWluY2FybmF0aW5nXCIgfCBcInJlY292ZXJpbmdcIiB8IFwicmVhZHlcIjtcbiAgfVtdO1xuICBidWlsZGluZ3M6IHN0cmluZ1tdO1xuICBhY3RpdmVCdWlsZHM6IHN0cmluZ1tdO1xuICBidWlsZEV2ZW50czogbnVtYmVyO1xuICBidWlsZER1c3Q6IG51bWJlcjtcbiAgc3Rha2VkPzogc3RyaW5nO1xuICBtYXJrZXJzOiBzdHJpbmdbXTtcbiAgdmlldzogW251bWJlciwgbnVtYmVyLCBudW1iZXIsIG51bWJlcl07XG4gIGNoZXN0Pzogc3RyaW5nO1xuICB3b3JrZXJzOiBzdHJpbmdbXTtcbiAgcmFua3M6IFJlY29yZDxzdHJpbmcsIG51bWJlcj47XG59O1xuZXhwb3J0IHR5cGUgVG93blZpZXcgPSB7XG4gIHJlYWRvbmx5IGVsOiBIVE1MRWxlbWVudDtcbiAgc2V0U3RhdGUoczogVG93blN0YXRlKTogdm9pZDtcbiAgLyoqIEF0IFNFTkQ6IHRoZSBoZXJvIHdhbGtzIHRvIHRoZSBtb3V0aCBhbmQgZ29lcyBpbiAo4omkIGBtc2ApOyByZXNvbHZlcyB3aGVuIGhlIGlzIGluLiAqL1xuICB3YWxrSW4obXM/OiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+O1xuICByZXNpemUoKTogdm9pZDtcbiAgLyoqIGEgcGxvdCdzIHNwcml0ZSBib3ggaW4gQ1NTIHB4IChyZWxhdGl2ZSB0byB0aGUgdmlldydzIGJveCk7IG51bGwgd2hlbiBub3RoaW5nIHN0YW5kcyB0aGVyZSAqL1xuICByZWN0T2YoXG4gICAgaWQ6IFBsb3RJZCB8IFwic3Rha2VkXCIgfCBcImNoZXN0XCIgfCBgd29ya2VyOiR7c3RyaW5nfWAsXG4gICk6IHsgeDogbnVtYmVyOyB5OiBudW1iZXI7IHc6IG51bWJlcjsgaDogbnVtYmVyIH0gfCBudWxsO1xuICBvbkxheW91dChmbjogKCkgPT4gdm9pZCk6IHZvaWQ7XG4gIHN0YXRzKCk6IFRvd25TdGF0cztcbiAgc3RyZXNzKG46IG51bWJlcik6IHZvaWQ7XG4gIHNldEhvdXIoaDogbnVtYmVyIHwgbnVsbCk6IHZvaWQ7XG4gIGZvY3VzSGVybygpOiB2b2lkO1xuICBhY3RvclJlY3QoaWQ6IG51bWJlcik6IHsgeDogbnVtYmVyOyB5OiBudW1iZXI7IHc6IG51bWJlcjsgaDogbnVtYmVyIH0gfCBudWxsO1xuICAvKiogQWN0dWFsIHJlc2lkZW50IGhpdCBhcmVhcyBpbiBsb2NhbCBDU1MgcGl4ZWxzOyBubyBzaW11bGF0aW9uIG11dGF0aW9uLiAqL1xuICBhY3RvclRhcmdldHMoKTogVG93bkFjdG9yVGFyZ2V0W107XG4gIG9uQWN0b3JzKGZuOiAoKSA9PiB2b2lkKTogdm9pZDtcbiAgLyoqIGlucHV0IHNlZW4gKHRoZSBpZGxlIGNhcCBsaWZ0cykgKi9cbiAgcG9rZSgpOiB2b2lkO1xuICBkaXNwb3NlKCk6IHZvaWQ7XG59O1xuY29uc3QgSURMRV9NUyA9IDEwXzAwMCxcbiAgSURMRV9GUFMgPSAyMCxcbiAgU09GVF9GUFMgPSAyO1xuXG5sZXQgc2hhcmVkQXRsYXM6IFRvd25BdGxhcyB8IG51bGwgPSBudWxsO1xubGV0IHNoYXJlZEdsOiB7IGNhbnZhczogSFRNTENhbnZhc0VsZW1lbnQ7IGdsOiBHTFRvd247IGxvc3Q6IGJvb2xlYW4gfSB8IG51bGwgPSBudWxsO1xubGV0IGxpZ2h0aW5nSW5zcGVjdG9yOiAoKCkgPT4gdW5rbm93bikgfCBudWxsID0gbnVsbDtcbi8qKiBEZXYtb25seSBpZGVudGljYWwtZnJhbWUgcmVhZGJhY2s7IG5ldmVyIHJ1bnMgaW4gdGhlIGFuaW1hdGlvbiBsb29wLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGluc3BlY3RUb3duTGlnaHRpbmcoKTogdW5rbm93biB7XG4gIHJldHVybiBpbXBvcnQubWV0YS5lbnYuREVWID8gbGlnaHRpbmdJbnNwZWN0b3I/LigpIDogbnVsbDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVUb3duVmlldyhob3N0OiBIVE1MRWxlbWVudCk6IFRvd25WaWV3IHtcbiAgY29uc3QgZWwgPSBob3N0O1xuICAvLyBvbmUgR0wgY2FudmFzIGFuZCBjb250ZXh0IGZvciBldmVyeSBtb3VudCAoYSBjYW1wIHJlLW1vdW50cyBvbiBldmVyeSByZXR1cm4pOiB0YWtlbiBoZXJlLCBnaXZlbiBiYWNrIG9uIGRpc3Bvc2VcbiAgY29uc3Qga2VwdCA9IHNoYXJlZEdsICYmICFzaGFyZWRHbC5nbC5pc0xvc3QoKSA/IHNoYXJlZEdsIDogbnVsbDtcbiAgaWYgKHNoYXJlZEdsICYmICFrZXB0KSBzaGFyZWRHbC5nbC5kaXNwb3NlKCk7XG4gIHNoYXJlZEdsID0gbnVsbDtcbiAgY29uc3QgZ2xDYW52YXMgPSBrZXB0Py5jYW52YXMgPz8gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKTtcbiAgZ2xDYW52YXMuY2xhc3NOYW1lID0gXCJ0b3duLWdsXCI7XG4gIGdsQ2FudmFzLnNldEF0dHJpYnV0ZShcImFyaWEtaGlkZGVuXCIsIFwidHJ1ZVwiKTtcbiAgZWwuYXBwZW5kQ2hpbGQoZ2xDYW52YXMpO1xuICBjb25zdCBhdGxhcyA9IChzaGFyZWRBdGxhcyA/Pz0gbmV3IFRvd25BdGxhcygpKTsgLy8gb25lIHNoZWV0IGZvciBldmVyeSBtb3VudCAodGhlIGNhbXAgcmUtbW91bnRzIG9uIGV2ZXJ5IHJldHVybjsgdGhlIGN1dHMgYXJlIG5vdCBmcmVlKVxuICBsZXQgZ2w6IEdMVG93biB8IG51bGwgPSBudWxsO1xuICBpZiAoa2VwdCkge1xuICAgIGdsID0ga2VwdC5nbDtcbiAgICBnbC5yZXN0b3JlZCgpO1xuICB9IGVsc2VcbiAgICB0cnkge1xuICAgICAgZ2wgPSBuZXcgR0xUb3duKGdsQ2FudmFzLCBhdGxhcyk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS53YXJuKFwidG93bjogbm8gV2ViR0wsIHRoZSAyRCB2aWV3IHN0YW5kcyBpblwiLCBlKTtcbiAgICAgIGdsID0gbnVsbDtcbiAgICB9XG4gIGxldCBjMmQ6IEhUTUxDYW52YXNFbGVtZW50IHwgbnVsbCA9IG51bGw7XG4gIGNvbnN0IHZpZXcyZCA9ICgpOiBIVE1MQ2FudmFzRWxlbWVudCA9PiB7XG4gICAgaWYgKGMyZCkgcmV0dXJuIGMyZDtcbiAgICBjMmQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiY2FudmFzXCIpO1xuICAgIGMyZC5jbGFzc05hbWUgPSBcInRvd24tMmRcIjtcbiAgICBjMmQuc2V0QXR0cmlidXRlKFwiYXJpYS1oaWRkZW5cIiwgXCJ0cnVlXCIpO1xuICAgIGVsLmFwcGVuZENoaWxkKGMyZCk7XG4gICAgcmV0dXJuIGMyZDtcbiAgfTtcbiAgbGV0IGdsTG9zdCA9IGZhbHNlO1xuICBjb25zdCBvbkxvc3QgPSAoZTogRXZlbnQpOiB2b2lkID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgZ2xMb3N0ID0gdHJ1ZTtcbiAgICBsYXlvdXREaXJ0eSA9IHRydWU7XG4gIH07XG4gIGNvbnN0IG9uUmVzdG9yZWQgPSAoKTogdm9pZCA9PiB7XG4gICAgZ2xMb3N0ID0gZmFsc2U7XG4gICAgZ2w/LnJlc3RvcmVkKCk7XG4gICAgbGF5b3V0RGlydHkgPSB0cnVlO1xuICB9O1xuICBnbENhbnZhcy5hZGRFdmVudExpc3RlbmVyKFwid2ViZ2xjb250ZXh0bG9zdFwiLCBvbkxvc3QpO1xuICBnbENhbnZhcy5hZGRFdmVudExpc3RlbmVyKFwid2ViZ2xjb250ZXh0cmVzdG9yZWRcIiwgb25SZXN0b3JlZCk7XG5cbiAgbGV0IHN0YXRlOiBUb3duU3RhdGUgfCBudWxsID0gbnVsbDtcbiAgbGV0IHdhbGtlcnM6IFdhbGtlcltdID0gW107XG4gIGxldCBob21lU3BvdHM6IEhvbWVSZXNpZGVudFNwb3RbXSA9IFtdO1xuICBjb25zdCBwYXJ0czogUGFydFtdID0gW107XG4gIGxldCB0ID0gMCxcbiAgICBsYXN0ID0gcGVyZm9ybWFuY2Uubm93KCksXG4gICAgcmFmID0gMCxcbiAgICBmcmFtZXMgPSAwLFxuICAgIGRpc3Bvc2VkID0gZmFsc2U7XG4gIGNvbnN0IGZwc1dpbjogbnVtYmVyW10gPSBbXSxcbiAgICBjcHU6IG51bWJlcltdID0gW107XG4gIGxldCBsYXN0SW5wdXQgPSBwZXJmb3JtYW5jZS5ub3coKSxcbiAgICBsYXN0RHJhdyA9IDA7XG4gIGxldCBob3VyT3ZlcnJpZGU6IG51bWJlciB8IG51bGwgPSBudWxsO1xuICBsZXQgbGF5b3V0RGlydHkgPSB0cnVlO1xuICBjb25zdCBsYXlvdXRGbnM6ICgoKSA9PiB2b2lkKVtdID0gW107XG4gIGNvbnN0IHVwZ3JhZGVGcm9tID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKTtcbiAgbGV0IGJ1aWxkRXZlbnRzID0gMDtcbiAgY29uc3QgYnVpbGRGeEVuYWJsZWQgPSAoKTogYm9vbGVhbiA9PlxuICAgICFtb3Rpb25QcmVmZXJlbmNlLm1hdGNoZXMgJiZcbiAgICAhZG9jdW1lbnQuaGlkZGVuICYmXG4gICAgZWZmZWN0c0xldmVsKCkgIT09IFwib2ZmXCIgJiZcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuZGF0YXNldC5qdWljZSAhPT0gXCJvZmZcIjtcbiAgbGV0IGJ1aWx0QXQgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpOyAvLyBmcmVzaCBidWlsZGluZ3M6IHRoZSBzY2VuZSB0aW1lIHRoZWlyIHNjYWZmb2xkIHdlbnQgdXBcbiAgbGV0IGhlcm86IFdhbGtlciB8IG51bGwgPSBudWxsO1xuICBjb25zdCBhY3RvckxheW91dDogKCgpID0+IHZvaWQpW10gPSBbXTtcbiAgbGV0IHdhbGtpbmdJbjogeyB0MDogbnVtYmVyOyB0MTogbnVtYmVyOyBkb25lOiAoKSA9PiB2b2lkIH0gfCBudWxsID0gbnVsbDtcbiAgbGV0IHN0cmVzc04gPSAwO1xuICBjb25zdCBhcnJpdmUgPSBuZXcgTWFwPHN0cmluZywgTGVnW10+KCk7IC8vIEN1dCAzMC41OiBhIHdvcmtlciBoaXJlZCBvbiB0aGlzIG1vdW50IHdhbGtzIG91dCBvZiB0aGUgdGVudCB0byBoaXMgcG9zdFxuICBjb25zdCBGOiBUb3duRnJhbWUgPSB7XG4gICAgeDA6IDAsXG4gICAgeTA6IDAsXG4gICAgdzogMSxcbiAgICBoOiAxLFxuICAgIGs6IDEsXG4gICAgVzogMSxcbiAgICBIOiAxLFxuICAgIHF1YWRzOiBbXSxcbiAgICBuOiAwLFxuICAgIHRlcnJhaW46IG51bGwsXG4gICAgZ3JvdW5kS2V5OiBcIlwiLFxuICAgIGxpZ2h0czogW10sXG4gICAgYW1iOiBbMSwgMSwgMV0sXG4gICAgbmlnaHQ6IDAsXG4gICAgbGl2ZTogMCxcbiAgfTtcbiAgaWYgKGltcG9ydC5tZXRhLmVudi5ERVYpIGxpZ2h0aW5nSW5zcGVjdG9yID0gKCkgPT4gKGdsICYmICFnbExvc3QgPyBnbC5jb21wYXJlTGlnaHRpbmcoRikgOiBudWxsKTtcbiAgbGV0IHRlcnJhaW5QYWludHMgPSAwLFxuICAgIHRlcnJhaW5QYWludE1zID0gMDtcbiAgbGV0IHdpbmRUdWZ0cyA9IDAsXG4gICAgd2luZFNpZ25hdHVyZSA9IDA7XG4gIGNvbnN0IG1vdGlvblByZWZlcmVuY2UgPSBtYXRjaE1lZGlhKFwiKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSlcIik7XG4gIGNvbnN0IHJuZyA9IChuOiBudW1iZXIpOiBudW1iZXIgPT4gKGhhc2hOKHN0YXRlPy5zZWVkID8/IDEsIG4pICUgMTAwMDAwKSAvIDEwMDAwMDtcblxuICAvLyAtLSB0aGUgd2Fsa2VycyBvZiBhIHN0YXRlIC0tXG4gIGZ1bmN0aW9uIGJ1aWxkKGhvbWVBcnJpdmFsID0gZmFsc2UpOiB2b2lkIHtcbiAgICBjb25zdCBzID0gc3RhdGUhO1xuICAgIHdhbGtlcnMgPSBbXTtcbiAgICBjb25zdCBjbHMgPSBzLmhlcm8uY2xzLFxuICAgICAgaGVyb0lkcyA9IFtcbiAgICAgICAgLi4uKHMuaGVyby5sb29rID8gW2BoZXJvXyR7Y2xzfV8ke3MuaGVyby5sb29rfWBdIDogW10pLFxuICAgICAgICBgaGVyb18ke2Nsc31gLFxuICAgICAgICBcImhlcm9fZmlnaHRlclwiLFxuICAgICAgXSxcbiAgICAgIHdhbGtJZHMgPSBbYHdhbGtfJHtjbHN9YCwgLi4uaGVyb0lkc107XG4gICAgbGV0IGsgPSAwO1xuICAgIGNvbnN0IHBhcnR5RW5kID0gcy5wYXJ0aWVzLmxlbmd0aCA/IHMucGFydGllc1tzLnBhcnRpZXMubGVuZ3RoIC0gMV0hLmF0ICsgNyA6IDA7XG4gICAgZm9yIChjb25zdCBwIG9mIHMucGFydGllcykge1xuICAgICAgY29uc3QgbGVnczogTGVnW10gPSBbXTtcbiAgICAgIGNvbnN0IGVuZCA9IGxlZ3NBbG9uZyhyb3V0ZShcImluXCIsIHAudG8pLCBwLmF0LCBTUEVFRCwgbGVncyk7XG4gICAgICBjb25zdCB3OiBXYWxrZXIgPSB7XG4gICAgICAgIGlkOiBgcGFydHkke2srK31gLFxuICAgICAgICBzcHJpdGU6IGhlcm9JZHMsXG4gICAgICAgIHdhbGs6IHdhbGtJZHMsXG4gICAgICAgIGg6IDI0LFxuICAgICAgICBsZWdzLFxuICAgICAgICBmcm9tOiBwLmF0LFxuICAgICAgICB0bzogZW5kICsgMC40LFxuICAgICAgICBsYWc6IDAsXG4gICAgICAgIGVtZXJnZTogdHJ1ZSxcbiAgICAgICAgdmFuaXNoOiB0cnVlLFxuICAgICAgICBjYXJyeTogcC5jaGVzdCA/IFwidG93bl9jaGVzdF9nbG93XCIgOiBwLnNhY2sgPyBgdG93bl9zYWNrXyR7cC5zYWNrfWAgOiB1bmRlZmluZWQsXG4gICAgICAgIGNhcnJ5SDogcC5jaGVzdCA/IDggOiBwLnNhY2sgPT09IFwibGFyZ2VcIiA/IDggOiA2LFxuICAgICAgfTtcbiAgICAgIHdhbGtlcnMucHVzaCh3KTtcbiAgICAgIGlmIChwLnBldClcbiAgICAgICAgd2Fsa2Vycy5wdXNoKHtcbiAgICAgICAgICBpZDogYCR7dy5pZH1wZXRgLFxuICAgICAgICAgIHNwcml0ZTogW3AucGV0LCBcInRvd25fZG9nXCJdLFxuICAgICAgICAgIHdhbGs6IFtwLnBldCwgXCJ0b3duX2RvZ1wiXSxcbiAgICAgICAgICBoOiAxNCxcbiAgICAgICAgICBsZWdzLFxuICAgICAgICAgIGZyb206IHAuYXQgKyAwLjcsXG4gICAgICAgICAgdG86IGVuZCArIDEuMSxcbiAgICAgICAgICBsYWc6IDAuNyxcbiAgICAgICAgICBmb2xsb3c6IHcsXG4gICAgICAgICAgZW1lcmdlOiB0cnVlLFxuICAgICAgICAgIHZhbmlzaDogdHJ1ZSxcbiAgICAgICAgICBwZXQ6IHRydWUsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBidWlsZEZvbGsoKTtcbiAgICBpZiAoIXMuaG9tZSkge1xuICAgICAgaGVybyA9IG51bGw7XG4gICAgICBhZGRTdHJlc3MoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gdGhlIGhlcm8gYXQgaG9tZTogdGVudCDihpIgZm9yZ2Ug4oaSIGZpcmUgKOKGkiB0aGUgY3JhdGUgd2hpbGUgbm8gZm9yZ2Ugc3RhbmRzKSwgYSBwYXVzZSBvZiAy4oCTNiBzIGF0IGVhY2hcbiAgICBjb25zdCBzdG9wcyA9IFtcbiAgICAgIFwidGVudFwiLFxuICAgICAgcy5idWlsZGluZ3Muc29tZSgoYikgPT4gYi5pZCA9PT0gXCJibGFja3NtaXRoXCIpID8gXCJzbWl0aFwiIDogXCJjcmF0ZVwiLFxuICAgICAgXCJmaXJlV1wiLFxuICAgIF07XG4gICAgaGVybyA9IG51bGw7XG4gICAgY29uc3QgcmVzaWRlbnRzID0gcy5yZXNpZGVudHMgPz8gW1xuICAgICAgeyBpZDogcy5zZWxlY3RlZEhlcm8gPz8gMSwgY2xzOiBzLmhlcm8uY2xzLCBsb29rOiBzLmhlcm8ubG9vayB9LFxuICAgIF07XG4gICAgZm9yIChjb25zdCByZXNpZGVudCBvZiByZXNpZGVudHMpIHtcbiAgICAgIGxldCBpID0gaG9tZUFycml2YWwgPyAwIDogKE1hdGguZmxvb3Iocm5nKHJlc2lkZW50LmlkICogMzEpICogMykgKyByZXNpZGVudC5pZCkgJSAzLFxuICAgICAgICBuID0gMDtcbiAgICAgIGNvbnN0IGlkcyA9IFtcbiAgICAgICAgLi4uKHJlc2lkZW50Lmxvb2sgPyBbYGhlcm9fJHtyZXNpZGVudC5jbHN9XyR7cmVzaWRlbnQubG9va31gXSA6IFtdKSxcbiAgICAgICAgYGhlcm9fJHtyZXNpZGVudC5jbHN9YCxcbiAgICAgICAgXCJoZXJvX2ZpZ2h0ZXJcIixcbiAgICAgIF07XG4gICAgICBjb25zdCBhY3RvcjogV2Fsa2VyID0ge1xuICAgICAgICBpZDogYHJlc2lkZW50OiR7cmVzaWRlbnQuaWR9YCxcbiAgICAgICAgaG9tZU9mZnNldDogeyB4OiAoKChyZXNpZGVudC5pZCAtIDEpICUgMykgLSAxKSAqIDEyLCB5OiAwIH0sXG4gICAgICAgIHNwcml0ZTogaWRzLFxuICAgICAgICB3YWxrOiBbYHdhbGtfJHtyZXNpZGVudC5jbHN9YCwgLi4uaWRzXSxcbiAgICAgICAgaDogMjQsXG4gICAgICAgIGxlZ3M6IFtdLFxuICAgICAgICBmcm9tOiBwYXJ0eUVuZCxcbiAgICAgICAgdG86IEluZmluaXR5LFxuICAgICAgICBsYWc6IHJlc2lkZW50LmlkICogMC4xLFxuICAgICAgICBleHRlbmQ6ICh3KSA9PiB7XG4gICAgICAgICAgbGV0IHR0ID0gdy5sZWdzLmxlbmd0aCA/IHcubGVnc1t3LmxlZ3MubGVuZ3RoIC0gMV0hLnQxIDogcGFydHlFbmQ7XG4gICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCA2OyBqKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGEgPSBzdG9wc1tpICUgM10hLFxuICAgICAgICAgICAgICBiID0gc3RvcHNbKGkgKyAxKSAlIDNdITtcbiAgICAgICAgICAgIGkrKztcbiAgICAgICAgICAgIGNvbnN0IHBhdXNlID0gMiArIHJuZygxMDAgKyByZXNpZGVudC5pZCAqIDEwMSArIG4rKykgKiA0O1xuICAgICAgICAgICAgY29uc3QgYXQgPSBOT0RFU1thXSE7XG4gICAgICAgICAgICB3LmxlZ3MucHVzaCh7IHQwOiB0dCwgdDE6IHR0ICsgcGF1c2UsIGE6IGF0LCBiOiBhdCB9KTtcbiAgICAgICAgICAgIHR0ICs9IHBhdXNlO1xuICAgICAgICAgICAgdHQgPSBsZWdzQWxvbmcocm91dGUoYSwgYiksIHR0LCBTUEVFRCAqIDAuOCwgdy5sZWdzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICB9O1xuICAgICAgaWYgKHJlc2lkZW50LnBoYXNlID09PSBcInJlaW5jYXJuYXRpbmdcIiAmJiBzLnNlcnZpY2VzPy5pbmNsdWRlcyhcImRldmljZVwiKSkge1xuICAgICAgICBhY3Rvci5ob21lT2Zmc2V0ID0geyB4OiAwLCB5OiAwIH07XG4gICAgICAgIGFjdG9yLnJlaW5jYXJuYXRpbmcgPSB0cnVlO1xuICAgICAgICBjb25zdCBwID0gaG9tZVNwb3RzLmZpbmQoKHApID0+IHAuaWQgPT09IHJlc2lkZW50LmlkKSEuZGV2aWNlO1xuICAgICAgICBhY3Rvci5sZWdzID0gW3sgdDA6IHBhcnR5RW5kLCB0MTogSW5maW5pdHksIGE6IHAsIGI6IHAgfV07XG4gICAgICAgIGFjdG9yLmV4dGVuZCA9IHVuZGVmaW5lZDtcbiAgICAgIH0gZWxzZSBpZiAocmVzaWRlbnQucmVzdGluZyAmJiBzLnNlcnZpY2VzPy5pbmNsdWRlcyhcInBvb2xcIikpIHtcbiAgICAgICAgYWN0b3IuaG9tZU9mZnNldCA9IHsgeDogMCwgeTogMCB9O1xuICAgICAgICBhY3Rvci5zcHJpdGUgPSBpZHMubWFwKChpZCkgPT4gYHRvd25fc2VhdGVkOiR7aWR9YCk7XG4gICAgICAgIGFjdG9yLndhbGsgPSBhY3Rvci5zcHJpdGU7XG4gICAgICAgIGNvbnN0IHAgPSBob21lU3BvdHMuZmluZCgocCkgPT4gcC5pZCA9PT0gcmVzaWRlbnQuaWQpIS5wb29sO1xuICAgICAgICBhY3Rvci5sZWdzID0gW3sgdDA6IHBhcnR5RW5kLCB0MTogSW5maW5pdHksIGE6IHAsIGI6IHAgfV07XG4gICAgICAgIGFjdG9yLmV4dGVuZCA9IHVuZGVmaW5lZDtcbiAgICAgIH0gZWxzZSBhY3Rvci5leHRlbmQhKGFjdG9yKTtcbiAgICAgIHdhbGtlcnMucHVzaChhY3Rvcik7XG4gICAgICBpZiAocmVzaWRlbnQuaWQgPT09IChzLnNlbGVjdGVkSGVybyA/PyAxKSkgaGVybyA9IGFjdG9yO1xuICAgIH1cbiAgICBpZiAoaGVybylcbiAgICAgIHMucGV0cy5mb3JFYWNoKChwLCBqKSA9PlxuICAgICAgICB3YWxrZXJzLnB1c2goe1xuICAgICAgICAgIGlkOiBgcGV0JHtqfWAsXG4gICAgICAgICAgc3ByaXRlOiBbcCwgXCJ0b3duX2RvZ1wiXSxcbiAgICAgICAgICB3YWxrOiBbcCwgXCJ0b3duX2RvZ1wiXSxcbiAgICAgICAgICBoOiAxNCxcbiAgICAgICAgICBsZWdzOiBoZXJvIS5sZWdzLFxuICAgICAgICAgIGZyb206IHBhcnR5RW5kLFxuICAgICAgICAgIHRvOiBJbmZpbml0eSxcbiAgICAgICAgICBsYWc6IDAuOSArIGogKiAwLjYsXG4gICAgICAgICAgZm9sbG93OiBoZXJvISxcbiAgICAgICAgICBwZXQ6IHRydWUsXG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgICBhZGRTdHJlc3MoKTtcbiAgfVxuICAvKiogQ3V0IDEwOTogdGhlIHdhbGtpbmcgdG93bnNmb2xrIChgZm9sa2AgZHJhd3MgdGhlbSBieSBzdGFnZSk6IHRoZSBjaGlsZCdzIGxvb3AgYW5kIHRoZSBjYXJ0ZXIncyByb3VuZCwgc2VlZGVkIGJ5IHRoZSBkYXkgKi9cbiAgbGV0IHRvd25zZm9sazogKFdhbGtlciAmIHsgbWluU3RhZ2U6IG51bWJlciB9KVtdID0gW107XG4gIGZ1bmN0aW9uIGJ1aWxkRm9saygpOiB2b2lkIHtcbiAgICB0b3duc2ZvbGsgPSBbXTtcbiAgICBjb25zdCBsb29wID0gKFxuICAgICAgaWQ6IHN0cmluZyxcbiAgICAgIHNwcml0ZTogc3RyaW5nLFxuICAgICAgaDogbnVtYmVyLFxuICAgICAgc3RvcHM6IHN0cmluZ1tdLFxuICAgICAgc3BlZWQ6IG51bWJlcixcbiAgICAgIHBhdXNlTG86IG51bWJlcixcbiAgICAgIHBhdXNlSGk6IG51bWJlcixcbiAgICAgIG1pblN0YWdlOiBudW1iZXIsXG4gICAgICBjYXJyeT86IHN0cmluZyxcbiAgICApOiB2b2lkID0+IHtcbiAgICAgIGxldCBpID0gMCxcbiAgICAgICAgbiA9IDA7XG4gICAgICBjb25zdCB3OiBXYWxrZXIgJiB7IG1pblN0YWdlOiBudW1iZXIgfSA9IHtcbiAgICAgICAgaWQsXG4gICAgICAgIHNwcml0ZTogW3Nwcml0ZV0sXG4gICAgICAgIHdhbGs6IFtzcHJpdGVdLFxuICAgICAgICBoLFxuICAgICAgICBsZWdzOiBbXSxcbiAgICAgICAgZnJvbTogMCxcbiAgICAgICAgdG86IEluZmluaXR5LFxuICAgICAgICBsYWc6IHJuZyg0MDAgKyBpZC5sZW5ndGgpICogMyxcbiAgICAgICAgbWluU3RhZ2UsXG4gICAgICAgIGNhcnJ5LFxuICAgICAgICBjYXJyeUg6IDE2LFxuICAgICAgICBleHRlbmQ6ICh3dykgPT4ge1xuICAgICAgICAgIGxldCB0dCA9IHd3LmxlZ3MubGVuZ3RoID8gd3cubGVnc1t3dy5sZWdzLmxlbmd0aCAtIDFdIS50MSA6IHJuZyg1MDAgKyBpZC5sZW5ndGgpICogNDtcbiAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IDY7IGorKykge1xuICAgICAgICAgICAgY29uc3QgYSA9IHN0b3BzW2kgJSBzdG9wcy5sZW5ndGhdISxcbiAgICAgICAgICAgICAgYiA9IHN0b3BzWyhpICsgMSkgJSBzdG9wcy5sZW5ndGhdITtcbiAgICAgICAgICAgIGkrKztcbiAgICAgICAgICAgIGNvbnN0IHBhdXNlID0gcGF1c2VMbyArIHJuZyg2MDAgKyBuKysgKyBpZC5sZW5ndGggKiA1MCkgKiAocGF1c2VIaSAtIHBhdXNlTG8pO1xuICAgICAgICAgICAgY29uc3QgYXQgPSBOT0RFU1thXSE7XG4gICAgICAgICAgICB3dy5sZWdzLnB1c2goeyB0MDogdHQsIHQxOiB0dCArIHBhdXNlLCBhOiBhdCwgYjogYXQgfSk7XG4gICAgICAgICAgICB0dCArPSBwYXVzZTtcbiAgICAgICAgICAgIHR0ID0gbGVnc0Fsb25nKHJvdXRlKGEsIGIpLCB0dCwgc3BlZWQsIHd3LmxlZ3MpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgIH07XG4gICAgICB3LmV4dGVuZCEodyk7XG4gICAgICB0b3duc2ZvbGsucHVzaCh3KTtcbiAgICB9O1xuICAgIGxvb3AoXG4gICAgICBcImNoaWxkXCIsXG4gICAgICBcInRvd25fY2hpbGRcIixcbiAgICAgIDE3LFxuICAgICAgW1wiZmlyZVNcIiwgXCJmaXJlV1wiLCBcImZpcmVOXCIsIFwiZmlyZUVcIl0sXG4gICAgICBTUEVFRCAqIDEuMTUsXG4gICAgICAwLjYsXG4gICAgICAyLjUsXG4gICAgICAyLFxuICAgICk7XG4gICAgbG9vcChcbiAgICAgIFwiY2FydGVyXCIsXG4gICAgICBcInRvd25fY2FydGVyXCIsXG4gICAgICAyMyxcbiAgICAgIFtcImV4aXRcIiwgXCJzb3V0aFwiLCBcImtlbm5lbFwiLCBcInNvdXRoXCJdLFxuICAgICAgU1BFRUQgKiAwLjYsXG4gICAgICAyLFxuICAgICAgNixcbiAgICAgIEJVSUxESU5HUy5sZW5ndGgsXG4gICAgICBcInRvd25fY2FydFwiLFxuICAgICk7XG4gIH1cbiAgZnVuY3Rpb24gYWRkU3RyZXNzKCk6IHZvaWQge1xuICAgIHdhbGtlcnMgPSB3YWxrZXJzLmZpbHRlcigodykgPT4gIXcuaWQuc3RhcnRzV2l0aChcInN0cmVzc1wiKSk7XG4gICAgY29uc3QgbmFtZXMgPSBPYmplY3Qua2V5cyhOT0RFUykuZmlsdGVyKCh4KSA9PiB4ICE9PSBcImluXCIgJiYgeCAhPT0gXCJleGl0XCIpLFxuICAgICAgY2xhc3NlcyA9IFtcImZpZ2h0ZXJcIiwgXCJyb2d1ZVwiLCBcInJhbmdlclwiLCBcImNhc3RlclwiXTtcbiAgICBmb3IgKGxldCBqID0gMDsgaiA8IHN0cmVzc047IGorKykge1xuICAgICAgY29uc3QgY2xzID0gY2xhc3Nlc1tqICUgNF0hO1xuICAgICAgbGV0IGF0ID0gbmFtZXNbaiAlIG5hbWVzLmxlbmd0aF0hO1xuICAgICAgbGV0IG0gPSAwO1xuICAgICAgY29uc3QgdzogV2Fsa2VyID0ge1xuICAgICAgICBpZDogYHN0cmVzcyR7an1gLFxuICAgICAgICBzcHJpdGU6IFtgaGVyb18ke2Nsc31gXSxcbiAgICAgICAgd2FsazogW2B3YWxrXyR7Y2xzfWAsIGBoZXJvXyR7Y2xzfWBdLFxuICAgICAgICBoOiAyNCxcbiAgICAgICAgbGVnczogW10sXG4gICAgICAgIGZyb206IHQsXG4gICAgICAgIHRvOiBJbmZpbml0eSxcbiAgICAgICAgbGFnOiAwLFxuICAgICAgICBleHRlbmQ6ICh3dykgPT4ge1xuICAgICAgICAgIGxldCB0dCA9IHd3LmxlZ3MubGVuZ3RoID8gd3cubGVnc1t3dy5sZWdzLmxlbmd0aCAtIDFdIS50MSA6IHQ7XG4gICAgICAgICAgZm9yIChsZXQgcSA9IDA7IHEgPCA2OyBxKyspIHtcbiAgICAgICAgICAgIGNvbnN0IG54ID0gbmFtZXNbaGFzaE4oaiwgbSsrLCA3NykgJSBuYW1lcy5sZW5ndGhdITtcbiAgICAgICAgICAgIGlmIChueCA9PT0gYXQpIGNvbnRpbnVlO1xuICAgICAgICAgICAgd3cubGVncy5wdXNoKHsgdDA6IHR0LCB0MTogdHQgKyAwLjYsIGE6IE5PREVTW2F0XSEsIGI6IE5PREVTW2F0XSEgfSk7XG4gICAgICAgICAgICB0dCA9IGxlZ3NBbG9uZyhyb3V0ZShhdCwgbngpLCB0dCArIDAuNiwgU1BFRUQsIHd3LmxlZ3MpO1xuICAgICAgICAgICAgYXQgPSBueDtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICB9O1xuICAgICAgdy5leHRlbmQhKHcpO1xuICAgICAgd2Fsa2Vycy5wdXNoKHcpO1xuICAgIH1cbiAgfVxuXG4gIC8vIC0tIHRoZSBmcmFtZSAtLVxuICBjb25zdCBwdXNoID0gKFxuICAgIHM6IFNsb3QsXG4gICAgeDogbnVtYmVyLFxuICAgIHk6IG51bWJlcixcbiAgICB6OiBudW1iZXIsXG4gICAgZmxpcCA9IGZhbHNlLFxuICAgIGRpbSA9IDEsXG4gICAgZmFkZSA9IDAsXG4gICAgdyA9IHMudyxcbiAgICBoID0gcy5oLFxuICApOiB2b2lkID0+IHtcbiAgICBsZXQgcSA9IEYucXVhZHNbRi5uXTtcbiAgICBpZiAoIXEpIHtcbiAgICAgIHEgPSB7IHMsIHgsIHksIHosIHcsIGgsIGZsaXAsIGRpbSwgZmFkZSB9O1xuICAgICAgRi5xdWFkc1tGLm5dID0gcTtcbiAgICB9IGVsc2Uge1xuICAgICAgcS5zID0gcztcbiAgICAgIHEueCA9IHg7XG4gICAgICBxLnkgPSB5O1xuICAgICAgcS56ID0gejtcbiAgICAgIHEudyA9IHc7XG4gICAgICBxLmggPSBoO1xuICAgICAgcS5mbGlwID0gZmxpcDtcbiAgICAgIHEuZGltID0gZGltO1xuICAgICAgcS5mYWRlID0gZmFkZTtcbiAgICAgIHEucmVsaWVmID0gMDtcbiAgICB9XG4gICAgRi5uKys7XG4gIH07XG4gIGNvbnN0IHpPZiA9IChmb290WTogbnVtYmVyKTogbnVtYmVyID0+IDEgKyBmb290WSAvIDIwMDA7XG4gIGNvbnN0IGluVmlldyA9ICh4OiBudW1iZXIsIHk6IG51bWJlciwgdzogbnVtYmVyLCBoOiBudW1iZXIpOiBib29sZWFuID0+XG4gICAgeCArIHcgLyAyID49IEYueDAgLSA0ICYmXG4gICAgeCAtIHcgLyAyIDw9IEYueDAgKyBGLncgKyA0ICYmXG4gICAgeSA+PSBGLnkwIC0gNCAmJlxuICAgIHkgLSBoIDw9IEYueTAgKyBGLmggKyA0O1xuICBmdW5jdGlvbiBncm91bmRpbmcoeDogbnVtYmVyLCB5OiBudW1iZXIsIHdpZHRoOiBudW1iZXIsIGhlaWdodDogbnVtYmVyLCBmYWRlID0gMCk6IHZvaWQge1xuICAgIGNvbnN0IGJyb2FkID0gaGVpZ2h0ID49IDM2LFxuICAgICAgdyA9IE1hdGgubWF4KDYsIE1hdGgucm91bmQod2lkdGggKiAoYnJvYWQgPyAwLjc4IDogMC42KSkpO1xuICAgIGNvbnN0IGRlcHRoID0gYnJvYWQgPyBNYXRoLm1pbigxMCwgTWF0aC5tYXgoNSwgTWF0aC5yb3VuZCh3aWR0aCAqIDAuMTMpKSkgOiA0O1xuICAgIGNvbnN0IGNvbnRhY3QgPSBhdGxhcy5zaGFkb3codywgZGVwdGgpO1xuICAgIHB1c2goXG4gICAgICBjb250YWN0LFxuICAgICAgTWF0aC5yb3VuZCh4KSxcbiAgICAgIE1hdGgucm91bmQoeSArIGRlcHRoIC8gMiAtIDEpLFxuICAgICAgMC4yMixcbiAgICAgIGZhbHNlLFxuICAgICAgMSxcbiAgICAgIE1hdGgubWF4KGZhZGUsIEYubmlnaHQgKiAwLjEyKSxcbiAgICApO1xuICAgIC8vIEEgc2hvcnQgY2FzdCBtYXJrIGlzIHZpc2libGUgaW4gZGF5bGlnaHQ7IG92ZXJoZWFkIG1vb25saWdodCBsZWF2ZXMgdGhlXG4gICAgLy8gY29udGFjdCBhbG9uZS4gR3JvdW5kLXBsYW5lIHoga2VlcHMgaXQgYmVoaW5kIGV2ZXJ5IHRyZWUsIHByb3AgYW5kIHBlcnNvbi5cbiAgICBpZiAoRi5uaWdodCA8IDAuODUpIHtcbiAgICAgIGNvbnN0IGNhc3QgPSBhdGxhcy5zaGFkb3coTWF0aC5yb3VuZCh3ICogMS4xNSksIGRlcHRoICsgKGJyb2FkID8gNCA6IDIpKTtcbiAgICAgIHB1c2goXG4gICAgICAgIGNhc3QsXG4gICAgICAgIE1hdGgucm91bmQoeCArIGhlaWdodCAqIDAuMDgpLFxuICAgICAgICBNYXRoLnJvdW5kKHkgKyBjYXN0LmggLSAxKSxcbiAgICAgICAgMC4yMSxcbiAgICAgICAgZmFsc2UsXG4gICAgICAgIDEsXG4gICAgICAgIE1hdGgubWF4KGZhZGUsIDAuNTUgKyBGLm5pZ2h0ICogMC40NSksXG4gICAgICApO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBzcHJpdGUoXG4gICAgaWRzOiBzdHJpbmcgfCBzdHJpbmdbXSxcbiAgICBoOiBudW1iZXIsXG4gICAgeDogbnVtYmVyLFxuICAgIHk6IG51bWJlcixcbiAgICBvOiB7XG4gICAgICBmbGlwPzogYm9vbGVhbjtcbiAgICAgIGRpbT86IG51bWJlcjtcbiAgICAgIGZhZGU/OiBudW1iZXI7XG4gICAgICB6PzogbnVtYmVyO1xuICAgICAgZ3JvdW5kPzogYm9vbGVhbjtcbiAgICAgIGdyb3VuZFk/OiBudW1iZXI7XG4gICAgfSA9IHt9LFxuICApOiB2b2lkIHtcbiAgICBjb25zdCBzID0gYXRsYXMuZ2V0KGlkcywgaCk7XG4gICAgaWYgKCFpblZpZXcoeCwgeSwgcy53LCBzLmgpKSByZXR1cm47XG4gICAgY29uc3QgaWQgPSBBcnJheS5pc0FycmF5KGlkcykgPyBpZHNbMF0hIDogaWRzO1xuICAgIGlmIChcbiAgICAgIG8uZ3JvdW5kID8/XG4gICAgICAvXihoZXJvX3x3YWxrX3x0b3duXyhob3VzZV98YmxhY2tzbWl0aF98YmFua198a2VubmVsX3x3b3JrZXJffHNtaXRoJHxtZXJjaGFudCR8Y2FydGVyJHxjaGlsZCR8Y3JhdGUkfGJvYXJkJHxjYW1wZmlyZV98aGF1bF9jaGVzdHxzdGFsbCR8YmFycmVsJHxicmF6aWVyJHxiZW5jaCR8d2VsbCQpKS8udGVzdChcbiAgICAgICAgaWQsXG4gICAgICApXG4gICAgKSB7XG4gICAgICBncm91bmRpbmcoeCwgby5ncm91bmRZID8/IHksIHMudywgcy5oLCBvLmZhZGUgPz8gMCk7XG4gICAgfVxuICAgIHB1c2gocywgTWF0aC5yb3VuZCh4KSwgTWF0aC5yb3VuZCh5KSwgby56ID8/IHpPZih5KSwgISFvLmZsaXAsIG8uZGltID8/IDEsIG8uZmFkZSA/PyAwKTtcbiAgICAvLyBPbmx5IGV4YWN0LCBkZWNvZGVkIHBhaW50ZWQgcG9zZXMgYXJlIG1hcHBlZC4gRmFsbGJhY2tzIGFuZCBvdGhlciBsb29rc1xuICAgIC8vIHJldGFpbiB0aGVpciBhcnQsIGluY2x1ZGluZyBsb29rLXNwZWNpZmljIGhlcm9lcyB0aGF0IGxhY2sgYSB3YWxrIHBvc2UuXG4gICAgY29uc3QgcmVzb2x2ZWQgPSAoQXJyYXkuaXNBcnJheShpZHMpID8gaWRzIDogW2lkc10pLmZpbmQoKGtleSkgPT4gYXRsYXMuaGFzKGtleSkpO1xuICAgIEYucXVhZHNbRi5uIC0gMV0hLnJlbGllZiA9XG4gICAgICAodG93blZvbHVtZVByb3RvdHlwZSgpID8gdm9sdW1lS2luZChyZXNvbHZlZCkgOiAwKSB8fFxuICAgICAgKHJlc29sdmVkID09PSBcInRvd25fYmxhY2tzbWl0aF8xXCJcbiAgICAgICAgPyAxXG4gICAgICAgIDogcmVzb2x2ZWQgPT09IFwiaGVyb19maWdodGVyXCIgfHxcbiAgICAgICAgICAgIHJlc29sdmVkID09PSBcImhlcm9fZmlnaHRlcl9tYWxlXCIgfHxcbiAgICAgICAgICAgIHJlc29sdmVkID09PSBcIndhbGtfZmlnaHRlclwiXG4gICAgICAgICAgPyAyXG4gICAgICAgICAgOiAwKTtcbiAgfVxuICAvKiogVGVycmFpbiBpcyBpbmRlcGVuZGVudCBvZiB0aGUgc3ByaXRlIGF0bGFzIGFuZCBjYW1lcmEuIE9uZSBiaXRtYXAgcGVyIGNvbnN0cnVjdGlvbiBzdGF0ZS4gKi9cbiAgZnVuY3Rpb24gZ3JvdW5kKCk6IHZvaWQge1xuICAgIGNvbnN0IHMgPSBzdGF0ZSEsXG4gICAgICBrZXkgPSBgJHtzLmhvbWV9fCR7cy5zdGFnZX18JHtob21lU3BvdHMubGVuZ3RofXwkeyhzLnNlcnZpY2VzID8/IFtdKS5qb2luKFwiLFwiKX18JHtzLmJ1aWxkaW5nc1xuICAgICAgICAubWFwKChiKSA9PiBiLmlkKVxuICAgICAgICAuc29ydCgpXG4gICAgICAgIC5qb2luKFwiLFwiKX18JHt0ZXJyYWluTWF0ZXJpYWxWZXJzaW9uKCl9YDtcbiAgICBpZiAoa2V5ID09PSBGLmdyb3VuZEtleSkgcmV0dXJuO1xuICAgIEYuZ3JvdW5kS2V5ID0ga2V5O1xuICAgIGNvbnN0IHN0YW5kaW5nID0gbmV3IFNldChbLi4ucy5idWlsZGluZ3MubWFwKChiKSA9PiBET09SW2IuaWRdKSwgLi4uKHMuc2VydmljZXMgPz8gW10pXSk7XG4gICAgY29uc3Qgc3RhcnRlZCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgIEYudGVycmFpbiA9IHBhaW50VG93blRlcnJhaW4oe1xuICAgICAgd2lkdGg6IE1BUF9XICogVElMRSxcbiAgICAgIGhlaWdodDogTUFQX0ggKiBUSUxFLFxuICAgICAgdHJhaWxzOiBbXG4gICAgICAgIC4uLkVER0VTLmZpbHRlcigoWywgYl0pID0+ICFTUFVSUy5oYXMoYikgfHwgc3RhbmRpbmcuaGFzKGIpKS5tYXAoKFthLCBiLCByXSkgPT4gKHtcbiAgICAgICAgICBhOiBOT0RFU1thXSEsXG4gICAgICAgICAgYjogTk9ERVNbYl0hLFxuICAgICAgICAgIHI6IHIgKiBUSUxFLFxuICAgICAgICB9KSksXG4gICAgICAgIC4uLihzLnNlcnZpY2VzID8/IFtdKVxuICAgICAgICAgIC5maWx0ZXIoKGlkKSA9PiBpZCA9PT0gXCJwb29sXCIgfHwgaWQgPT09IFwiZGV2aWNlXCIpXG4gICAgICAgICAgLmZsYXRNYXAoKGlkKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBwb2ludHMgPSBob21lU3BvdHMubWFwKChzcG90KSA9PiBzcG90W2lkIGFzIFwicG9vbFwiIHwgXCJkZXZpY2VcIl0pO1xuICAgICAgICAgICAgcmV0dXJuIHBvaW50cy5sZW5ndGhcbiAgICAgICAgICAgICAgPyBbXG4gICAgICAgICAgICAgICAgICB7IGE6IE5PREVTW2lkXSEsIGI6IHBvaW50c1swXSEsIHI6IDQgfSxcbiAgICAgICAgICAgICAgICAgIC4uLnBvaW50cy5zbGljZSgxKS5tYXAoKHAsIGkpID0+ICh7IGE6IHBvaW50c1tpXSEsIGI6IHAsIHI6IDQgfSkpLFxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgOiBbXTtcbiAgICAgICAgICB9KSxcbiAgICAgIF0sXG4gICAgICBmaXJlOiBQTE9UUy5maXJlLFxuICAgICAgcGxhemE6IHMuc3RhZ2UgPj0gQlVJTERJTkdTLmxlbmd0aCxcbiAgICAgIGFwcm9uczogW1xuICAgICAgICAuLi4ocy5ob21lID8gW1BMT1RTLmhvdXNlXSA6IFtdKSxcbiAgICAgICAgLi4ucy5idWlsZGluZ3MubWFwKChiKSA9PiBQTE9UU1tiLmlkXSksXG4gICAgICAgIC4uLihzLnNlcnZpY2VzID8/IFtdKS5tYXAoKGlkKSA9PiBQTE9UU1tpZF0pLFxuICAgICAgXSxcbiAgICAgIGhpbGxGb290LFxuICAgICAgc2hhZG93czogdHJlZXMsXG4gICAgfSk7XG4gICAgdGVycmFpblBhaW50TXMgPSBwZXJmb3JtYW5jZS5ub3coKSAtIHN0YXJ0ZWQ7XG4gICAgdGVycmFpblBhaW50cysrO1xuICB9XG4gIGZ1bmN0aW9uIGdyYXNzV2luZCgpOiB2b2lkIHtcbiAgICB3aW5kVHVmdHMgPSAwO1xuICAgIHdpbmRTaWduYXR1cmUgPSAwO1xuICAgIGNvbnN0IGxldmVsID0gZWZmZWN0c0xldmVsKCk7XG4gICAgaWYgKCFGLnRlcnJhaW4gfHwgbGV2ZWwgPT09IFwib2ZmXCIgfHwgbW90aW9uUHJlZmVyZW5jZS5tYXRjaGVzKSByZXR1cm47XG4gICAgY29uc3Qgcm9vdHMgPSB0b3duR3Jhc3NSb290cyhGLnRlcnJhaW4pLFxuICAgICAgc3RyaWRlID0gbGV2ZWwgPT09IFwibG93XCIgPyAzIDogMTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJvb3RzLmxlbmd0aDsgaSArPSBzdHJpZGUpIHtcbiAgICAgIGNvbnN0IHAgPSByb290c1tpXSE7XG4gICAgICBpZiAoIWluVmlldyhwLngsIHAueSwgOCwgcC5oKSkgY29udGludWU7XG4gICAgICAvLyBBIHNoYXJlZCB0cmF2ZWxsaW5nIGd1c3QgcGx1cyBhIHF1aWV0ZXIgbG9jYWwgZmx1dHRlci4gQmFzZXMgbmV2ZXIgbW92ZS5cbiAgICAgIGNvbnN0IGd1c3QgPSBNYXRoLnNpbih0ICogMC44NSAtIHAueCAqIDAuMDI1IC0gcC55ICogMC4wMTMpO1xuICAgICAgY29uc3QgcG9zZSA9IE1hdGgubWF4KFxuICAgICAgICAwLFxuICAgICAgICBNYXRoLm1pbig0LCAyICsgTWF0aC5yb3VuZCgoZ3VzdCAqIDAuOCArIE1hdGguc2luKHQgKiAxLjQgKyBwLnBoYXNlKSAqIDAuMikgKiAyKSksXG4gICAgICApO1xuICAgICAgY29uc3Qgc2xvdCA9IGF0bGFzLmdldChgdG93bl93aW5kX2dyYXNzXyR7cG9zZX1gLCBwLmgpO1xuICAgICAgcHVzaChzbG90LCBwLngsIHAueSwgMC4xLCBmYWxzZSwgMC45LCAwLjI4KTtcbiAgICAgIHdpbmRUdWZ0cysrO1xuICAgICAgd2luZFNpZ25hdHVyZSA9IChNYXRoLmltdWwod2luZFNpZ25hdHVyZSwgMzEpICsgcG9zZSArIGkpID4+PiAwO1xuICAgIH1cbiAgfVxuICAvKiogdGhlIGhpbGwncyBmb290OiBhIHJhZ2dlZCBsaW5lIChydW5zIG9mIHR3byBjb2x1bW5zLCBvbmUgaW4gdGhyZWUsIGEgdGlsZSBmdXJ0aGVyIGRvd24sIG5ldmVyIGJ5IHRoZSBtb3V0aCksIG5vdCBhIHJ1bGVkIGVkZ2UgKi9cbiAgY29uc3QgaGlsbEZvb3QgPSAoeDogbnVtYmVyKTogbnVtYmVyID0+XG4gICAgNSArIE9ZICsgKE1hdGguYWJzKHggLSBDWCkgPiA0ICYmIGhhc2hOKHggPj4gMSwgMCwgNykgJSAzID09PSAwID8gMSA6IDApO1xuICBjb25zdCBoaWxsRGltID0gKHk6IG51bWJlcik6IG51bWJlciA9PiAwLjMgKyAwLjcgKiBNYXRoLnBvdyhNYXRoLm1pbigxLCAoeSArIDEpIC8gKDUgKyBPWSkpLCAxLjYpO1xuICBjb25zdCBET09SOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgIGJsYWNrc21pdGg6IFwic21pdGhcIixcbiAgICBiYW5rOiBcImJhbmtcIixcbiAgICBrZW5uZWw6IFwia2VubmVsXCIsXG4gIH07XG4gIGNvbnN0IFNQVVJTID0gbmV3IFNldChbLi4uT2JqZWN0LnZhbHVlcyhET09SKSwgXCJndWlsZFwiLCBcInBvb2xcIiwgXCJkZXZpY2VcIl0pO1xuICAvKiogdGhlIGZvcmVzdDogdHJlZXMgb24gYSBqaXR0ZXJlZCBncmlkLCBjbGVhcmVkIGZyb20gdGhlIHBhdGhzLCB0aGUgcGxvdHMgYW5kIHRoZSBjbGlmZiAqL1xuICBsZXQgdHJlZXM6IChQdCAmIHsgazogYm9vbGVhbjsgaDogbnVtYmVyOyBkPzogbnVtYmVyIH0pW10gPSBbXTtcbiAgZnVuY3Rpb24gZm9yZXN0KCk6IHZvaWQge1xuICAgIHRyZWVzID0gW107XG4gICAgY29uc3Qga2VlcCA9IChwOiBQdCk6IGJvb2xlYW4gPT4ge1xuICAgICAgaWYgKHAueSA8ICg1LjYgKyBPWSkgKiBUSUxFIHx8IChwLnggPiAoQ1ggLSAxOS44KSAqIFRJTEUgJiYgcC54IDwgKENYIC0gMTYuMikgKiBUSUxFKSlcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgaWYgKFxuICAgICAgICBFREdFUy5zb21lKFxuICAgICAgICAgIChbYSwgYiwgcl0pID0+XG4gICAgICAgICAgICAoIShbXCJndWlsZFwiLCBcInBvb2xcIiwgXCJkZXZpY2VcIl0gYXMgc3RyaW5nW10pLmluY2x1ZGVzKGIpIHx8XG4gICAgICAgICAgICAgIHN0YXRlPy5zZXJ2aWNlcz8uaW5jbHVkZXMoYiBhcyBTZXJ2aWNlSWQpKSAmJlxuICAgICAgICAgICAgc2VnRGlzdChwLCBOT0RFU1thXSEsIE5PREVTW2JdISkgPD0gKHIgKyAwLjkpICogVElMRSxcbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICBpZiAoZGlzdChwLCBQTE9UUy5maXJlKSA8IDMgKiBUSUxFKSByZXR1cm4gZmFsc2U7XG4gICAgICBpZiAoXG4gICAgICAgIFBST1BTLnNvbWUoXG4gICAgICAgICAgKHEpID0+XG4gICAgICAgICAgICBNYXRoLmFicyhwLnggLSBxLngpIDwgMi4yICogVElMRSAmJiBwLnkgPiBxLnkgLSBxLmggKiAwLjYgJiYgcC55IDwgcS55ICsgMS40ICogVElMRSxcbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICBmb3IgKGNvbnN0IGlkIG9mIFtcInBvb2xcIiwgXCJkZXZpY2VcIl0gYXMgY29uc3QpIHtcbiAgICAgICAgaWYgKCFzdGF0ZT8uc2VydmljZXM/LmluY2x1ZGVzKGlkKSkgY29udGludWU7XG4gICAgICAgIGNvbnN0IHBvaW50cyA9IGhvbWVTcG90cy5tYXAoKHNwb3QpID0+IHNwb3RbaWRdKTtcbiAgICAgICAgaWYgKFxuICAgICAgICAgIHBvaW50cy5zb21lKFxuICAgICAgICAgICAgKHNwb3QpID0+IE1hdGguYWJzKHAueCAtIHNwb3QueCkgPCA0MCAmJiBwLnkgPiBzcG90LnkgLSAzMiAmJiBwLnkgPCBzcG90LnkgKyA2NCxcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIGlmIChwb2ludHMuc29tZSgoc3BvdCwgaSkgPT4gc2VnRGlzdChwLCBpID8gcG9pbnRzW2kgLSAxXSEgOiBOT0RFU1tpZF0hLCBzcG90KSA8IDIyKSlcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBpZiAoT2JqZWN0LnZhbHVlcyhGT0xLX0FUKS5zb21lKChxKSA9PiBkaXN0KHAsIHEpIDwgMS42ICogVElMRSkpIHJldHVybiBmYWxzZTtcbiAgICAgIGZvciAoY29uc3QgW2lkLCBwbF0gb2YgT2JqZWN0LmVudHJpZXMoUExPVFMpKSB7XG4gICAgICAgIGlmICgoaWQgPT09IFwiZ3VpbGRcIiB8fCBpZCA9PT0gXCJwb29sXCIgfHwgaWQgPT09IFwiZGV2aWNlXCIpICYmICFzdGF0ZT8uc2VydmljZXM/LmluY2x1ZGVzKGlkKSlcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgY29uc3QgaHcgPVxuICAgICAgICAgIGlkID09PSBcIm1vdXRoXCIgPyA0LjIgKiBUSUxFIDogaWQgPT09IFwiZmlyZVwiIHx8IGlkID09PSBcImNyYXRlXCIgPyAxLjQgKiBUSUxFIDogMy4zICogVElMRTtcbiAgICAgICAgaWYgKE1hdGguYWJzKHAueCAtIHBsLngpIDwgaHcgJiYgcC55ID4gcGwueSAtIHBsLmggKiAwLjU1ICYmIHAueSA8IHBsLnkgKyAxLjYgKiBUSUxFKVxuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH07XG4gICAgZm9yIChsZXQgZ3kgPSA1LjggKyBPWTsgZ3kgPCBNQVBfSDsgZ3kgKz0gMS4zNSlcbiAgICAgIGZvciAobGV0IGd4ID0gMC41OyBneCA8IE1BUF9XOyBneCArPSAxLjI1KSB7XG4gICAgICAgIGNvbnN0IGogPSBoYXNoTihNYXRoLnJvdW5kKGd4ICogMTApLCBNYXRoLnJvdW5kKGd5ICogMTApLCA5KTtcbiAgICAgICAgY29uc3QgcCA9IHtcbiAgICAgICAgICB4OiAoZ3ggKyAoKGogJSAxMDApIC8gMTAwIC0gMC41KSAqIDAuOSkgKiBUSUxFLFxuICAgICAgICAgIHk6IChneSArICgoKGogPj4gOCkgJSAxMDApIC8gMTAwIC0gMC41KSAqIDAuOCkgKiBUSUxFLFxuICAgICAgICB9O1xuICAgICAgICBpZiAoKGogPj4gMTYpICUgMTAwIDwgMTgpIGNvbnRpbnVlO1xuICAgICAgICBpZiAoa2VlcChwKSlcbiAgICAgICAgICB0cmVlcy5wdXNoKHtcbiAgICAgICAgICAgIC4uLnAsXG4gICAgICAgICAgICBrOiAoaiA+PiA0KSAlIDMgPT09IDAsXG4gICAgICAgICAgICBoOiAyNCArIChqICUgNCkgKiA0LFxuICAgICAgICAgICAgZDogMC44OCArICgoaiA+PiA4KSAlIDQpICogMC4wNCxcbiAgICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAvLyBhIHRoaW4gd29vZCB1cCB0aGUgaGlsbHNpZGUgKGRpbW1lZCB3aXRoIHRoZSBzbG9wZSksIGNsZWFyIG9mIHRoZSBtb3V0aDogdGhlIGJhbmQgcmVhZHMgYXMgYSBoaWxsLCBub3QgYSB3YWxsXG4gICAgZm9yIChsZXQgZ3kgPSAyLjI7IGd5IDwgNS40ICsgT1k7IGd5ICs9IDEuNSlcbiAgICAgIGZvciAobGV0IGd4ID0gMC41OyBneCA8IE1BUF9XOyBneCArPSAxLjYpIHtcbiAgICAgICAgY29uc3QgaiA9IGhhc2hOKE1hdGgucm91bmQoZ3ggKiAxMCksIE1hdGgucm91bmQoZ3kgKiAxMCksIDEzKTtcbiAgICAgICAgY29uc3QgcCA9IHtcbiAgICAgICAgICB4OiAoZ3ggKyAoKGogJSAxMDApIC8gMTAwIC0gMC41KSAqIDEuMikgKiBUSUxFLFxuICAgICAgICAgIHk6IChneSArICgoKGogPj4gOCkgJSAxMDApIC8gMTAwIC0gMC41KSAqIDAuOSkgKiBUSUxFLFxuICAgICAgICB9O1xuICAgICAgICBpZiAoKGogPj4gMTYpICUgMTAwIDwgNTUgfHwgTWF0aC5hYnMocC54IC0gUExPVFMubW91dGgueCkgPCA0LjYgKiBUSUxFKSBjb250aW51ZTtcbiAgICAgICAgdHJlZXMucHVzaCh7XG4gICAgICAgICAgLi4ucCxcbiAgICAgICAgICBrOiAoaiA+PiA0KSAlIDIgPT09IDAsXG4gICAgICAgICAgaDogMjQgKyAoaiAlIDQpICogNCxcbiAgICAgICAgICBkOiBoaWxsRGltKHAueSAvIFRJTEUgLSAwLjUpICogMC44NSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgdHJlZXMuc29ydCgoYSwgYikgPT4gYS55IC0gYi55KTtcbiAgfVxuICBmb3Jlc3QoKTtcblxuICBsZXQgZmxpY2tOb3cgPSAxO1xuICAvKiogdGhlIHdhcm0gZW1pdHRlcnMgcGFpbnRlZCBpbnRvIGEgc3ByaXRlIChhcnQvdG93bl9saWdodHMuanNvbjogW2R4LCBkeSwgc3RyZW5ndGhdIGZyb20gaXRzIGZvb3QpLCBhdCBgYmFzZWAgc3RyZW5ndGggYnkgZGF5ICovXG4gIGZ1bmN0aW9uIGVtaXR0ZXJzKFxuICAgIGlkOiBzdHJpbmcsXG4gICAgcDogUHQsXG4gICAgbmlnaHQ6IG51bWJlcixcbiAgICByOiBudW1iZXIsXG4gICAgYmFzZTogbnVtYmVyLFxuICAgIGdhaW4gPSAxLjUsXG4gICAgc2NhbGUgPSAxLFxuICApOiB2b2lkIHtcbiAgICBjb25zdCBMID0gTElHSFRTIGFzIFJlY29yZDxzdHJpbmcsIG51bWJlcltdW10+O1xuICAgIGNvbnN0IGxpc3QgPSBMW2lkXSA/PyBMW2lkLnJlcGxhY2UoL19cXGQkLywgXCJfMVwiKV0gPz8gW107XG4gICAgZm9yIChjb25zdCBbZHgsIGR5LCBrXSBvZiBsaXN0KSB7XG4gICAgICBjb25zdCBhID0gKGJhc2UgKyBuaWdodCAqIGdhaW4pICogKGsgPz8gMSkgKiBmbGlja05vdztcbiAgICAgIGlmIChhIDwgMC4wNCB8fCBGLmxpZ2h0cy5sZW5ndGggPj0gTUFYX0xJR0hUUykgY29udGludWU7XG4gICAgICBGLmxpZ2h0cy5wdXNoKHtcbiAgICAgICAgeDogcC54ICsgZHghICogc2NhbGUsXG4gICAgICAgIHk6IHAueSArIGR5ISAqIHNjYWxlLFxuICAgICAgICByOiByICogKDAuNyArIDAuMyAqIChrID8/IDEpKSArIG5pZ2h0ICogMTIsXG4gICAgICAgIGM6IFsxLjAgKiBhLCAwLjY0ICogYSwgMC4zICogYV0sXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgY29uc3QgY2hhcmFjdGVyTGlnaHRzOiBMaWdodFtdID0gW107XG4gIGZ1bmN0aW9uIGxhbnRlcm4oeDogbnVtYmVyLCB5OiBudW1iZXIsIGZsaXA6IGJvb2xlYW4sIG5pZ2h0OiBudW1iZXIsIGZhZGUgPSAwKTogdm9pZCB7XG4gICAgY29uc3Qgc3RyZW5ndGggPSBNYXRoLm1heCgwLCBNYXRoLm1pbigxLCAobmlnaHQgLSAwLjE1KSAvIDAuNjUpKSAqICgxIC0gZmFkZSk7XG4gICAgaWYgKHN0cmVuZ3RoIDw9IDAgfHwgIWluVmlldyh4LCB5LCAyNCwgMzApKSByZXR1cm47XG4gICAgY29uc3QgbHggPSB4ICsgKGZsaXAgPyAtNiA6IDYpLFxuICAgICAgbHkgPSB5IC0gODtcbiAgICBzcHJpdGUoXCJ0b3duX2xhbnRlcm5cIiwgNSwgbHgsIGx5ICsgMiwgeyB6OiB6T2YoeSkgKyAwLjAwMDQsIGZhZGU6IDEgLSBzdHJlbmd0aCB9KTtcbiAgICBjb25zdCBhID0gc3RyZW5ndGggKiAwLjg1O1xuICAgIGNoYXJhY3RlckxpZ2h0cy5wdXNoKHsgeDogbHgsIHk6IGx5LCByOiAyMywgYzogW2EsIGEgKiAwLjY0LCBhICogMC4zXSB9KTtcbiAgfVxuICAvKiogQ3V0IDEwOTogdGhlIHRvd25zZm9sayDigJQgdGhlIHNtaXRoIGF0IHRoZSBmb3JnZSdzIGRvb3IgZnJvbSB0aGUgZmlyc3QgYnVpbGRpbmcsIGEgY2hpbGQgYWJvdXQgdGhlIGZpcmUgYW5kIHRoZSB3ZWxsIGZyb20gdGhlXG4gICAqICBzZWNvbmQsIHRoZSBtZXJjaGFudCBhdCB0aGUgc3RhbGwgZnJvbSB0aGUgdGhpcmQsIHRoZSBjYXJ0ZXIgdXAgYW5kIGRvd24gdGhlIHNvdXRoIHJvYWQgd2hlbiBhbGwgZmFjaWxpdGllcyBzdGFuZDsgYSBzdGVwIGJvYiwgbm8gd2FsayBmcmFtZXMgKi9cbiAgZnVuY3Rpb24gZm9sayhzOiBUb3duU3RhdGUsIG5pZ2h0OiBudW1iZXIpOiB2b2lkIHtcbiAgICBpZiAoIXMuaG9tZSkgcmV0dXJuO1xuICAgIGNvbnN0IGJvYiA9IChwaDogbnVtYmVyLCByYXRlID0gMS4zKTogbnVtYmVyID0+IE1hdGguZmxvb3IodCAqIHJhdGUgKyBwaCkgJiAxO1xuICAgIGlmIChzLmJ1aWxkaW5ncy5zb21lKChiKSA9PiBiLmlkID09PSBcImJsYWNrc21pdGhcIikpIHtcbiAgICAgIGNvbnN0IHAgPSBGT0xLX0FULnNtaXRoO1xuICAgICAgc3ByaXRlKFwidG93bl9zbWl0aFwiLCAyMywgcC54LCBwLnkgLSBib2IoMC4zLCAyLjIpLCB7IGZsaXA6IGZhbHNlIH0pO1xuICAgICAgbGFudGVybihwLngsIHAueSAtIGJvYigwLjMsIDIuMiksIGZhbHNlLCBuaWdodCk7XG4gICAgfVxuICAgIGlmIChzLnN0YWdlID49IDMpIHtcbiAgICAgIGNvbnN0IHAgPSBGT0xLX0FULm1lcmNoYW50O1xuICAgICAgc3ByaXRlKFwidG93bl9tZXJjaGFudFwiLCAyMiwgcC54LCBwLnkgLSBib2IoMC43LCAwLjkpLCB7IGZsaXA6IHRydWUgfSk7XG4gICAgICBsYW50ZXJuKHAueCwgcC55IC0gYm9iKDAuNywgMC45KSwgdHJ1ZSwgbmlnaHQpO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IHcgb2YgdG93bnNmb2xrKSB7XG4gICAgICBpZiAody5taW5TdGFnZSA+IHMuc3RhZ2UpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgYXQgPSB3YWxrZXJBdCh3LCB0KTtcbiAgICAgIGlmICghYXQpIGNvbnRpbnVlO1xuICAgICAgY29uc3Qgc3RlcCA9IGF0Lm1vdmluZyAmJiAoTWF0aC5mbG9vcih0ICogNiArIHcubGFnKSAmIDEpID09PSAxO1xuICAgICAgc3ByaXRlKHcuc3ByaXRlLCB3LmgsIGF0LngsIGF0LnkgLSAoc3RlcCA/IDEgOiAwKSwgeyBmbGlwOiBhdC5keCA8IC0wLjAxIH0pO1xuICAgICAgbGFudGVybihhdC54LCBhdC55IC0gKHN0ZXAgPyAxIDogMCksIGF0LmR4IDwgLTAuMDEsIG5pZ2h0KTtcbiAgICAgIGlmICh3LmNhcnJ5KVxuICAgICAgICBzcHJpdGUody5jYXJyeSwgdy5jYXJyeUggPz8gMTQsIGF0LnggKyAoYXQuZHggPCAtMC4wMSA/IDEzIDogLTEzKSwgYXQueSwge1xuICAgICAgICAgIGZsaXA6IGF0LmR4IDwgLTAuMDEsXG4gICAgICAgICAgejogek9mKGF0LnkpIC0gMC4wMDAyLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLy8gZmlyZWZsaWVzIGZyb20gZHVzazogYSBkb3plbiBtb3RlcyBkcmlmdGluZyBvdmVyIHRoZSBncmFzcywgZWFjaCBibGlua2luZyBvbiBpdHMgb3duIGJlYXRcbiAgICBpZiAobmlnaHQgPiAwLjM1KVxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAxNDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGh4ID0gaGFzaE4oaSwgMzEpLFxuICAgICAgICAgIGh5ID0gaGFzaE4oaSwgNTcpO1xuICAgICAgICBjb25zdCBieCA9IFBMT1RTLmZpcmUueCArICgoaHggJSAyMDAwKSAvIDEwMDAgLSAxKSAqIDkgKiBUSUxFLFxuICAgICAgICAgIGJ5ID0gUExPVFMuZmlyZS55ICsgKChoeSAlIDIwMDApIC8gMTAwMCAtIDEpICogNyAqIFRJTEU7XG4gICAgICAgIGNvbnN0IHggPSBieCArIE1hdGguc2luKHQgKiAwLjM3ICsgaSkgKiAxMCArIE1hdGguc2luKHQgKiAxLjEgKyBpICogMi4zKSAqIDMsXG4gICAgICAgICAgeSA9IGJ5ICsgTWF0aC5jb3ModCAqIDAuMjkgKyBpICogMS43KSAqIDc7XG4gICAgICAgIGNvbnN0IGJsaW5rID0gTWF0aC5tYXgoMCwgTWF0aC5zaW4odCAqICgwLjggKyAoaHggJSA3KSAvIDEwKSArIGkgKiAxLjkpKTtcbiAgICAgICAgaWYgKGJsaW5rIDwgMC4yNSkgY29udGludWU7XG4gICAgICAgIHNwcml0ZShcImZ4X2RvdF9lOGYwOGFcIiwgMSwgeCwgeSwgeyB6OiAyLjU1LCBmYWRlOiAxIC0gYmxpbmsgfSk7XG4gICAgICAgIGlmIChibGluayA+IDAuOCAmJiBGLmxpZ2h0cy5sZW5ndGggPCBNQVhfTElHSFRTIC0gNClcbiAgICAgICAgICBGLmxpZ2h0cy5wdXNoKHsgeCwgeSwgcjogNywgYzogWzAuNSAqIG5pZ2h0LCAwLjYgKiBuaWdodCwgMC4yNSAqIG5pZ2h0XSB9KTtcbiAgICAgIH1cbiAgfVxuICBmdW5jdGlvbiBjb21wbGV0aW9uR2xpbnQocDogUHQgJiB7IGg6IG51bWJlciB9LCBhdDogbnVtYmVyIHwgdW5kZWZpbmVkKTogdm9pZCB7XG4gICAgaWYgKGF0ID09PSB1bmRlZmluZWQgfHwgdCAtIGF0IDwgQlVJTERfQVNTRU1CTFlfUyB8fCB0IC0gYXQgPj0gQlVJTERfRlhfUykgcmV0dXJuO1xuICAgIGNvbnN0IGcgPSAodCAtIGF0IC0gQlVJTERfQVNTRU1CTFlfUykgLyAoQlVJTERfRlhfUyAtIEJVSUxEX0FTU0VNQkxZX1MpO1xuICAgIHNwcml0ZShcImZ4X2dsaW50XCIsIGVmZmVjdHNMZXZlbCgpID09PSBcImxvd1wiID8gNiA6IDksIHAueCArIDE4LCBwLnkgLSBwLmggKyA4ICsgZyAqIDQsIHtcbiAgICAgIHo6IDMsXG4gICAgICBmYWRlOiBNYXRoLm1heCgwLCBnICogMS4yIC0gMC4yKSxcbiAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBidWlsZGluZ1Nwcml0ZShpZDogQnVpbGRpbmdJZCB8IFwiaG91c2VcIiwgbG9vazogbnVtYmVyKTogdm9pZCB7XG4gICAgY29uc3QgcCA9IFBMT1RTW2lkXSxcbiAgICAgIGF0ID0gYnVpbHRBdC5nZXQoaWQpO1xuICAgIGNvbnN0IGFnZSA9IGF0ID09PSB1bmRlZmluZWQgPyBCVUlMRF9GWF9TIDogdCAtIGF0O1xuICAgIGNvbnN0IGFydCA9IChuOiBudW1iZXIpOiBzdHJpbmdbXSA9PiBbYHRvd25fJHtpZH1fJHtufWAsIGB0b3duXyR7aWR9XzFgXTtcbiAgICBpZiAoYXQgPT09IHVuZGVmaW5lZCB8fCBhZ2UgPj0gQlVJTERfQVNTRU1CTFlfUykgc3ByaXRlKGFydChsb29rKSwgcC5oLCBwLngsIHAueSk7XG4gICAgZWxzZSB7XG4gICAgICBjb25zdCBvbGRMb29rID0gdXBncmFkZUZyb20uZ2V0KGlkKTtcbiAgICAgIGlmIChvbGRMb29rICE9PSB1bmRlZmluZWQpIHNwcml0ZShhcnQob2xkTG9vayksIHAuaCwgcC54LCBwLnkpO1xuICAgICAgZWxzZSBzcHJpdGUoXCJ0b3duX3Bsb3RcIiwgMTYsIHAueCwgcC55KTtcbiAgICAgIGNvbnN0IHJldmVhbCA9IE1hdGgubWF4KDAsIE1hdGgubWluKDEsIChhZ2UgLSAwLjYpIC8gMC42KSk7XG4gICAgICBzcHJpdGUoXCJ0b3duX3NjYWZmb2xkXCIsIG9sZExvb2sgIT09IHVuZGVmaW5lZCA/IDI4IDogcC5oLCBwLngsIHAueSwge1xuICAgICAgICBmYWRlOiByZXZlYWwsXG4gICAgICAgIGdyb3VuZDogdHJ1ZSxcbiAgICAgIH0pO1xuICAgICAgaWYgKHJldmVhbCA+IDApIHNwcml0ZShhcnQobG9vayksIHAuaCwgcC54LCBwLnksIHsgZmFkZTogMSAtIHJldmVhbCB9KTtcbiAgICB9XG4gICAgY29tcGxldGlvbkdsaW50KHAsIGF0KTtcbiAgfVxuICBmdW5jdGlvbiBmcmFtZSgpOiB2b2lkIHtcbiAgICBjb25zdCBzID0gc3RhdGUhO1xuICAgIGlmICghYnVpbGRGeEVuYWJsZWQoKSkge1xuICAgICAgYnVpbHRBdC5jbGVhcigpO1xuICAgICAgdXBncmFkZUZyb20uY2xlYXIoKTtcbiAgICAgIGR1c3RlZC5jbGVhcigpO1xuICAgICAgZm9yIChsZXQgaSA9IHBhcnRzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBpZiAocGFydHNbaV0hLmtpbmQgPT09IFwiZHVzdFwiKSBwYXJ0cy5zcGxpY2UoaSwgMSk7XG4gICAgfSBlbHNlXG4gICAgICBmb3IgKGNvbnN0IFtpZCwgYXRdIG9mIGJ1aWx0QXQpXG4gICAgICAgIGlmICh0IC0gYXQgPj0gQlVJTERfRlhfUykge1xuICAgICAgICAgIGJ1aWx0QXQuZGVsZXRlKGlkKTtcbiAgICAgICAgICB1cGdyYWRlRnJvbS5kZWxldGUoaWQpO1xuICAgICAgICAgIGR1c3RlZC5kZWxldGUoaWQpO1xuICAgICAgICB9XG4gICAgRi5uID0gMDtcbiAgICBGLmxpZ2h0cy5sZW5ndGggPSAwO1xuICAgIGNoYXJhY3RlckxpZ2h0cy5sZW5ndGggPSAwO1xuICAgIGNvbnN0IGhvdXIgPSBob3VyT3ZlcnJpZGUgPz8gbG9jYWxIb3VyKCk7XG4gICAgRi5uaWdodCA9IG5pZ2h0T2YoaG91cik7XG4gICAgRi5hbWIgPSBhbWJpZW50T2YoRi5uaWdodCk7XG4gICAgY29uc3QgbmlnaHQgPSBGLm5pZ2h0O1xuICAgIGdyb3VuZCgpO1xuICAgIGdyYXNzV2luZCgpO1xuICAgIC8vIHRyZWVzICh0d28ga2luZHMpLCB0aGUgY2xpZmYncyByaW0gb2YgdHJlZXNcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRyZWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBwID0gdHJlZXNbaV0hLFxuICAgICAgICBzbCA9IGF0bGFzLmdldChwLmsgPyBcInRvd25fZW52X3RyZWVfMVwiIDogXCJ0b3duX2Vudl90cmVlXzBcIiwgcC5oKTtcbiAgICAgIGlmIChpblZpZXcocC54LCBwLnksIHNsLncsIHNsLmgpKVxuICAgICAgICBwdXNoKHNsLCBNYXRoLnJvdW5kKHAueCksIE1hdGgucm91bmQocC55KSwgek9mKHAueSksIGZhbHNlLCBwLmQgPz8gMSk7XG4gICAgfVxuICAgIC8vIHRoZSBtb3V0aCwgaXRzIHRvcmNoZXMsIHRoZSBkZXB0aCBwbGFxdWUncyBsaWdodFxuICAgIGNvbnN0IG0gPSBQTE9UUy5tb3V0aDtcbiAgICBzcHJpdGUoW1widG93bl9tb3V0aF9jYXZlXCJdLCBtLmgsIG0ueCwgbS55KTtcbiAgICBjb25zdCBmbCA9IE1hdGguZmxvb3IodCAqIDYpICYgMTtcbiAgICB2b2lkIGZsO1xuICAgIGVtaXR0ZXJzKFwidG93bl9tb3V0aF9jYXZlXCIsIG0sIG5pZ2h0LCAzMCwgMC41LCAwLjcpOyAvLyB0aGUgdG9yY2hlcyBhIHN0ZXAgdW5kZXIgdGhlIHdpbmRvd3MgYW5kIHRoZSBmaXJlIChhdCAxLjUgdGhlIG1vdXRoIHJlYWQgYWJsYXplKVxuICAgIC8vIHRoZSBjYW1wOiB0aGUgZmlyZSwgdGhlIHRlbnQsIHRoZSBjcmF0ZVxuICAgIGNvbnN0IGYgPSBQTE9UUy5maXJlO1xuICAgIGlmIChzLmhvbWUpXG4gICAgICBzcHJpdGUoW2B0b3duX2NhbXBmaXJlXyR7TWF0aC5mbG9vcih0ICogNSkgJiAxfWAsIFwidG93bl9jYW1wZmlyZV8wXCJdLCBmLmgsIGYueCwgZi55KTtcbiAgICBjb25zdCBmbGljayA9IDAuOSArIDAuMSAqIE1hdGguc2luKHQgKiAxMSkgKiBNYXRoLnNpbih0ICogMy43KTtcbiAgICBpZiAocy5ob21lKVxuICAgICAgRi5saWdodHMucHVzaCh7XG4gICAgICAgIHg6IGYueCxcbiAgICAgICAgeTogZi55IC0gOCxcbiAgICAgICAgcjogKDQ2ICsgbmlnaHQgKiA0NCkgKiBmbGljayxcbiAgICAgICAgYzogWzEuMCwgMC42LCAwLjI2XS5tYXAoKHYpID0+IHYgKiAoMC40NSArIG5pZ2h0ICogMS41KSAqIGZsaWNrKSBhcyBbXG4gICAgICAgICAgbnVtYmVyLFxuICAgICAgICAgIG51bWJlcixcbiAgICAgICAgICBudW1iZXIsXG4gICAgICAgIF0sXG4gICAgICB9KTtcbiAgICBmbGlja05vdyA9IGZsaWNrO1xuICAgIGlmIChzLmhvbWUpIHtcbiAgICAgIGNvbnN0IHAgPSBQTE9UUy5ob3VzZSxcbiAgICAgICAgbG9vayA9IGhvdXNlTG9vayhzKTtcbiAgICAgIGJ1aWxkaW5nU3ByaXRlKFwiaG91c2VcIiwgbG9vayk7XG4gICAgICBlbWl0dGVycyhgdG93bl9ob3VzZV8ke2xvb2t9YCwgcCwgbmlnaHQsIDE2LCAwLCAxLjMsIHAuaCAvIDY0KTtcbiAgICB9XG4gICAgaWYgKHMuaG9tZSAmJiBuaWdodCA+IDAuMylcbiAgICAgIEYubGlnaHRzLnB1c2goeyB4OiBQTE9UUy50ZW50LngsIHk6IFBMT1RTLnRlbnQueSAtIDYsIHI6IDE0LCBjOiBbMC45LCAwLjU1LCAwLjI1XSB9KTtcbiAgICBpZiAocy5ob21lKSBzcHJpdGUoXCJ0b3duX2NyYXRlXCIsIFBMT1RTLmNyYXRlLmgsIFBMT1RTLmNyYXRlLngsIFBMT1RTLmNyYXRlLnkpO1xuICAgIC8vIEN1dCAxMDk6IHRoZSBkcmVzc2luZyB0aGUgc3RhZ2UgaGFzIGVhcm5lZCwgdGhlIGxhbXBzIGxpdCBhdCBkdXNrXG4gICAgZm9yIChjb25zdCBxIG9mIFBST1BTKSB7XG4gICAgICBpZiAocS5zdGFnZSA+IHMuc3RhZ2UgfHwgKCFzLmhvbWUgJiYgcS5zdGFnZSA9PT0gMCkpIGNvbnRpbnVlO1xuICAgICAgc3ByaXRlKHEuaWQsIHEuaCwgcS54LCBxLnksIHsgZmxpcDogcS5mbGlwIH0pO1xuICAgICAgaWYgKHEubGFtcCAmJiBuaWdodCA+IDAuMTUgJiYgRi5saWdodHMubGVuZ3RoIDwgTUFYX0xJR0hUUykge1xuICAgICAgICBjb25zdCBhID0gKDAuMiArIG5pZ2h0ICogMS4wNSkgKiBmbGlja05vdztcbiAgICAgICAgRi5saWdodHMucHVzaCh7XG4gICAgICAgICAgeDogcS54IC0gMixcbiAgICAgICAgICB5OiBxLnkgLSBxLmggKiAwLjc4LFxuICAgICAgICAgIHI6IDIwICsgbmlnaHQgKiAxMCxcbiAgICAgICAgICBjOiBbMS4wICogYSwgMC42NiAqIGEsIDAuMzIgKiBhXSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpZiAocS5pZCA9PT0gXCJ0b3duX3N0YWxsXCIpIGVtaXR0ZXJzKFwidG93bl9zdGFsbFwiLCBxLCBuaWdodCwgMTIsIDAsIDAuNiwgcS5oIC8gNDApO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGlkIG9mIHMuc2VydmljZXMgPz8gW10pIHtcbiAgICAgIGNvbnN0IHAgPSBTRVJWSUNFX1BMT1RTW2lkXTtcbiAgICAgIGNvbnN0IHJlaW5jYXJuYXRpbmcgPVxuICAgICAgICBpZCA9PT0gXCJkZXZpY2VcIiAmJiBzLnJlc2lkZW50cz8uc29tZSgocikgPT4gci5waGFzZSA9PT0gXCJyZWluY2FybmF0aW5nXCIpO1xuICAgICAgY29uc3QgYW5pbWF0ZSA9ICFtb3Rpb25QcmVmZXJlbmNlLm1hdGNoZXMgJiYgZWZmZWN0c0xldmVsKCkgIT09IFwib2ZmXCI7XG4gICAgICBjb25zdCBzcHJpdGVJZCA9XG4gICAgICAgIGlkID09PSBcImRldmljZVwiICYmIHJlaW5jYXJuYXRpbmdcbiAgICAgICAgICA/IGB0b3duX3NlcnZpY2VfZGV2aWNlX2FjdGl2ZV8ke2FuaW1hdGUgPyBNYXRoLmZsb29yKHQgKiAyKSAmIDEgOiAwfWBcbiAgICAgICAgICA6IGB0b3duX3NlcnZpY2VfJHtpZH1gO1xuICAgICAgc3ByaXRlKHNwcml0ZUlkLCBwLmgsIHAueCwgcC55LCB7IGdyb3VuZDogdHJ1ZSB9KTtcbiAgICAgIGlmIChpZCA9PT0gXCJwb29sXCIpIHtcbiAgICAgICAgZm9yIChjb25zdCBzcG90IG9mIGhvbWVTcG90cylcbiAgICAgICAgICBzcHJpdGUoXCJ0b3duX2JlbmNoXCIsIDgsIHNwb3QucG9vbC54LCBzcG90LnBvb2wueSArIDIsIHsgZ3JvdW5kOiB0cnVlIH0pO1xuICAgICAgICBpZiAoYW5pbWF0ZSkge1xuICAgICAgICAgIGNvbnN0IHdhdmVzID0gZWZmZWN0c0xldmVsKCkgPT09IFwibG93XCIgPyAxIDogMjtcbiAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHdhdmVzOyBpKyspXG4gICAgICAgICAgICBzcHJpdGUoXG4gICAgICAgICAgICAgIFwiZnhfZG90X2E0YmNkNlwiLFxuICAgICAgICAgICAgICAxLFxuICAgICAgICAgICAgICBwLnggLSAxMCArIGkgKiAxOCArIE1hdGgucm91bmQoTWF0aC5zaW4odCAqIDAuNyArIGkpICogMiksXG4gICAgICAgICAgICAgIHAueSAtIDEwICsgaSAqIDMsXG4gICAgICAgICAgICAgIHsgejogek9mKHAueSkgKyAwLjAwMDEsIGZhZGU6IDAuNSB9LFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGlkID09PSBcImRldmljZVwiKVxuICAgICAgICBmb3IgKGNvbnN0IHNwb3Qgb2YgaG9tZVNwb3RzKVxuICAgICAgICAgIHNwcml0ZShcInRvd25fc2VydmljZV9zdGF0aW9uXCIsIDYsIHNwb3QuZGV2aWNlLngsIHNwb3QuZGV2aWNlLnkgKyAyLCB7IGdyb3VuZDogdHJ1ZSB9KTtcbiAgICAgIGlmIChuaWdodCA+IDAuMTUgJiYgRi5saWdodHMubGVuZ3RoIDwgTUFYX0xJR0hUUykge1xuICAgICAgICBjb25zdCBseCA9IGlkID09PSBcImd1aWxkXCIgPyBwLnggKyAxNyA6IGlkID09PSBcImRldmljZVwiID8gcC54ICsgMTYgOiBwLnggLSAyNTtcbiAgICAgICAgY29uc3QgbHkgPSBpZCA9PT0gXCJndWlsZFwiID8gcC55IC0gMjAgOiBpZCA9PT0gXCJkZXZpY2VcIiA/IHAueSAtIDkgOiBwLnkgLSA2O1xuICAgICAgICBpZiAoaWQgPT09IFwicG9vbFwiKSBzcHJpdGUoXCJ0b3duX2xhbnRlcm5cIiwgOCwgbHgsIGx5LCB7IGdyb3VuZDogdHJ1ZSB9KTtcbiAgICAgICAgY29uc3QgYSA9IG5pZ2h0ICogMC40MjtcbiAgICAgICAgRi5saWdodHMucHVzaCh7IHg6IGx4LCB5OiBseSwgcjogaWQgPT09IFwicG9vbFwiID8gMTIgOiAxNywgYzogW2EsIDAuNjQgKiBhLCAwLjMgKiBhXSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgZm9sayhzLCBuaWdodCk7XG4gICAgaWYgKHMuYm9hcmQpIHNwcml0ZShcInRvd25fYm9hcmRcIiwgUExPVFMuYm9hcmQuaCwgUExPVFMuYm9hcmQueCwgUExPVFMuYm9hcmQueSk7XG4gICAgLy8gdGhlIGJ1aWxkaW5nczogc2NhZmZvbGQg4oaSIGJ1aWx0IChkdXN0LCBhIGdsaW50KVxuICAgIGZvciAoY29uc3QgYiBvZiBzLmJ1aWxkaW5ncykge1xuICAgICAgY29uc3QgcCA9IFBMT1RTW2IuaWRdO1xuICAgICAgYnVpbGRpbmdTcHJpdGUoYi5pZCwgYi5sb29rKTtcbiAgICAgIC8vIHRoZSBwYWludGVkIGVtaXR0ZXJzIChhcnQvdG93bl9saWdodHMuanNvbjogdGhlIGZvcmdlJ3MgbW91dGgsIGxpdCB3aW5kb3dzKTogdGhlIGZvcmdlIGFsd2F5cywgdGhlIHdpbmRvd3MgYXQgbmlnaHRcbiAgICAgIGVtaXR0ZXJzKFxuICAgICAgICBgdG93bl8ke2IuaWR9XyR7Yi5sb29rfWAsXG4gICAgICAgIHAsXG4gICAgICAgIG5pZ2h0LFxuICAgICAgICBiLmlkID09PSBcImJsYWNrc21pdGhcIiA/IDI2IDogMTgsXG4gICAgICAgIGIuaWQgPT09IFwiYmxhY2tzbWl0aFwiID8gMC4zNSA6IDAsXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAocy5zdGFrZWQpIHtcbiAgICAgIGNvbnN0IHAgPSBQTE9UU1tzLnN0YWtlZC5pZF07XG4gICAgICAvLyBSZWFkeSBwbG90cyB1c2UgdGhlIGxhcmdlciBwYWludGVkIGZvdW5kYXRpb24gaW4gdGhlIFVJIG92ZXJsYXkuXG4gICAgICBpZiAoIXMuc3Rha2VkLnJlYWR5ICYmIHMuc3Rha2VkLmlkICE9PSBcImhvdXNlXCIpIHNwcml0ZShcInRvd25fcGxvdFwiLCAxNiwgcC54LCBwLnkpO1xuICAgIH1cbiAgICAvLyBDdXQgMzAuNTogdGhlIGhhdWwgY2hlc3QgYnkgdGhlIG1vdXRoIOKAlCBmdWxsLCBpdCBob3BzIGFuZCBnbGludHM7IG9wZW4sIHRoZSBsaWQgdXAgYSBtb21lbnQgYWZ0ZXIgdGhlIHRhcFxuICAgIGlmIChzLmNoZXN0KSB7XG4gICAgICBjb25zdCBjID0gQ0hFU1RfQVQsXG4gICAgICAgIHN0ID0gcy5jaGVzdC5zdGF0ZSxcbiAgICAgICAgZnVsbCA9IHN0ID09PSBcImZ1bGxcIjtcbiAgICAgIGNvbnN0IGhvcCA9IGZ1bGwgPyAtTWF0aC5yb3VuZChNYXRoLm1heCgwLCBNYXRoLnNpbih0ICogNCkpICogMikgOiAwO1xuICAgICAgc3ByaXRlKFxuICAgICAgICBbYHRvd25faGF1bF9jaGVzdCR7c3QgPT09IFwiY2xvc2VkXCIgPyBcIlwiIDogYF8ke3N0fWB9YCwgXCJ0b3duX2hhdWxfY2hlc3RcIl0sXG4gICAgICAgIGMuaCxcbiAgICAgICAgYy54LFxuICAgICAgICBjLnkgKyBob3AsXG4gICAgICApO1xuICAgICAgaWYgKGZ1bGwpIHtcbiAgICAgICAgY29uc3QgZyA9ICh0ICogMC43KSAlIDE7XG4gICAgICAgIHNwcml0ZShcImZ4X2dsaW50XCIsIDcsIGMueCArIDUsIGMueSAtIGMuaCArIDEgKyBob3AsIHtcbiAgICAgICAgICB6OiAzLFxuICAgICAgICAgIGZhZGU6IE1hdGgubWluKDEsIE1hdGguYWJzKGcgLSAwLjUpICogMi40KSxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChGLmxpZ2h0cy5sZW5ndGggPCBNQVhfTElHSFRTKVxuICAgICAgICAgIEYubGlnaHRzLnB1c2goeyB4OiBjLngsIHk6IGMueSAtIDYsIHI6IDE0ICsgbmlnaHQgKiA4LCBjOiBbMC45LCAwLjcyLCAwLjNdIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICAvLyBDdXQgMzAuNTogdGhlIHdvcmtlcnMgYXQgdGhlaXIgcG9zdHMg4oCUIGFuIGlkbGUgYmVhdCAodHdvIGZyYW1lcywgZGVzeW5jaHJvbmlzZWQpOyB0aGUgbGl0IG5vZGUncyB3b3JrZXIgZ3JleWVkLCBzdGlsbDsgYSBuZXcgaGlyZVxuICAgIC8vIHdhbGtzIG91dCBvZiB0aGUgdGVudCB0byBoaXMgcG9zdFxuICAgIGZvciAoY29uc3QgdyBvZiBzLndvcmtlcnMpIHtcbiAgICAgIGNvbnN0IHAgPSB3b3JrZXJBdCh3KTtcbiAgICAgIGlmICghcCkgY29udGludWU7XG4gICAgICBsZXQgeCA9IHAueCxcbiAgICAgICAgeSA9IHAueSxcbiAgICAgICAgbW92aW5nID0gZmFsc2UsXG4gICAgICAgIGZsaXAgPSBmYWxzZTtcbiAgICAgIGNvbnN0IGxlZ3MgPSBhcnJpdmUuZ2V0KHcuaWQpO1xuICAgICAgaWYgKGxlZ3M/Lmxlbmd0aCkge1xuICAgICAgICBjb25zdCBhdCA9IHdhbGtlckF0KHsgbGVncywgZnJvbTogbGVnc1swXSEudDAsIHRvOiBJbmZpbml0eSB9IGFzIFdhbGtlciwgdCk7XG4gICAgICAgIGlmIChhdCAmJiB0IDwgbGVnc1tsZWdzLmxlbmd0aCAtIDFdIS50MSkge1xuICAgICAgICAgIHggPSBhdC54O1xuICAgICAgICAgIHkgPSBhdC55O1xuICAgICAgICAgIG1vdmluZyA9IGF0Lm1vdmluZztcbiAgICAgICAgICBmbGlwID0gYXQuZHggPCAtMC4wMTtcbiAgICAgICAgfSBlbHNlIGFycml2ZS5kZWxldGUody5pZCk7XG4gICAgICB9XG4gICAgICBjb25zdCBrID0gaGFzaE4ody5pZC5sZW5ndGgsIHcuaWQuY2hhckNvZGVBdCgwKSwgdy5pZC5jaGFyQ29kZUF0KHcuaWQubGVuZ3RoIC0gMSkpO1xuICAgICAgY29uc3QgYmVhdCA9IDAuOSArIChrICUgNTApIC8gMTAwLFxuICAgICAgICBwaGFzZSA9IChrICUgOTcpIC8gMzE7XG4gICAgICBjb25zdCBzdGVwID0gbW92aW5nICYmIChNYXRoLmZsb29yKHQgKiA2LjUpICYgMSkgPT09IDE7XG4gICAgICBjb25zdCBmcmFtZU4gPSB3LmxpdCB8fCBtb3ZpbmcgPyAwIDogTWF0aC5mbG9vcigodCArIHBoYXNlKSAvIGJlYXQpICYgMTtcbiAgICAgIGlmICh3LmxpdCkge1xuICAgICAgICBjb25zdCBnID0gYXRsYXMuZ3JleSh3b3JrZXJJZHMody5pZCksIDI0KTtcbiAgICAgICAgaWYgKGluVmlldyh4LCB5LCBnLncsIGcuaCkpIHtcbiAgICAgICAgICBncm91bmRpbmcoeCwgeSwgZy53LCBnLmgpO1xuICAgICAgICAgIHB1c2goZywgTWF0aC5yb3VuZCh4KSwgTWF0aC5yb3VuZCh5KSwgek9mKHkpLCBmbGlwLCAxLCAwKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlXG4gICAgICAgIHNwcml0ZSh3b3JrZXJJZHMody5pZCwgZnJhbWVOKSwgMjQsIHgsIHkgLSAoc3RlcCA/IDEgOiAwKSwge1xuICAgICAgICAgIGZsaXAsXG4gICAgICAgICAgZGltOiB3LnBhdXNlZCA/IDAuNyA6IDEsXG4gICAgICAgIH0pO1xuICAgICAgLy8gd2VlayAyOiBoaXMgcmFuaywgcXVpZXQg4oCUIGEgZ2lsdCBwaXAgb3ZlciBoaXMgaGVhZCBwZXIgcmFuayBwYXN0IHRoZSBmaXJzdCAoSUkgwrcsIElJSSDCt8K3KVxuICAgICAgaWYgKCF3LmxpdCAmJiB3LnJhbmsgPiAxKVxuICAgICAgICBmb3IgKGxldCByID0gMDsgciA8IHcucmFuayAtIDE7IHIrKylcbiAgICAgICAgICBzcHJpdGUoXCJmeF9kb3RfZDhiNDVhXCIsIDIsIHggLSAody5yYW5rIC0gMikgKiAxLjUgKyByICogMywgeSAtIDI2IC0gKHN0ZXAgPyAxIDogMCksIHtcbiAgICAgICAgICAgIHo6IHpPZih5KSArIDAuMDAwMyxcbiAgICAgICAgICB9KTtcbiAgICAgIGlmICghdy5saXQpIGxhbnRlcm4oeCwgeSAtIChzdGVwID8gMSA6IDApLCBmbGlwLCBuaWdodCk7XG4gICAgfVxuICAgIC8vIHRoZSBwZW46IHBlbm5lZCBwZXRzIGxpZSBieSB0aGUga2VubmVsXG4gICAgcy5wZW5uZWQuZm9yRWFjaCgoaywgaikgPT4ge1xuICAgICAgY29uc3QgcCA9IFBMT1RTLmtlbm5lbDtcbiAgICAgIHNwcml0ZShbaywgXCJ0b3duX2RvZ1wiXSwgMTAsIHAueCAtIDIwICsgaiAqIDEyLCBwLnkgKyA4LCB7IGZsaXA6IGogJSAyID09PSAxLCBncm91bmQ6IHRydWUgfSk7XG4gICAgfSk7XG4gICAgLy8gd2Fsa2Vyc1xuICAgIGxldCBsaXZlID0gMDtcbiAgICBmb3IgKGNvbnN0IHcgb2Ygd2Fsa2Vycykge1xuICAgICAgY29uc3QgYXQgPSB3LmZvbGxvdyA/IHdhbGtlckF0KHcuZm9sbG93LCB0IC0gdy5sYWcpIDogd2Fsa2VyQXQodywgdCk7XG4gICAgICBpZiAoIWF0IHx8ICh3LmZvbGxvdyAmJiB0IDwgdy5mcm9tKSB8fCB0ID4gdy50bykgY29udGludWU7XG4gICAgICBjb25zdCBvZmZzZXQgPSAody5mb2xsb3cgPz8gdykuaG9tZU9mZnNldDtcbiAgICAgIGxldCB4ID0gYXQueCArIChvZmZzZXQ/LnggPz8gMCksXG4gICAgICAgIHkgPSBhdC55ICsgKG9mZnNldD8ueSA/PyAwKTtcbiAgICAgIGlmICh3LmZvbGxvdyAmJiBhdC5tb3ZpbmcpIHtcbiAgICAgICAgeCAtPSBNYXRoLnNpZ24oYXQuZHgpICogNDtcbiAgICAgICAgeSArPSAyO1xuICAgICAgfVxuICAgICAgY29uc3QgZmxpcCA9IGF0LmR4IDwgLTAuMDE7XG4gICAgICBsZXQgZmFkZSA9IDA7XG4gICAgICBpZiAody5lbWVyZ2UpIHtcbiAgICAgICAgY29uc3QgYWdlID0gdCAtIHcuZnJvbTtcbiAgICAgICAgaWYgKGFnZSA8IDAuNSkgZmFkZSA9IDEgLSBhZ2UgLyAwLjU7XG4gICAgICB9XG4gICAgICBpZiAody52YW5pc2ggJiYgdy50byAtIHQgPCAwLjUpIGZhZGUgPSBNYXRoLm1heChmYWRlLCAxIC0gKHcudG8gLSB0KSAvIDAuNSk7XG4gICAgICBpZiAodyA9PT0gaGVybyAmJiB3YWxraW5nSW4pIHtcbiAgICAgICAgY29uc3QgZyA9ICh0IC0gd2Fsa2luZ0luLnQwKSAvICh3YWxraW5nSW4udDEgLSB3YWxraW5nSW4udDApO1xuICAgICAgICBpZiAoZyA+IDAuNzUpIGZhZGUgPSBNYXRoLm1pbigxLCAoZyAtIDAuNzUpICogNCk7XG4gICAgICB9XG4gICAgICBpZiAody5yZWluY2FybmF0aW5nKVxuICAgICAgICBmYWRlID0gTWF0aC5tYXgoXG4gICAgICAgICAgZmFkZSxcbiAgICAgICAgICBtb3Rpb25QcmVmZXJlbmNlLm1hdGNoZXMgfHwgZWZmZWN0c0xldmVsKCkgPT09IFwib2ZmXCJcbiAgICAgICAgICAgID8gMC4zNVxuICAgICAgICAgICAgOiAwLjMgKyBNYXRoLnNpbih0ICogMikgKiAwLjEyLFxuICAgICAgICApO1xuICAgICAgY29uc3Qgc3RlcCA9IGF0Lm1vdmluZyAmJiAoTWF0aC5mbG9vcih0ICogNi41ICsgdy5sYWcgKiAzKSAmIDEpID09PSAxO1xuICAgICAgY29uc3QgaWRzID0gc3RlcCA/IHcud2FsayA6IHcuc3ByaXRlO1xuICAgICAgY29uc3QgcHJldmlvdXNRdWFkcyA9IEYubjtcbiAgICAgIGNvbnN0IG1hcHBlZEhlcm8gPVxuICAgICAgICB3LnNwcml0ZVswXSA9PT0gXCJoZXJvX2ZpZ2h0ZXJcIiB8fFxuICAgICAgICB3LnNwcml0ZVswXSA9PT0gXCJoZXJvX2ZpZ2h0ZXJfbWFsZVwiIHx8XG4gICAgICAgICh0b3duVm9sdW1lUHJvdG90eXBlKCkgJiYgdm9sdW1lS2luZCh3LnNwcml0ZVswXSkgPT09IDUpO1xuICAgICAgc3ByaXRlKGlkcywgdy5oLCB4LCB5IC0gKHN0ZXAgPyAxIDogMCksIHtcbiAgICAgICAgZmxpcCxcbiAgICAgICAgZmFkZSxcbiAgICAgICAgZ3JvdW5kOiB0cnVlLFxuICAgICAgICBncm91bmRZOiB0b3duTGlnaHRQcm90b3R5cGUoKSAmJiBtYXBwZWRIZXJvID8geSA6IHVuZGVmaW5lZCxcbiAgICAgIH0pO1xuICAgICAgaWYgKEYubiA+IHByZXZpb3VzUXVhZHMgJiYgIW1hcHBlZEhlcm8pIEYucXVhZHNbRi5uIC0gMV0hLnJlbGllZiA9IDA7XG4gICAgICBpZiAoIXcucGV0KSBsYW50ZXJuKHgsIHkgLSAoc3RlcCA/IDEgOiAwKSwgZmxpcCwgbmlnaHQsIGZhZGUpO1xuICAgICAgaWYgKHcuY2FycnkpIHtcbiAgICAgICAgY29uc3QgYmFjayA9IChmbGlwID8gLTEgOiAxKSAqICh3LmNhcnJ5ID09PSBcInRvd25fY2hlc3RfZ2xvd1wiID8gNiA6IDcpO1xuICAgICAgICBzcHJpdGUody5jYXJyeSwgdy5jYXJyeUggPz8gNiwgeCArIGJhY2ssIHkgLSA4ICsgKHcuY2FycnlIID8/IDYpIC0gKHN0ZXAgPyAxIDogMCksIHtcbiAgICAgICAgICB6OiB6T2YoeSkgKyAwLjAwMDIsXG4gICAgICAgICAgZmxpcCxcbiAgICAgICAgICBmYWRlLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKHcuY2FycnkgPT09IFwidG93bl9jaGVzdF9nbG93XCIpXG4gICAgICAgICAgRi5saWdodHMucHVzaCh7IHg6IHggKyBiYWNrLCB5OiB5IC0gOCwgcjogMTgsIGM6IFsxLjAsIDAuODUsIDAuNF0gfSk7XG4gICAgICB9XG4gICAgICBsaXZlKys7XG4gICAgfVxuICAgIEYubGl2ZSA9IGxpdmU7XG4gICAgLy8gcGFydGljbGVzOiBzbW9rZSBvdmVyIHRoZSBmaXJlIGFuZCB0aGUgZm9yZ2UncyBjaGltbmV5LCBlbWJlcnMsIGZvcmdlIHNwYXJrcywgdGhlIGJ1aWxkJ3MgZHVzdFxuICAgIHRpY2tQYXJ0cyhuaWdodCk7XG4gICAgZm9yIChjb25zdCBwIG9mIHBhcnRzKSB7XG4gICAgICBjb25zdCBsaWZlID0gcC5hZ2UgLyBwLmxpZmU7XG4gICAgICBzcHJpdGUoYGZ4X2RvdF8ke3AuY31gLCBwLnMsIHAueCwgcC55LCB7XG4gICAgICAgIHo6IHAua2luZCA9PT0gXCJzbW9rZVwiID8gMi41IDogMi42LFxuICAgICAgICBmYWRlOiBwLmtpbmQgPT09IFwic21va2VcIiA/IE1hdGgubWF4KDAsIGxpZmUgKiAxLjMgLSAwLjMpIDogTWF0aC5tYXgoMCwgbGlmZSAqIDEuNiAtIDAuNiksXG4gICAgICB9KTtcbiAgICAgIGlmIChwLmtpbmQgPT09IFwic3BhcmtcIiAmJiBuaWdodCA+IDAuNSAmJiBGLmxpZ2h0cy5sZW5ndGggPCBNQVhfTElHSFRTKVxuICAgICAgICBGLmxpZ2h0cy5wdXNoKHsgeDogcC54LCB5OiBwLnksIHI6IDYsIGM6IFsxLCAwLjYsIDAuMl0gfSk7XG4gICAgfVxuICAgIC8vIFByaW9yaXRpemUgcGVvcGxlIG92ZXIgZGVjb3JhdGl2ZSBtb3RlcyB3aXRoaW4gdGhlIGV4aXN0aW5nIHNoYWRlciBidWRnZXQuXG4gICAgRi5saWdodHMudW5zaGlmdCguLi5jaGFyYWN0ZXJMaWdodHMpO1xuICAgIEYubGlnaHRzLmxlbmd0aCA9IE1hdGgubWluKEYubGlnaHRzLmxlbmd0aCwgTUFYX0xJR0hUUyk7XG4gIH1cbiAgbGV0IGVtaXRUID0gMCxcbiAgICBzcGFya1QgPSAwLFxuICAgIGNoaW1UID0gMDtcbiAgZnVuY3Rpb24gdGlja1BhcnRzKG5pZ2h0OiBudW1iZXIpOiB2b2lkIHtcbiAgICB2b2lkIG5pZ2h0O1xuICAgIGNvbnN0IGR0ID0gTWF0aC5taW4oMC4xLCB0IC0gZW1pdFQpO1xuICAgIGVtaXRUID0gdDtcbiAgICBjb25zdCBmID0gUExPVFMuZmlyZTtcbiAgICBjb25zdCByYW5kID0gTWF0aC5yYW5kb207XG4gICAgaWYgKHN0YXRlIS5ob21lICYmIHJhbmQoKSA8IGR0ICogNSlcbiAgICAgIHBhcnRzLnB1c2goe1xuICAgICAgICB4OiBmLnggKyAocmFuZCgpIC0gMC41KSAqIDQsXG4gICAgICAgIHk6IGYueSAtIDEwLFxuICAgICAgICB2eDogKHJhbmQoKSAtIDAuNSkgKiAyLFxuICAgICAgICB2eTogLTEwIC0gcmFuZCgpICogNCxcbiAgICAgICAgYWdlOiAwLFxuICAgICAgICBsaWZlOiAyLjQgKyByYW5kKCksXG4gICAgICAgIGtpbmQ6IFwic21va2VcIixcbiAgICAgICAgYzogU01PS0VbTWF0aC5mbG9vcihyYW5kKCkgKiAzKV0hLFxuICAgICAgICBzOiByYW5kKCkgPCAwLjUgPyAyIDogMyxcbiAgICAgIH0pO1xuICAgIGlmIChzdGF0ZSEuaG9tZSAmJiByYW5kKCkgPCBkdCAqIDQpXG4gICAgICBwYXJ0cy5wdXNoKHtcbiAgICAgICAgeDogZi54ICsgKHJhbmQoKSAtIDAuNSkgKiA2LFxuICAgICAgICB5OiBmLnkgLSA2LFxuICAgICAgICB2eDogKHJhbmQoKSAtIDAuNSkgKiA2LFxuICAgICAgICB2eTogLTIyIC0gcmFuZCgpICogMTAsXG4gICAgICAgIGFnZTogMCxcbiAgICAgICAgbGlmZTogMC42ICsgcmFuZCgpICogMC40LFxuICAgICAgICBraW5kOiBcImVtYmVyXCIsXG4gICAgICAgIGM6IEVNQkVSW01hdGguZmxvb3IocmFuZCgpICogMyldISxcbiAgICAgICAgczogMSxcbiAgICAgIH0pO1xuICAgIGNvbnN0IHNtaXRoID0gc3RhdGUhLmJ1aWxkaW5ncy5maW5kKFxuICAgICAgKGIpID0+XG4gICAgICAgIGIuaWQgPT09IFwiYmxhY2tzbWl0aFwiICYmICEoYnVpbHRBdC5oYXMoYi5pZCkgJiYgdCAtIGJ1aWx0QXQuZ2V0KGIuaWQpISA8IEJVSUxEX0FTU0VNQkxZX1MpLFxuICAgICk7XG4gICAgaWYgKHNtaXRoKSB7XG4gICAgICBjb25zdCBwID0gUExPVFMuYmxhY2tzbWl0aDtcbiAgICAgIGlmICh0IC0gc3BhcmtUID4gMS41ICsgKGhhc2hOKE1hdGguZmxvb3IodCkpICUgMTApIC8gMTApIHtcbiAgICAgICAgc3BhcmtUID0gdDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA3OyBpKyspXG4gICAgICAgICAgcGFydHMucHVzaCh7XG4gICAgICAgICAgICB4OiBwLnggLSAxNCxcbiAgICAgICAgICAgIHk6IHAueSAtIDgsXG4gICAgICAgICAgICB2eDogKHJhbmQoKSAtIDAuNSkgKiA0MCxcbiAgICAgICAgICAgIHZ5OiAtMjAgLSByYW5kKCkgKiAyNSxcbiAgICAgICAgICAgIGFnZTogMCxcbiAgICAgICAgICAgIGxpZmU6IDAuNCArIHJhbmQoKSAqIDAuMyxcbiAgICAgICAgICAgIGtpbmQ6IFwic3BhcmtcIixcbiAgICAgICAgICAgIGM6IEVNQkVSW01hdGguZmxvb3IocmFuZCgpICogMyldISxcbiAgICAgICAgICAgIHM6IDEsXG4gICAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpZiAodCAtIGNoaW1UID4gMC40NSkge1xuICAgICAgICBjaGltVCA9IHQ7XG4gICAgICAgIHBhcnRzLnB1c2goe1xuICAgICAgICAgIHg6IHAueCArIDE0ICsgKHJhbmQoKSAtIDAuNSkgKiAyLFxuICAgICAgICAgIHk6IHAueSAtIHAuaCArIDIsXG4gICAgICAgICAgdng6IDMgKyByYW5kKCkgKiAyLFxuICAgICAgICAgIHZ5OiAtOCAtIHJhbmQoKSAqIDMsXG4gICAgICAgICAgYWdlOiAwLFxuICAgICAgICAgIGxpZmU6IDIuNiArIHJhbmQoKSxcbiAgICAgICAgICBraW5kOiBcInNtb2tlXCIsXG4gICAgICAgICAgYzogU01PS0VbTWF0aC5mbG9vcihyYW5kKCkgKiAzKV0hLFxuICAgICAgICAgIHM6IDIsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICBmb3IgKGNvbnN0IFtpZCwgYXRdIG9mIGJ1aWx0QXQpXG4gICAgICBpZiAoYnVpbGRGeEVuYWJsZWQoKSAmJiB0IC0gYXQgPj0gQlVJTERfQVNTRU1CTFlfUyAmJiAhZHVzdGVkLmhhcyhpZCkpIHtcbiAgICAgICAgZHVzdGVkLmFkZChpZCk7XG4gICAgICAgIGNvbnN0IHAgPSBQTE9UU1tpZCBhcyBQbG90SWRdO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IChlZmZlY3RzTGV2ZWwoKSA9PT0gXCJsb3dcIiA/IDggOiAyMik7IGkrKykge1xuICAgICAgICAgIGNvbnN0IGEgPSByYW5kKCkgKiBNYXRoLlBJICogMixcbiAgICAgICAgICAgIHYgPSAxNCArIHJhbmQoKSAqIDIyO1xuICAgICAgICAgIHBhcnRzLnB1c2goe1xuICAgICAgICAgICAgeDogcC54ICsgTWF0aC5jb3MoYSkgKiAxNCxcbiAgICAgICAgICAgIHk6IHAueSAtIDQsXG4gICAgICAgICAgICB2eDogTWF0aC5jb3MoYSkgKiB2LFxuICAgICAgICAgICAgdnk6IE1hdGguc2luKGEpICogdiAqIDAuNCAtIDYsXG4gICAgICAgICAgICBhZ2U6IDAsXG4gICAgICAgICAgICBsaWZlOiAwLjUgKyByYW5kKCkgKiAwLjMsXG4gICAgICAgICAgICBraW5kOiBcImR1c3RcIixcbiAgICAgICAgICAgIGM6IChpZCA9PT0gXCJibGFja3NtaXRoXCIgPyBTTU9LRSA6IERVU1QpW01hdGguZmxvb3IocmFuZCgpICogMyldISxcbiAgICAgICAgICAgIHM6IDIsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICBmb3IgKGxldCBpID0gcGFydHMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgIGNvbnN0IHAgPSBwYXJ0c1tpXSE7XG4gICAgICBwLmFnZSArPSBkdDtcbiAgICAgIGlmIChwLmFnZSA+PSBwLmxpZmUpIHtcbiAgICAgICAgcGFydHMuc3BsaWNlKGksIDEpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGlmIChwLmtpbmQgPT09IFwic21va2VcIikge1xuICAgICAgICBwLnZ4ICs9IE1hdGguc2luKHQgKiAxLjMgKyBpKSAqIGR0ICogMjtcbiAgICAgICAgcC5zID0gcC5hZ2UgLyBwLmxpZmUgPiAwLjUgPyAzIDogcC5zO1xuICAgICAgfVxuICAgICAgaWYgKHAua2luZCA9PT0gXCJzcGFya1wiKSBwLnZ5ICs9IDcwICogZHQ7XG4gICAgICBpZiAocC5raW5kID09PSBcImR1c3RcIikge1xuICAgICAgICBwLnZ4ICo9IDEgLSBkdCAqIDM7XG4gICAgICAgIHAudnkgKj0gMSAtIGR0ICogMztcbiAgICAgIH1cbiAgICAgIHAueCArPSBwLnZ4ICogZHQ7XG4gICAgICBwLnkgKz0gcC52eSAqIGR0O1xuICAgIH1cbiAgICBpZiAocGFydHMubGVuZ3RoID4gMjIwKSBwYXJ0cy5zcGxpY2UoMCwgcGFydHMubGVuZ3RoIC0gMjIwKTtcbiAgfVxuICBjb25zdCBkdXN0ZWQgPSBuZXcgU2V0PHN0cmluZz4oKTtcblxuICAvLyAtLSB0aGUgY2FtZXJhOiB0aGUgc3RhZ2UncyBib3ggZml0cyB0aGUgdmlldywgayA9IHdob2xlIGRldmljZSBweCBwZXIgdGV4ZWwgLS1cbiAgZnVuY3Rpb24gZml0KCk6IHZvaWQge1xuICAgIGNvbnN0IHMgPSBzdGF0ZTtcbiAgICBpZiAoIXMpIHJldHVybjtcbiAgICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY29uc3QgZHByID0gd2luZG93LmRldmljZVBpeGVsUmF0aW8gfHwgMTtcbiAgICBjb25zdCBXID0gTWF0aC5tYXgoMSwgTWF0aC5yb3VuZChyLndpZHRoICogZHByKSksXG4gICAgICBIID0gTWF0aC5tYXgoMSwgTWF0aC5yb3VuZChyLmhlaWdodCAqIGRwcikpO1xuICAgIC8vIHRoZSBib3g6IHdoYXQgc3RhbmRzICh0aGUgbW91dGgsIHRoZSBjYW1wLCB0aGUgYnVpbGRpbmdzLCB0aGUgc3Rha2VkIHBsb3QpIHdpdGggYSBtYXJnaW5cbiAgICBsZXQgeDAgPSBJbmZpbml0eSxcbiAgICAgIHkwID0gSW5maW5pdHksXG4gICAgICB4MSA9IC1JbmZpbml0eSxcbiAgICAgIHkxID0gLUluZmluaXR5O1xuICAgIGNvbnN0IGFkZCA9IChwOiBQdCAmIHsgaDogbnVtYmVyIH0sIGh3OiBudW1iZXIpOiB2b2lkID0+IHtcbiAgICAgIHgwID0gTWF0aC5taW4oeDAsIHAueCAtIGh3KTtcbiAgICAgIHgxID0gTWF0aC5tYXgoeDEsIHAueCArIGh3KTtcbiAgICAgIHkwID0gTWF0aC5taW4oeTAsIHAueSAtIHAuaCk7XG4gICAgICB5MSA9IE1hdGgubWF4KHkxLCBwLnkgKyA2KTtcbiAgICB9O1xuICAgIGFkZChQTE9UUy5tb3V0aCwgNTIpO1xuICAgIGFkZChQTE9UUy5maXJlLCAzMCk7XG4gICAgYWRkKFBMT1RTLnRlbnQsIDE4KTtcbiAgICBhZGQoUExPVFMuY3JhdGUsIDEwKTtcbiAgICBmb3IgKGNvbnN0IGIgb2Ygcy5idWlsZGluZ3MpIGFkZChQTE9UU1tiLmlkXSwgNDQpO1xuICAgIGZvciAoY29uc3QgaWQgb2Ygcy5zZXJ2aWNlcyA/PyBbXSlcbiAgICAgIGFkZChQTE9UU1tpZF0sIGlkID09PSBcImd1aWxkXCIgPyAzMiA6IGlkID09PSBcInBvb2xcIiA/IDMwIDogMjMpO1xuICAgIGZvciAoY29uc3QgaWQgb2YgW1wicG9vbFwiLCBcImRldmljZVwiXSBhcyBjb25zdClcbiAgICAgIGlmIChzLnNlcnZpY2VzPy5pbmNsdWRlcyhpZCkpIGZvciAoY29uc3Qgc3BvdCBvZiBob21lU3BvdHMpIGFkZCh7IC4uLnNwb3RbaWRdLCBoOiA0NCB9LCAzNCk7XG4gICAgZm9yIChjb25zdCB3IG9mIHMud29ya2Vycykge1xuICAgICAgY29uc3QgcCA9IHdvcmtlckF0KHcpO1xuICAgICAgaWYgKHApIGFkZCh7IC4uLnAsIGg6IDI0IH0sIDEwKTtcbiAgICB9XG4gICAgaWYgKHMuc3Rha2VkKSBhZGQoeyAuLi5QTE9UU1tzLnN0YWtlZC5pZF0sIGg6IDIyIH0sIDI0KTtcbiAgICBmb3IgKGNvbnN0IHEgb2YgUFJPUFMpXG4gICAgICBpZiAocS5zdGFnZSA8PSBzLnN0YWdlICYmIHEuc3RhZ2UgPiAwICYmIHEueSA8IFBMT1RTLmtlbm5lbC55ICsgNC41ICogVElMRSkgYWRkKHEsIDEyKTtcbiAgICBjb25zdCBNID0gMTA7XG4gICAgeDAgLT0gTTtcbiAgICB4MSArPSBNO1xuICAgIHkwIC09IE07XG4gICAgeTEgKz0gTSArIDQ7XG4gICAgLy8gazogd2hvbGUgZGV2aWNlIHB4IHBlciB0ZXhlbCDigJQgdGhlIGxhcmdlc3QgdGhhdCBmaXRzIHRoZSBib3gsIG9yIG9uZSBtb3JlIHdoZW4gdGhhdCBjcm9wcyDiiaQgYSBtYXJnaW4ncyB3b3J0aCBvbiBlYWNoIHNpZGVcbiAgICBjb25zdCBrZiA9IE1hdGgubWluKFcgLyAoeDEgLSB4MCksIEggLyAoeTEgLSB5MCkpO1xuICAgIGNvbnN0IHVwID0gTWF0aC5jZWlsKGtmKSxcbiAgICAgIGZpdHNVcCA9IFcgLyB1cCA+PSB4MSAtIHgwIC0gMiAqIE0gLSA0ICYmIEggLyB1cCA+PSB5MSAtIHkwIC0gMiAqIE0gLSA4O1xuICAgIC8vIChhIGxvdy1kZW5zaXR5IHNjcmVlbiDigJQgZmV3ZXIgdGhhbiAyIGRldmljZSBweCBhIHRleGVsIOKAlCBzY2FsZXMgYnkgYSBmcmFjdGlvbiBpbnN0ZWFkOiB0aGUgdG93biBhdCBrID0gMSB3YXMgYSBwb3N0YWdlIHN0YW1wKVxuICAgIGNvbnN0IGsgPVxuICAgICAgdXAgPiBrZiAmJiBmaXRzVXAgPyB1cCA6IGtmIDwgMiA/IE1hdGgubWF4KDEsIE1hdGguZmxvb3Ioa2YgKiA4KSAvIDgpIDogTWF0aC5mbG9vcihrZik7XG4gICAgY29uc3QgdyA9IE1hdGguY2VpbChXIC8gayksXG4gICAgICBoID0gTWF0aC5jZWlsKEggLyBrKTtcbiAgICBsZXQgY3ggPSAoeDAgKyB4MSkgLyAyLFxuICAgICAgY3kgPSAoeTAgKyB5MSkgLyAyO1xuICAgIGN4ID0gTWF0aC5tYXgodyAvIDIsIE1hdGgubWluKE1BUF9XICogVElMRSAtIHcgLyAyLCBjeCkpO1xuICAgIGN5ID0gTWF0aC5tYXgoaCAvIDIsIE1hdGgubWluKE1BUF9IICogVElMRSAtIGggLyAyLCBjeSkpO1xuICAgIGNvbnN0IG54MCA9IE1hdGgucm91bmQoY3ggLSB3IC8gMiksXG4gICAgICBueTAgPSBNYXRoLnJvdW5kKGN5IC0gaCAvIDIpO1xuICAgIGlmIChcbiAgICAgIG54MCAhPT0gRi54MCB8fFxuICAgICAgbnkwICE9PSBGLnkwIHx8XG4gICAgICB3ICE9PSBGLncgfHxcbiAgICAgIGggIT09IEYuaCB8fFxuICAgICAgayAhPT0gRi5rIHx8XG4gICAgICBXICE9PSBGLlcgfHxcbiAgICAgIEggIT09IEYuSFxuICAgICkge1xuICAgICAgRi54MCA9IG54MDtcbiAgICAgIEYueTAgPSBueTA7XG4gICAgICBGLncgPSB3O1xuICAgICAgRi5oID0gaDtcbiAgICAgIEYuayA9IGs7XG4gICAgICBGLlcgPSBXO1xuICAgICAgRi5IID0gSDtcbiAgICAgIGxheW91dERpcnR5ID0gdHJ1ZTtcbiAgICAgIGZvciAoY29uc3QgZm4gb2YgYWN0b3JMYXlvdXQpIGZuKCk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gbG9vcChub3c6IG51bWJlcik6IHZvaWQge1xuICAgIHJhZiA9IDA7XG4gICAgaWYgKGRpc3Bvc2VkKSByZXR1cm47XG4gICAgaWYgKGRvY3VtZW50LmhpZGRlbikge1xuICAgICAgbGFzdCA9IG5vdztcbiAgICAgIHJldHVybjtcbiAgICB9IC8vIGhpZGRlbjogbm8gZnJhbWVzICh2aXNpYmlsaXR5Y2hhbmdlIHJlc3VtZXMpXG4gICAgaWYgKCFlbC5pc0Nvbm5lY3RlZCkge1xuICAgICAgbGFzdCA9IG5vdztcbiAgICAgIHJhZiA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShsb29wKTtcbiAgICAgIHJldHVybjtcbiAgICB9IC8vIChub3QgbW91bnRlZCB5ZXQpXG4gICAgY29uc3QgaWRsZSA9IG5vdyAtIGxhc3RJbnB1dCA+IElETEVfTVM7XG4gICAgLy8gdGhlIGZyYW1lIGNhcDogbm9uZSB3aGlsZSBpbnB1dCBhcnJpdmVzLCBJRExFX0ZQUyBhZnRlciAxMCBzIHdpdGhvdXQ7IGEgc29mdHdhcmUgR0wgdW5kZXIgYXV0b21hdGlvbiAoanVpY2Ugb2ZmOiB0aGUgaGVhZGxlc3NcbiAgICAvLyBzdWl0ZXMsIHNldmVuIGJyb3dzZXJzIG9uIHRoZSBDUFUpIGRyYXdzIGF0IFNPRlRfRlBTIOKAlCB0aGUgc2NlbmUgaXMgY29zbWV0aWMgYW5kIGl0cyBmcmFtZXMgd2VyZSB0aGUgc3VpdGUncyBsb2FkXG4gICAgY29uc3QgY2FwID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmRhdGFzZXQuanVpY2UgPT09IFwib2ZmXCIgPyBTT0ZUX0ZQUyA6IGlkbGUgPyBJRExFX0ZQUyA6IDA7XG4gICAgaWYgKGNhcCAmJiBub3cgLSBsYXN0RHJhdyA8IDEwMDAgLyBjYXAgLSAyKSB7XG4gICAgICByYWYgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUobG9vcCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGR0ID0gTWF0aC5taW4oMC4xLCAobm93IC0gbGFzdCkgLyAxMDAwKTtcbiAgICBsYXN0ID0gbm93O1xuICAgIGxhc3REcmF3ID0gbm93O1xuICAgIHQgKz0gZHQ7XG4gICAgaWYgKHN0YXRlKSB7XG4gICAgICBjb25zdCBjMCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgZml0KCk7XG4gICAgICBmcmFtZSgpO1xuICAgICAgaWYgKGdsICYmICFnbExvc3QpIHtcbiAgICAgICAgZ2wucmVuZGVyKEYpO1xuICAgICAgICBpZiAoYzJkKSBjMmQuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgYyA9IHZpZXcyZCgpO1xuICAgICAgICBjLnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XG4gICAgICAgIGRyYXdUb3duMkQoYywgRiwgYXRsYXMuY2FudmFzKTtcbiAgICAgIH1cbiAgICAgIGNwdS5wdXNoKHBlcmZvcm1hbmNlLm5vdygpIC0gYzApO1xuICAgICAgaWYgKGNwdS5sZW5ndGggPiAxMjApIGNwdS5zaGlmdCgpO1xuICAgICAgZm9yIChjb25zdCBmbiBvZiBhY3RvckxheW91dCkgZm4oKTtcbiAgICAgIGZyYW1lcysrO1xuICAgICAgZnBzV2luLnB1c2gobm93KTtcbiAgICAgIHdoaWxlIChmcHNXaW4ubGVuZ3RoICYmIGZwc1dpblswXSEgPCBub3cgLSAxMDAwKSBmcHNXaW4uc2hpZnQoKTtcbiAgICAgIGlmICh3YWxraW5nSW4gJiYgdCA+PSB3YWxraW5nSW4udDEpIHtcbiAgICAgICAgY29uc3QgZCA9IHdhbGtpbmdJbi5kb25lO1xuICAgICAgICB3YWxraW5nSW4gPSBudWxsO1xuICAgICAgICBkKCk7XG4gICAgICB9XG4gICAgICBpZiAobGF5b3V0RGlydHkpIHtcbiAgICAgICAgbGF5b3V0RGlydHkgPSBmYWxzZTtcbiAgICAgICAgZm9yIChjb25zdCBmbiBvZiBsYXlvdXRGbnMpIGZuKCk7XG4gICAgICB9XG4gICAgfVxuICAgIHJhZiA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShsb29wKTtcbiAgfVxuICBjb25zdCBzdGFydCA9ICgpOiB2b2lkID0+IHtcbiAgICBpZiAoIXJhZiAmJiAhZGlzcG9zZWQpIHtcbiAgICAgIGxhc3QgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgIHJhZiA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShsb29wKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IG9uVmlzID0gKCk6IHZvaWQgPT4ge1xuICAgIGlmICghZG9jdW1lbnQuaGlkZGVuKSBzdGFydCgpO1xuICB9O1xuICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwidmlzaWJpbGl0eWNoYW5nZVwiLCBvblZpcyk7XG4gIGNvbnN0IHBva2UgPSAoKTogdm9pZCA9PiB7XG4gICAgbGFzdElucHV0ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gIH07XG4gIGNvbnN0IGlucHV0cyA9IFtcInBvaW50ZXJkb3duXCIsIFwicG9pbnRlcm1vdmVcIiwgXCJrZXlkb3duXCIsIFwid2hlZWxcIiwgXCJ0b3VjaHN0YXJ0XCJdIGFzIGNvbnN0O1xuICBmb3IgKGNvbnN0IGV2IG9mIGlucHV0cykgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoZXYsIHBva2UsIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgY29uc3Qgcm8gPVxuICAgIHR5cGVvZiBSZXNpemVPYnNlcnZlciAhPT0gXCJ1bmRlZmluZWRcIlxuICAgICAgPyBuZXcgUmVzaXplT2JzZXJ2ZXIoKCkgPT4ge1xuICAgICAgICAgIGZpdCgpO1xuICAgICAgICAgIGxheW91dERpcnR5ID0gdHJ1ZTtcbiAgICAgICAgfSlcbiAgICAgIDogbnVsbDtcbiAgcm8/Lm9ic2VydmUoZWwpO1xuXG4gIGNvbnN0IGNzcyA9ICh4OiBudW1iZXIsIHk6IG51bWJlcik6IFB0ID0+IHtcbiAgICBjb25zdCBkcHIgPSB3aW5kb3cuZGV2aWNlUGl4ZWxSYXRpbyB8fCAxO1xuICAgIHJldHVybiB7IHg6ICgoeCAtIEYueDApICogRi5rKSAvIGRwciwgeTogKCh5IC0gRi55MCkgKiBGLmspIC8gZHByIH07XG4gIH07XG4gIGNvbnN0IGFjdG9yUmVjdCA9IChpZDogbnVtYmVyKTogeyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdzogbnVtYmVyOyBoOiBudW1iZXIgfSB8IG51bGwgPT4ge1xuICAgIGNvbnN0IGFjdG9yID0gd2Fsa2Vycy5maW5kKCh3KSA9PiB3LmlkID09PSBgcmVzaWRlbnQ6JHtpZH1gKTtcbiAgICBpZiAoIWFjdG9yKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBhdCA9IHdhbGtlckF0KGFjdG9yLCB0KTtcbiAgICBpZiAoIWF0KSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBzbG90ID0gYXRsYXMuZ2V0KGFjdG9yLnNwcml0ZSwgYWN0b3IuaCk7XG4gICAgY29uc3QgeCA9IGF0LnggKyAoYWN0b3IuaG9tZU9mZnNldD8ueCA/PyAwKSxcbiAgICAgIHkgPSBhdC55ICsgKGFjdG9yLmhvbWVPZmZzZXQ/LnkgPz8gMCk7XG4gICAgY29uc3QgYSA9IGNzcyh4IC0gc2xvdC53IC8gMiwgeSAtIHNsb3QuaCksXG4gICAgICBiID0gY3NzKHggKyBzbG90LncgLyAyLCB5KTtcbiAgICByZXR1cm4geyB4OiBhLngsIHk6IGEueSwgdzogYi54IC0gYS54LCBoOiBiLnkgLSBhLnkgfTtcbiAgfTtcbiAgcmV0dXJuIHtcbiAgICBlbCxcbiAgICBzZXRTdGF0ZShzKSB7XG4gICAgICBjb25zdCBwcmV2ID0gc3RhdGU7XG4gICAgICBzdGF0ZSA9IHM7XG4gICAgICBob21lU3BvdHMgPSBob21lUmVzaWRlbnRTcG90cyhzKTtcbiAgICAgIGlmIChwcmV2KVxuICAgICAgICBmb3IgKGNvbnN0IGlkIG9mIGJ1aWx0QXQua2V5cygpKSB7XG4gICAgICAgICAgY29uc3Qgb2xkTG9vayA9XG4gICAgICAgICAgICBpZCA9PT0gXCJob3VzZVwiID8gaG91c2VMb29rKHByZXYpIDogcHJldi5idWlsZGluZ3MuZmluZCgoYikgPT4gYi5pZCA9PT0gaWQpPy5sb29rO1xuICAgICAgICAgIGNvbnN0IG5leHRMb29rID1cbiAgICAgICAgICAgIGlkID09PSBcImhvdXNlXCJcbiAgICAgICAgICAgICAgPyBzLmhvbWVcbiAgICAgICAgICAgICAgICA/IGhvdXNlTG9vayhzKVxuICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkXG4gICAgICAgICAgICAgIDogcy5idWlsZGluZ3MuZmluZCgoYikgPT4gYi5pZCA9PT0gaWQpPy5sb29rO1xuICAgICAgICAgIGlmIChuZXh0TG9vayA9PT0gdW5kZWZpbmVkIHx8IChvbGRMb29rICE9PSB1bmRlZmluZWQgJiYgbmV4dExvb2sgPCBvbGRMb29rKSkge1xuICAgICAgICAgICAgYnVpbHRBdC5kZWxldGUoaWQpO1xuICAgICAgICAgICAgdXBncmFkZUZyb20uZGVsZXRlKGlkKTtcbiAgICAgICAgICAgIGR1c3RlZC5kZWxldGUoaWQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgY29uc3QgY2hhbmdlcyA9IGNvbnN0cnVjdGlvbkNoYW5nZXMocHJldiwgcyk7XG4gICAgICBidWlsZEV2ZW50cyArPSBjaGFuZ2VzLmxlbmd0aDtcbiAgICAgIGlmIChjaGFuZ2VzLmxlbmd0aCAmJiBidWlsZEZ4RW5hYmxlZCgpKSBwb2tlKCk7XG4gICAgICBpZiAoYnVpbGRGeEVuYWJsZWQoKSlcbiAgICAgICAgZm9yIChjb25zdCBjaGFuZ2Ugb2YgY2hhbmdlcykge1xuICAgICAgICAgIGJ1aWx0QXQuc2V0KGNoYW5nZS5pZCwgdCk7XG4gICAgICAgICAgZHVzdGVkLmRlbGV0ZShjaGFuZ2UuaWQpO1xuICAgICAgICAgIGlmIChjaGFuZ2UuZnJvbUxvb2sgIT09IHVuZGVmaW5lZCkgdXBncmFkZUZyb20uc2V0KGNoYW5nZS5pZCwgY2hhbmdlLmZyb21Mb29rKTtcbiAgICAgICAgICBlbHNlIHVwZ3JhZGVGcm9tLmRlbGV0ZShjaGFuZ2UuaWQpO1xuICAgICAgICB9XG4gICAgICAvLyBhIHdvcmtlciBoaXJlZCBzaW5jZSB0aGUgbGFzdCBzdGF0ZSAoaGUgc3Rvb2QgZ3JleWVkLCBvciBub3doZXJlKTogb3V0IG9mIHRoZSB0ZW50LCBhbG9uZyB0aGUgcGF0aHMsIHRvIGhpcyBwb3N0XG4gICAgICBpZiAocHJldilcbiAgICAgICAgZm9yIChjb25zdCB3IG9mIHMud29ya2Vycykge1xuICAgICAgICAgIGlmICh3LmxpdCB8fCBwcmV2LndvcmtlcnMuc29tZSgoeCkgPT4geC5pZCA9PT0gdy5pZCAmJiAheC5saXQpKSBjb250aW51ZTtcbiAgICAgICAgICBjb25zdCBwID0gd29ya2VyQXQodyk7XG4gICAgICAgICAgaWYgKCFwKSBjb250aW51ZTtcbiAgICAgICAgICBjb25zdCBsZWdzOiBMZWdbXSA9IFtdO1xuICAgICAgICAgIGxlZ3NBbG9uZyhbTk9ERVMudGVudCEsIC4uLnJvdXRlKFwidGVudFwiLCBuZWFyZXN0Tm9kZShwKSksIHBdLCB0ICsgMC4yLCBTUEVFRCAqIDEuMywgbGVncyk7XG4gICAgICAgICAgYXJyaXZlLnNldCh3LmlkLCBsZWdzKTtcbiAgICAgICAgfVxuICAgICAgaWYgKFxuICAgICAgICAhcHJldiB8fFxuICAgICAgICBKU09OLnN0cmluZ2lmeShbcHJldi5zZXJ2aWNlcywgcHJldi5yb3N0ZXI/Lmxlbmd0aF0pICE9PVxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KFtzLnNlcnZpY2VzLCBzLnJvc3Rlcj8ubGVuZ3RoXSlcbiAgICAgIClcbiAgICAgICAgZm9yZXN0KCk7XG4gICAgICBjb25zdCBrZXkgPSAoeDogVG93blN0YXRlIHwgbnVsbCk6IHN0cmluZyA9PlxuICAgICAgICB4XG4gICAgICAgICAgPyBKU09OLnN0cmluZ2lmeShbXG4gICAgICAgICAgICAgIHguaG9tZSxcbiAgICAgICAgICAgICAgeC5oZXJvLFxuICAgICAgICAgICAgICB4LnJlc2lkZW50cyxcbiAgICAgICAgICAgICAgeC5yb3N0ZXIsXG4gICAgICAgICAgICAgIHguc2VydmljZXMsXG4gICAgICAgICAgICAgIHguc2VsZWN0ZWRIZXJvLFxuICAgICAgICAgICAgICB4LnBldHMsXG4gICAgICAgICAgICAgIHgucGFydGllcy5sZW5ndGgsXG4gICAgICAgICAgICAgIHguYnVpbGRpbmdzLm1hcCgoYikgPT4gYi5pZCksXG4gICAgICAgICAgICAgIHguc2VlZCxcbiAgICAgICAgICAgIF0pXG4gICAgICAgICAgOiBcIlwiO1xuICAgICAgaWYgKCFwcmV2IHx8IGtleShwcmV2KSAhPT0ga2V5KHMpKSBidWlsZChwcmV2Py5ob21lID09PSBmYWxzZSAmJiBzLmhvbWUpO1xuICAgICAgaWYgKFxuICAgICAgICBwcmV2Py5ob21lID09PSBmYWxzZSAmJlxuICAgICAgICBzLmhvbWUgJiZcbiAgICAgICAgaGVybyAmJlxuICAgICAgICAhbWF0Y2hNZWRpYShcIihwcmVmZXJzLXJlZHVjZWQtbW90aW9uOiByZWR1Y2UpXCIpLm1hdGNoZXNcbiAgICAgICkge1xuICAgICAgICBjb25zdCBkZXN0aW5hdGlvbiA9IE5PREVTLnRlbnQhO1xuICAgICAgICBoZXJvLmZyb20gPSB0ICsgMC41O1xuICAgICAgICBoZXJvLmxlZ3MgPSBbXTtcbiAgICAgICAgbGVnc0Fsb25nKFxuICAgICAgICAgIFt7IHg6IGRlc3RpbmF0aW9uLnggKyAxMDAsIHk6IGRlc3RpbmF0aW9uLnkgKyA3MCB9LCBkZXN0aW5hdGlvbl0sXG4gICAgICAgICAgdCArIDAuNSxcbiAgICAgICAgICAxMDAsXG4gICAgICAgICAgaGVyby5sZWdzLFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgZml0KCk7XG4gICAgICBsYXlvdXREaXJ0eSA9IHRydWU7XG4gICAgICBzdGFydCgpO1xuICAgIH0sXG4gICAgZm9jdXNIZXJvKCkge1xuICAgICAgaWYgKCFoZXJvKSByZXR1cm47XG4gICAgICBjb25zdCBhdCA9IHdhbGtlckF0KGhlcm8sIHQpO1xuICAgICAgaWYgKCFhdCkgcmV0dXJuO1xuICAgICAgY29uc3QgcCA9IGNzcyhhdC54LCBhdC55KTtcbiAgICAgIGNvbnN0IHJpbmcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaVwiKTtcbiAgICAgIHJpbmcuY2xhc3NOYW1lID0gXCJ0b3duLWhlcm8tZm9jdXNcIjtcbiAgICAgIHJpbmcuc2V0QXR0cmlidXRlKFwiYXJpYS1oaWRkZW5cIiwgXCJ0cnVlXCIpO1xuICAgICAgcmluZy5zdHlsZS5sZWZ0ID0gYCR7cC54fXB4YDtcbiAgICAgIHJpbmcuc3R5bGUudG9wID0gYCR7cC55fXB4YDtcbiAgICAgIGVsLmFwcGVuZENoaWxkKHJpbmcpO1xuICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4gcmluZy5yZW1vdmUoKSwgMTgwMCk7XG4gICAgICBwb2tlKCk7XG4gICAgICBzdGFydCgpO1xuICAgIH0sXG4gICAgd2Fsa0luKG1zID0gNzAwKSB7XG4gICAgICBpZiAoIWhlcm8gfHwgIXN0YXRlKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgICBpZiAod2Fsa2luZ0luKVxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlcykgPT4ge1xuICAgICAgICAgIGNvbnN0IGQgPSB3YWxraW5nSW4hLmRvbmU7XG4gICAgICAgICAgd2Fsa2luZ0luIS5kb25lID0gKCkgPT4ge1xuICAgICAgICAgICAgZCgpO1xuICAgICAgICAgICAgcmVzKCk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfSk7XG4gICAgICBjb25zdCBhdCA9IHdhbGtlckF0KGhlcm8sIHQpID8/IHsgeDogTk9ERVMudGVudCEueCwgeTogTk9ERVMudGVudCEueSB9O1xuICAgICAgY29uc3QgcHRzID0gW3sgeDogYXQueCwgeTogYXQueSB9LCAuLi5yb3V0ZShuZWFyZXN0Tm9kZShhdCksIFwiaW5cIildO1xuICAgICAgbGV0IGxlbiA9IDA7XG4gICAgICBmb3IgKGxldCBpID0gMTsgaSA8IHB0cy5sZW5ndGg7IGkrKykgbGVuICs9IGRpc3QocHRzW2kgLSAxXSEsIHB0c1tpXSEpO1xuICAgICAgY29uc3QgZHVyID0gbXMgLyAxMDAwO1xuICAgICAgaGVyby5mcm9tID0gTWF0aC5taW4oaGVyby5mcm9tLCB0KTtcbiAgICAgIGhlcm8ubGVncyA9IFtdO1xuICAgICAgaGVyby5leHRlbmQgPSB1bmRlZmluZWQ7XG4gICAgICBoZXJvLnRvID0gdCArIGR1ciArIDAuMDU7XG4gICAgICBoZXJvLnZhbmlzaCA9IGZhbHNlO1xuICAgICAgbGVnc0Fsb25nKHB0cywgdCwgTWF0aC5tYXgoU1BFRUQsIGxlbiAvIGR1ciksIGhlcm8ubGVncyk7XG4gICAgICBwb2tlKCk7XG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlcykgPT4ge1xuICAgICAgICB3YWxraW5nSW4gPSB7IHQwOiB0LCB0MTogdCArIGR1ciwgZG9uZTogcmVzIH07XG4gICAgICAgIHN0YXJ0KCk7XG4gICAgICB9KTtcbiAgICB9LFxuICAgIHJlc2l6ZSgpIHtcbiAgICAgIGZpdCgpO1xuICAgICAgbGF5b3V0RGlydHkgPSB0cnVlO1xuICAgIH0sXG4gICAgcmVjdE9mKGlkKSB7XG4gICAgICBpZiAoIXN0YXRlKSByZXR1cm4gbnVsbDtcbiAgICAgIGlmIChpZCA9PT0gXCJjaGVzdFwiIHx8IGlkLnN0YXJ0c1dpdGgoXCJ3b3JrZXI6XCIpKSB7XG4gICAgICAgIC8vICh0aGUgY2hlc3QgYW5kIHRoZSB3b3JrZXJzIHN0YW5kIG9mZiB0aGUgcGxvdHMpXG4gICAgICAgIGNvbnN0IHdrID0gaWQgPT09IFwiY2hlc3RcIiA/IG51bGwgOiBzdGF0ZS53b3JrZXJzLmZpbmQoKHcpID0+IGB3b3JrZXI6JHt3LmlkfWAgPT09IGlkKTtcbiAgICAgICAgY29uc3QgcCA9IGlkID09PSBcImNoZXN0XCIgPyAoc3RhdGUuY2hlc3QgPyBDSEVTVF9BVCA6IG51bGwpIDogd2sgPyB3b3JrZXJBdCh3aykgOiBudWxsO1xuICAgICAgICBpZiAoIXApIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBzID1cbiAgICAgICAgICBpZCA9PT0gXCJjaGVzdFwiXG4gICAgICAgICAgICA/IGF0bGFzLmdldChbXCJ0b3duX2hhdWxfY2hlc3RcIl0sIENIRVNUX0FULmgpXG4gICAgICAgICAgICA6IGF0bGFzLmdldCh3b3JrZXJJZHMod2shLmlkKSwgMjQpO1xuICAgICAgICBjb25zdCBhID0gY3NzKHAueCAtIHMudyAvIDIsIHAueSAtIHMuaCksXG4gICAgICAgICAgYiA9IGNzcyhwLnggKyBzLncgLyAyLCBwLnkpO1xuICAgICAgICByZXR1cm4geyB4OiBhLngsIHk6IGEueSwgdzogYi54IC0gYS54LCBoOiBiLnkgLSBhLnkgfTtcbiAgICAgIH1cbiAgICAgIGlmICgoaWQgPT09IFwiZ3VpbGRcIiB8fCBpZCA9PT0gXCJwb29sXCIgfHwgaWQgPT09IFwiZGV2aWNlXCIpICYmICFzdGF0ZS5zZXJ2aWNlcz8uaW5jbHVkZXMoaWQpKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIGNvbnN0IHBsb3QgPVxuICAgICAgICBpZCA9PT0gXCJzdGFrZWRcIiA/IChzdGF0ZS5zdGFrZWQgPyBQTE9UU1tzdGF0ZS5zdGFrZWQuaWRdIDogbnVsbCkgOiBQTE9UU1tpZCBhcyBQbG90SWRdO1xuICAgICAgaWYgKCFwbG90KSByZXR1cm4gbnVsbDtcbiAgICAgIGNvbnN0IGlkczogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+ID0ge1xuICAgICAgICBtb3V0aDogW1widG93bl9tb3V0aF9jYXZlXCJdLFxuICAgICAgICBmaXJlOiBbXCJ0b3duX2NhbXBmaXJlXzBcIl0sXG4gICAgICAgIHRlbnQ6IFtcInRvd25fdGVudFwiXSxcbiAgICAgICAgY3JhdGU6IFtcInRvd25fY3JhdGVcIl0sXG4gICAgICAgIGJvYXJkOiBbXCJ0b3duX2JvYXJkXCJdLFxuICAgICAgICBndWlsZDogW1widG93bl9zZXJ2aWNlX2d1aWxkXCJdLFxuICAgICAgICBwb29sOiBbXCJ0b3duX3NlcnZpY2VfcG9vbFwiXSxcbiAgICAgICAgZGV2aWNlOiBbXCJ0b3duX3NlcnZpY2VfZGV2aWNlXCJdLFxuICAgICAgfTtcbiAgICAgIGxldCBzOiBTbG90O1xuICAgICAgaWYgKGlkID09PSBcInRlbnRcIiAmJiBzdGF0ZS5ob21lKVxuICAgICAgICBzID0gYXRsYXMuZ2V0KFtgdG93bl9ob3VzZV8ke2hvdXNlTG9vayhzdGF0ZSl9YCwgXCJ0b3duX2hvdXNlXzFcIl0sIFBMT1RTLmhvdXNlLmgpO1xuICAgICAgZWxzZSBpZiAoaWQgPT09IFwic3Rha2VkXCIpIHMgPSBhdGxhcy5nZXQoXCJ0b3duX3Bsb3RcIiwgMTYpO1xuICAgICAgZWxzZSBpZiAoKEJVSUxESU5HUyBhcyByZWFkb25seSBzdHJpbmdbXSkuaW5jbHVkZXMoaWQpKSB7XG4gICAgICAgIGNvbnN0IGIgPSBzdGF0ZS5idWlsZGluZ3MuZmluZCgoeCkgPT4geC5pZCA9PT0gaWQpO1xuICAgICAgICBpZiAoIWIpIHJldHVybiBudWxsO1xuICAgICAgICBzID0gYXRsYXMuZ2V0KFtgdG93bl8ke2lkfV8ke2IubG9va31gLCBgdG93bl8ke2lkfV8xYF0sIHBsb3QuaCk7XG4gICAgICB9IGVsc2UgcyA9IGF0bGFzLmdldChpZHNbaWRdID8/IFtpZF0sIHBsb3QuaCk7XG4gICAgICBjb25zdCBhID0gY3NzKHBsb3QueCAtIHMudyAvIDIsIHBsb3QueSAtIHMuaCksXG4gICAgICAgIGIgPSBjc3MocGxvdC54ICsgcy53IC8gMiwgcGxvdC55KTtcbiAgICAgIHJldHVybiB7IHg6IGEueCwgeTogYS55LCB3OiBiLnggLSBhLngsIGg6IGIueSAtIGEueSB9O1xuICAgIH0sXG4gICAgb25MYXlvdXQoZm4pIHtcbiAgICAgIGxheW91dEZucy5wdXNoKGZuKTtcbiAgICB9LFxuICAgIG9uQWN0b3JzKGZuKSB7XG4gICAgICBhY3RvckxheW91dC5wdXNoKGZuKTtcbiAgICB9LFxuICAgIGFjdG9yUmVjdCxcbiAgICBhY3RvclRhcmdldHMoKSB7XG4gICAgICByZXR1cm4gKHN0YXRlPy5yZXNpZGVudHMgPz8gW10pLmZsYXRNYXAoKHJlc2lkZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IHIgPSBhY3RvclJlY3QocmVzaWRlbnQuaWQpO1xuICAgICAgICBpZiAoIXIpIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgdyA9IE1hdGgubWF4KDQ0LCByLncpLFxuICAgICAgICAgIGggPSBNYXRoLm1heCg0NCwgci5oKTtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogcmVzaWRlbnQuaWQsXG4gICAgICAgICAgICB4OiBNYXRoLnJvdW5kKHIueCArIHIudyAvIDIgLSB3IC8gMiksXG4gICAgICAgICAgICB5OiBNYXRoLnJvdW5kKHIueSArIHIuaCAvIDIgLSBoIC8gMiksXG4gICAgICAgICAgICB3OiBNYXRoLnJvdW5kKHcpLFxuICAgICAgICAgICAgaDogTWF0aC5yb3VuZChoKSxcbiAgICAgICAgICB9LFxuICAgICAgICBdO1xuICAgICAgfSk7XG4gICAgfSxcbiAgICBzdGF0cygpIHtcbiAgICAgIGNvbnN0IHMgPSBzdGF0ZTtcbiAgICAgIGNvbnN0IHNvcnRlZCA9IFsuLi5jcHVdLnNvcnQoKGEsIGIpID0+IGEgLSBiKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGZwczogZnBzV2luLmxlbmd0aCxcbiAgICAgICAgZnJhbWVzLFxuICAgICAgICBjcHVNczogY3B1W2NwdS5sZW5ndGggLSAxXSA/PyAwLFxuICAgICAgICBjcHVQNTA6IHNvcnRlZFtNYXRoLmZsb29yKHNvcnRlZC5sZW5ndGggKiAwLjUpXSA/PyAwLFxuICAgICAgICBjcHVQOTU6IHNvcnRlZFtNYXRoLmZsb29yKHNvcnRlZC5sZW5ndGggKiAwLjk1KV0gPz8gMCxcbiAgICAgICAgd2Fsa2VyczogRi5saXZlLFxuICAgICAgICBtb2RlOiBnbCAmJiAhZ2xMb3N0ID8gXCJnbFwiIDogXCIyZFwiLFxuICAgICAgICBnbExvc3QsXG4gICAgICAgIGs6IEYuayxcbiAgICAgICAgbmlnaHQ6IEYubmlnaHQsXG4gICAgICAgIGNoYXJhY3RlckxpZ2h0czogY2hhcmFjdGVyTGlnaHRzLmxlbmd0aCxcbiAgICAgICAgZGltZW5zaW9uYWxMaWdodDogZ2wgJiYgIWdsTG9zdCAmJiB0b3duTGlnaHRQcm90b3R5cGUoKSxcbiAgICAgICAgbWFwcGVkU3ByaXRlczogRi5xdWFkc1xuICAgICAgICAgIC5zbGljZSgwLCBGLm4pXG4gICAgICAgICAgLmZpbHRlcigocSkgPT4gcS5yZWxpZWYpXG4gICAgICAgICAgLm1hcCgocSkgPT4gKHsga2luZDogcS5yZWxpZWYsIGZsaXA6IHEuZmxpcCwgeDogcS54LCB5OiBxLnkgfSkpLFxuICAgICAgICBsaWdodHM6IEYubGlnaHRzLmxlbmd0aCxcbiAgICAgICAgaWRsZTogcGVyZm9ybWFuY2Uubm93KCkgLSBsYXN0SW5wdXQgPiBJRExFX01TLFxuICAgICAgICBydW5uaW5nOiAhIXJhZixcbiAgICAgICAgdGVycmFpblBhaW50cyxcbiAgICAgICAgdGVycmFpblBhaW50TXMsXG4gICAgICAgIHdpbmRUdWZ0cyxcbiAgICAgICAgd2luZFNpZ25hdHVyZSxcbiAgICAgICAgYnVpbGRpbmdzOiBzPy5idWlsZGluZ3MubWFwKChiKSA9PiBiLmlkKSA/PyBbXSxcbiAgICAgICAgc2VydmljZXM6IHM/LnNlcnZpY2VzID8/IFtdLFxuICAgICAgICByZXNpZGVudFN0YXRlczpcbiAgICAgICAgICBzPy5yZXNpZGVudHM/Lm1hcCgocikgPT4gKHsgaWQ6IHIuaWQsIHJlc3Rpbmc6ICEhci5yZXN0aW5nLCBwaGFzZTogci5waGFzZSB9KSkgPz8gW10sXG4gICAgICAgIGFjdGl2ZUJ1aWxkczogWy4uLmJ1aWx0QXQua2V5cygpXSxcbiAgICAgICAgYnVpbGRFdmVudHMsXG4gICAgICAgIGJ1aWxkRHVzdDogcGFydHMuZmlsdGVyKChwKSA9PiBwLmtpbmQgPT09IFwiZHVzdFwiKS5sZW5ndGgsXG4gICAgICAgIHN0YWtlZDogcz8uc3Rha2VkPy5pZCxcbiAgICAgICAgbWFya2Vyczogcz8ubWFya2Vycy5tYXAoKG0pID0+IGAke20ua2luZH1AJHttLmF0fWApID8/IFtdLFxuICAgICAgICB2aWV3OiBbRi54MCwgRi55MCwgRi53LCBGLmhdLFxuICAgICAgICBjaGVzdDogcz8uY2hlc3Q/LnN0YXRlLFxuICAgICAgICB3b3JrZXJzOiBzPy53b3JrZXJzLm1hcCgodykgPT4gYCR7dy5pZH0ke3cubGl0ID8gXCIobGl0KVwiIDogdy5wYXVzZWQgPyBcIihvZmYpXCIgOiBcIlwifWApID8/IFtdLFxuICAgICAgICByYW5rczogT2JqZWN0LmZyb21FbnRyaWVzKFxuICAgICAgICAgIChzPy53b3JrZXJzID8/IFtdKS5maWx0ZXIoKHcpID0+ICF3LmxpdCAmJiB3LnJhbmsgPiAxKS5tYXAoKHcpID0+IFt3LmlkLCB3LnJhbmtdKSxcbiAgICAgICAgKSxcbiAgICAgIH07XG4gICAgfSxcbiAgICBzdHJlc3Mobikge1xuICAgICAgc3RyZXNzTiA9IG47XG4gICAgICBpZiAoc3RhdGUpIGFkZFN0cmVzcygpO1xuICAgIH0sXG4gICAgc2V0SG91cihoKSB7XG4gICAgICBob3VyT3ZlcnJpZGUgPSBoO1xuICAgIH0sXG4gICAgcG9rZSxcbiAgICBkaXNwb3NlKCkge1xuICAgICAgZGlzcG9zZWQgPSB0cnVlO1xuICAgICAgaWYgKHJhZikgY2FuY2VsQW5pbWF0aW9uRnJhbWUocmFmKTtcbiAgICAgIHJhZiA9IDA7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwidmlzaWJpbGl0eWNoYW5nZVwiLCBvblZpcyk7XG4gICAgICBmb3IgKGNvbnN0IGV2IG9mIGlucHV0cykgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoZXYsIHBva2UpO1xuICAgICAgcm8/LmRpc2Nvbm5lY3QoKTtcbiAgICAgIGdsQ2FudmFzLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJ3ZWJnbGNvbnRleHRsb3N0XCIsIG9uTG9zdCk7XG4gICAgICBnbENhbnZhcy5yZW1vdmVFdmVudExpc3RlbmVyKFwid2ViZ2xjb250ZXh0cmVzdG9yZWRcIiwgb25SZXN0b3JlZCk7XG4gICAgICBnbENhbnZhcy5yZW1vdmUoKTtcbiAgICAgIGMyZD8ucmVtb3ZlKCk7XG4gICAgICAvLyB0aGUgY29udGV4dCBpcyBrZXB0IGZvciB0aGUgbmV4dCBtb3VudCAobmV2ZXIgbGVmdCBmb3IgdGhlIGJyb3dzZXIgdG8gcmVhcDogYSBkb3plbiBjYW1wcyBoZWxkIGEgZG96ZW4gY29udGV4dHMsIGFuZCBDaHJvbWUnc1xuICAgICAgLy8gY2FwIHRoZW4gZm9yY2VkIHRoZSBvbGRlc3QgbGl2ZSBvbmUg4oCUIHRoZSB3YXRjaCdzIOKAlCBsb3N0KTsgYSBsb3N0IG9uZSBpcyBsZXQgZ29cbiAgICAgIGlmIChnbCAmJiAhZ2xMb3N0KSB7XG4gICAgICAgIHNoYXJlZEdsPy5nbC5kaXNwb3NlKCk7XG4gICAgICAgIHNoYXJlZEdsID0geyBjYW52YXM6IGdsQ2FudmFzLCBnbCwgbG9zdDogZmFsc2UgfTtcbiAgICAgIH0gZWxzZSBnbD8uZGlzcG9zZSgpO1xuICAgIH0sXG4gIH07XG59XG5mdW5jdGlvbiBzZWdEaXN0KHA6IFB0LCBhOiBQdCwgYjogUHQpOiBudW1iZXIge1xuICBjb25zdCBkeCA9IGIueCAtIGEueCxcbiAgICBkeSA9IGIueSAtIGEueSxcbiAgICBsMiA9IGR4ICogZHggKyBkeSAqIGR5O1xuICBjb25zdCB1ID0gbDIgPyBNYXRoLm1heCgwLCBNYXRoLm1pbigxLCAoKHAueCAtIGEueCkgKiBkeCArIChwLnkgLSBhLnkpICogZHkpIC8gbDIpKSA6IDA7XG4gIHJldHVybiBNYXRoLmh5cG90KHAueCAtIChhLnggKyB1ICogZHgpLCBwLnkgLSAoYS55ICsgdSAqIGR5KSk7XG59XG5cbi8vIC0tLS0gdGhlIEdMIHZpZXc6IG9uZSB0YXJnZXQgb2YgdG93biB0ZXhlbHMsIHRoZSBsaWdodCBwYXNzIHVwc2NhbGluZyBpdCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuY29uc3QgTUFYX0xJR0hUUyA9IDMyO1xuZnVuY3Rpb24gdG93bkxpZ2h0UHJvdG90eXBlKCk6IGJvb2xlYW4ge1xuICByZXR1cm4gKFxuICAgIGltcG9ydC5tZXRhLmVudi5ERVYgJiZcbiAgICBbXCJwbGFuZXNcIiwgXCJ2b2x1bWVcIl0uaW5jbHVkZXMobmV3IFVSTFNlYXJjaFBhcmFtcyhsb2NhdGlvbi5zZWFyY2gpLmdldChcInRvd25MaWdodFwiKSA/PyBcIlwiKSAmJlxuICAgIGVmZmVjdHNMZXZlbCgpICE9PSBcIm9mZlwiXG4gICk7XG59XG5mdW5jdGlvbiB0b3duVm9sdW1lUHJvdG90eXBlKCk6IGJvb2xlYW4ge1xuICByZXR1cm4gKFxuICAgIGltcG9ydC5tZXRhLmVudi5ERVYgJiZcbiAgICBuZXcgVVJMU2VhcmNoUGFyYW1zKGxvY2F0aW9uLnNlYXJjaCkuZ2V0KFwidG93bkxpZ2h0XCIpID09PSBcInZvbHVtZVwiICYmXG4gICAgZWZmZWN0c0xldmVsKCkgIT09IFwib2ZmXCJcbiAgKTtcbn1cblxuLy8gQW5hbHl0aWMgc3VyZmFjZSBtYXNrcyBpbiBzcHJpdGUtbG9jYWwgY29vcmRpbmF0ZXM6IG5vIHJlcGVhdGVkIGF0bGFzIHJlYWRzLFxuLy8gbHVtYS1kZXJpdmVkIGdlb21ldHJ5LCBleHRyYSBidWZmZXIsIG9yIGF1dGhvcmVkLWFydCByZXBsYWNlbWVudC4gTG9jYWwgWCBpc1xuLy8gbWlycm9yZWQgd2l0aCB0aGUgY29sb3VyIFVWOyBub3JtYWwgWCBpcyB0aGVuIHJldHVybmVkIHRvIHdvcmxkIG9yaWVudGF0aW9uLlxuY29uc3QgVE9XTl9SRUxJRUYgPSAvKiBnbHNsICovIGBcbiR7Vk9MVU1FX0dMU0x9XG51bmlmb3JtIGZsb2F0IHVSZWxpZWZPbjtcbnVuaWZvcm0gZmxvYXQgdVJlbGllZk5pZ2h0O1xudW5pZm9ybSB2ZWM0IHVSZWxpZWZMWyR7TUFYX0xJR0hUU31dO1xudW5pZm9ybSB2ZWMzIHVSZWxpZWZDWyR7TUFYX0xJR0hUU31dO1xudW5pZm9ybSBpbnQgdVJlbGllZk47XG52YXJ5aW5nIHZlYzIgdkxvY2FsO1xudmFyeWluZyB2ZWMyIHZXb3JsZDtcbnZlYzMgdG93bk5vcm1hbCh2ZWMyIHAsIGZsb2F0IGtpbmQpIHtcbiAgaWYgKHVWb2x1bWVPbiA+IDAuNSAmJiBraW5kID4gMS41KSByZXR1cm4gdm9sdW1lTm9ybWFsKHAsa2luZCk7XG4gIGlmIChraW5kIDwgMS41KSB7XG4gICAgLy8gTWFpbiBzbGF0ZSByb29mLCBsb3dlciB0aW1iZXIgc2lkZSwgb3BlbiBnYWJsZS9mcm9udDsgY2hpbW5leSBpcyBtYXNvbnJ5LlxuICAgIGlmIChwLnggPCAwLjIyICYmIHAueSA+IDAuNTMpIHJldHVybiBub3JtYWxpemUodmVjMygtMC42NSwgMC4wLCAwLjgpKTtcbiAgICBpZiAocC55ID4gMC40MCArIDAuMjcgKiAoMS4wIC0gcC54KSkgcmV0dXJuIG5vcm1hbGl6ZSh2ZWMzKC0wLjIyLCAwLjc4LCAwLjY1KSk7XG4gICAgaWYgKHAueCA8IDAuNTYpIHJldHVybiBub3JtYWxpemUodmVjMygtMC43LCAwLjA1LCAwLjcyKSk7XG4gICAgcmV0dXJuIG5vcm1hbGl6ZSh2ZWMzKDAuNDgsIDAuMDUsIDAuODgpKTtcbiAgfVxuICAvLyBUaW55IGhlYWQvY2xvdGggdm9sdW1lczogc2lsaG91ZXR0ZSBhcnQgcmVtYWlucyBhdXRob3JpdGF0aXZlLiBObyBnbG9zcyxcbiAgLy8gbm8gdHJlYXRpbmcgaW5rL3dhc2ggYnJpZ2h0bmVzcyBhcyBidW1wcy4gQm90aCBleGlzdGluZyBwb3NlcyBzaGFyZSBheGVzLlxuICBmbG9hdCBoZWFkID0gc3RlcCgwLjc2LCBwLnkpO1xuICBmbG9hdCBjZW50cmUgPSBtaXgoMC40OSwgMC40NiwgaGVhZCk7XG4gIGZsb2F0IG54ID0gY2xhbXAoKHAueCAtIGNlbnRyZSkgKiAxLjUsIC0wLjY1LCAwLjY1KTtcbiAgZmxvYXQgbnkgPSBtaXgoMC4xMiwgY2xhbXAoKHAueSAtIDAuODUpICogNC4wLCAtMC4zLCAwLjQ1KSwgaGVhZCk7XG4gIHJldHVybiBub3JtYWxpemUodmVjMyhueCwgbnksIDEuMCkpO1xufVxudmVjMyB0b3duUmVsaWVmKHZlYzMgY29sb3VyKSB7XG4gIGlmICh1UmVsaWVmT24gPCAwLjUgfHwgdlBhcmFtLnkgPCAwLjUpIHJldHVybiBjb2xvdXI7XG4gIHZlYzMgTiA9IHRvd25Ob3JtYWwodkxvY2FsLCB2UGFyYW0ueSk7XG4gIGlmICh2UGFyYW0udyA+IDAuNSkgTi54ID0gLU4ueDtcbiAgdmVjMyBza3kgPSBub3JtYWxpemUodmVjMyhtaXgoLTAuNTUsIC0wLjEyLCB1UmVsaWVmTmlnaHQpLCAwLjgyLCAwLjg1KSk7XG4gIGZsb2F0IGtleSA9IGNsYW1wKChkb3QoTiwgc2t5KSAtIDAuNjUpICogMC40LCAtMC4xOCwgMC4xOCk7XG4gIHZlYzMgcmVzcG9uc2UgPSB2ZWMzKDAuMCk7XG4gIGZvciAoaW50IGkgPSAwOyBpIDwgJHtNQVhfTElHSFRTfTsgaSsrKSB7XG4gICAgaWYgKGkgPj0gdVJlbGllZk4pIGJyZWFrO1xuICAgIHZlYzIgZCA9IHVSZWxpZWZMW2ldLnh5IC0gdldvcmxkO1xuICAgIGZsb2F0IGZhbGwgPSBtYXgoMC4wLCAxLjAgLSBsZW5ndGgoZCkgLyB1UmVsaWVmTFtpXS56KTtcbiAgICB2ZWMzIEwgPSBub3JtYWxpemUodmVjMyhkLngsIC1kLnksIDE0LjApKTtcbiAgICByZXNwb25zZSArPSB1UmVsaWVmQ1tpXSAqIGZhbGwgKiBmYWxsICogKGRvdChOLCBMKSAtIDAuNjUpICogMC4zICogdm9sdW1lVmlzaWJpbGl0eSh2V29ybGQsdVJlbGllZkxbaV0ueHkpO1xuICB9XG4gIGZsb2F0IGluayA9IHNtb290aHN0ZXAoMC4wMzUsIDAuMTIsIGRvdChjb2xvdXIsIHZlYzMoMC4yMTI2LCAwLjcxNTIsIDAuMDcyMikpKTtcbiAgcmV0dXJuIGNvbG91ciAqICh2ZWMzKDEuMCkgKyBpbmsgKiAodmVjMyhrZXkpICsgY2xhbXAocmVzcG9uc2UsIHZlYzMoLTAuMTIpLCB2ZWMzKDAuMTIpKSkpO1xufVxuYDtcbmNvbnN0IEJMSVRfVkVSVCA9IC8qIGdsc2wgKi8gYHZhcnlpbmcgdmVjMiB2VXY7IHZvaWQgbWFpbigpIHsgdlV2ID0gdXY7IGdsX1Bvc2l0aW9uID0gdmVjNChwb3NpdGlvbi54eSwgMC4wLCAxLjApOyB9YDtcbmNvbnN0IEJMSVRfRlJBRyA9IC8qIGdsc2wgKi8gYFxuJHtWT0xVTUVfR0xTTH1cbnVuaWZvcm0gc2FtcGxlcjJEIHRleDtcbnVuaWZvcm0gdmVjMiB1U2l6ZTsgICAgICAvLyB0aGUgdGFyZ2V0LCB0ZXhlbHNcbnVuaWZvcm0gZmxvYXQgdUs7ICAgICAgICAvLyBkZXZpY2UgcHggcGVyIHRleGVsXG51bmlmb3JtIGZsb2F0IHVEZXZIO1xudW5pZm9ybSB2ZWMzIHVBbWI7XG51bmlmb3JtIGZsb2F0IHVOaWdodDtcbnVuaWZvcm0gdmVjNCB1TFske01BWF9MSUdIVFN9XTsgICAvLyB4LCB5ICh0ZXhlbHMgZnJvbSB0aGUgdmlldydzIHRvcC1sZWZ0KSwgcmFkaXVzLCB1bnVzZWRcbnVuaWZvcm0gdmVjMyB1Q1ske01BWF9MSUdIVFN9XTtcbnVuaWZvcm0gaW50IHVOO1xudW5pZm9ybSB2ZWMyIHVPcmlnaW47ICAgIC8vIHRoZSB2aWV3J3MgdG9wLWxlZnQgaW4gd29ybGQgdGV4ZWxzICh0aGUgbW9vbmxpZ2h0J3MgcGF0Y2hlcyBzdGF5IG9uIHRoZSBncm91bmQpXG51bmlmb3JtIGZsb2F0IHVUaW1lO1xuJHtCQVlFUl9HTFNMfVxudm9pZCBtYWluKCkge1xuICB2ZWMyIHB4ID0gZmxvb3IodmVjMihnbF9GcmFnQ29vcmQueCwgdURldkggLSBnbF9GcmFnQ29vcmQueSkgLyB1Syk7XG4gIHZlYzIgdXYgPSB2ZWMyKChweC54ICsgMC41KSAvIHVTaXplLngsIDEuMCAtIChweC55ICsgMC41KSAvIHVTaXplLnkpO1xuICB2ZWMzIGMgPSB0ZXh0dXJlMkQodGV4LCB1dikucmdiO1xuICB2ZWMzIGxpZ2h0ID0gdmVjMygwLjApO1xuICBmbG9hdCBkNCA9IGJheWVyNChweCk7XG4gIGZvciAoaW50IGkgPSAwOyBpIDwgJHtNQVhfTElHSFRTfTsgaSsrKSB7XG4gICAgaWYgKGkgPj0gdU4pIGJyZWFrO1xuICAgIHZlYzIgZCA9IHB4IC0gdUxbaV0ueHk7XG4gICAgZmxvYXQgZiA9IG1heCgwLjAsIDEuMCAtIGxlbmd0aChkICogdmVjMigxLjAsIDEuMjUpKSAvIHVMW2ldLnopO1xuICAgIGYgPSBmbG9vcihmICogZiAqIDYuMCArIGQ0KSAvIDYuMDsgICAvLyBiYW5kZWQsIGRpdGhlcmVkIGZhbGxvZmY6IGEgcGl4ZWwtYXJ0IHBvb2xcbiAgICBsaWdodCArPSB1Q1tpXSAqIGYgKiB2b2x1bWVWaXNpYmlsaXR5KHB4ICsgdU9yaWdpbiwgdUxbaV0ueHkgKyB1T3JpZ2luKTtcbiAgfVxuICAvLyBtb29ubGlnaHQgaW4gZHJpZnRpbmcgcGF0Y2hlcyAodGhlIGFydCBub3RlOiB0aGUgZ3Jhc3MgcmVhZCBmbGF0KTogYSBzbG93LCBicm9hZCB2YWx1ZSBzd2VsbCBvdmVyIHRoZSBncm91bmQsIGJhbmRlZFxuICB2ZWMyIHcgPSBweCArIHVPcmlnaW47XG4gIGZsb2F0IG0gPSBzaW4ody54ICogMC4wMjEgKyB1VGltZSAqIDAuMDQpICogc2luKHcueSAqIDAuMDI3IC0gdVRpbWUgKiAwLjAzKSArIDAuNSAqIHNpbigody54ICsgdy55KSAqIDAuMDEzICsgMS43KTtcbiAgbSA9IGZsb29yKCgwLjUgKyAwLjMzICogbSkgKiA1LjAgKyBkNCkgLyA1LjA7XG4gIC8vIG5pZ2h0OiB3aGF0IHRoZSB3YXJtIGxpZ2h0IGRvZXMgbm90IHJlYWNoIGlzIGdyYWRlZCB0b3dhcmQgdGhlIG1vb24gKGNvb2wsIGRlc2F0dXJhdGVkKSwgc28gYSBsaXQgd2luZG93IG9yIHRoZSBmaXJlIHJlYWRzXG4gIC8vIGFnYWluc3QgYSBibHVlIHdvcmxkIHJhdGhlciB0aGFuIGEgZGFya2VyIGNvcHkgb2YgdGhlIGRheVxuICBmbG9hdCBsaXQgPSBjbGFtcChkb3QobGlnaHQsIHZlYzMoMC40NSwgMC4zNSwgMC4yKSkgKiAyLjAsIDAuMCwgMS4wKTtcbiAgZmxvYXQgbHVtID0gZG90KGMsIHZlYzMoMC4yOTksIDAuNTg3LCAwLjExNCkpO1xuICBjID0gbWl4KGMsIHZlYzMoMC42MiwgMC44LCAxLjIpICogbHVtLCAwLjY1ICogdU5pZ2h0ICogKDEuMCAtIGxpdCkpO1xuICB2ZWMzIGNvbCA9IGMgKiAodUFtYiAqICgwLjg0ICsgMC4zNiAqIG0pICsgbGlnaHQpICsgbGlnaHQgKiBsaWdodCAqICgwLjA1ICsgMC4xMiAqIHVOaWdodCkgKiAoMC40ICsgdU5pZ2h0KTtcbiAgLy8gYSBzb2Z0IHZpZ25ldHRlOiB0aGUgY29ybmVycyBhIHN0ZXAgZG93biAodGhlIG5pZ2h0J3MgbW9yZSlcbiAgdmVjMiBxID0gcHggLyB1U2l6ZSAtIDAuNTtcbiAgY29sICo9IDEuMCAtICgwLjE4ICsgMC4yMiAqIHVOaWdodCkgKiBzbW9vdGhzdGVwKDAuMzIsIDAuNzUsIGxlbmd0aChxICogdmVjMigxLjAsIDAuOCkpKTtcbiAgZ2xfRnJhZ0NvbG9yID0gdmVjNChjb2wsIDEuMCk7XG59YDtcbmNsYXNzIEdMVG93biB7XG4gIHByaXZhdGUgcmVuZGVyZXI6IFRIUkVFLldlYkdMUmVuZGVyZXI7XG4gIHByaXZhdGUgcnQ6IFRIUkVFLldlYkdMUmVuZGVyVGFyZ2V0O1xuICBwcml2YXRlIHNjZW5lID0gbmV3IFRIUkVFLlNjZW5lKCk7XG4gIHByaXZhdGUgY2FtZXJhID0gbmV3IFRIUkVFLk9ydGhvZ3JhcGhpY0NhbWVyYSgtMSwgMSwgMSwgLTEsIDEsIDIwMCk7XG4gIHByaXZhdGUgdGV4OiBUSFJFRS5DYW52YXNUZXh0dXJlO1xuICBwcml2YXRlIHRlcnJhaW5UZXg6IFRIUkVFLkNhbnZhc1RleHR1cmU7XG4gIHByaXZhdGUgZ3JvdW5kTDogUXVhZExheWVyO1xuICBwcml2YXRlIG9iakw6IFF1YWRMYXllcjtcbiAgcHJpdmF0ZSBzaGFkb3dMOiBRdWFkTGF5ZXI7XG4gIHByaXZhdGUgYmxpdFNjZW5lID0gbmV3IFRIUkVFLlNjZW5lKCk7XG4gIHByaXZhdGUgYmxpdENhbSA9IG5ldyBUSFJFRS5PcnRob2dyYXBoaWNDYW1lcmEoLTEsIDEsIDEsIC0xLCAwLCAxKTtcbiAgcHJpdmF0ZSBtYXQ6IFRIUkVFLlNoYWRlck1hdGVyaWFsO1xuICBwcml2YXRlIGdyb3VuZEtleSA9IFwiXCI7XG4gIHByaXZhdGUgYXRsYXNWID0gLTE7XG4gIHByaXZhdGUgbHYgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBNQVhfTElHSFRTIH0sICgpID0+IG5ldyBUSFJFRS5WZWN0b3I0KCkpO1xuICBwcml2YXRlIGxjID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogTUFYX0xJR0hUUyB9LCAoKSA9PiBuZXcgVEhSRUUuVmVjdG9yMygpKTtcbiAgcHJpdmF0ZSB2b2x1bWVCbG9ja3MgPSBbbmV3IFRIUkVFLlZlY3RvcjQoKSwgbmV3IFRIUkVFLlZlY3RvcjQoKV07XG4gIHByaXZhdGUgY2FudmFzOiBIVE1MQ2FudmFzRWxlbWVudDtcbiAgcHJpdmF0ZSBhdGxhczogVG93bkF0bGFzO1xuICBjb25zdHJ1Y3RvcihjYW52YXM6IEhUTUxDYW52YXNFbGVtZW50LCBhdGxhczogVG93bkF0bGFzKSB7XG4gICAgdGhpcy5jYW52YXMgPSBjYW52YXM7XG4gICAgdGhpcy5hdGxhcyA9IGF0bGFzO1xuICAgIHRoaXMucmVuZGVyZXIgPSBuZXcgVEhSRUUuV2ViR0xSZW5kZXJlcih7XG4gICAgICBjYW52YXMsXG4gICAgICBhbnRpYWxpYXM6IGZhbHNlLFxuICAgICAgYWxwaGE6IGZhbHNlLFxuICAgICAgc3RlbmNpbDogZmFsc2UsXG4gICAgICBkZXB0aDogZmFsc2UsXG4gICAgICBwb3dlclByZWZlcmVuY2U6IFwiaGlnaC1wZXJmb3JtYW5jZVwiLFxuICAgICAgcHJlbXVsdGlwbGllZEFscGhhOiBmYWxzZSxcbiAgICB9KTtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFBpeGVsUmF0aW8oMSk7XG4gICAgdGhpcy5ydCA9IG5ldyBUSFJFRS5XZWJHTFJlbmRlclRhcmdldCg0LCA0LCB7XG4gICAgICBtaW5GaWx0ZXI6IFRIUkVFLk5lYXJlc3RGaWx0ZXIsXG4gICAgICBtYWdGaWx0ZXI6IFRIUkVFLk5lYXJlc3RGaWx0ZXIsXG4gICAgICBnZW5lcmF0ZU1pcG1hcHM6IGZhbHNlLFxuICAgICAgZGVwdGhCdWZmZXI6IHRydWUsXG4gICAgICBzdGVuY2lsQnVmZmVyOiBmYWxzZSxcbiAgICAgIGNvbG9yU3BhY2U6IFRIUkVFLk5vQ29sb3JTcGFjZSxcbiAgICB9KTtcbiAgICB0aGlzLnRleCA9IG5ldyBUSFJFRS5DYW52YXNUZXh0dXJlKGF0bGFzLmNhbnZhcyk7XG4gICAgT2JqZWN0LmFzc2lnbih0aGlzLnRleCwge1xuICAgICAgbWluRmlsdGVyOiBUSFJFRS5OZWFyZXN0RmlsdGVyLFxuICAgICAgbWFnRmlsdGVyOiBUSFJFRS5OZWFyZXN0RmlsdGVyLFxuICAgICAgZ2VuZXJhdGVNaXBtYXBzOiBmYWxzZSxcbiAgICAgIGNvbG9yU3BhY2U6IFRIUkVFLk5vQ29sb3JTcGFjZSxcbiAgICAgIGZsaXBZOiB0cnVlLFxuICAgICAgcHJlbXVsdGlwbHlBbHBoYTogZmFsc2UsXG4gICAgfSk7XG4gICAgdGhpcy50ZXJyYWluVGV4ID0gbmV3IFRIUkVFLkNhbnZhc1RleHR1cmUoZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKSk7XG4gICAgT2JqZWN0LmFzc2lnbih0aGlzLnRlcnJhaW5UZXgsIHtcbiAgICAgIG1pbkZpbHRlcjogVEhSRUUuTmVhcmVzdEZpbHRlcixcbiAgICAgIG1hZ0ZpbHRlcjogVEhSRUUuTmVhcmVzdEZpbHRlcixcbiAgICAgIGdlbmVyYXRlTWlwbWFwczogZmFsc2UsXG4gICAgICBjb2xvclNwYWNlOiBUSFJFRS5Ob0NvbG9yU3BhY2UsXG4gICAgICBmbGlwWTogdHJ1ZSxcbiAgICB9KTtcbiAgICB0aGlzLmdyb3VuZEwgPSBuZXcgUXVhZExheWVyKHRoaXMudGVycmFpblRleCwgMSwgMSwgMCk7XG4gICAgdGhpcy5vYmpMID0gbmV3IFF1YWRMYXllcih0aGlzLnRleCwgMTYwMCwgMSwgMSk7XG4gICAgdGhpcy5zaGFkb3dMID0gbmV3IFF1YWRMYXllcih0aGlzLnRleCwgODAwLCAxLCAxKTtcbiAgICBjb25zdCBvYmplY3RNYXQgPSB0aGlzLm9iakwubWVzaC5tYXRlcmlhbCBhcyBUSFJFRS5TaGFkZXJNYXRlcmlhbDtcbiAgICBvYmplY3RNYXQudmVydGV4U2hhZGVyID0gb2JqZWN0TWF0LnZlcnRleFNoYWRlclxuICAgICAgLnJlcGxhY2UoXCJ2YXJ5aW5nIHZlYzIgdlV2O1wiLCBcInZhcnlpbmcgdmVjMiB2VXY7IHZhcnlpbmcgdmVjMiB2TG9jYWw7IHZhcnlpbmcgdmVjMiB2V29ybGQ7XCIpXG4gICAgICAucmVwbGFjZShcInZQYXJhbSA9IGlQYXJhbTtcIiwgXCJ2UGFyYW0gPSBpUGFyYW07IHZMb2NhbCA9IHZlYzIodSwgdXYueSk7XCIpXG4gICAgICAucmVwbGFjZShcImdsX1Bvc2l0aW9uID1cIiwgXCJ2V29ybGQgPSB2ZWMyKHAueCwgLXAueSk7IGdsX1Bvc2l0aW9uID1cIik7XG4gICAgb2JqZWN0TWF0LmZyYWdtZW50U2hhZGVyID0gb2JqZWN0TWF0LmZyYWdtZW50U2hhZGVyXG4gICAgICAucmVwbGFjZShcInZvaWQgbWFpbigpIHtcIiwgYCR7VE9XTl9SRUxJRUZ9XFxudm9pZCBtYWluKCkge2ApXG4gICAgICAucmVwbGFjZShcbiAgICAgICAgXCJjb2wgPSBtaXgoY29sLCB1Rmxhc2gsIHZQYXJhbS55ICogc21vb3Roc3RlcCgwLjA2LCAwLjMsIGwpKTtcIixcbiAgICAgICAgXCJjb2wgPSB0b3duUmVsaWVmKGNvbCk7XCIsXG4gICAgICApO1xuICAgIE9iamVjdC5hc3NpZ24ob2JqZWN0TWF0LnVuaWZvcm1zLCB7XG4gICAgICB1Vm9sdW1lT246IHsgdmFsdWU6IDAgfSxcbiAgICAgIHVWb2x1bWVCbG9jazogeyB2YWx1ZTogdGhpcy52b2x1bWVCbG9ja3MgfSxcbiAgICAgIHVSZWxpZWZPbjogeyB2YWx1ZTogMCB9LFxuICAgICAgdVJlbGllZk5pZ2h0OiB7IHZhbHVlOiAwIH0sXG4gICAgICB1UmVsaWVmTDogeyB2YWx1ZTogdGhpcy5sdiB9LFxuICAgICAgdVJlbGllZkM6IHsgdmFsdWU6IHRoaXMubGMgfSxcbiAgICAgIHVSZWxpZWZOOiB7IHZhbHVlOiAwIH0sXG4gICAgfSk7XG4gICAgLy8gVG93bi1vbmx5IHRyYW5zbHVjZW50IGdyb3VuZCBwaWdtZW50LiBPcmRpbmFyeSBzcHJpdGVzIHJldGFpbiB0aGVpclxuICAgIC8vIGV4aXN0aW5nIGhhcmQgYWxwaGEgdGhyZXNob2xkOyB0aGlzIGxheWVyIHdyaXRlcyBubyBkZXB0aCBvciBsaWdodCB0YWdzLlxuICAgIGNvbnN0IHNoYWRvd01hdCA9IHRoaXMuc2hhZG93TC5tZXNoLm1hdGVyaWFsIGFzIFRIUkVFLlNoYWRlck1hdGVyaWFsO1xuICAgIHNoYWRvd01hdC5mcmFnbWVudFNoYWRlciA9IHNoYWRvd01hdC5mcmFnbWVudFNoYWRlclxuICAgICAgLnJlcGxhY2UoXCJpZiAoYy5hIDwgMC41KSBkaXNjYXJkO1wiLCBcImlmIChjLmEgPCAwLjAxKSBkaXNjYXJkO1wiKVxuICAgICAgLnJlcGxhY2UoXCJpZiAodlBhcmFtLnogPiAwLjAgJiYgdlBhcmFtLnogPiBiYXllcjQoZ2xfRnJhZ0Nvb3JkLnh5KSkgZGlzY2FyZDtcIiwgXCJcIilcbiAgICAgIC5yZXBsYWNlKFxuICAgICAgICBcImdsX0ZyYWdDb2xvciA9IHZlYzQoY29sLCB1VGFnKTtcIixcbiAgICAgICAgXCJnbF9GcmFnQ29sb3IgPSB2ZWM0KGNvbCwgYy5hICogKDEuMCAtIHZQYXJhbS56KSk7XCIsXG4gICAgICApO1xuICAgIHNoYWRvd01hdC50cmFuc3BhcmVudCA9IHRydWU7XG4gICAgc2hhZG93TWF0LmRlcHRoV3JpdGUgPSBmYWxzZTtcbiAgICB0aGlzLnNjZW5lLmFkZCh0aGlzLmdyb3VuZEwubWVzaCwgdGhpcy5vYmpMLm1lc2gsIHRoaXMuc2hhZG93TC5tZXNoKTtcbiAgICB0aGlzLmNhbWVyYS5wb3NpdGlvbi5zZXQoMCwgMCwgMTAwKTtcbiAgICB0aGlzLm1hdCA9IG5ldyBUSFJFRS5TaGFkZXJNYXRlcmlhbCh7XG4gICAgICB2ZXJ0ZXhTaGFkZXI6IEJMSVRfVkVSVCxcbiAgICAgIGZyYWdtZW50U2hhZGVyOiBCTElUX0ZSQUcsXG4gICAgICBkZXB0aFRlc3Q6IGZhbHNlLFxuICAgICAgZGVwdGhXcml0ZTogZmFsc2UsXG4gICAgICB1bmlmb3Jtczoge1xuICAgICAgICB0ZXg6IHsgdmFsdWU6IHRoaXMucnQudGV4dHVyZSB9LFxuICAgICAgICB1U2l6ZTogeyB2YWx1ZTogbmV3IFRIUkVFLlZlY3RvcjIoNCwgNCkgfSxcbiAgICAgICAgdUs6IHsgdmFsdWU6IDEgfSxcbiAgICAgICAgdURldkg6IHsgdmFsdWU6IDQgfSxcbiAgICAgICAgdUFtYjogeyB2YWx1ZTogbmV3IFRIUkVFLlZlY3RvcjMoMSwgMSwgMSkgfSxcbiAgICAgICAgdU5pZ2h0OiB7IHZhbHVlOiAwIH0sXG4gICAgICAgIHVMOiB7IHZhbHVlOiB0aGlzLmx2IH0sXG4gICAgICAgIHVDOiB7IHZhbHVlOiB0aGlzLmxjIH0sXG4gICAgICAgIHVOOiB7IHZhbHVlOiAwIH0sXG4gICAgICAgIHVPcmlnaW46IHsgdmFsdWU6IG5ldyBUSFJFRS5WZWN0b3IyKCkgfSxcbiAgICAgICAgdVRpbWU6IHsgdmFsdWU6IDAgfSxcbiAgICAgICAgdVZvbHVtZU9uOiB7IHZhbHVlOiAwIH0sXG4gICAgICAgIHVWb2x1bWVCbG9jazogeyB2YWx1ZTogdGhpcy52b2x1bWVCbG9ja3MgfSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgdGhpcy5ibGl0U2NlbmUuYWRkKG5ldyBUSFJFRS5NZXNoKG5ldyBUSFJFRS5QbGFuZUdlb21ldHJ5KDIsIDIpLCB0aGlzLm1hdCkpO1xuICB9XG4gIHJlc3RvcmVkKCk6IHZvaWQge1xuICAgIHRoaXMuZ3JvdW5kS2V5ID0gXCJcIjtcbiAgICB0aGlzLmF0bGFzViA9IC0xO1xuICAgIHRoaXMudGV4Lm5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgICB0aGlzLnRlcnJhaW5UZXgubmVlZHNVcGRhdGUgPSB0cnVlO1xuICB9XG4gIC8qKiB0aGUgR0wgY29udGV4dCBpcyBnb25lIChmb3JjZWQgbG9zdCBvbiBkaXNwb3NlLCBvciBieSB0aGUgYnJvd3NlcikgKi9cbiAgaXNMb3N0KCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnJlbmRlcmVyLmdldENvbnRleHQoKS5pc0NvbnRleHRMb3N0KCk7XG4gIH1cbiAgY29tcGFyZUxpZ2h0aW5nKEY6IFRvd25GcmFtZSk6IHVua25vd24ge1xuICAgIGNvbnN0IGNhcHR1cmVzOiBVaW50OEFycmF5W10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IGVuYWJsZWQgb2YgW2ZhbHNlLCB0cnVlXSkge1xuICAgICAgdGhpcy5yZW5kZXIoRiwgZW5hYmxlZCwgMCk7XG4gICAgICBjb25zdCBwaXhlbHMgPSBuZXcgVWludDhBcnJheShGLncgKiBGLmggKiA0KTtcbiAgICAgIHRoaXMucmVuZGVyZXIucmVhZFJlbmRlclRhcmdldFBpeGVscyh0aGlzLnJ0LCAwLCAwLCBGLncsIEYuaCwgcGl4ZWxzKTtcbiAgICAgIGNhcHR1cmVzLnB1c2gocGl4ZWxzKTtcbiAgICB9XG4gICAgbGV0IGNoYW5nZWQgPSAwLFxuICAgICAgdW5tYXBwZWQgPSAwLFxuICAgICAgYWxwaGFDaGFuZ2VzID0gMCxcbiAgICAgIG1heCA9IDAsXG4gICAgICBzdW0gPSAwO1xuICAgIGNvbnN0IG1hcHMgPSBGLnF1YWRzLnNsaWNlKDAsIEYubikuZmlsdGVyKChxKSA9PiBxLnJlbGllZik7XG4gICAgY29uc3QgY2hhbmdlZEJ5S2luZDogUmVjb3JkPG51bWJlciwgbnVtYmVyPiA9IHt9O1xuICAgIGZvciAobGV0IHkgPSAwOyB5IDwgRi5oOyB5KyspXG4gICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IEYudzsgeCsrKSB7XG4gICAgICAgIGNvbnN0IGkgPSAoeSAqIEYudyArIHgpICogNDtcbiAgICAgICAgY29uc3QgZGVsdGEgPSBNYXRoLm1heChcbiAgICAgICAgICAuLi5bMCwgMSwgMl0ubWFwKChjKSA9PiBNYXRoLmFicyhjYXB0dXJlc1swXSFbaSArIGNdISAtIGNhcHR1cmVzWzFdIVtpICsgY10hKSksXG4gICAgICAgICk7XG4gICAgICAgIGlmIChjYXB0dXJlc1swXSFbaSArIDNdICE9PSBjYXB0dXJlc1sxXSFbaSArIDNdKSBhbHBoYUNoYW5nZXMrKztcbiAgICAgICAgaWYgKCFkZWx0YSkgY29udGludWU7XG4gICAgICAgIGNoYW5nZWQrKztcbiAgICAgICAgc3VtICs9IGRlbHRhO1xuICAgICAgICBtYXggPSBNYXRoLm1heChtYXgsIGRlbHRhKTtcbiAgICAgICAgY29uc3Qgd3ggPSBGLngwICsgeCArIDAuNSxcbiAgICAgICAgICB3eSA9IEYueTAgKyBGLmggLSB5IC0gMC41O1xuICAgICAgICBmb3IgKGNvbnN0IHEgb2YgbWFwcykge1xuICAgICAgICAgIGlmICh3eCA+PSBxLnggLSBxLncgLyAyICYmIHd4IDw9IHEueCArIHEudyAvIDIgJiYgd3kgPD0gcS55ICYmIHd5ID49IHEueSAtIHEuaClcbiAgICAgICAgICAgIGNoYW5nZWRCeUtpbmRbcS5yZWxpZWYhXSA9IChjaGFuZ2VkQnlLaW5kW3EucmVsaWVmIV0gPz8gMCkgKyAxO1xuICAgICAgICB9XG4gICAgICAgIGlmIChcbiAgICAgICAgICAhbWFwcy5zb21lKFxuICAgICAgICAgICAgKHEpID0+IHd4ID49IHEueCAtIHEudyAvIDIgJiYgd3ggPD0gcS54ICsgcS53IC8gMiAmJiB3eSA8PSBxLnkgJiYgd3kgPj0gcS55IC0gcS5oLFxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgICAgIHVubWFwcGVkKys7XG4gICAgICB9XG4gICAgY29uc3QgaW1hZ2VzID0gY2FwdHVyZXMubWFwKChwaXhlbHMpID0+IHtcbiAgICAgIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJjYW52YXNcIik7XG4gICAgICBjYW52YXMud2lkdGggPSBGLnc7XG4gICAgICBjYW52YXMuaGVpZ2h0ID0gRi5oO1xuICAgICAgY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoXCIyZFwiKSEsXG4gICAgICAgIGltYWdlID0gY3R4LmNyZWF0ZUltYWdlRGF0YShGLncsIEYuaCk7XG4gICAgICBmb3IgKGxldCB5ID0gMDsgeSA8IEYuaDsgeSsrKVxuICAgICAgICBpbWFnZS5kYXRhLnNldChwaXhlbHMuc3ViYXJyYXkoeSAqIEYudyAqIDQsICh5ICsgMSkgKiBGLncgKiA0KSwgKEYuaCAtIDEgLSB5KSAqIEYudyAqIDQpO1xuICAgICAgY3R4LnB1dEltYWdlRGF0YShpbWFnZSwgMCwgMCk7XG4gICAgICByZXR1cm4gY2FudmFzLnRvRGF0YVVSTCgpO1xuICAgIH0pO1xuICAgIHRoaXMucmVuZGVyKEYpO1xuICAgIGNvbnN0IG1hdGVyaWFsID0gdGhpcy5vYmpMLm1lc2gubWF0ZXJpYWwgYXMgVEhSRUUuU2hhZGVyTWF0ZXJpYWw7XG4gICAgcmV0dXJuIHtcbiAgICAgIHdpZHRoOiBGLncsXG4gICAgICBoZWlnaHQ6IEYuaCxcbiAgICAgIG5pZ2h0OiBGLm5pZ2h0LFxuICAgICAgY2hhbmdlZCxcbiAgICAgIHVubWFwcGVkLFxuICAgICAgYWxwaGFDaGFuZ2VzLFxuICAgICAgbWF4RGVsdGE6IG1heCxcbiAgICAgIG1lYW5DaGFuZ2VkRGVsdGE6IGNoYW5nZWQgPyBzdW0gLyBjaGFuZ2VkIDogMCxcbiAgICAgIGNoYW5nZWRCeUtpbmQsXG4gICAgICBtYXBwZWRQb3NlczogbWFwcy5tYXAoKHEpID0+ICh7IGtpbmQ6IHEucmVsaWVmLCB3OiBxLncsIGg6IHEuaCwgZmxpcDogcS5mbGlwIH0pKSxcbiAgICAgIHNoYWRlclBhdGNoZWQ6XG4gICAgICAgIG1hdGVyaWFsLmZyYWdtZW50U2hhZGVyLmluY2x1ZGVzKFwiY29sID0gdG93blJlbGllZihjb2wpO1wiKSAmJlxuICAgICAgICBtYXRlcmlhbC52ZXJ0ZXhTaGFkZXIuaW5jbHVkZXMoXCJ2TG9jYWwgPSB2ZWMyKHUsIHV2LnkpXCIpLFxuICAgICAgaW1hZ2VzLFxuICAgIH07XG4gIH1cbiAgcmVuZGVyKEY6IFRvd25GcmFtZSwgcmVsaWVmT3ZlcnJpZGU/OiBib29sZWFuLCB0aW1lT3ZlcnJpZGU/OiBudW1iZXIpOiB2b2lkIHtcbiAgICBjb25zdCByID0gdGhpcy5yZW5kZXJlcjtcbiAgICBpZiAodGhpcy5jYW52YXMud2lkdGggIT09IEYuVyB8fCB0aGlzLmNhbnZhcy5oZWlnaHQgIT09IEYuSCkgci5zZXRTaXplKEYuVywgRi5ILCBmYWxzZSk7XG4gICAgaWYgKHRoaXMucnQud2lkdGggIT09IEYudyB8fCB0aGlzLnJ0LmhlaWdodCAhPT0gRi5oKSB0aGlzLnJ0LnNldFNpemUoRi53LCBGLmgpO1xuICAgIGlmICh0aGlzLmF0bGFzLnZlcnNpb24gIT09IHRoaXMuYXRsYXNWKSB7XG4gICAgICB0aGlzLmF0bGFzViA9IHRoaXMuYXRsYXMudmVyc2lvbjtcbiAgICAgIHRoaXMudGV4Lm5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKEYuZ3JvdW5kS2V5ICE9PSB0aGlzLmdyb3VuZEtleSkge1xuICAgICAgdGhpcy5ncm91bmRLZXkgPSBGLmdyb3VuZEtleTtcbiAgICAgIGNvbnN0IEwgPSB0aGlzLmdyb3VuZEw7XG4gICAgICBMLmJlZ2luKCk7XG4gICAgICBpZiAoRi50ZXJyYWluKSB7XG4gICAgICAgIHRoaXMudGVycmFpblRleC5pbWFnZSA9IEYudGVycmFpbjtcbiAgICAgICAgdGhpcy50ZXJyYWluVGV4Lm5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgICAgICAgTC5wdXNoKChNQVBfVyAqIFRJTEUpIC8gMiwgLU1BUF9IICogVElMRSwgMCwgTUFQX1cgKiBUSUxFLCBNQVBfSCAqIFRJTEUsIDAsIDAsIDEsIDEpO1xuICAgICAgfVxuICAgICAgTC5lbmQoKTtcbiAgICB9XG4gICAgY29uc3QgTyA9IHRoaXMub2JqTCxcbiAgICAgIFMgPSB0aGlzLnNoYWRvd0w7XG4gICAgTy5iZWdpbigpO1xuICAgIFMuYmVnaW4oKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IEYubjsgaSsrKSB7XG4gICAgICBjb25zdCBxID0gRi5xdWFkc1tpXSE7XG4gICAgICAvLyAuMjEvLjIyIGFyZSByZXNlcnZlZCBmb3IgZ3JvdW5kIHBpZ21lbnQ7IHdpbmQgc3RheXMgYXQgLjEuXG4gICAgICBjb25zdCBsYXllciA9IHEueiA9PT0gMC4yMSB8fCBxLnogPT09IDAuMjIgPyBTIDogTztcbiAgICAgIGxheWVyLnB1c2goXG4gICAgICAgIHEueCxcbiAgICAgICAgLXEueSxcbiAgICAgICAgcS56LFxuICAgICAgICBxLncsXG4gICAgICAgIHEuaCxcbiAgICAgICAgcS5zLnUwLFxuICAgICAgICBxLnMudjAsXG4gICAgICAgIHEucy51MSxcbiAgICAgICAgcS5zLnYxLFxuICAgICAgICBxLmRpbSxcbiAgICAgICAgcS5yZWxpZWYgPz8gMCxcbiAgICAgICAgcS5mYWRlLFxuICAgICAgICBxLmZsaXAgPyAxIDogMCxcbiAgICAgICk7XG4gICAgfVxuICAgIE8uZW5kKCk7XG4gICAgUy5lbmQoKTtcbiAgICBjb25zdCBjID0gdGhpcy5jYW1lcmE7XG4gICAgYy5sZWZ0ID0gRi54MDtcbiAgICBjLnJpZ2h0ID0gRi54MCArIEYudztcbiAgICBjLnRvcCA9IC1GLnkwO1xuICAgIGMuYm90dG9tID0gLShGLnkwICsgRi5oKTtcbiAgICBjLnVwZGF0ZVByb2plY3Rpb25NYXRyaXgoKTtcbiAgICBjb25zdCByZWxpZWYgPSAodGhpcy5vYmpMLm1lc2gubWF0ZXJpYWwgYXMgVEhSRUUuU2hhZGVyTWF0ZXJpYWwpLnVuaWZvcm1zO1xuICAgIHJlbGllZi51UmVsaWVmT24hLnZhbHVlID0gKHJlbGllZk92ZXJyaWRlID8/IHRvd25MaWdodFByb3RvdHlwZSgpKSA/IDEgOiAwO1xuICAgIGNvbnN0IHZvbHVtZSA9IHRvd25Wb2x1bWVQcm90b3R5cGUoKSAmJiAocmVsaWVmT3ZlcnJpZGUgPz8gdHJ1ZSk7XG4gICAgcmVsaWVmLnVWb2x1bWVPbiEudmFsdWUgPSB2b2x1bWUgPyAxIDogMDtcbiAgICBmb3IgKGNvbnN0IGIgb2YgdGhpcy52b2x1bWVCbG9ja3MpIGIuc2V0KDAsIDAsIDAsIDApO1xuICAgIGxldCBibG9jayA9IDA7XG4gICAgaWYgKHZvbHVtZSlcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgRi5uICYmIGJsb2NrIDwgMjsgaSsrKSB7XG4gICAgICAgIGNvbnN0IHEgPSBGLnF1YWRzW2ldITtcbiAgICAgICAgaWYgKHEucmVsaWVmID09PSAzIHx8IHEucmVsaWVmID09PSA0KVxuICAgICAgICAgIHRoaXMudm9sdW1lQmxvY2tzW2Jsb2NrKytdIS5zZXQocS54LCBxLnkgLSA1LCBxLncgKiAwLjI3LCBNYXRoLm1heCgzLCBxLmggKiAwLjA3KSk7XG4gICAgICB9XG4gICAgcmVsaWVmLnVSZWxpZWZOaWdodCEudmFsdWUgPSBGLm5pZ2h0O1xuICAgIHJlbGllZi51UmVsaWVmTiEudmFsdWUgPSBNYXRoLm1pbihNQVhfTElHSFRTLCBGLmxpZ2h0cy5sZW5ndGgpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVsaWVmLnVSZWxpZWZOIS52YWx1ZTsgaSsrKSB7XG4gICAgICBjb25zdCBsaWdodCA9IEYubGlnaHRzW2ldITtcbiAgICAgIHRoaXMubHZbaV0hLnNldChsaWdodC54LCBsaWdodC55LCBsaWdodC5yLCAwKTtcbiAgICAgIHRoaXMubGNbaV0hLnNldCguLi5saWdodC5jKTtcbiAgICB9XG4gICAgci5zZXRSZW5kZXJUYXJnZXQodGhpcy5ydCk7XG4gICAgci5zZXRDbGVhckNvbG9yKDB4MWIyNDEyLCAxKTtcbiAgICByLmNsZWFyKCk7XG4gICAgci5yZW5kZXIodGhpcy5zY2VuZSwgYyk7XG4gICAgY29uc3QgdSA9IHRoaXMubWF0LnVuaWZvcm1zO1xuICAgIHUudVZvbHVtZU9uIS52YWx1ZSA9IHZvbHVtZSA/IDEgOiAwO1xuICAgICh1LnVTaXplIS52YWx1ZSBhcyBUSFJFRS5WZWN0b3IyKS5zZXQoRi53LCBGLmgpO1xuICAgIHUudUshLnZhbHVlID0gRi5rO1xuICAgIHUudURldkghLnZhbHVlID0gRi5IO1xuICAgICh1LnVBbWIhLnZhbHVlIGFzIFRIUkVFLlZlY3RvcjMpLnNldCguLi5GLmFtYik7XG4gICAgdS51TmlnaHQhLnZhbHVlID0gRi5uaWdodDtcbiAgICBjb25zdCBuID0gTWF0aC5taW4oTUFYX0xJR0hUUywgRi5saWdodHMubGVuZ3RoKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG47IGkrKykge1xuICAgICAgY29uc3QgbCA9IEYubGlnaHRzW2ldITtcbiAgICAgIHRoaXMubHZbaV0hLnNldChsLnggLSBGLngwLCBsLnkgLSBGLnkwLCBsLnIsIDApO1xuICAgICAgdGhpcy5sY1tpXSEuc2V0KC4uLmwuYyk7XG4gICAgfVxuICAgIHUudU4hLnZhbHVlID0gbjtcbiAgICAodS51T3JpZ2luIS52YWx1ZSBhcyBUSFJFRS5WZWN0b3IyKS5zZXQoRi54MCwgRi55MCk7XG4gICAgdS51VGltZSEudmFsdWUgPSB0aW1lT3ZlcnJpZGUgPz8gcGVyZm9ybWFuY2Uubm93KCkgLyAxMDAwO1xuICAgIHIuc2V0UmVuZGVyVGFyZ2V0KG51bGwpO1xuICAgIHIucmVuZGVyKHRoaXMuYmxpdFNjZW5lLCB0aGlzLmJsaXRDYW0pO1xuICB9XG4gIC8vICh0aGUgY29udGV4dCBpcyBsZXQgZ28sIG5vdCBsZWZ0IGZvciB0aGUgYnJvd3NlciB0byByZWFwOiBhIGNhbXAgbW91bnRlZCBhIGRvemVuIHRpbWVzIGhlbGQgYSBkb3plbiBjb250ZXh0cywgYW5kIENocm9tZSdzIGNhcFxuICAvLyB0aGVuIGZvcmNlZCB0aGUgb2xkZXN0IGxpdmUgb25lIOKAlCB0aGUgd2F0Y2gncyDigJQgbG9zdClcbiAgZGlzcG9zZSgpOiB2b2lkIHtcbiAgICB0aGlzLmdyb3VuZEwuZGlzcG9zZSgpO1xuICAgIHRoaXMub2JqTC5kaXNwb3NlKCk7XG4gICAgdGhpcy5zaGFkb3dMLmRpc3Bvc2UoKTtcbiAgICB0aGlzLm1hdC5kaXNwb3NlKCk7XG4gICAgdGhpcy5ydC5kaXNwb3NlKCk7XG4gICAgdGhpcy50ZXguZGlzcG9zZSgpO1xuICAgIHRoaXMudGVycmFpblRleC5kaXNwb3NlKCk7XG4gICAgdGhpcy5yZW5kZXJlci5kaXNwb3NlKCk7XG4gICAgdGhpcy5yZW5kZXJlci5mb3JjZUNvbnRleHRMb3NzKCk7XG4gIH1cbn1cbiJdfQ==