## 1. The fourteen axes

Each axis has a one-line definition, the theory it rests on, a *bot proxy* (what
telemetry or a scripted agent can measure — always a ceiling, never an award) and a
*human probe* (the question a player answers). Awards are 0–1 on the anchors in §3.

| # | Axis (id) | Layer | Definition | Rests on | Bot proxy (cap) | Human probe |
|---|---|---|---|---|---|---|
| 1 | Clear goal and feedback (`clarity`) | core | At every moment the player knows what they are trying to do and sees what their last action did | Flow (clear goals, immediate feedback); PXI *clarity of goals*, *ease of control*; Into the Breach's shown intent | time-to-first-success; % of first-session actions with visible consequence; misread rate | "Did you ever not know what to do, or what just happened?" |
| 2 | Interesting decisions (`decisions`) | engine | Choices with trade-offs whose consequences the player can foresee and would defend | Meier; Schell's lens of the puzzle; PXI *autonomy* (meaningful choice) | decision-gap (share of turns where top-2 options are within 10%); dominated-option rate | "Name a choice you made and why. Would you make it again?" |
| 3 | Mastery curve (`mastery`) | core | Skill grows, is visible to the player, and the game keeps offering the next thing to learn | Koster (fun = learning patterns); SDT competence; PXI *mastery*, *challenge* | win-rate vs sessions; hint suppression; retry-to-success curve | "What can you do now that you couldn't an hour ago?" |
| 4 | Tension, risk and release (`tension`) | engine | Difficulty sits in the band that is neither trivial nor hopeless, the outcome stays in doubt, stakes the player chose to carry, and a release that pays it off | Flow channel; ~85% learning rule (Wilson 2019); Lazzaro fiero; near-miss research; XCOM's exposed odds; Browne's drama/uncertainty | win-rate bands for a level-for-week agent; *bloody-win* share (won with a hero down or ≤ 2 HP); near-miss rate | "Where did you sweat? Did the game notice?" |
| 5 | Feel and juice (`feel`) | engine | Control responds immediately and readably; audiovisual consequence is amplified at the moment it matters and quiet otherwise | Swink game feel; Jonasson/Purho juice; Celeste's coyote time | frame time, input latency, feedback-event density on scoring actions vs routine | "What felt good in the hands, and what did you do just because it felt good? What did you actually see, hear or feel?" |
| 6 | Surprise and variety (`surprise`) | core | Directly encountered situations produce material, not merely cosmetic, changes often enough to keep the played pattern from exhausting | Koster; Halo "never repeat 30 seconds"; Baba's low-cost surprise | distinct-state entropy per session; seeded events per run; repeat rate of situations | "What directly surprised you? Which played situations changed your decisions, and when did they repeat?" |
| 7 | Expression and identity (`expression`) | engine | The player's choices make something that is recognisably *theirs* — a build, a deck, an island, a style | Quantic Foundry creativity; Slay the Spire's niche cards; ACNH islands | build-diversity index across wins; share of winning configurations | "Describe your build/character/place to a friend without naming the game." |
| 8 | Story to tell (`story`) | conditional | The session produces an anecdote with a turn in it, usually from variance × stakes | Lazzaro people fun; XCOM's 95% miss; Hades' reactivity | chronicle/story sentence carries road + peak + end; peak events per run | "Tell me about one run in three sentences." |
| 9 | Flow and pacing (`pacing`) | core | The whole played session — core action and recurring administration/transitions — has bounded loops with friction only where it is a decision | Csikszentmihalyi; Griesemer's nested loops; Civ's overlapping timers | in-play turn length and dead time; administration/transition time; animation/interaction ratio; session length distribution | "Where did play itself drag, where did administration delay the next play, and where did you want one more?" |
| 10 | Fairness and legibility of failure (`failure`) | core | A loss names its cause and how close it was; recovery is cheap enough to try again | Juul (art of failure); Meier (players blame the game); Celeste's instant respawn | loss screens that name cause + margin; retry latency; attribution probe | "Why did you lose? Whose fault was it?" |
| 11 | Social and relatedness (`social`) | conditional | Other people, or sustained character relationships that develop across encounters, create consequential belonging, cooperation or competition | SDT relatedness; Jackbox's laughing objective; Hades' reactive dialogue | co-op/competitive presence; persistent or choice-specific relationship-state changes | "Who did you relate to or play with, how did that relationship develop, and how did it change the experience?" |
| 12 | Autonomy and exploration (`autonomy`) | conditional | The player chooses order, pace and goal; discovery is found by looking, not by icons | SDT autonomy; Elden Ring; Outer Wilds (knowledge as upgrade) | branch/order freedom; self-set goals observed; optional-content share | "What did you decide to do that the game didn't ask for?" |
| 13 | Collection and progression (`progression`) | retention | The game's declared long-goal layer — within a unit, persistent between units, or both — provides earned gains at a legible cadence, scored *separately* from fun | Quantic Foundry achievement; idler research | within-unit gain cadence; persistent unlock cadence; time between visible gains | "What grew within this run/session, what persisted into the next one, and which layer were you working toward?" |
| 14 | Atmosphere and audiovisual appeal (`aesthetic`) | conditional | Art, sound and tone that make the world worth being in | PXI *audiovisual appeal*, *immersion*; Bananza "beautiful enough to break" | none reliable (bots cannot see); performance gates only | "Describe the place. Would you sit in it doing nothing?" |

Layers: **core** (weighted ≥ 2 in nearly every genre), **engine** (the genre picks one
or two at 3), **conditional** (genre-dependent, can be 0), **retention** (progression;
scored but never rescues a weak core).

**What is deliberately not an axis.** *Enjoyment* and *return intent* are the criterion
the score must predict, not things to award; the scorecard records them separately
("I had fun" 1–7, "would you play again tomorrow, unpaid?" 1–7, "recommend to a friend"
0–10) and the framework is valid on a game only if the weighted score and the criterion
agree (§6). *Frustration and tedium* are read as the low end of `failure` and `pacing`
rather than an axis of their own. *Immersion* is folded into `aesthetic` and `pacing`
because PXI's own validation found it hard to separate. Player-type models are weights
over the axes (§2), never axes.

## 2. Genre presets and player profiles

Weights are 0–3 per axis in `presets/presets.json`, from the synthesis table in
`research/genres.md`, and renormalised to 100 by the scorer so scores compare
across genres. Presets: `universal`, `match3`, `puzzle`, `strategy`, `tactics-roguelike`,
`roguelike`, `fps`, `platformer`, `driving`, `farming`, `idler`, `abstract`,
`open-world`, `party`, `rhythm`, `narrative`. A game that straddles genres takes the
preset of its *engine* (what the player is doing most of the time), and the evaluator
notes the second genre in the scorecard.

**Player profiles** tilt the weights for a player type without changing the anchors.
The full form: take the twelve Quantic Foundry motivation percentiles for the player or
persona (Destruction, Excitement · Competition, Community · Challenge, Strategy ·
Completion, Power · Fantasy, Story · Design, Discovery), z-score them, map each to the
axes it loads on (Strategy → decisions; Challenge → mastery and tension; Excitement and
Destruction → feel and tension; Completion and Power → progression; Discovery and Design →
surprise, expression, autonomy; Fantasy and Story → story, aesthetic; Competition and
Community → social), and set weight = base × (1 + 0.5 × mean z), renormalised. The
presets file ships the six cluster profiles as ready-made multipliers:
`action`, `social`, `mastery`, `achievement`, `immersion`, `creativity` (the six Quantic
Foundry clusters). A profile is a set of multipliers (e.g. `mastery` ×1.5 on the mastery
and decisions axes, ×0.8 on aesthetic). Use one when you are scoring for a known audience;
leave it off for the generic verdict. The neutral score and the profile score are both
reported, and a game whose neutral score is fun but whose target profile's score is not
has a positioning problem, not a fun problem.

## 3. Anchors (how to award 0–1)

Every axis uses the same five anchors, read through the axis's definition and the
precommitted evidence horizon below. Write one sentence of evidence per axis; the
sentence must quote something directly observed, not the rubric's own words or a
feature catalog.

| Award | Anchor | Test |
|---|---|---|
| 1.0 | Defining | Direct evidence across the whole agreed horizon, no material lapse, and a named genre benchmark does not do it better; a player names it unprompted as *why* the game is fun |
| 0.8 | Strong | Directly present throughout the agreed horizon, with one named material lapse |
| 0.6 | Adequate | Directly present often enough to support the loop, but routine repetition, friction or an untested required layer keeps it from strong |
| 0.3 | Weak | Present in places; its absence is felt in an ordinary session |
| 0.0 | Absent or harmful | Missing, or actively working against the player |

Two rules keep the awards honest. **No double counting:** one observation supports one
axis (a ×3 cascade with a held chord is *feel*, the fact that a run produced it is
*surprise*, that the chronicle retold it is *story*). **Evidence before adjectives:** an
award above 0.6 needs a quoted line, a screenshot, or a number. Land on one of the five
anchors by default. In a reliability cohort, an in-between award is allowed only when
all raters precommit the same quantitative interpolation rule; otherwise use the highest
anchor whose entire test is met.

### Evidence scope and disputed boundaries

The **evidence horizon** is the play duration and breadth promised before play: build,
save state, number of complete units, and any genre-relevant stratification (for example
maps, characters, difficulty bands or seasons). Human awards use only what the rater
directly encounters inside it. A catalog entry, code path, generated content count or bot
proxy may explain what could happen and may impose a cap, but it cannot raise a human
award for something the rater did not experience.

These boundaries are part of the anchors, not optional interpretation:

| Axis | Count here | Do not substitute |
|---|---|---|
| `surprise` | Materially different situations the rater directly encountered and can name, including how they changed play | Unvisited catalog breadth, seed counts, or cosmetic relabeling. One surprising event supports that event; it does not prove session-long variety |
| `feel` | Experienced response and consequence in each claimed modality. Sound counts only when the rater actually listened on an audible, unmuted setup | The existence of sound files/events, visual timing, or a latency proxy as evidence that audio felt good. If audio is unassessed, mark it unassessed; do not praise or fault it |
| `pacing` | Report **in-play pacing** (decisions, routine actions, animation) and **administrative pacing** (menus, councils, loading, repeated setup) separately, then judge the recurring whole-session loop | A fast input or short fight erasing repeated administration. A long fight is a pacing lapse only when its extra time is repetition, waiting or foregone decisions, not merely meaningful play |
| `progression` | Name the game's intended long-goal layer and observe its cadence. Record within-unit growth separately from persistent growth across units | A rich build inside one run proving between-run retention, or an unlock screen proving the next run changes. If the game promises both and one required layer is unobserved, the combined axis cannot exceed 0.6 |
| `social` | Human co-presence that changes play, or a sustained character relationship that develops across encounters and affects the experience | Generic/state-aware barks, names, or a narrator acknowledging an outcome. Those can support `story` or `aesthetic`, but alone support at most 0.3 social |

The same direct-assessment rule applies to `aesthetic`: a rater may score the visual and
atmospheric evidence they experienced, but may claim audiovisual excellence or use sound
as evidence only after actually listening.

