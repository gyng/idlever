//! Cut201 earned first-session diagnostic. No grants, forced milestones or balance certification.
use idlever_core::{Game, tree};
use serde_json::{json, Value};
use std::{fs, path::PathBuf};

fn main() {
    let out = std::env::args().nth(1).map(PathBuf::from).expect("output directory");
    fs::create_dir_all(&out).unwrap();
    let mut results = Vec::new();
    for seed in [1, 3, 5, 7, 11, 13, 17, 29] {
        let mut game = Game::new(seed);
        game.build_town("house").unwrap();
        let mut model_s = 5.0; // actual house tap, same five-second chore model as dayplayer
        let mut observations = Vec::<Value>::new();
        let mut manual_delves = 0;
        let mut first_affordable = None;
        let mut events = Vec::new();
        for _ in 0..12 {
            // Construction is a real ready action, never an automatic grant.
            loop {
                let town = game.lineage().town;
                let Some(next) = town.next.filter(|_| town.next_ready) else { break };
                game.build_town(&next).unwrap();
                model_s += 5.0;
            }
            for id in ["porter", "scout"] {
                if tree::lit(&game.lineage).is_some_and(|n| n.id == id)
                    && game.hire(id).is_ok() { model_s += 5.0; }
            }
            if tree::hired(&game.lineage, "scout") { break; }
            game.send();
            let before = game.lineage.total_turns;
            // The actual in-flight run is completed by the existing first-session harness path.
            let report = idlever_core::offline::run_offline_counts(&mut game, 1);
            manual_delves += 1;
            model_s += (game.lineage.total_turns - before) as f64 / 10.0 / 4.0 + 25.0;
            let wire = game.lineage();
            let kit_affordable = idlever_core::kit::ladders(&game.lineage).iter()
                .any(|l| l.next.as_ref().is_some_and(|n| n.affordable));
            if kit_affordable && first_affordable.is_none() { first_affordable = Some(manual_delves); }
            let ready: Vec<_> = tree::NODES.iter().filter(|n| !tree::hired(&game.lineage, n.id) && tree::ready(&game.lineage, n))
                .map(|n| n.id).collect();
            observations.push(json!({"delve":manual_delves,"model_s":model_s,"gold":wire.gold,
                "deepest":game.lineage.best_depth,"runs":report.runs,"kit_affordable":kit_affordable,
                "town":wire.town,"ready_workers":ready,"unlock_offers":game.unlocks().iter().map(|u| &u.id).collect::<Vec<_>>() }));
            events.extend(game.events.iter().cloned());
            fs::write(out.join(format!("seed-{seed}-delve-{manual_delves}.json")), game.save()).unwrap();
        }
        let scout = tree::hired(&game.lineage, "scout");
        let autonomous_runs = if scout { idlever_core::offline::run_offline_counts(&mut game, 8 * 3600).runs } else { 0 };
        let mut after_scout_builds = Vec::new();
        if std::env::args().any(|a| a == "--finish-plots") {
            loop {
                let town = game.lineage().town;
                let Some(next) = town.next.filter(|_| town.next_ready) else { break };
                game.build_town(&next).unwrap();
                after_scout_builds.push(next);
            }
        }
        fs::write(out.join(format!("seed-{seed}-final.json")), game.save()).unwrap();
        fs::write(out.join(format!("seed-{seed}-events.json")), serde_json::to_vec(&events).unwrap()).unwrap();
        results.push(json!({"seed":seed,"manual_delves":manual_delves,"scout_hired":scout,
            "model_s":model_s,"scout_bound":scout && manual_delves<=5 && model_s<=900.0,
            "first_affordable_kit_delve":first_affordable,"autonomous_8h_runs":autonomous_runs,"after_scout_manual_builds":after_scout_builds,"observations":observations}));
    }
    let result = json!({"fixture":"earned actual-play diagnostic","time_model":"dayplayer: run ticks/10/4 +25s camp +5s actual construction/hire", "seeds":results});
    fs::write(out.join("pacing.json"), serde_json::to_vec_pretty(&result).unwrap()).unwrap();
    println!("{}", serde_json::to_string(&result).unwrap());
}
