# Recovery ledger

Same attempt: b60d282a675ad6044b002996d5f057344a38c0f4, seed223.
Workspace runtime restart stopped driver/browser and lost /tmp and in-tool serializable memory. Coordinator restored same frozen262 assets at same URL41271. No game source/history/acceptance artifacts read.
Verified browser-state.json SHA2562d8e039ca3f6115c06541016d7a920c312ac7d4ee16d9b019043e5d02787fbc6. Preserved unchanged copy recovery-original-earned.json with same hash, restored that file through driver41433 --headless --checkpoint --restore. Navigated same URL with dev1/runs1/seed223 only. No fresh/menu/absent, timestamp edits, replacement town, or forced save.

Before and after: Bloodline1 / Sable Ash / FighterL1 XP24/60 / gold148 / Legacy4 / bestD3 / hauls1/3. Keep armour, loot armour, legacy health persist. No new completed run, XP, gold on recovered camp. Incidental real elapsed interruption gives zero active credit and is distinct from planned absences (none yet taken).

Explicit timer outputs surviving in conversation: active64.194s after storage control read,76.481s after supplies inspection,84.525s after supplies buttons. Earlier unmetered UI play credited0. Timer increments only between returned UI results and next direct UI decision (tool/loading excluded). A27.063s helper-writing interval was explicitly removed. Cold phase proved active84.525s; no40m claim. Tools conservatively190 with setup failures/wrappers counted; image reads2(each once).

Coverage: house manually built, first earned full haul D3, freeforge and storehouse manually built; first haul reconciles124banked+24salvage=148,XP24,Legacy4,0deaths. First fights run observed direct D1,D2archer text; screenshot later showed haul rather than combat. Own changes: Legacyhealth,keepforheirsarmour,lootarmour. Actual pen attempt1 opens public lock Opens meetMother; completedwrittenedits0. No prescribed absences or fast runs.
