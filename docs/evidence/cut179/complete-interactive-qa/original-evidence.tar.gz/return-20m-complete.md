# First prescribed return: 20m

Actual credited active seconds: 419.461 (minimum 300 exceeded while reading the new run and newly unlocked hero pen). Cold remains 2416.452. Tools 735 conservatively; image reads 9. Same original earned save.

Initial return run #6: D8 returned, zero deaths. Carry161 + salvage19=180 gross earned; exit96 (60%, loss65) + salvage19 - repeat leash30 =85 wallet173→258. Porter hauled115. FighterXP180+58=238/240 L2; HeroLegacy13+1=14; style19+1=20. Owner Details confirmed238/240 and14 before gift. Earned default Legacy gift+2→16, HealthI cost15→1, +3HP. Forge leather200 wallet258→58.

Own named Grak edit: prior selfhp<30 follow → selfhp<50 follow, above adjacent≥1 attack. This fifth completed companion edit was saved and present on the next actual send. Screenshot return-20m-edit-Grak.png read once. Actual send #7: hero41HP, leather blocks frequent attacks; Grak limped home atD6 after gas. Warlord fell in live log, first wall passed; Mother encountered atD13, counter learned. Hero banked2044 atD13 (1608 secured+436 at100%), alive9/33 starving−12. No hero death. Kept mail+1, salvaged29, repeatleash30. Actual wallet58−37 insureleather+2044+29−30=2064, global Gold ledger supplied missing setup insurance37. Fighter238+322=560 total, leveledL3, XP320/540; Legacy1+6=7; style20+21=41; bestD13.

Pen now genuinely opened after Mother encounter. Completed first actual owner Sable Ash hero written edit: package bank hp<30 and depth≥9 was copied/edited to hp<40 and depth≥9 →bank. Visible own written1/4 ABOVE packages8; owner Sable Ash L3 card remains visible. Actual attempt selected return condition first, canceled without change, then bank condition first and chose40. Screenshot return-20m-hero-edit.png read once. This is a completed written hero rule, distinct from earlier two locked hero attempts and drills/packages. Intent: bank sooner against Mother gas; next actual-send persistence pending. No inferred causal benefit; forecast remains rough.

Screenshots return-20m.png, return-20m-edit-Grak.png, return-20m-hero-edit.png. All audio unassessed. Remaining ordered4h/8h phases, hero-death/verdict breadth still missing because no actual deaths yet.
