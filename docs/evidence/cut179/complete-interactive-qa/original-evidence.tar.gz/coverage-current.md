# Coverage checkpoint before second fast run

Cold phase proved active1596.732s (26m36.732s). No prescribed20m/4h/8h absence yet. Conservative tools398 incl this admin write; image reads3 once each.

Manual construction: house, forge, storehouse, kennel; genuinely earned single seed223 lineage. FreePorter hired; Scout hired for100; readsheets include sends eachrest, town nowdeparture countdown.

Own configurations include Legacyhealth,keepforheirsarmour,lootarmour,secondleash30,forgeaim200,Steady3-run drill,GuardedL1,and fieldedGrak. Packages/drill are not written edits.

Actual written-entry/edit attempts6: heroPen atD3 lockedMother; Skim ownedwriter reorder; Skim ownedwriter25→50; heroPen afterGuarded readonly rows lockedMother; Grak ownedwriter reorder; Grak ownedwriter25→30. Completed manual rowchanges4, all companions: Skim2 andGrak2. Completed hero hand edits0. Each owner explicitly named in openedwriter: ratSkimL1 andgoblinGrakL1. Priority HPfollow row first, adjacentattack second. Skim50 order persisted through first actual fast send (ui-106); Grak30 not yet sent. No claimed tactic/package or lock as completed hand edit.

Actual completed runs3: two default fights-mode runs (D3,D4) and one selected fast-mode run (D6). Direct snapshots/readings, toolbuffered setup elapsed excluded from active timer. Hero deaths0. Goal next actual fast send and direct outcome read to complete2fast. Scout enableduncapped clock; all subsequent navigations retain dev1/runs1/seed223 and nofresh/menu.

Report1:124collected+24salvage=148,XP24,Legacy4. Report2:118start+126collected+26salvage=270,XP+42→FighterL2XP6/240,Legacy+2→6;class/styletokens+3 includesreputation1. Report3:70start+281collected+30salvage−30repeatedleash=351,XP+78→84/240,Legacy+3→9,class/styletokens total12. Scout purchase100→251. Need full owner/detail reconciliation each prescribed return still.
