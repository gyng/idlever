# Firsthand lapse candidates / evidence

Confirmed product gap: Combat log · repeated “Foe → Sable Ash”, “Foe → Foe”, “Foe · fell” · expected usable actor identity, so I can tell who attacked whom · seed223 second fights run (ui-55.json) and first fast run (ui-85.json); repeated across separate actual sends.
Coordinator subsequently supplied a source diagnosis and independent regression reproduction identifying lost actor-name fallback. I did not read source or that regression artifact, and the frozen b60d282 build is unchanged. This is QA, not blind rating; diagnosis is coordinator-provided, not firsthand game evidence.

Unexplained unit candidate: Companions card · “FETCHERSkim L1 / 1 heir / 5/5 · 2/2” · expected units for both fractions; I could not establish the second fraction from the card and considered a combat stat · seed223 ui-71.json and ui-72.json. The opened Skim writer independently shows2/2 rows. Coordinator later explained that card fractions areHP andwrittenrows, but neither unit is printed. Need reproduce through next public owner view and preserve clear report category.

Worker-source candidate (not confirmed/final): WORKERS opened after my free Porter hire lists checked quartermaster and porter; I have not yet found a source/name for Quartermaster from the public sheets. Clicking quartermaster text changed nothing, but button affordance has not yet been visually inspected; do not file inert-text as a product defect without that distinction.
