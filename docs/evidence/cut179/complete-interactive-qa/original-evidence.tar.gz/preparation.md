# Interactive QA preparation

Prepared 2026-10-12. No browser started; no town/save created; zero play credit.

This is QA, not a blind rating. The automatically supplied user AGENTS.md game operating manual was present in context before the task; it describes the game, invariants, repository map, and operational commands. I have not separately opened design/source/history, other QA reports, or scorecards. Read eval/QA_PROMPT.md, eval/RATING.md, and docs/FUN_EVAL_IDLE.md. The permitted tools/driver.mjs header read printed through line 180, so it also exposed some driver implementation (checkpoint, DOM operations, send/watch and beginning of sheets) inadvertently; no game source was read.

Await final accepted immutable build URL/release before starting. Fresh earned seed223 save; runs=1 each visit; fresh/menu only initially. Planned headless driver port41433 with --checkpoint. Restore only its unchanged earned committed game storage after browser failure; no manufactured save/progress/time.

Horizon: actual direct active40m cold; ordered20m absence + active5m;4h absence + active5m;8h absence + active20m. Previous attempts transfer zero credit. Track reading/deciding/observing only; tools/loading/admin/report time excluded. Split watch into short direct sampling and observation so buffered watch results are evidence, not active time.

Required: two fights and two fast watched runs; every hero death, because link, trace/replay when offered; >=four own configurations; >=four actual written-entry/edit attempts; distinguish owner-named completed hero/companion edits from packages/patches/locks. Available drop/reorder/repeat/supply, affordable upgrades/workers and their sheets, home/report windows. Reconcile each return runs/depth/gold/classXP/Legacy against owner/total/detail views; check persisted choices on next actual send. Reproduce odd behavior once.

Budget override from coordinator: <=2000 all nested tool calls, <=120 image reads conservatively including setup/failure/wrappers; each image once. Preparation has used3 functions.exec wrappers +3 nested exec_command calls =6 conservatively counted tool calls; image reads0.

Report only original eval/qa/<BUILD>.qa_cut179_interactive.md plus own scratchpad evidence. No score, commits, pushes or deployment. Group lapse lines as defect/misread/unexplained/friction with quote/expectation/repro and counts. State actual minutes, absences, deaths and edits, including incompleteness honestly.

Open protocol issues: final immutable build URL/hash pending. The QA prompt default200-call limit is superseded by explicit prospective2000 budget. Current RATING.md40/5/5/20 three-absence horizon supersedes FUN_EVAL_IDLE.md older single-absence tier description. Sixteen human probes are referred to but this allowed FUN_EVAL_IDLE.md text contains the two explicit idle probes and five idle boundaries; no separate full sixteen-probe list is present. QA receives no scores and will cover available explicit probes through lapse evidence.

Preparation clarification: coordinator authorized /tmp/riddle-blind-reference-preflight/FRAMEWORK-1-3.md; read it. Its Framework §1 Human probe column supplies the fourteen shared probes; with the two idle probes the full sixteen are now available. Missing-probe issue resolved. Still no build release/browser/play. Added2 wrappers +nested calls; cumulative preparation calls10 conservatively, images0.
