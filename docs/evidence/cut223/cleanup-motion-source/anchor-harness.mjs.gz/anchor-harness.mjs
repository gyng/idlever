import assert from 'node:assert/strict';
import { launchBrowser } from '/home/g/p/riddle/tools/browser.mjs';
import { writeFileSync } from 'node:fs';
const browser = await launchBrowser();
try {
 const page = await browser.newPage({viewport:{width:400,height:900}});
 await page.route('**/gold-point-fixture', r=>r.fulfill({contentType:'text/html',body:'<!doctype html><html><body></body></html>'}));
 await page.goto('http://localhost:5380/gold-point-fixture');
 const result = await page.evaluate(async()=>{
  const {visibleGoldPoint}=await import('/src/ui/gold-transfers.ts');
  const panel=document.createElement('div');
  panel.style.cssText='position:fixed;left:100px;top:100px;width:100px;height:100px;overflow:hidden';
  const anchor=document.createElement('button');
  anchor.style.cssText='position:absolute;left:20px;top:140px;width:40px;height:40px;border:0;padding:0';
  panel.append(anchor);document.body.append(panel);
  const clipped=visibleGoldPoint(anchor);
  anchor.style.top='80px';const partial=visibleGoldPoint(anchor);
  anchor.style.top='20px';const visible=visibleGoldPoint(anchor);
  const cover=document.createElement('div');cover.style.cssText='position:fixed;left:100px;top:100px;width:100px;height:100px;background:black;z-index:99';document.body.append(cover);const covered=visibleGoldPoint(anchor);cover.className='sheet-wrap';cover.style.background='rgba(13,12,20,0.55)';const dimmed=visibleGoldPoint(anchor);const opaquePanel=document.createElement('div');opaquePanel.style.cssText='width:100px;height:100px;background:black';cover.append(opaquePanel);const panelCovered=visibleGoldPoint(anchor);cover.remove();const uncovered=visibleGoldPoint(anchor);
  panel.style.opacity='0';const transparent=visibleGoldPoint(anchor);
  panel.style.opacity='1';panel.style.visibility='hidden';const hidden=visibleGoldPoint(anchor);
  panel.remove();const detached=visibleGoldPoint(anchor);
  return {clipped,partial,visible,covered,dimmed,panelCovered,uncovered,transparent,hidden,detached};
 });
 assert.deepEqual(result,{clipped:null,partial:{x:140,y:190},visible:{x:140,y:140},covered:null,dimmed:{x:140,y:140},panelCovered:null,uncovered:{x:140,y:140},transparent:null,hidden:null,detached:null});
 writeFileSync('/home/g/p/riddle/docs/evidence/cut223/anchor-occlusion-final.json',JSON.stringify({result:'PASS',scope:'ten actual DOM clipping/occlusion/backdrop/visibility cases; no game or GPU performance claim',cases:result},null,2));
 console.log('PASS ten clipping/occlusion/backdrop/visibility cases');
}finally{await browser.close();}
