import assert from "node:assert/strict";
import { readFileSync, mkdirSync, writeFileSync } from "node:fs";
import { gunzipSync } from "node:zlib";
import { createHash } from "node:crypto";
import { launchBrowser } from "../../tools/browser.mjs";

const url = process.env.IDLEVER_TEST_URL ?? "http://localhost:5380/";
const out = process.env.IDLEVER_GOLD_OUT;
if (out) mkdirSync(out, { recursive: true });
const fixture = "docs/evidence/cut219/ui-inputs-final/earned-inherited-offer-home.game.json.gz";
const raw = gunzipSync(readFileSync(new URL(`../../${fixture}`, import.meta.url))).toString();
const binary = readFileSync(new URL("../src/engine/pkg/idlever_wasm_bg.wasm", import.meta.url));
const hash = (b) => createHash("sha256").update(b).digest("hex");
const result = { fixture, fixtureSha256: hash(raw), layouts: [], errors: [], packages: [] };
let checks = 0;
const browser = await launchBrowser();
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const packets = [];
  page.on("response", (r) => {
    if (r.url().includes("idlever_wasm_bg.wasm"))
      packets.push(r.body().then((b) => ({ bytes: b.length, sha256: hash(b) })));
  });
  page.on("pageerror", (e) => result.errors.push(e.message));
  await page.goto(`${url}?fresh=1&runs=0`);
  await page.waitForFunction(() => window.__idlever?.booted);
  assert.equal(await page.evaluate(() => window.__idlever.kind), "wasm");
  await page.evaluate(() => {
    window.__idleverGoldProof = [];
    new MutationObserver((records) => {
      for (const record of records)
        for (const node of record.addedNodes) {
          if (!(node instanceof HTMLElement) || !node.classList.contains("coin-flight")) continue;
          window.__idleverGoldProof.push({
            delta: Number(node.dataset.goldDelta),
            why: node.dataset.goldReason,
            width: parseFloat(node.style.width),
            left: parseFloat(node.style.left),
            top: parseFloat(node.style.top),
            frames: node.getAnimations()[0]?.effect?.getKeyframes(),
          });
        }
    }).observe(document.body, { childList: true });
  });
  const clear = () =>
    page.evaluate(() => {
      window.__idleverGoldProof = [];
    });
  const particles = () => page.evaluate(() => window.__idleverGoldProof);
  const load = async () => {
    await clear();
    assert.equal(
      await page.evaluate(
        (raw) =>
          window.__idlever.importSave(
            JSON.stringify({ engine: raw, loadout: [], runs: 0, last_seen: Date.now() }),
          ),
        raw,
      ),
      true,
    );
    await page.waitForTimeout(60);
    assert.deepEqual(await particles(), []);
    checks++;
    await page.evaluate(async () => {
      document.documentElement.dataset.juice = "on";
      const { setEffectsLevel } = await import("/src/render/fxpref.ts");
      setEffectsLevel("full");
    });
  };
  for (const width of [320, 400, 1440])
    for (const scale of [1, 2]) {
      await page.setViewportSize({ width, height: 900 });
      await load();
      await page.evaluate((scale) => {
        document.documentElement.style.fontSize = `${16 * scale}px`;
      }, scale);
      await page.locator('[data-tile="forge"]').first().click();
      await page.waitForSelector(".forge");
      const before = await page.evaluate(() => ({
        gold: window.__idlever.lineage.gold,
        save: window.__idlever.engine.save(),
        kit: window.__idlever.lineage.kit,
      }));
      const slot = before.kit.find((k) => k.next?.affordable)?.slot;
      assert.ok(slot, "actual affordable permanent upgrade required");
      await clear();
      const purchase = await page.evaluate(async (slot) => {
        const a = window.__idlever,
          before = a.lineage.gold;
        const ok = await a.mutate(() => a.engine.buyKit(slot));
        return { ok, debit: before - a.lineage.gold, ledger: a.lineage.gold_ledger?.at(-1) };
      }, slot);
      await page.waitForTimeout(60);
      const records = await particles();
      assert.equal(purchase.ok, true);
      assert.ok(purchase.debit > 0);
      assert.ok(records.length >= 2 && records.length <= 12);
      assert.ok(
        records.every(
          (r) =>
            r.delta === -purchase.debit &&
            r.why === purchase.ledger.why &&
            r.width >= 4 &&
            r.width <= 12 &&
            r.frames.length === 3,
        ),
      );
      checks += 4;
      const after = await page.evaluate(() => window.__idlever.engine.save());
      await clear();
      await page.evaluate(async () => {
        await window.__idlever.refresh();
        await window.__idlever.refresh();
      });
      await page.waitForTimeout(60);
      assert.deepEqual(await particles(), []);
      assert.equal(await page.evaluate(() => window.__idlever.engine.save()), after);
      checks += 2;
      result.layouts.push({ width, scale, purchase, particles: records });
    }
  await load();
  const model = await page.evaluate(async () => {
    const { goldTransfers, goldParticleScale } = await import("/src/ui/gold-transfers.ts");
    const old = Array.from({ length: 80 }, (_, t) => ({ t, delta: 1, why: "returned D1" }));
    const spend = { t: 80, delta: -120, why: "forge sword" };
    const same = { t: 80, delta: 30, why: "returned D2", lost: 200 };
    return {
      unchanged: goldTransfers({ gold: 80, gold_ledger: old }, { gold: 80, gold_ledger: old }),
      evicted: goldTransfers(
        { gold: 200, gold_ledger: old },
        { gold: 80, gold_ledger: [...old.slice(1), spend] },
      ),
      repeated: goldTransfers(
        { gold: 100, gold_ledger: [same] },
        { gold: 130, gold_ledger: [same, same] },
      ),
      zeroNet: goldTransfers(
        { gold: 100, gold_ledger: old },
        {
          gold: 100,
          gold_ledger: [
            ...old.slice(2),
            { t: 80, delta: 50, why: "returned D3" },
            { t: 80, delta: -50, why: "forge sword" },
          ],
        },
      ),
      truncated: goldTransfers(
        { gold: 100, gold_ledger: old },
        { gold: 105, gold_ledger: [{ t: 200, delta: 2, why: "returned D8" }] },
      ),
      scales: [1, 100, 10000].map((n) => goldParticleScale(n)),
    };
  });
  assert.deepEqual(model.unchanged, []);
  assert.deepEqual(model.evicted, [{ delta: -120, why: "forge sword", bloodlineId: 1 }]);
  assert.deepEqual(model.repeated, [{ delta: 30, why: "returned D2", bloodlineId: 1 }]);
  assert.deepEqual(
    model.zeroNet.map((r) => r.delta),
    [50, -50],
  );
  assert.deepEqual(model.truncated, [{ delta: 5, why: null }]);
  assert.ok(
    model.scales[0].diameter < model.scales[1].diameter &&
      model.scales[1].diameter < model.scales[2].diameter,
  );
  checks += 6;
  for (const pref of ["off", "low", "full", "reduced"]) {
    await load();
    await page.emulateMedia({ reducedMotion: pref === "reduced" ? "reduce" : "no-preference" });
    await page.evaluate(
      async (pref) =>
        (await import("/src/render/fxpref.ts")).setEffectsLevel(pref === "reduced" ? "full" : pref),
      pref,
    );
    await clear();
    const debit = await page.evaluate(async () => {
      const a = window.__idlever,
        before = a.lineage.gold,
        slot = a.lineage.kit.find((k) => k.next?.affordable).slot;
      await a.mutate(() => a.engine.buyKit(slot));
      return before - a.lineage.gold;
    });
    assert.ok(debit > 0);
    await page.waitForTimeout(60);
    const records = await particles();
    if (pref === "off" || pref === "reduced") assert.deepEqual(records, []);
    else assert.ok(records.length > 0 && records.length <= (pref === "low" ? 5 : 12));
    checks += 2;
  }
  result.packages = await Promise.all(packets);
  assert.ok(result.packages.length);
  for (const pkg of result.packages)
    assert.deepEqual(pkg, { bytes: binary.length, sha256: hash(binary) });
  assert.deepEqual(result.errors, []);
  checks += 2;
  result.checks = checks;
  result.result = "PASS";
  if (out) writeFileSync(`${out}/results.json`, JSON.stringify(result, null, 2));
  console.log(
    JSON.stringify({
      checks,
      layouts: result.layouts.length,
      packages: result.packages,
      result: result.result,
    }),
  );
} catch (error) {
  result.failure = String(error);
  if (out) writeFileSync(`${out}/failure.json`, JSON.stringify(result, null, 2));
  throw error;
} finally {
  await browser.close();
}
