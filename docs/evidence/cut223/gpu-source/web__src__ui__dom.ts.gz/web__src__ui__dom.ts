// Tiny DOM helpers. No framework.
import { nameRefs } from "./tokens";
type Child = Node | string | number | null | undefined | false;
type Attrs = Record<string, string | number | boolean | ((e: Event) => void) | undefined>;

export function h<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  attrs?: Attrs | null,
  ...children: Child[]
): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  if (attrs)
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === false) continue;
      if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
      else if (k === "class") el.className = String(v);
      else if (v === true) el.setAttribute(k, "");
      else el.setAttribute(k, String(v));
    }
  append(el, children);
  return el;
}
/** docs/COPY.md §2: every string reaches the screen through here, so a rule the core wrote as `R2` is named by what it says
 *  (`tokens.nameRefs`) whoever wrote it. */
export function append(el: Node, children: Child[]): void {
  for (const c of children) {
    if (c === null || c === undefined || c === false) continue;
    el.appendChild(
      typeof c === "string"
        ? document.createTextNode(nameRefs(c))
        : typeof c === "number"
          ? document.createTextNode(String(c))
          : c,
    );
  }
}
export function clear(el: Element): void {
  while (el.firstChild) el.removeChild(el.firstChild);
}
export function replace(el: Element, ...children: Child[]): void {
  clear(el);
  append(el, children);
}
export const pct = (x: number): string => `${Math.round(x * 100)}%`;
export function flash(el: HTMLElement, cls = "hl", ms = 1600): void {
  el.classList.add(cls);
  setTimeout(() => el.classList.remove(cls), ms);
}
/** Cut 117 §2 (blind 8cf9050 A: "quest/breed taps gave no visible result"): a tap's result as a brief toast over the screen —
 *  ≤ 3 words (tagged at the call site), `role=status`, gone after ~1.8 s; a newer toast replaces the last. `data-toast` keeps the
 *  words for tests after it fades. */
export function toast(text: string, ms = 1800): HTMLElement | null {
  if (typeof document === "undefined") return null;
  for (const old of document.querySelectorAll(".toast")) old.remove();
  const t = h("div", { class: "toast", role: "status", "aria-live": "polite" }, text);
  document.body.appendChild(t);
  document.body.dataset.toast = text;
  setTimeout(() => t.remove(), ms);
  return t;
}
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
/** `1 item` / `4 items` (tagged at the call site). */
export const items = (n: number): string => `${n} item${n === 1 ? "" : "s"}`;
/** Seconds → `12m` (whole minutes up); under a minute `40s`. */
export const spanOf = (s: number): string =>
  s >= 60 ? `${Math.ceil(s / 60)}m` : `${Math.max(0, Math.round(s))}s`;
/** QA e75ec29 (R: the `$50` hatch and the `$75` insure charged on one tap): a paid chip takes two taps — the first arms it (its label
 *  becomes `ok $50`, `.armed`), the second pays. Cut 23 §4 (AI: "the drop confirm undid itself"): an armed chip stays armed until it
 *  is tapped again or a tap lands elsewhere — never on a timer — and a repaint that rebuilds it with the same `key` keeps it armed. */
const armedKeys = new Set<string>();
const armedNow = new Map<HTMLElement, () => void>();
if (typeof document !== "undefined")
  document.addEventListener(
    "pointerdown",
    (e) => {
      const t = e.target as Node | null;
      for (const [el, disarm] of Array.from(armedNow)) if (!(t && el.contains(t))) disarm();
    },
    true,
  );
/** Cut 25 §6 (AN: "a two-tap `ok $275`"): `armedContent` — the armed face as nodes, in place of the bare `armedLabel` (the forge's step keeps
 *  its line and turns its price into `ok $340` where it stood: the second tap lands where the first was). */
export function twoTap(
  label: string | Node[],
  armedLabel: string,
  act: () => void,
  attrs: { class?: string; disabled?: boolean; key?: string; armedContent?: () => Node[] } = {},
): HTMLButtonElement {
  const content = (): Child[] => (typeof label === "string" ? [label] : label);
  const plain =
    typeof label === "string" ? label : label.map((node) => node.textContent ?? "").join("");
  const b: HTMLButtonElement = h("button", {
    class: attrs.class ?? "chip mini",
    disabled: attrs.disabled,
    "aria-label": plain,
  });
  const key = attrs.key;
  let armed = false;
  const disarm = (): void => {
    armed = false;
    armedNow.delete(b);
    if (key) armedKeys.delete(key);
    if (!b.isConnected) return;
    b.classList.remove("armed");
    replace(b, ...content());
    b.setAttribute("aria-label", plain);
  };
  const arm = (): void => {
    armed = true;
    armedNow.set(b, disarm);
    if (key) armedKeys.add(key);
    b.classList.add("armed");
    replace(b, ...(attrs.armedContent ? attrs.armedContent() : [armedLabel]));
    b.setAttribute("aria-label", armedLabel);
  };
  b.onclick = (e: Event): void => {
    e.stopPropagation();
    if (armed) {
      armed = false;
      armedNow.delete(b);
      if (key) armedKeys.delete(key);
      act();
      return;
    }
    arm();
  };
  append(b, content());
  if (key && armedKeys.has(key) && !attrs.disabled) arm();
  return b;
}
