/* tslint:disable */
/* eslint-disable */

export class Game {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Take control: the hero's next action — `{"k":"step","dx":1,"dy":0}` · `{"k":"verb","verb":{"v":"drink","a":"heal"}}` · `{"k":"wait"}`.
     */
    act(action_json: string): void;
    addBloodline(): string;
    /**
     * RUNS_UI: the open app's clock (`elapsed_ms`): rest, then runs, unwatched; a run in flight stays
     * in flight. Returns the Advance (the runs it finished, the run under way).
     */
    advance(elapsed_ms: number): string;
    /**
     * After the ending: a new lineage under `variant` (`no_rest | short_list | bones_only |
     * hunted`); returns the Lineage.
     */
    ascend(variant: string): string;
    /**
     * `ids`: JSON array of item ids from `StepResult.exit_pending.items` to vault.
     * QA on 23ed91f: resolve the pending exit by the keep preference and owned automations
     * (`ExitPending.auto_keep`, replacing a weaker vault item of the same category when the
     * vault is full) — the skipped keep sheet's call (`keep([])` keeps nothing).
     */
    autoKeep(): string;
    /**
     * §5: queue a `return` for the hero's next action (the rules untouched).
     */
    bail(): void;
    /**
     * Cut 30 §3: deposit gold in the bank (capped); returns the Lineage.
     */
    bankDeposit(amount: number): string;
    /**
     * Cut 30 §3: take gold out of the bank; returns the Lineage.
     */
    bankWithdraw(amount: number): string;
    /**
     * Begin an unlocked numbered dungeon; all validation precedes mutation.
     */
    beginDescent(tier: number): string;
    breed(a: number, b: number): string;
    buildTown(id: string): string;
    /**
     * Cut 23 §1: buy the next forge step of `weapon | armour | pack`; returns the Lineage.
     */
    buyKit(slot: string): string;
    /**
     * Cut 122 §5: buy the next send's ration by hand (`Forecast.hunger`); returns the Lineage.
     */
    buyRation(): string;
    buySupply(kind: string): string;
    /**
     * Cut 118 §4: commission the survey (the deep forks open early); returns the Lineage.
     */
    buySurvey(): string;
    /**
     * Cut 15 §2: buy with gold at `UnlockInfo.gold` (marks untouched); returns the lineage.
     */
    buyUnlockGold(unlock: string): string;
    buy(unlock: string): string;
    /**
     * §1: each cage preference measured for the active set — `CageOption[]` (`pref`,
     * `current`, `depth`, `reach`/`reach_delta`, `bank`/`bank_delta`, `gold`/`gold_delta`,
     * `delta` — the picker's headline — and `pm`). Four camp panels (three new): call it when
     * the cage tablet's picker opens, or after the refine; memoised like the forecast.
     * QA on 524827b: `refined` — measure on the camp's refined pass (the sheet's current option
     * is then the camp's number); absent, the lineage's own read (`forecast::camp_sims`).
     */
    cageForecast(refined?: boolean | null): string;
    /**
     * §4: take one item of the opened vault (`Snapshot.vault_choice.items[].id`); returns
     * the Snapshot.
     */
    choose(item_id: number): string;
    clearSupplies(): string;
    /**
     * Cut 29 §5: commission the next work with gold; returns the Lineage.
     */
    commission(): string;
    companionVocabulary(id: number): string;
    /**
     * QA on 23ed91f: the death's shown patches with the camp's own reach deltas (seconds:
     * four camp panels); `death` answers first with them `camp_pending`.
     */
    deathDeltas(run_id: number): string;
    death(run_id: number): string;
    deleteStartingKit(id: string): string;
    /**
     * Numbered dungeon preview, computed without changing the selected bloodline.
     */
    descentOffer(tier: number): string;
    /**
     * Cut 27 §2: the edit as a scene against `prev` (JSON RuleSet: the sent set) — `Divergence`
     * or `null` when the sets play alike on every seed tried. Reads the camp's paired panels
     * (cached by the forecast and its `vs`); call it after the forecast's `vs`.
     */
    divergence(prev: string): string;
    /**
     * Cut 29 §1: an oath draw (◆2): a fresh standing oath; returns the Lineage.
     */
    drawOath(): string;
    dropSupply(id: number): string;
    /**
     * Cut 30 §2: equip a package (`id`: a stance, a tactic in `slot` 0/1, a temperament); returns the Lineage.
     */
    equipPackage(id: string, slot: number): string;
    exportRules(): string;
    /**
     * Cut 27 §1: right after `send` — play the floors the set clears ≥ 95 % and return the fold
     * line (`FoldLine`: `from`, `to`, `clear`, `gold`, `beats`, `chips`, `floors[]` with each
     * floor's snapshot and events, `step` as one `step()`). Nothing folded: `to < from`.
     */
    fold(): string;
    forecastEstimate(): string;
    /**
     * Cut 28 §2: the camp's move against `prev` (JSON RuleSet: the set sent), attributed to the
     * state since the send and the rows (`ForecastMove`: `whole`, `parts[{kind, text, move}]`,
     * `lead`, `rows`, `state`), or `null` when no send was recorded. 2–6 camp panels: call it on
     * a background lane after the forecast.
     */
    forecastMove(prev: string): string;
    /**
     * Cut 6 §9: the same forecast at 100 sims (same seeds first), the client's refine pass.
     */
    forecastRefine(): string;
    forecastVsEstimate(prev: string): string;
    /**
     * Cut 22 §3: the edit's paired move — the active set's camp panel minus `prev`'s (JSON
     * RuleSet: the set as it was at the last painted forecast) on the same seeds —
     * `ForecastVs` (`depths[{depth, delta, pm, abs_pm}]`, `bank`/`death`/`return`/`gold` as
     * `{delta, pm}`, `sims`). The active panel is the forecast's own (cached); the previous
     * set's is usually cached from its paint. Call it after the forecast's first paint.
     */
    forecastVs(prev: string): string;
    forecast(): string;
    /**
     * Cut 26 §2: the fork chip's option tablet — both stairs of the fork at `fork` (5, 9, 14, 19,
     * 24) for the active set: `ForkOption[]` (`biome`, `far`, `current`, `route` — the set's
     * route with that stair —, `depth` the band's last floor, `reach`/`reach_delta`, `bank`,
     * `gold`, `death`, `delta`, `pm`). One camp panel (the other stair's); memoised. A route
     * edit itself is `setRules` with the set's `route` (fork depths of its far stairs).
     */
    forkForecast(fork: number, refined?: boolean | null): string;
    /**
     * Cut 29 §1: forswear the sworn oath `id` (either slot); returns the Lineage.
     */
    forswearOathId(id: string): string;
    /**
     * Cut 28 §1: forswear the sworn oath (half its price back); returns the Lineage.
     */
    forswearOath(): string;
    /**
     * A new Game from a save (static).
     */
    static fromSave(save: string): Game;
    hatch(egg_id: number): string;
    hire(id: string): string;
    importRules(text: string): string;
    /**
     * Insure a vault item against loss on death (25% of salvage value ×10).
     */
    insure(id: number): string;
    keep(ids_json: string): string;
    /**
     * Cut 23 §1: the forge's ladders with each next step's paired forecast move.
     */
    kitDeltas(): string;
    kitEstimates(): string;
    learnClassSkill(id: string): string;
    lineage(): string;
    /**
     * Replace the state from a save; returns the Lineage.
     */
    load(save: string): string;
    /**
     * `itemIds`: JSON array of vault item ids to bring.
     */
    loadout(item_ids: string): void;
    /**
     * Start a fresh lineage in place; returns the Lineage.
     */
    newLineage(seed: number): string;
    constructor(seed: number);
    /**
     * Cut 30.5: the haul chest into the purse; returns the Lineage.
     */
    openChest(): string;
    packageOptionsForKey(sims: number, choices_json: string): string;
    packageOptionsFor(sims: number, choices_json: string): string;
    packageOptionsKey(sims: number): string;
    /**
     * Cut 30 §2: every package move priced on the paired panel (`PkgOption[]`, best first).
     */
    packageOptions(sims: number): string;
    /**
     * Cut 30 §2: take a wake card (`Lineage.packages.offer`); returns the Lineage.
     */
    pickTemperament(id: string): string;
    /**
     * Cut 30.5, week 2: promote the worker whose rank is on offer; returns the Lineage.
     */
    promote(id: string): string;
    rebirthHero(token: string): string;
    renameHero(name: string): string;
    /**
     * RUNS_UI: a held run re-simulated from its send (the Replay), or `null`.
     */
    replay(run_id: number): string;
    resetClassSkills(): string;
    respecLegacy(): string;
    /**
     * Cut 30 §1: revoke (or restore) a drill — one tap; returns the Lineage.
     */
    revokeDrill(boss: string, revoked: boolean): string;
    /**
     * Cut 119 §0: revoke (or restore) the default tame row (`Lineage.pets.tame`) — one tap; returns the Lineage.
     */
    revokeTame(revoked: boolean): string;
    /**
     * Offline batch without the worst-death verdict (report carries `worst_death_id`).
     */
    runOfflineQuick(elapsed_s: number): string;
    /**
     * Resumable transport slice. Before `last`, returns `slice_pending` only;
     * the final call settles one report for the whole absence.
     */
    runOfflineSlice(elapsed_s: number, last: boolean): string;
    runOffline(elapsed_s: number): string;
    saveStartingKit(name: string, config: string, id?: string | null): string;
    save(): string;
    /**
     * Cut 118 §1: the next send seeks `boss` (a band boss with a token banked; the token is spent at the send);
     * `""` sends in order (the default). Returns the Lineage (`feats.seek`, `feats.tokens`).
     */
    seekBoss(boss: string): string;
    /**
     * Cut 118 §1: each banked token's seek priced from his stone — `SeekOption[]` (`boss`, `depth`, `stone`,
     * `tokens`, `reach`, `past`, `death`, `sims`, `current`). One camp panel per token boss: call it off the foreground.
     */
    seekForecast(): string;
    /**
     * Cut 29 §2: the camp showed the newly opened systems (clears `Lineage.systems[].new`); returns the Lineage.
     */
    seenSystems(): string;
    /**
     * Cut 30.5: hire the lit node's worker; returns the Lineage.
     */
    selectBloodline(id: number): string;
    selectSet(index: number): string;
    selectStartingKit(id: string): string;
    /**
     * QA on 308f045: take an item out of the vault — salvaged at a bank's share (the lineage).
     */
    sellVault(id: number): string;
    send(): string;
    setClass(_class: string): string;
    setCompanionRules(id: number, set: string): void;
    setFamilyLean(when: string): string;
    /**
     * Cut 13 §2: pick the new heir's trait from `Lineage.trait_offer` (before the first
     * send; a send without a pick keeps the first); returns the Lineage.
     */
    setInheritedTrait(name: string): string;
    setKeepPref(pref: string): string;
    /**
     * Hero looks: the heirs' cosmetic look (`male | female | cat`); returns the Lineage.
     */
    setLook(look: string): string;
    /**
     * Cut 29 §4: set the standing orders (a `StandingOrders` JSON); returns the Lineage.
     */
    setOrders(orders_json: string): string;
    setParty(ids_json: string): string;
    /**
     * Cut 120 §2: a worker's rank-II perk chip (`WorkNode.perks`; `apprentice`: cheaper steps · keeps a reserve,
     * `scout`: shorter rest · safer start); returns the Lineage.
     */
    setPerk(worker: string, perk: string): string;
    /**
     * §3: the loadout's repeat on or off (off refunds the re-packed shelf); returns the Lineage.
     */
    setRestock(on: boolean): string;
    setRules(set: string): void;
    setSetFocus(family?: string | null): string;
    setSpecialization(id: string): string;
    /**
     * §1: the floor the next sends start on — 1 or a lit waystone (`Lineage.waystones`);
     * refused when not lit; returns the Lineage (`start`, `start_toll`).
     */
    setStart(depth: number): string;
    setStartingKit(config: string): string;
    /**
     * Cut 111: pick a tactic's L3 row variant (0 · 1); returns the Lineage.
     */
    setTacticVariant(id: string, variant: number): string;
    setTrait(name: string): string;
    /**
     * Cut 118 §2: opt into week `week`'s trial (`Lineage.feats.trials[].week`; a negative week opts out); the next
     * send while away plays it. Returns the Lineage.
     */
    setTrial(week: number): string;
    /**
     * §4: what an unwatched vault choice takes (`weapon | armour | potion | scroll`).
     */
    setVaultPref(pref: string): string;
    /**
     * Cut 30.5: switch a hired worker off or on; returns the Lineage.
     */
    setWorker(id: string, on: boolean): string;
    /**
     * Cut 30 §2: spend marks on a package's next level; returns the Lineage.
     */
    spendLevel(id: string): string;
    /**
     * §1: each start the tablet offers (D1 and every lit waystone) measured for the active
     * set — `StartOption[]` (`depth`, `current`, `toll`, `short`, `bar`, `reach`/`reach_delta`,
     * `bank`/`bank_delta`, `gold`, `net`/`net_delta`, `pm`). One camp panel per option (seconds
     * in wasm): call it when the tablet opens, or after the refine; memoised like the forecast.
     */
    startForecast(refined?: boolean | null): string;
    step(turns: number): string;
    supplyCatalogue(): string;
    /**
     * Cut 30 §5: the day's free swap of the quest on the board; returns the Lineage.
     */
    swapQuest(): string;
    /**
     * Cut 28 §1: swear the standing oath `id` (pays its price); returns the Lineage.
     */
    swearOath(id: string): string;
    /**
     * Take control (a secondary mode): the player has the watched run's hero (`on`), or hands him back.
     */
    takeControl(on: boolean): void;
    /**
     * Cut 115 §4: take a death's tactic fix (`Death.pick`: the tactic worn in its variant, credited
     * `taught`); returns the Lineage.
     */
    takeFix(id: string, variant: number): string;
    /**
     * Cut 113 §3: take one offer (`drill · legacy · forge · marks`) of the return's pick; returns the Lineage.
     */
    takeReturnPick(id: string): string;
    /**
     * Cut 118 §4: tithe `n` Legacy points at the falling rate (Kit complete); returns the Lineage.
     */
    tithe(n: number): string;
    /**
     * Cut 30 §2: empty a tactic or temperament slot; returns the Lineage.
     */
    unequipPackage(id: string): string;
    /**
     * Cut 4 §9: the catalogue with `delta` simulated for every open card and verb (memoised
     * per lineage state; `unlocks()` carries the same deltas afterwards without sims).
     */
    unlockDeltas(): string;
    unlocks(): string;
    /**
     * Blind b58b431: a Legacy upgrade bought while the hero is away, for the next run.
     */
    upgradeHeroNext(id: string): string;
    upgradeHero(id: string): string;
    vocabulary(): string;
    /**
     * Cut 29 §1 (E1): at a wall, the one-row edit that passes it (`WallEdit` JSON, or `null`) —
     * searched once a day (seconds to minutes in wasm: call it on the report, off the foreground),
     * the cached offer after (`Lineage.wall`).
     */
    wallEdit(): string;
}

export function version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_game_free: (a: number, b: number) => void;
    readonly game_act: (a: number, b: number, c: number) => [number, number];
    readonly game_addBloodline: (a: number) => [number, number, number, number];
    readonly game_advance: (a: number, b: number) => [number, number];
    readonly game_ascend: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_autoKeep: (a: number) => [number, number];
    readonly game_bail: (a: number) => void;
    readonly game_bankDeposit: (a: number, b: number) => [number, number, number, number];
    readonly game_bankWithdraw: (a: number, b: number) => [number, number, number, number];
    readonly game_beginDescent: (a: number, b: number) => [number, number, number, number];
    readonly game_breed: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_buildTown: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_buy: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_buyKit: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_buyRation: (a: number) => [number, number, number, number];
    readonly game_buySupply: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_buySurvey: (a: number) => [number, number, number, number];
    readonly game_buyUnlockGold: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_cageForecast: (a: number, b: number) => [number, number];
    readonly game_choose: (a: number, b: number) => [number, number, number, number];
    readonly game_clearSupplies: (a: number) => [number, number];
    readonly game_commission: (a: number) => [number, number, number, number];
    readonly game_companionVocabulary: (a: number, b: number) => [number, number, number, number];
    readonly game_death: (a: number, b: number) => [number, number, number, number];
    readonly game_deathDeltas: (a: number, b: number) => [number, number, number, number];
    readonly game_deleteStartingKit: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_descentOffer: (a: number, b: number) => [number, number, number, number];
    readonly game_divergence: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_drawOath: (a: number) => [number, number, number, number];
    readonly game_dropSupply: (a: number, b: number) => [number, number, number, number];
    readonly game_equipPackage: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly game_exportRules: (a: number) => [number, number];
    readonly game_fold: (a: number) => [number, number];
    readonly game_forecast: (a: number) => [number, number];
    readonly game_forecastEstimate: (a: number) => [number, number];
    readonly game_forecastMove: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_forecastRefine: (a: number) => [number, number];
    readonly game_forecastVs: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_forecastVsEstimate: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_forkForecast: (a: number, b: number, c: number) => [number, number];
    readonly game_forswearOath: (a: number) => [number, number, number, number];
    readonly game_forswearOathId: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_fromSave: (a: number, b: number) => [number, number, number];
    readonly game_hatch: (a: number, b: number) => [number, number, number, number];
    readonly game_hire: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_importRules: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_insure: (a: number, b: number) => [number, number, number, number];
    readonly game_keep: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_kitDeltas: (a: number) => [number, number];
    readonly game_kitEstimates: (a: number) => [number, number];
    readonly game_learnClassSkill: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_lineage: (a: number) => [number, number];
    readonly game_load: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_loadout: (a: number, b: number, c: number) => [number, number];
    readonly game_new: (a: number) => number;
    readonly game_newLineage: (a: number, b: number) => [number, number];
    readonly game_openChest: (a: number) => [number, number, number, number];
    readonly game_packageOptions: (a: number, b: number) => [number, number];
    readonly game_packageOptionsFor: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly game_packageOptionsForKey: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly game_packageOptionsKey: (a: number, b: number) => [number, number];
    readonly game_pickTemperament: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_promote: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_rebirthHero: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_renameHero: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_replay: (a: number, b: number) => [number, number];
    readonly game_resetClassSkills: (a: number) => [number, number, number, number];
    readonly game_respecLegacy: (a: number) => [number, number, number, number];
    readonly game_revokeDrill: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly game_revokeTame: (a: number, b: number) => [number, number, number, number];
    readonly game_runOffline: (a: number, b: number) => [number, number];
    readonly game_runOfflineQuick: (a: number, b: number) => [number, number];
    readonly game_runOfflineSlice: (a: number, b: number, c: number) => [number, number];
    readonly game_save: (a: number) => [number, number];
    readonly game_saveStartingKit: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number, number];
    readonly game_seekBoss: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_seekForecast: (a: number) => [number, number];
    readonly game_seenSystems: (a: number) => [number, number];
    readonly game_selectBloodline: (a: number, b: number) => [number, number, number, number];
    readonly game_selectSet: (a: number, b: number) => [number, number];
    readonly game_selectStartingKit: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_sellVault: (a: number, b: number) => [number, number, number, number];
    readonly game_send: (a: number) => [number, number, number, number];
    readonly game_setClass: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setCompanionRules: (a: number, b: number, c: number, d: number) => [number, number];
    readonly game_setFamilyLean: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setInheritedTrait: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setKeepPref: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setLook: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setOrders: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setParty: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setPerk: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly game_setRestock: (a: number, b: number) => [number, number];
    readonly game_setRules: (a: number, b: number, c: number) => [number, number];
    readonly game_setSetFocus: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setSpecialization: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setStart: (a: number, b: number) => [number, number, number, number];
    readonly game_setStartingKit: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setTacticVariant: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly game_setTrait: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setTrial: (a: number, b: number) => [number, number, number, number];
    readonly game_setVaultPref: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_setWorker: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly game_spendLevel: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_startForecast: (a: number, b: number) => [number, number];
    readonly game_step: (a: number, b: number) => [number, number];
    readonly game_supplyCatalogue: (a: number) => [number, number];
    readonly game_swapQuest: (a: number) => [number, number, number, number];
    readonly game_swearOath: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_takeControl: (a: number, b: number) => [number, number];
    readonly game_takeFix: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly game_takeReturnPick: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_tithe: (a: number, b: number) => [number, number, number, number];
    readonly game_unequipPackage: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_unlockDeltas: (a: number) => [number, number];
    readonly game_unlocks: (a: number) => [number, number];
    readonly game_upgradeHero: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_upgradeHeroNext: (a: number, b: number, c: number) => [number, number, number, number];
    readonly game_vocabulary: (a: number) => [number, number];
    readonly game_wallEdit: (a: number) => [number, number];
    readonly version: () => [number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
