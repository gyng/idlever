//! Cut 30 §3–5 (docs/CUT30.md, docs/TOWN.md): the town's core — its buildings (each built on its
//! trigger, the next plot staked), the bank (deposits earn interest each night, capped), the four
//! tracks (character · items · scale · town: the stage, the next one and its trigger) and what grew
//! on each over an absence; and the quest board (one plain goal, a reward, a progress bar, no stake).
//! Everything here is derived from the lineage or deterministic on it; the town's walkers are the
//! client's (cosmetic, never read back).
use crate::engine::LineageState;
use crate::wire::{GrewLine, QuestWire, TownWire, TrackWire};
use serde::{Deserialize, Serialize};

/// The buildings v1, in the order the plots are staked, each with its trigger (≤ 3 words).
pub const BUILDINGS: [(&str, &str); 3] = [("blacksmith", "four delves"), ("kennel", "tame a pet"), ("bank", "a night's purse")];

/// A night's interest on the bank, in percent, and the bank's cap in nights of net income.
/// Cut233: `balance` `gold.bank_pct` (interest, % a night), `gold.bank_nights`, `gold.bank_floor`.
pub fn bank_pct() -> i32 {
    crate::balance::get().gold.bank_pct
}
pub fn bank_nights() -> i32 {
    crate::balance::get().gold.bank_nights
}

fn manual_default() -> bool { true }
pub fn home_default() -> bool { true }

/// The lineage's town (`LineageState::town`).
#[derive(Clone, Debug, Default, Serialize, Deserialize, PartialEq, Eq)]
pub struct Town {
    #[serde(default)]
    pub forge_eligible:bool,
    #[serde(default)]
    pub kennel_eligible:bool,
    /// Actual legendary finds unlock their equipment shape for every resident.
    #[serde(default, skip_serializing_if="std::collections::BTreeSet::is_empty")]
    pub owned_shapes: std::collections::BTreeSet<String>,
    #[serde(default,skip_serializing_if="std::collections::BTreeMap::is_empty")]
    pub piece_victories: std::collections::BTreeMap<String,u32>,
    /// Multi-bloodline Savings pays per shared night of completed expeditions.
    #[serde(default, skip_serializing_if="Option::is_none")]
    pub shared_night_runs: Option<u32>,
    /// Old towns already have a resident; genuinely new towns start empty.
    #[serde(default)]
    pub home: Option<bool>,
    /// New towns collect each returned haul automatically; old saves keep their chest.
    #[serde(default)]
    pub auto_collect: bool,
    #[serde(default)]
    pub gold_v: u32,
    /// Buildings require construction by hand, including unbuilt plots in old saves.
    #[serde(default = "manual_default")]
    pub manual: bool,
    /// Buildings built, in the order they were (id, the day built).
    #[serde(default)]
    pub built: Vec<(String, u32)>,
    /// Gold in the bank, and the interest it paid in all.
    #[serde(default)]
    pub bank: i32,
    #[serde(default)]
    pub interest: i32,
    /// The quest on the board (from the Warlord slain), the quests kept, the day of the last free
    /// swap.
    #[serde(default)]
    pub quest: Option<Quest>,
    #[serde(default)]
    pub quests_done: u32,
    #[serde(default)]
    pub swap_day: Option<u32>,
    #[serde(default)]
    pub quest_seq: u32,
    /// A harness's switch (the dayplayer's leave-one-out): the board never opens.
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub off: bool,
    /// The day on the lineage's clock inside an absence (the offline loop's, as its sends finish):
    /// `LineageState::day` moves at an absence's start, the board's day at every day it crosses.
    #[serde(skip)]
    pub today: u32,
}

pub(crate) fn forge_qualified(l:&LineageState)->bool{crate::tree::hired(l,"scout")&&l.persistent.completed>=crate::balance::get().unlocks.forge_delves&&(l.persistent.exit_gold_credit||l.gold_ledger.iter().any(|x|x.delta>0&&crate::engine::is_exit_why(&x.why)))}
pub(crate) fn kennel_qualified(l:&LineageState)->bool{crate::tree::hired(l,"scout")&&(l.tamed_kinds()>0||l.all_companions().next().is_some())}
/// A harness's literal lineage offers a plot the moment it qualifies; a player's lineage gets its plots one at a
/// time at a run's report (Cut232, `news`: one new decision a report — `open_plot`).
pub(crate) fn refresh_eligibility(l:&mut LineageState){if l.pkg.literal {l.town.forge_eligible|=forge_qualified(l);l.town.kennel_eligible|=kennel_qualified(l);}}
/// Cut232 (docs/CUT232_CADENCE.md): the first qualified plot not yet offered, offered now (the forge's, then the
/// kennel's); its id. A run's report calls it when nothing else is new there.
pub(crate) fn open_plot(l:&mut LineageState)->Option<&'static str>{
    if !l.town.forge_eligible&&forge_qualified(l){l.town.forge_eligible=true;return Some("blacksmith");}
    if !l.town.kennel_eligible&&kennel_qualified(l){l.town.kennel_eligible=true;return Some("kennel");}
    None
}
fn triggered(l: &LineageState, id: &str) -> bool {
    let literal = l.pkg.literal;
    match id {
        "blacksmith" => l.town.forge_eligible||literal&&forge_qualified(l),
        "kennel" => l.town.kennel_eligible||literal&&kennel_qualified(l),
        "bank" => l.last_night_net > 0 && l.gold >= l.last_night_net,
        _ => false,
    }
}

pub fn built(l: &LineageState, id: &str) -> bool {
    l.town.built.iter().any(|(b, _)| b == id)
}

/// Read-only construction eligibility for Journal guidance.
pub fn build_ready(l: &LineageState, id: &str) -> bool {
    if id == "house" { return !l.town.home.unwrap_or(true); }
    l.town.home.unwrap_or(true) && !built(l,id) && BUILDINGS.iter().any(|(b,_)|*b==id) && triggered(l,id)
}

/// Build every building whose trigger has happened; the ids built now.
pub fn update(l: &mut LineageState) -> Vec<String> {
    if l.town.manual { return Vec::new(); }
    let mut out = Vec::new();
    for (id, _) in BUILDINGS {
        if !built(l, id) && triggered(l, id) {
            let day = l.day;
            l.town.built.push((id.to_string(), day));
            out.push(id.to_string());
        }
    }
    out
}

/// Construction is free once its milestone is met; never happens during an absence.
pub fn construct(l: &mut LineageState, id: &str) -> Result<(), String> {
    if id == "house" {
        if l.town.home.unwrap_or(true) { return Err("already built".into()); }
        l.town.home = Some(true);
        return Ok(());
    }
    if !l.town.home.unwrap_or(true) { return Err("build a house".into()); }
    if !BUILDINGS.iter().any(|(b, _)| *b == id) { return Err("unknown building".into()); }
    if built(l, id) { return Err("already built".into()); }
    if !triggered(l, id) { return Err("not ready".into()); }
    l.town.built.push((id.into(), l.day));
    Ok(())
}

/// A building's look (1–3): the blacksmith by its forge steps, the bank by its balance.
pub fn level(l: &LineageState, id: &str) -> u32 {
    match id {
        "blacksmith" => {
            let steps: u32 = crate::kit::KIT_SLOTS.iter().map(|s| crate::kit::owned(l, s)).sum();
            1 + (steps >= 3) as u32 + (steps >= 7) as u32
        }
        "bank" => 1 + (l.town.bank >= bank_cap(l) / 2 && l.town.bank > 0) as u32 + (l.town.bank >= bank_cap(l) && l.town.bank > 0) as u32,
        _ => 1,
    }
}

/// The bank holds at most `BANK_NIGHTS` nights of net income (never under 100).
pub fn bank_cap(l: &LineageState) -> i32 {
    (bank_nights() * l.last_night_net.max(l.last_day_net / 4)).max(crate::balance::get().gold.bank_floor)
}

/// Deposit gold (refused before the bank is built; capped).
pub fn deposit(l: &mut LineageState, amount: i32) -> Result<i32, String> {
    if !built(l, "bank") {
        return Err("no bank yet".into());
    }
    let room = (bank_cap(l) - l.town.bank).max(0);
    let n = amount.min(crate::tree::purse(l)).min(room).max(0);
    if n == 0 {
        return Err(if room == 0 { "bank full".into() } else { "no gold".into() });
    }
    l.gold_move(-n, "bank deposit");
    l.town.bank += n;
    Ok(n)
}

/// Withdraw gold (all of it at most).
pub fn withdraw(l: &mut LineageState, amount: i32) -> Result<i32, String> {
    let n = amount.min(l.town.bank).max(0);
    if n == 0 {
        return Err("bank empty".into());
    }
    l.town.bank -= n;
    l.gold_move(n, "bank withdraw");
    Ok(n)
}

/// A night ended: the bank pays its interest (never negative; the balance may pass the cap by it).
pub fn night(l: &mut LineageState) -> i32 {
    // (Cut 30.5, week 2: the clerk's rank adds a quarter of a percent a night each)
    let permille = bank_pct() * 10 + crate::balance::get().tree.clerk_bonus_permille * crate::tree::bonus_rank(l, "clerk") as i32;
    let i = (l.town.bank.max(0) * permille / 1000).max(0);
    l.town.bank += i;
    l.town.interest += i;
    l.tree.ledger += i as i64;
    i
}

// ---------------------------------------------------------------- tracks

/// A track's stages v1 (docs/CUT30.md §4), each with its trigger.
pub fn stages(track: &str) -> &'static [(&'static str, &'static str)] {
    match track {
        // (each band boss's drill is a stage of the hero's: the idle climb's own milestones)
        "character" => &[
            ("Steady", ""),
            ("second stance", "meet Captain"),
            ("Warlord drilled", "meet Warlord twice"),
            ("a tactic", "slay Warlord"),
            ("pets", "first stray"),
            ("a class", "first bank"),
            ("a temperament", "heir 3"),
            ("the pen", "meet Mother"),
            ("Mother drilled", "meet Mother twice"),
            ("tactic slot 2", "meet Lich"),
            ("Lich drilled", "meet Lich twice"),
            ("Foundry drilled", "meet golems twice"),
            ("Queen drilled", "meet Queen twice"),
            ("King drilled", "meet King twice"),
        ],
        "items" => &[("pack of 3", ""), ("blacksmith steps", "first gold home"), ("a counter packed", "a drill's item")],
        // (a waystone lit deeper is the scale's next stage: the sends can start there)
        // (each band boss slain is a stage too: the descent opens past him for good)
        "scale" => &[("one hero", ""), ("party slot 2", "a second slot"), ("waystones", "slay Warlord"), ("Mother slain", "slay Mother"), ("Lich slain", "slay Lich"), ("Master slain", "slay Master"), ("Queen slain", "slay Queen"), ("the bottom", "reach D33"), ("waystone D14", "bank at D14"), ("waystone D19", "bank at D19"), ("waystone D24", "bank at D24"), ("waystone D29", "bank at D29"), ("party slots 3–4", "a fourth slot"),
            // (Cut 30.5, week 2: a wall wears down — each band boss's scars at ×3 and at the cap ×6, a day met each: the
            // progress a held record makes while it holds)
            ("Warlord scarred ×3", "3 days met"), ("Mother scarred ×3", "3 days met"), ("Lich scarred ×3", "3 days met"), ("Master scarred ×3", "3 days met"), ("Queen scarred ×3", "3 days met"), ("King scarred ×3", "3 days met"),
            ("Warlord scarred ×6", "6 days met"), ("Mother scarred ×6", "6 days met"), ("Lich scarred ×6", "6 days met"), ("Master scarred ×6", "6 days met"), ("Queen scarred ×6", "6 days met"), ("King scarred ×6", "6 days met")],
        "town" => &[("camp", ""), ("blacksmith", "four delves"), ("kennel", "tame a pet"), ("bank", "a night's purse")],
        _ => &[],
    }
}

pub const TRACKS: [&str; 4] = ["character", "items", "scale", "town"];

/// Whether a track's stage has come for this lineage.
pub fn reached(l: &LineageState, track: &str, stage: &str) -> bool {
    let met = |k: &str| l.pkg.meets.get(k).copied().unwrap_or(0) > 0 || l.facts.contains(&format!("foe:{k}")) || l.kills.contains(k);
    match (track, stage) {
        (_, "Steady" | "pack of 3" | "one hero" | "camp") => true,
        ("character", "second stance") => met("goblin_captain") || met("goblin_warlord"),
        ("character", "a tactic") | ("scale", "waystones") => l.kills.contains("goblin_warlord"),
        ("character", "pets") => l.facts.contains("stray") || l.all_companions().next().is_some(),
        ("character", "a class") => l.classes.iter().any(|(k, c)| k != "fighter" && (c.xp > 0 || c.level > 1)) || ["rogue", "ranger", "caster"].iter().any(|c| l.unlocks.contains(*c)),
        ("character", "a temperament") => crate::packages::temperament_open(l),
        ("character", "tactic slot 2") => crate::packages::tactic_slots(l) >= 2,
        ("character", "the pen") => l.pkg.pen_open,
        ("items", "blacksmith steps") => crate::kit::KIT_SLOTS.iter().any(|s| crate::kit::owned(l, s) > 0) || built(l, "blacksmith"),
        ("items", "a counter packed") => !crate::packages::quartermaster(l).is_empty() || l.pkg.drills.iter().any(|d| crate::packages::drill_item(d).is_some()),
        ("character", d) if d.ends_with(" drilled") => {
            let boss = match d.trim_end_matches(" drilled") {
                "Warlord" => "goblin_warlord",
                "Mother" => "bloat_mother",
                "Lich" => "lich",
                "Foundry" => "foundry_master",
                "Queen" => "lurker_queen",
                _ => "mirror_king",
            };
            l.pkg.drills.iter().any(|x| x.boss == boss)
        }
        ("scale", s) if s.ends_with(" slain") => {
            let boss = match s.trim_end_matches(" slain") {
                "Mother" => "bloat_mother",
                "Lich" => "lich",
                "Master" => "foundry_master",
                _ => "lurker_queen",
            };
            l.kills.contains(boss)
        }
        ("scale", w) if w.contains(" scarred ×") => {
            let (who, n) = w.split_once(" scarred ×").unwrap_or(("", "9"));
            let boss = match who {
                "Warlord" => "goblin_warlord",
                "Mother" => "bloat_mother",
                "Lich" => "lich",
                "Master" => "foundry_master",
                "Queen" => "lurker_queen",
                _ => "mirror_king",
            };
            l.pkg.meets.get(boss).copied().unwrap_or(0) >= n.parse().unwrap_or(99)
        }
        ("scale", w) if w.starts_with("waystone D") => w.trim_start_matches("waystone D").parse::<u32>().is_ok_and(|d| l.stones().contains(&d)),
        // (the King's floor: the descent's last band seen)
        ("scale", "the bottom") => l.best_depth >= crate::descent::BANDS[crate::descent::BANDS.len() - 1].1,
        ("scale", "party slot 2") => l.party_slots() >= 2,
        ("scale", "party slots 3–4") => l.party_slots() >= 4,
        ("town", b) => built(l, b),
        _ => false,
    }
}

/// The four tracks on the wire: each one's stage (the last reached in order), its next stage and
/// trigger, and progress toward it when the trigger is numeric.
pub fn tracks(l: &LineageState) -> Vec<TrackWire> {
    TRACKS
        .iter()
        .map(|t| {
            let st = stages(t);
            let done: Vec<bool> = st.iter().map(|(s, _)| reached(l, t, s)).collect();
            let stage = st.iter().zip(&done).filter(|(_, d)| **d).map(|((s, _), _)| *s).next_back().unwrap_or(st[0].0);
            let next = st.iter().zip(&done).find(|(_, d)| !**d).map(|((s, tr), _)| (*s, *tr));
            let progress = match next.map(|n| n.0) {
                Some("bank") => (l.last_night_net > 0).then(|| (l.gold as f64 / l.last_night_net as f64).clamp(0.0, 1.0)),
                Some("a temperament") => Some((l.heir as f64 / 3.0).min(1.0)),
                _ => None,
            };
            TrackWire { id: t.to_string(), stage: stage.into(), stages: done.iter().filter(|d| **d).count() as u32, next: next.map(|n| n.0.to_string()), trigger: next.map(|n| n.1.to_string()), progress }
        })
        .collect()
}

/// The stages reached on every track (for `grew`: a stage that opened between two looks).
pub fn stage_set(l: &LineageState) -> Vec<(String, String)> {
    let mut v = Vec::new();
    // (every package that arrives is a stage of the character's: a stance, a tactic of the drip, a
    // temperament — §2 "each arrives on a stage trigger")
    for id in l.pkg.owned.iter().filter(|id| crate::packages::def(id).is_some() && id.as_str() != "steady") {
        v.push(("character".to_string(), format!("+{}", crate::packages::name(id))));
    }
    // (a building stepped to its next look is a stage of the town's: the forge's steps, the bank's fill)
    for (b, _) in &l.town.built {
        for look in 2..=level(l, b) {
            v.push(("town".to_string(), format!("{b} look {look}")));
        }
    }
    for t in TRACKS {
        for (s, _) in stages(t) {
            if reached(l, t, s) {
                v.push((t.to_string(), s.to_string()));
            }
        }
    }
    // (Cut 30.5: the works tree replaces the tracks — a worker hired is a stage of the town's: `+apprentice`)
    if !l.pkg.literal {
        for (id, _) in &l.tree.hired {
            if let Some(n) = crate::tree::def(id).filter(|n| !n.chore.is_empty()) {
                v.push(("town".to_string(), format!("+{}", n.name)));
                // (week 2: each rank a worker reaches)
                for r in 2..=crate::tree::rank(l, id) {
                    v.push(("town".to_string(), format!("+{} {}", n.name, crate::tree::numeral(r))));
                }
            }
        }
    }
    v
}

/// A lineage's state as `grew` compares it (before and after an absence).
#[derive(Clone, Debug, Default, Serialize, Deserialize, PartialEq, Eq)]
pub struct Snap {
    pub xp: u64,
    pub class_level: u32,
    /// Each package's level (id, level).
    pub pkg_level: Vec<(String, u32)>,
    pub gold: i64,
    pub kit: u32,
    pub finds: usize,
    pub best: u32,
    pub party: usize,
    pub buildings: usize,
    pub bank: i32,
    pub stages: Vec<(String, String)>,
    pub drills: usize,
}

pub fn snap(l: &LineageState) -> Snap {
    Snap {
        xp: l.classes.values().map(|c| c.xp as u64 + 1000 * c.level as u64).sum(),
        class_level: l.class_level(),
        pkg_level: l.pkg.runs.keys().map(|k| (k.clone(), l.pkg.level(k))).collect(),
        gold: l.gold as i64 + l.town.bank as i64,
        kit: crate::kit::KIT_SLOTS.iter().map(|s| crate::kit::owned(l, s)).sum(),
        finds: l.vault.len() + l.found_kinds.len(),
        best: l.best_depth,
        party: l.all_companions().count(),
        buildings: l.town.built.len(),
        bank: l.town.bank,
        stages: stage_set(l),
        drills: l.pkg.drills.len(),
    }
}

/// What grew on each track between two snaps (the report leads with it). Per track, the most
/// important first — a new stage, a package that arrived, a level, then xp and gold — each fact once
/// (no `opened` prefix: the stage's name is the news; a stage another line already says is left out).
pub fn grew(a: &Snap, b: &Snap) -> Vec<GrewLine> {
    let new: Vec<&(String, String)> = b.stages.iter().filter(|s| !a.stages.contains(s)).collect();
    let has = |t: &str, s: &str| new.iter().any(|(tt, ss)| tt == t && ss == s);
    let arrived = new.iter().any(|(t, s)| t == "character" && s.starts_with('+'));
    let mut out: Vec<GrewLine> = Vec::new();
    for track in TRACKS {
        let mut add = |what: String| out.push(GrewLine { track: track.into(), what });
        // 1 · the stages (a package's arrival after them; its slot's stage is the same news)
        for (t, s) in new.iter().filter(|(t, s)| t == track && !s.starts_with('+')) {
            let said = match (t.as_str(), s.as_str()) {
                ("character", "second stance" | "a tactic" | "a temperament") => arrived,
                // (the town's row names the building)
                ("items", "blacksmith steps") => has("town", "blacksmith"),
                _ => false,
            };
            if !said {
                add(s.clone());
            }
        }
        match track {
            "character" => {
                for (_, s) in new.iter().filter(|(t, s)| t == "character" && s.starts_with('+')) {
                    add(s.clone());
                }
                if b.class_level > a.class_level {
                    add(format!("L{}", b.class_level));
                }
                for (id, lv) in &b.pkg_level {
                    if a.pkg_level.iter().find(|(k, _)| k == id).map_or(1, |(_, l)| *l) < *lv {
                        add(format!("{} L{lv}", crate::packages::name(id)));
                    }
                }
                if b.drills > a.drills && !new.iter().any(|(t, s)| t == "character" && s.ends_with(" drilled")) {
                    add("drilled".into());
                }
                if b.class_level <= a.class_level && b.xp > a.xp {
                    add("xp".into());
                }
            }
            "items" => {
                if b.gold > a.gold {
                    add(format!("+${}", b.gold - a.gold));
                }
                if b.finds > a.finds {
                    add("a find".into());
                }
                if b.kit > a.kit {
                    add("blacksmith step".into());
                }
            }
            "scale" => {
                if b.best > a.best {
                    add(format!("best D{}", b.best));
                }
                if b.party > a.party {
                    add("a companion".into());
                }
            }
            _ => {
                for (_, s) in new.iter().filter(|(t, s)| t == "town" && s.starts_with('+')) {
                    add(s.clone());
                }
                if b.bank > a.bank {
                    add("interest".into());
                }
            }
        }
    }
    out
}

/// The town on the wire.
pub fn build_blocked(l:&LineageState,id:&str)->Option<String>{
 if built(l,id)||triggered(l,id){return None;}
 if !l.town.home.unwrap_or(true){return Some("Build a house".into());}
 match id {"blacksmith"=>{if !crate::tree::hired(l,"scout"){Some("Hire Scout".into())}else if l.persistent.completed<4{Some(format!("Complete {} more delves",4-l.persistent.completed))}else if !triggered(l,id){Some("Secure Gold from a delve".into())}else{None}},"kennel"=>{if !crate::tree::hired(l,"scout"){Some("Hire Scout".into())}else if !triggered(l,id){Some("Tame a pet with a leash".into())}else{None}},_=>None}
}
pub fn wire(l: &LineageState) -> TownWire {
    let next = if !l.town.home.unwrap_or(true) { Some(("house".into(), String::new())) } else { BUILDINGS.iter().find(|(id, _)| !built(l, id)).map(|(id, tr)| (id.to_string(), build_blocked(l,id).unwrap_or_else(||tr.to_string()))) };
    TownWire {
        home: l.town.home.unwrap_or(true),
        auto_collect: l.town.auto_collect,
        buildings: l.town.built.iter().filter(|(id, _)| BUILDINGS.iter().any(|(active, _)| *active == id)).map(|(id, day)| crate::wire::BuildingWire { id: id.clone(), level: level(l, id), day: *day, trigger: BUILDINGS.iter().find(|b| b.0 == id).map(|b| b.1.to_string()).unwrap_or_default() }).collect(),
        next: next.as_ref().map(|n| n.0.clone()),
        next_ready: next.as_ref().is_some_and(|n| n.0 == "house" || triggered(l, &n.0)),
        next_trigger: next.map(|n| n.1),
        bank: l.town.bank,
        bank_cap: bank_cap(l),
        interest: l.town.interest,
        quest: l.town.quest.as_ref().map(|q| quest_wire(l, q)),
        quests_done: l.town.quests_done,
        workers: if l.pkg.literal { Vec::new() } else { crate::tree::posts(l) },
        forge_work: None,
    }
}

/// Cut 228: how long (ticks of the hero's clock) a forged step keeps the smith at the anvil: 45 s.
pub const FORGE_WORK_TICKS: u64 = 450;

/// Cut 228 (read model, no mutation): the Forge's present work among `games` (each hero's own game). A hero's own
/// ledger lines carry its own clock (`GoldLine.t` is its `total_turns`), so each line is aged against the clock of
/// the hero who paid it, and only while that clock moves (resting or delving): a waiting hero's clock stands, and a
/// stale line must not read as present work. The newest such step wins (one anvil).
pub fn forge_work<'a>(games: impl IntoIterator<Item = &'a crate::Game>) -> Option<crate::wire::ForgeWork> {
    let mut best: Option<(u64, crate::wire::ForgeWork)> = None;
    for g in games {
        let l = &g.lineage;
        if l.pkg.literal || !built(l, "blacksmith") || !l.town.home.unwrap_or(true) {
            continue;
        }
        let moving = l.rest_left > 0 || g.run.as_ref().is_some_and(|r| r.over.is_none());
        if !moving {
            continue;
        }
        let Some(line) = l.gold_ledger.iter().rev().find(|x| x.bloodline_id == l.bloodline_id && x.delta < 0 && x.why.starts_with("forge ")) else { continue };
        let age = l.total_turns.saturating_sub(line.t);
        if line.t > l.total_turns || age >= FORGE_WORK_TICKS {
            continue;
        }
        let left = FORGE_WORK_TICKS - age;
        if best.as_ref().is_none_or(|(a, _)| age < *a) {
            let step = line.why.trim_start_matches("forge ").trim_start_matches("commission ").to_string();
            best = Some((age, crate::wire::ForgeWork { step, hero: l.bloodline_id, left_s: left.div_ceil(crate::offline::TICKS_PER_SECOND) as u32 }));
        }
    }
    best.map(|b| b.1)
}

#[cfg(test)]
mod storage_retirement_tests {
    use super::*;
    use crate::{Game, meta, tree};

    #[test]
    fn retired_progression_is_absent_and_rejects_purchases_without_mutation() {
        let mut g = Game::new(201); g.build_town("house").unwrap();
        let saved = g.save();
        assert!(g.build_town("storehouse").is_err());
        for worker in ["keeper", "armourer"] {
            assert!(tree::def(worker).is_none());
            assert!(g.hire(worker).is_err());
            assert!(g.set_worker(worker, false).is_err());
        }
        for unlock in ["vault2", "vault3", "vault4", "vault5"] {
            assert!(meta::def(unlock).is_none());
            assert!(g.buy(unlock).is_err());
        }
        assert_eq!(g.save(), saved);
        assert!(!crate::engine::VARIANTS.contains(&"bones_only"));
        assert!(g.lineage().tree.unwrap().nodes.iter().all(|n| !matches!(n.id.as_str(), "keeper" | "armourer" | "town:storehouse" | "items:storehouse")));
        assert!(g.lineage().systems.iter().all(|s| s.id != "storehouse"));
    }

    #[test]
    fn remaining_plots_are_manual_and_storage_never_blocks_the_next_plot() {
        let mut g = Game::new(202); g.build_town("house").unwrap();
        // Diagnostic income and survivor prerequisites supply a trigger, not earned pacing evidence.
        crate::test_stage::traits(&mut g.lineage,4,1);
        g.lineage.gold_move(10, "returned D1");
        // (Cut232: the qualified plot is offered at a quiet report)
        assert_eq!(open_plot(&mut g.lineage), Some("blacksmith"));
        assert!(!built(&g.lineage, "blacksmith"));
        assert!(update(&mut g.lineage).is_empty());
        assert_eq!(wire(&g.lineage).next.as_deref(), Some("blacksmith"));
        g.build_town("blacksmith").unwrap();
        assert_eq!(wire(&g.lineage).next.as_deref(), Some("kennel"));
        assert!(!built(&g.lineage, "kennel"));
        assert!(!wire(&g.lineage).next_ready);
        assert!(g.build_town("kennel").is_err());
        assert!(stages("items").iter().chain(stages("town")).all(|(id, _)| *id != "storehouse"));
        assert!(["quartermaster", "scout", "apprentice"].iter().all(|id| tree::def(id).is_some()));
    }

    #[test]
    fn forge_work_is_a_read_model_of_a_real_recent_step_on_a_moving_clock() {
        let mut g = Game::new(204); g.build_town("house").unwrap();
        // Diagnostic trigger/income (as above): this tests the read model, not pacing.
        crate::test_stage::traits(&mut g.lineage,4,1);
        g.lineage.gold_move(10, "returned D1");
        open_plot(&mut g.lineage);
        g.build_town("blacksmith").unwrap();
        g.lineage.rest_left = 1000;
        assert_eq!(g.lineage().town.forge_work, None, "an owned Forge is no proof of work");
        g.lineage.gold_move(100_000, "returned D2");
        crate::kit::buy_step(&mut g.lineage, "weapon").unwrap();
        let before = g.save();
        let w = g.lineage().town.forge_work.expect("the step just forged");
        assert_eq!(before, g.save(), "reading the town never mutates");
        assert_eq!((w.hero, w.left_s), (1, 45));
        assert!(w.step.ends_with("+1"), "{}", w.step);
        // the same clock moves: 449 ticks on it still lasts; the 450th ends it
        assert_eq!(g.rest_tick(449), 449);
        assert_eq!(g.lineage().town.forge_work.map(|w| w.left_s), Some(1));
        g.rest_tick(1);
        assert_eq!(g.lineage().town.forge_work, None);
        // a standing clock (a hero waiting, no run) never shows stale work as present
        crate::kit::buy_step(&mut g.lineage, "weapon").unwrap();
        assert!(g.lineage().town.forge_work.is_some());
        g.lineage.rest_left = 0;
        assert!(g.run.is_none());
        assert_eq!(g.lineage().town.forge_work, None);
        let json = serde_json::to_string(&g.lineage().town).unwrap();
        assert!(!json.contains("forge_work"), "absent when idle: old wires and goldens unchanged");
    }

    #[test]
    fn inactive_storage_metadata_never_emits_a_building_or_worker_offer() {
        let mut g = Game::new(203); g.build_town("house").unwrap();
        // A diagnostic serialized state can retain old private metadata until API cleanup.
        g.lineage.town.built.push(("storehouse".into(), 0));
        g.lineage.tree.hired.push(("armourer".into(), 0));
        g.lineage.tree.hired.push(("keeper".into(), 0));
        assert!(!tree::on(&g.lineage, "armourer") && !tree::on(&g.lineage, "keeper"));
        let wire = g.lineage();
        assert!(wire.town.buildings.iter().all(|b| b.id != "storehouse"));
        assert!(wire.tree.unwrap().nodes.iter().all(|n| !matches!(n.id.as_str(), "keeper" | "armourer")));
        assert!(wire.town.workers.iter().all(|w| !matches!(w.id.as_str(), "keeper" | "armourer")));
        assert!(wire.keep_auto.is_empty());
    }
}

// ---------------------------------------------------------------- the quest board

/// A quest: one plain goal, a reward, progress (0..1), the day it was drawn. No stake.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct Quest {
    pub id: u32,
    /// `reach` · `reach_no_return` · `bank` · `slay`.
    pub goal: String,
    pub depth: u32,
    #[serde(default)]
    pub boss: Option<String>,
    /// The reward's picture (`title` · `row` · `slot` · `card`).
    pub reward: String,
    /// Best progress so far, permille.
    #[serde(default)]
    pub progress: u32,
    pub day: u32,
    #[serde(default)]
    pub done: bool,
}

/// The board opens with the Warlord slain.
pub fn quests_open(l: &LineageState) -> bool {
    l.kills.contains("goblin_warlord") && !l.town.off && !l.pkg.literal
}

/// The goal line, ≤ 5 words (`reach D10 · no return`).
pub fn goal_text(q: &Quest) -> String {
    match q.goal.as_str() {
        "reach_no_return" => format!("reach D{} · no return", q.depth),
        "bank" => format!("home from D{}", q.depth),
        "slay" => format!("slay the {}", crate::sifter::boss_short(q.boss.as_deref().unwrap_or(""))),
        _ => format!("reach D{}", q.depth),
    }
}

fn quest_wire(l: &LineageState, q: &Quest) -> QuestWire {
    QuestWire { goal: goal_text(q), reward: q.reward.clone(), progress: q.progress as f64 / 1000.0, done: q.done, swap: l.town.swap_day != Some(l.day) }
}

/// The rewards, in the order the board offers them (the first one the lineage can still take).
fn reward_for(l: &LineageState, seq: u32) -> String {
    let rows = ["row5", "row6", "row7", "row8", "row9", "row10"];
    let slots = ["party_slot_2", "party_slot_3", "party_slot_4"];
    let order = ["title", "row", "slot", "card"];
    for k in 0..order.len() {
        let r = order[(seq as usize + k) % order.len()];
        let ok = match r {
            "row" => rows.iter().any(|u| !l.unlocks.contains(*u)),
            "slot" => slots.iter().any(|u| !l.unlocks.contains(*u)),
            _ => true,
        };
        if ok {
            return r.into();
        }
    }
    "title".into()
}

/// Draw the next quest (deterministic on the lineage and its sequence): a goal just past the record
/// or at the next boss.
pub fn draw(l: &mut LineageState) {
    let seq = l.town.quest_seq;
    l.town.quest_seq += 1;
    let mut rng = crate::rng::Rng::derive(l.seed, crate::rng::hash_str("quest") ^ seq as u64);
    let best = l.best_depth.max(1);
    let next_boss = crate::descent::BOSS_DEPTHS.iter().find(|(k, d)| !l.kills.contains(*k) && *d <= best + 2 && *k != "foundry_master" && l.pkg.drills.iter().any(|x| x.boss == *k && !x.revoked)).map(|(k, _)| k.to_string());
    let goal = match (rng.below(4), &next_boss) {
        (0, Some(_)) => "slay",
        (0, None) | (1, _) => "reach",
        (2, _) => "reach_no_return",
        _ => "bank",
    };
    let depth = match goal {
        // (goals a night of the sends from D1 keeps: the record's band, not its last floor)
        "reach" => best.saturating_sub(3).max(2),
        "reach_no_return" => best.saturating_sub(5).max(2),
        // (a cleared floor: the deepest lit waystone at or under the record — banked there before — else three under it)
        "bank" => l.stones().into_iter().filter(|s| *s <= best).max().unwrap_or(best.saturating_sub(5)).max(2),
        _ => crate::descent::boss_depth(next_boss.as_deref().unwrap_or("")).unwrap_or(best),
    };
    let reward = reward_for(l, seq);
    let day = today(l);
    l.town.quest = Some(Quest { id: seq, goal: goal.into(), depth, boss: if goal == "slay" { next_boss } else { None }, reward, progress: 0, day, done: false });
}

/// The board's day: the lineage's, or a later one an absence has crossed.
pub fn today(l: &LineageState) -> u32 {
    l.day.max(l.town.today)
}

/// A new day on the board: a quest kept on an earlier day gives way to the day's draw (from the
/// record as it stands), as does an empty board.
pub fn roll(l: &mut LineageState) {
    if quests_open(l) && l.town.quest.as_ref().is_none_or(|q| q.done && q.day < today(l)) {
        draw(l);
    }
}

/// One free swap a day: a fresh quest in place of the one on the board.
pub fn swap(l: &mut LineageState) -> Result<(), String> {
    if !quests_open(l) {
        return Err("no board yet".into());
    }
    if l.town.swap_day == Some(l.day) {
        return Err("swapped today".into());
    }
    l.town.swap_day = Some(l.day);
    draw(l);
    Ok(())
}

/// A run's progress on the quest (`max_depth`, the exit, whether a return was committed, the bosses
/// it slew); a kept quest pays its reward. The line for the report (`QUEST DONE`), if kept now.
pub fn on_run(l: &mut LineageState, max_depth: u32, tier: crate::engine::ExitTier, returned: bool, _exit_depth: u32, slew: &[String]) -> Option<String> {
    if !quests_open(l) {
        return None;
    }
    // a new quest the day after one was kept (or at the board's first look)
    roll(l);
    let day = today(l);
    let q = l.town.quest.as_mut()?;
    if q.done {
        return None;
    }
    let depth = q.depth.max(1);
    let (p, kept) = match q.goal.as_str() {
        "reach" => ((max_depth * 1000 / depth).min(1000), max_depth >= depth),
        "reach_no_return" => (if returned { 0 } else { (max_depth * 1000 / depth).min(1000) }, !returned && max_depth >= depth),
        // (home from a cleared floor: a bank or a return that reached it)
        "bank" => ((max_depth * 1000 / depth).min(999), tier != crate::engine::ExitTier::Death && max_depth >= depth),
        _ => {
            let b = q.boss.clone().unwrap_or_default();
            ((max_depth * 900 / depth).min(900), slew.contains(&b))
        }
    };
    q.progress = q.progress.max(if kept { 1000 } else { p });
    if !kept {
        return None;
    }
    q.done = true;
    q.day = day;
    let reward = q.reward.clone();
    let text = goal_text(q);
    l.town.quests_done += 1;
    grant(l, &reward, &text);
    Some(format!("QUEST DONE · {text}"))
}

fn grant(l: &mut LineageState, reward: &str, text: &str) {
    match reward {
        "row" => {
            if let Some(u) = ["row5", "row6", "row7", "row8", "row9", "row10"].iter().find(|u| !l.unlocks.contains(**u)) {
                l.unlocks.insert(u.to_string());
            }
        }
        "slot" => {
            if let Some(u) = ["party_slot_2", "party_slot_3", "party_slot_4"].iter().find(|u| !l.unlocks.contains(**u)) {
                l.unlocks.insert(u.to_string());
            }
        }
        "card" => {
            let id = l.pkg.stance.clone();
            let runs = l.pkg.runs.entry(id).or_insert(0);
            *runs = crate::packages::next_at(*runs).unwrap_or(*runs);
        }
        _ => {
            l.titles.push(text.to_string());
            l.marks += 2;
        }
    }
}
